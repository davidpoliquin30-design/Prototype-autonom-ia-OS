import { useState, useEffect, useCallback } from "react";
import { quantumStateTracker, StateFrame } from "../memory/QuantumStateTracker";

/**
 * Hook d'intégration pour la mémoire quantique.
 */
export function useQuantumMemory<T>(module: string, initialState: T) {
  const [state, setState] = useState<T>(initialState);

  // Restauration à chaud lors du montage
  useEffect(() => {
    quantumStateTracker.getLatestState().then((frame: StateFrame | null) => {
      if (frame && frame.module === module) {
        setState(frame.data as T);
      }
    });
  }, [module]);

  // Enregistrement réactif (sauvegarde temps réel)
  const setQuantumState = useCallback((newState: T | ((prev: T) => T)) => {
    setState((prevState) => {
      const updatedState = typeof newState === 'function' 
        ? (newState as (prev: T) => T)(prevState) 
        : newState;
      
      // Persistance asynchrone $\psi_{QMEM}$
      quantumStateTracker.capture(module, updatedState as Record<string, any>);
      
      return updatedState;
    });
  }, [module]);

  return [state, setQuantumState] as const;
}
