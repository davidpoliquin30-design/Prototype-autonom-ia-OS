import { useState, useEffect, useCallback } from "react";
import { agentMeshHub, AgentInfo, SynapticMessage } from "../services/agentMeshHub";

export interface CanvasElement {
  id: string;
  type: "node" | "flux" | "text" | "shield";
  x: number;
  y: number;
  label: string;
  color: string;
  intensity: number; // 0 to 1
}

export function useUnifiedAgentEngine() {
  const [agents, setAgents] = useState<AgentInfo[]>([]);
  const [logs, setLogs] = useState<SynapticMessage[]>([]);
  const [isTransmitting, setIsTransmitting] = useState<boolean>(false);
  const [coherenceScore, setCoherenceScore] = useState<number>(94.8);
  const [systemLoad, setSystemLoad] = useState<number>(41.2);
  const [activeSignalPath, setActiveSignalPath] = useState<{ sender: string; receiver: string } | null>(null);
  
  // Real-time canvas representation coordinates and objects
  const [canvasElements, setCanvasElements] = useState<CanvasElement[]>([]);

  // Reload agents and logs
  const reloadEngineState = useCallback(() => {
    const freshAgents = agentMeshHub.getAgents();
    const freshLogs = agentMeshHub.getLogs();
    setAgents(freshAgents);
    setLogs(freshLogs);

    // Synchronize canvas representation from active agent nodes
    const elements: CanvasElement[] = freshAgents.map((ag, idx) => {
      // Circle coordinates representing poles on a elegant futuristic geometric path
      const angle = (idx / freshAgents.length) * 2 * Math.PI;
      const radius = 180; // inside the 16:9 box
      const centerX = 960 / 2; // 16:9 virtual width
      const centerY = 540 / 2; // 16:9 virtual height
      
      let color = "#f97316"; // orange default
      if (ag.pole === "direction") color = "#3b82f6"; // blue
      if (ag.pole === "gouvernance") color = "#ef4444"; // red
      if (ag.pole === "optimisation") color = "#10b981"; // green
      if (ag.pole === "code") color = "#a855f7"; // purple

      return {
        id: ag.id,
        type: "node",
        x: centerX + Math.cos(angle) * radius,
        y: centerY + Math.sin(angle) * radius,
        label: ag.name,
        color,
        intensity: ag.status === "online" ? 1.0 : 0.4
      };
    });

    setCanvasElements(elements);
  }, []);

  useEffect(() => {
    reloadEngineState();
    const unsubscribe = agentMeshHub.subscribe(reloadEngineState);
    return () => unsubscribe();
  }, [reloadEngineState]);

  // Execute a transaction through the synaptic conduit
  const executeTransaction = useCallback(async (
    sender: string,
    receiver: string,
    input: string
  ) => {
    setIsTransmitting(true);
    setActiveSignalPath({ sender, receiver });
    
    // Smooth transition simulation for physical and cognitive steps
    setSystemLoad(prev => Math.min(95, prev + 12));
    
    try {
      const result = await agentMeshHub.routeConduitTransaction(sender, receiver, input);
      
      // Dynamic coherence adaptation
      setCoherenceScore(prev => {
        const base = result.invariantsViolated ? prev - 2.5 : prev + 0.8;
        return Math.max(70, Math.min(100, base));
      });

      return result;
    } finally {
      setIsTransmitting(false);
      setActiveSignalPath(null);
      setSystemLoad(prev => Math.max(30, prev - 10));
    }
  }, []);

  return {
    agents,
    logs,
    isTransmitting,
    coherenceScore,
    systemLoad,
    activeSignalPath,
    canvasElements,
    executeTransaction,
    reloadEngineState
  };
}
