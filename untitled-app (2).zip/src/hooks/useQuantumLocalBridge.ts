import { useEffect, useState, useCallback } from 'react';
import { geometricBuffer, GeometricTuple } from '../memory/GeometricExecutionBuffer';

export const useQuantumLocalBridge = () => {
  const [isLocalServerOnline, setIsLocalServerOnline] = useState<boolean>(false);
  const [activeModel, setActiveModel] = useState<string>('qwen2.5-coder:7b');
  const [executionStack, setExecutionStack] = useState<GeometricTuple[]>([]);

  // Heartbeat automatique vers le serveur GPU local (http://localhost:11434)
  const checkLocalServerHeartbeat = useCallback(async () => {
    try {
      const response = await fetch('http://localhost:11434/api/tags', { method: 'GET' });
      if (response.ok) {
        const data = await response.json();
        setIsLocalServerOnline(true);
        if (data.models && data.models.length > 0) {
          setActiveModel(data.models[0].name);
        }
      } else {
        setIsLocalServerOnline(false);
      }
    } catch {
      setIsLocalServerOnline(false);
    }
  }, []);

  useEffect(() => {
    checkLocalServerHeartbeat();
    const interval = setInterval(checkLocalServerHeartbeat, 5000);
    return () => clearInterval(interval);
  }, [checkLocalServerHeartbeat]);

  // Injection d'une instruction dans la mémoire géométrique tampon (Plan ALPHA)
  const pushLocalInstruction = async (
    moduleId: string,
    x: number,
    y: number,
    rotation: number = 0,
    scale: number = 1.0
  ) => {
    const timestamp = Date.now();
    const newTuple: GeometricTuple = [moduleId, x, y, rotation, scale, timestamp];
    
    await geometricBuffer.push(newTuple);
    setExecutionStack((prev) => [...prev, newTuple]);
  };

  return {
    isLocalServerOnline,
    activeModel,
    executionStack,
    pushLocalInstruction,
  };
};
