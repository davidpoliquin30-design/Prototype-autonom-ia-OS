import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { autoRepairSystemEngine } from "./services/agents/autoRepairSystemEngine";

window.addEventListener("error", (event) => {
  autoRepairSystemEngine.reportRuntimeAnomaly({
    source: "runtime_exception",
    message: event.message,
    filename: event.filename,
    lineno: event.lineno,
    colno: event.colno,
    error: event.error,
    severity: "high"
  });
});

window.addEventListener("unhandledrejection", (event) => {
  autoRepairSystemEngine.reportRuntimeAnomaly({
    source: "unhandled_promise",
    message: event.reason?.message || "Promesse rejetée non gérée",
    error: event.reason,
    severity: "medium"
  });
});

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
