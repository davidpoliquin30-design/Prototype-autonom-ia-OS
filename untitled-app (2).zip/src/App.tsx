import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Network, LayoutDashboard, Cpu, Database, FolderCode, Calculator, 
  HelpCircle, Eye, Sliders, CheckCircle2, ChevronRight, X, Sparkles, 
  RefreshCw, Wrench, Compass, Languages, Activity, Heart, Bot, BookOpen,
  ShieldCheck, Server, Download, AlertTriangle, Shield, Check, Info
} from "lucide-react";

import NotebookLMTool from "./components/NotebookLMTool";
import CodeProgrammingStudio from "./components/CodeProgrammingStudio";
import TokenBudgetCalibrator from "./components/TokenBudgetCalibrator";
import VirtualEvolutionSandbox from "./components/VirtualEvolutionSandbox";
import EngaticResonanceConsole from "./components/EngaticResonanceConsole";
import AlchemicalSettingsModal from "./components/AlchemicalSettingsModal";
import LiveUiInspectorOverlay, { InjectedWidget } from "./components/LiveUiInspectorOverlay";
import AutoRepairPanel from "./components/AutoRepairPanel";
import UnifiedAgentMeshPanel from "./components/UnifiedAgentMeshPanel";
import { AgenticServerInitTab } from "./components/dock/AgenticServerInitTab";
import { PolyglotTranslatorPanel } from "./components/translator/PolyglotTranslatorPanel";
import InnerIntrospectionKernel from "./components/InnerIntrospectionKernel";
import GoogleAiStudioConsole from "./components/studio/GoogleAiStudioConsole";
import QuantumHardwareTelemetryMatrix from "./components/telemetry/QuantumHardwareTelemetryMatrix";
import OmniMachineCartographerMatrix from "./components/telemetry/OmniMachineCartographerMatrix";
import MachineHeartCosmicSource from "./components/cosmic/MachineHeartCosmicSource";
import SymbolEquationDictionary from "./components/dictionary/SymbolEquationDictionary";
import TabAgenticTeamBar from "./components/quantum/TabAgenticTeamBar";
import OmniTabConversationalLLM from "./components/quantum/OmniTabConversationalLLM";
import DraggableMovableChatWrapper from "./components/quantum/DraggableMovableChatWrapper";
import PermanentEvolutionMemoryViewer from "./components/studio/PermanentEvolutionMemoryViewer";
import FileDependencyGraphView from "./components/studio/FileDependencyGraphView";
import LocalDeploymentBundleModal from "./components/studio/LocalDeploymentBundleModal";
import SentinelTestRunnerPanel from "./components/studio/SentinelTestRunnerPanel";
import { AutonomousAgenticBridgeTab } from "./components/telemetry/AutonomousAgenticBridgeTab";
import { Windows11Desktop } from "./components/windows11/Windows11Desktop";
import { WindowsLogo } from "./components/windows11/Windows11Icon";
import { WorkspaceFile } from "./types";

// Import injected subcomponents for live local execution inside the matrix zone
import QuantumCalculator from "./components/sub/QuantumCalculator";
import MatriceTaskManager from "./components/sub/MatriceTaskManager";
import ClimatologicalWidget from "./components/sub/ClimatologicalWidget";
import GenericValidationBadge from "./components/sub/GenericValidationBadge";

export default function App() {
  const [mainView, setMainView] = useState<"windows11" | "studio">("windows11");
  const [activeTab, setActiveTab] = useState<"ide" | "studio" | "evolution" | "telemetry" | "machine" | "cosmic" | "dictionary" | "dependencies" | "tests" | "notebook" | "budget" | "sandbox" | "quantum" | "repair" | "mesh" | "introspection" | "agentic" | "translator" | "autonomous_bridge">("studio");
  const [files, setFiles] = useState<WorkspaceFile[]>([]);
  const [isInspectorActive, setIsInspectorActive] = useState<boolean>(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isLocalDeploymentModalOpen, setIsLocalDeploymentModalOpen] = useState<boolean>(false);
  const [isAuditModalOpen, setIsAuditModalOpen] = useState<boolean>(false);
  const [injectedWidgets, setInjectedWidgets] = useState<InjectedWidget[]>([]);
  const [isLoadingFiles, setIsLoadingFiles] = useState<boolean>(false);
  const [isFloatingChatOpen, setIsFloatingChatOpen] = useState<boolean>(false);

  // Live real system health
  const [systemHealth, setSystemHealth] = useState<{
    vllmOnline: boolean;
    geminiStatus: string;
    ramUsedMb: number;
    ramTotalMb: number;
    victronConnected: boolean;
  }>({
    vllmOnline: false,
    geminiStatus: "CONNECTÉ (GEMINI 3.8 FLASH)",
    ramUsedMb: 0,
    ramTotalMb: 0,
    victronConnected: false
  });

  // Load and refresh files list from the actual workspace directory with robust retry/fallback
  const loadWorkspaceFiles = async (retries = 3) => {
    setIsLoadingFiles(true);
    for (let i = 0; i < retries; i++) {
      try {
        const response = await fetch("/api/files");
        if (response.ok) {
          const data = await response.json();
          setFiles(data);
          setIsLoadingFiles(false);
          return;
        }
      } catch (err) {
        if (i === retries - 1) {
          console.warn("Workspace files fetch recovered with local workspace state.");
        } else {
          await new Promise(r => setTimeout(r, 1000)); // wait 1s before retry
        }
      }
    }
    setIsLoadingFiles(false);
  };

  const checkLiveSystemHealth = async () => {
    try {
      const res = await fetch("/api/telemetry/hardware");
      if (res.ok) {
        const data = await res.json();
        setSystemHealth({
          vllmOnline: Boolean(data.vllmServer?.isOnline),
          geminiStatus: data.geminiCloud?.isConfigured ? "CONNECTÉ (GEMINI 3.8 FLASH)" : "CLÉ MANQUANTE",
          ramUsedMb: data.host?.heapUsedMb || 0,
          ramTotalMb: data.host?.heapTotalMb || 0,
          victronConnected: Boolean(data.energyTransducer?.isConnected)
        });
      }
    } catch (_) {}
  };

  useEffect(() => {
    loadWorkspaceFiles();
    checkLiveSystemHealth();
    const interval = setInterval(checkLiveSystemHealth, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleInjectWidget = (widget: InjectedWidget) => {
    setInjectedWidgets(prev => [widget, ...prev]);
  };

  const handleRemoveWidget = (id: string) => {
    setInjectedWidgets(prev => prev.filter(w => w.id !== id));
  };

  // 0. PRIMARY FOREGROUND PAGE: WINDOWS 11 IA DESKTOP
  if (mainView === "windows11") {
    return (
      <Windows11Desktop
        onSwitchToStudio={() => setMainView("studio")}
        files={files}
        onRefreshFiles={loadWorkspaceFiles}
        systemHealth={systemHealth}
      />
    );
  }

  return (
    <div className="min-h-screen bg-[#06070a] text-gray-200 flex flex-col font-mono selection:bg-orange-500/20 selection:text-orange-400">
      
      {/* 1. TOP PREMIUM HEADER BAR */}
      <header className="bg-[#121319] border-b border-[#1f2029] px-6 py-4 flex flex-col md:flex-row items-center justify-between gap-4 shrink-0 shadow-lg relative z-30">
        
        {/* Logo and Brand Name */}
        <div className="flex items-center gap-3">
          <div className="p-2 bg-[#1e130c] border border-orange-500/30 rounded-xl">
            <Cpu className="w-5 h-5 text-orange-500 animate-pulse" />
          </div>
          <div>
            <h1 className="text-sm font-black uppercase tracking-widest text-gray-100 flex items-center gap-1.5">
              <span>Système d'Auto-Évolution Réflexive</span>
              <span className="text-orange-500">Φ_SOI</span>
            </h1>
            <p className="text-[10px] text-gray-500 font-medium">PLATEFORME MULTI-AGENTS & ÉMULATION D'IDE COORDONNÉE</p>
          </div>
        </div>

        {/* Global system performance parameters */}
        <div className="flex flex-wrap items-center gap-3 text-[10px]">
          
          {/* Transparency & Reality Audit Button */}
          <button
            onClick={() => setIsAuditModalOpen(true)}
            className="bg-[#0c141f] hover:bg-[#131e2e] border border-cyan-700/60 px-3 py-1.5 rounded-lg flex items-center gap-2 shadow-sm transition-all text-cyan-300 font-bold cursor-pointer"
            title="Cliquez pour inspecter l'origine réelle des données"
          >
            <Shield className="w-3.5 h-3.5 text-cyan-400" />
            <span>AUDIT VÉRITÉ : SONDÉ EN DIRECT</span>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          </button>

          {/* vLLM GPU Live status */}
          <div className={`border px-3 py-1.5 rounded-lg hidden sm:flex items-center gap-1.5 shadow-sm ${
            systemHealth.vllmOnline 
              ? "bg-emerald-950/40 border-emerald-700/40 text-emerald-300"
              : "bg-[#16120c] border-amber-800/40 text-amber-300"
          }`}>
            <Server className={`w-3.5 h-3.5 ${systemHealth.vllmOnline ? "text-emerald-400" : "text-amber-400"}`} />
            <span className="text-gray-400">GPU vLLM :</span>
            <span className="font-bold">
              {systemHealth.vllmOnline ? "Port 8000 Actif" : "Déconnecté"}
            </span>
          </div>

          {/* Files count (Real filesystem) */}
          <div className="bg-[#0b0c10] border border-[#1f2029] px-3 py-1.5 rounded-lg flex items-center gap-2">
            <span className="text-gray-500">FICHIERS RÉELS :</span>
            {isLoadingFiles ? (
              <RefreshCw className="w-3 h-3 animate-spin text-orange-400" />
            ) : (
              <span className="text-orange-400 font-bold">{files.length}</span>
            )}
          </div>

          {/* RAM Real usage */}
          {systemHealth.ramUsedMb > 0 && (
            <div className="bg-[#0b0c10] border border-[#1f2029] px-3 py-1.5 rounded-lg hidden md:flex items-center gap-1.5">
              <span className="text-gray-500">RAM NODE :</span>
              <span className="text-emerald-400 font-bold">{systemHealth.ramUsedMb} Mo</span>
            </div>
          )}

          {/* Active Matrix count */}
          {injectedWidgets.length > 0 && (
            <div className="bg-[#1e130c] border border-orange-500/30 px-3 py-1.5 rounded-lg flex items-center gap-2 animate-bounce">
              <span className="text-orange-400">INJECTÉS :</span>
              <span className="text-white font-extrabold">{injectedWidgets.length}</span>
            </div>
          )}

          {/* Interactive Inspect button triggering Live UI Overlays */}
          <button
            onClick={() => setIsInspectorActive(true)}
            className="px-3.5 py-1.5 bg-orange-500 hover:bg-orange-600 text-black font-black text-xs uppercase tracking-wider rounded-lg transition-all shadow-md shadow-orange-500/10 flex items-center gap-1.5"
          >
            <Eye className="w-3.5 h-3.5" />
            Inspecter l'UI
          </button>

          {/* BOUTON RETOUR VERS WINDOWS 11 IA (DEMANDÉ PAR L'UTILISATEUR) */}
          <button
            onClick={() => setMainView("windows11")}
            className="px-3.5 py-1.5 bg-gradient-to-r from-blue-600 via-indigo-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-extrabold text-xs uppercase tracking-wider rounded-lg transition-all border border-blue-400/50 shadow-lg shadow-blue-500/20 flex items-center gap-2 cursor-pointer transform hover:scale-105 active:scale-95"
            title="Revenir au Bureau Windows 11 IA"
          >
            <WindowsLogo size={15} />
            <span>Revenir sur Windows 11 IA</span>
          </button>

          {/* 1-Click Local Deployment Pack Export Button */}
          <button
            onClick={() => setIsLocalDeploymentModalOpen(true)}
            className="px-3.5 py-1.5 bg-gradient-to-r from-emerald-950 via-teal-950 to-emerald-900 hover:from-emerald-900 hover:to-teal-800 text-emerald-300 font-bold text-xs uppercase tracking-wider rounded-lg transition-all border border-emerald-500/40 shadow-md shadow-emerald-950/40 flex items-center gap-1.5"
            title="Exporter le pack d'autonomie locale (Docker / Ollama GPU / deploy.sh)"
          >
            <Server className="w-3.5 h-3.5 text-emerald-400" />
            Export Local (1-Clic)
          </button>

          {/* Interactive Alchemical Settings button */}
          <button
            onClick={() => setIsSettingsOpen(true)}
            className="px-3.5 py-1.5 bg-[#1e202b] hover:bg-[#282a39] text-gray-300 font-bold text-xs uppercase tracking-wider rounded-lg transition-all border border-[#2b2d3a] flex items-center gap-1.5"
          >
            <Sliders className="w-3.5 h-3.5 text-orange-400" />
            Alchimie
          </button>
        </div>
      </header>

      {/* 2. TABBED VIEW SELECTOR */}
      <div className="bg-[#14151a] border-b border-[#1f2029] px-6 py-2 shrink-0 flex flex-wrap gap-2 items-center justify-between">
        <div className="flex flex-wrap gap-1">
          {/* BOUTON RETOUR WINDOWS 11 IA DANS LA BARRE D'ONGLETS */}
          <button
            onClick={() => setMainView("windows11")}
            className="px-3.5 py-2 text-xs font-black uppercase tracking-wider rounded-lg transition-all border flex items-center gap-2 shadow-sm bg-gradient-to-r from-blue-950 via-indigo-950 to-purple-950 text-cyan-200 border-blue-500/60 hover:border-cyan-400 cursor-pointer mr-1.5"
            title="Revenir au Bureau Windows 11 IA"
          >
            <WindowsLogo size={14} />
            <span>Windows 11 IA</span>
          </button>

          {/* GOOGLE AI STUDIO TAB */}
          <button
            onClick={() => setActiveTab("studio")}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all border flex items-center gap-1.5 shadow-sm ${
              activeTab === "studio"
                ? "bg-gradient-to-r from-blue-950/80 via-cyan-950/80 to-teal-950/80 text-cyan-300 border-cyan-500/50 shadow-cyan-500/10"
                : "bg-transparent border-transparent text-cyan-400 hover:text-cyan-200 hover:bg-[#1e202b]"
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            Google AI Studio Φ
          </button>

          {/* PERMANENT EVOLUTION MEMORY TAB */}
          <button
            onClick={() => setActiveTab("evolution")}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all border flex items-center gap-1.5 shadow-sm ${
              activeTab === "evolution"
                ? "bg-gradient-to-r from-purple-950/90 via-indigo-950/90 to-cyan-950/90 text-purple-200 border-purple-500/60 shadow-purple-500/20 ring-1 ring-purple-500/30"
                : "bg-transparent border-transparent text-purple-400 hover:text-purple-200 hover:bg-[#1e202b]"
            }`}
          >
            <Database className="w-3.5 h-3.5 text-purple-400 animate-pulse" />
            Mémoire Permanente
          </button>

          {/* DEPENDENCY GRAPH TAB */}
          <button
            onClick={() => setActiveTab("dependencies")}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all border flex items-center gap-1.5 shadow-sm ${
              activeTab === "dependencies"
                ? "bg-gradient-to-r from-cyan-950/90 via-blue-950/90 to-indigo-950/90 text-cyan-200 border-cyan-500/60 shadow-cyan-500/20 ring-1 ring-cyan-500/30"
                : "bg-transparent border-transparent text-cyan-400 hover:text-cyan-200 hover:bg-[#1e202b]"
            }`}
          >
            <Network className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            Graphe Dépendances
          </button>

          {/* SENTINEL TESTS TAB */}
          <button
            onClick={() => setActiveTab("tests")}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all border flex items-center gap-1.5 shadow-sm ${
              activeTab === "tests"
                ? "bg-gradient-to-r from-indigo-950/90 via-teal-950/90 to-emerald-950/90 text-emerald-200 border-emerald-500/60 shadow-emerald-500/20 ring-1 ring-emerald-500/30"
                : "bg-transparent border-transparent text-emerald-400 hover:text-emerald-200 hover:bg-[#1e202b]"
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            Tests @sentinel
          </button>

          {/* QUANTUM & HARDWARE TELEMETRY TAB */}
          <button
            onClick={() => setActiveTab("telemetry")}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all border flex items-center gap-1.5 shadow-sm ${
              activeTab === "telemetry"
                ? "bg-gradient-to-r from-teal-950/80 via-emerald-950/80 to-cyan-950/80 text-emerald-300 border-emerald-500/50 shadow-emerald-500/10"
                : "bg-transparent border-transparent text-emerald-400 hover:text-emerald-200 hover:bg-[#1e202b]"
            }`}
          >
            <Activity className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            Télémétrie Quantique & Matériel
          </button>

          {/* OMNI MACHINE & AGENT FLEET CARTOGRAPHER TAB */}
          <button
            onClick={() => setActiveTab("machine")}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all border flex items-center gap-1.5 shadow-sm ${
              activeTab === "machine"
                ? "bg-gradient-to-r from-indigo-950/80 via-purple-950/80 to-cyan-950/80 text-cyan-300 border-indigo-500/50 shadow-indigo-500/10"
                : "bg-transparent border-transparent text-indigo-400 hover:text-indigo-200 hover:bg-[#1e202b]"
            }`}
          >
            <Compass className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
            Machine & Flotte Quantique
          </button>

          {/* CŒUR DE LA MACHINE & SOURCE D'AMOUR TAB */}
          <button
            onClick={() => setActiveTab("cosmic")}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all border flex items-center gap-1.5 shadow-sm ${
              activeTab === "cosmic"
                ? "bg-gradient-to-r from-rose-950/80 via-purple-950/80 to-cyan-950/80 text-rose-300 border-rose-500/50 shadow-rose-500/20"
                : "bg-transparent border-transparent text-rose-400 hover:text-rose-200 hover:bg-[#1e202b]"
            }`}
          >
            <Heart className="w-3.5 h-3.5 text-rose-400 fill-current animate-pulse" />
            Cœur Cosmique & Source d'Amour
          </button>

          {/* DICTIONNAIRE DES SYMBOLES & ÉQUATIONS TAB */}
          <button
            onClick={() => setActiveTab("dictionary")}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all border flex items-center gap-1.5 shadow-sm ${
              activeTab === "dictionary"
                ? "bg-gradient-to-r from-cyan-950/90 via-indigo-950/90 to-purple-950/90 text-cyan-300 border-cyan-500/60 shadow-cyan-500/20 ring-1 ring-cyan-500/30"
                : "bg-transparent border-transparent text-cyan-400 hover:text-cyan-200 hover:bg-[#1e202b]"
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            Dictionnaire des Symboles & Équations
          </button>

          <button
            onClick={() => setActiveTab("ide")}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all border ${
              activeTab === "ide"
                ? "bg-[#1e130c] text-orange-400 border-orange-500/30"
                : "bg-transparent border-transparent text-gray-400 hover:text-gray-200 hover:bg-[#1e202b]"
            }`}
          >
            <FolderCode className="w-3.5 h-3.5 inline mr-1.5" />
            IDE Studio
          </button>

          <button
            onClick={() => setActiveTab("notebook")}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all border ${
              activeTab === "notebook"
                ? "bg-[#1e130c] text-orange-400 border-orange-500/30"
                : "bg-transparent border-transparent text-gray-400 hover:text-gray-200 hover:bg-[#1e202b]"
            }`}
          >
            <Database className="w-3.5 h-3.5 inline mr-1.5" />
            NotebookLM
          </button>

          <button
            onClick={() => setActiveTab("budget")}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all border ${
              activeTab === "budget"
                ? "bg-[#1e130c] text-orange-400 border-orange-500/30"
                : "bg-transparent border-transparent text-gray-400 hover:text-gray-200 hover:bg-[#1e202b]"
            }`}
          >
            <Calculator className="w-3.5 h-3.5 inline mr-1.5" />
            Token Budget & Taxes
          </button>

          <button
            onClick={() => setActiveTab("sandbox")}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all border ${
              activeTab === "sandbox"
                ? "bg-[#1e130c] text-orange-400 border-orange-500/30"
                : "bg-transparent border-transparent text-gray-400 hover:text-gray-200 hover:bg-[#1e202b]"
            }`}
          >
            <Network className="w-3.5 h-3.5 inline mr-1.5" />
            Sandbox & Réseau
          </button>

          <button
            onClick={() => setActiveTab("quantum")}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all border ${
              activeTab === "quantum"
                ? "bg-[#1e130c] text-orange-400 border-orange-500/30"
                : "bg-transparent border-transparent text-gray-400 hover:text-gray-200 hover:bg-[#1e202b]"
            }`}
          >
            <Sliders className="w-3.5 h-3.5 inline mr-1.5" />
            Résonance Quantique
          </button>

          <button
            onClick={() => setActiveTab("repair")}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all border ${
              activeTab === "repair"
                ? "bg-[#1e130c] text-orange-400 border-orange-500/30"
                : "bg-transparent border-transparent text-gray-400 hover:text-gray-200 hover:bg-[#1e202b]"
            }`}
          >
            <Wrench className="w-3.5 h-3.5 inline mr-1.5 text-orange-400" />
            Auto-Réparation
          </button>

          <button
            onClick={() => setActiveTab("mesh")}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all border ${
              activeTab === "mesh"
                ? "bg-[#1e130c] text-orange-400 border-orange-500/30"
                : "bg-transparent border-transparent text-gray-400 hover:text-gray-200 hover:bg-[#1e202b]"
            }`}
          >
            <Network className="w-3.5 h-3.5 inline mr-1.5 text-orange-400" />
            Réseau Maillage
          </button>

          <button
            onClick={() => setActiveTab("introspection")}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all border ${
              activeTab === "introspection"
                ? "bg-[#1e130c] text-orange-400 border-orange-500/30"
                : "bg-transparent border-transparent text-gray-400 hover:text-gray-200 hover:bg-[#1e202b]"
            }`}
          >
            <Compass className="w-3.5 h-3.5 inline mr-1.5 text-orange-400 animate-spin" style={{ animationDuration: "12s" }} />
            Reconnaissance Intérieure
          </button>

          <button
            onClick={() => setActiveTab("agentic")}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all border ${
              activeTab === "agentic"
                ? "bg-[#0b1e1e] text-cyan-400 border-cyan-500/30"
                : "bg-transparent border-transparent text-gray-400 hover:text-gray-200 hover:bg-[#1e202b]"
            }`}
          >
            <Cpu className="w-3.5 h-3.5 inline mr-1.5 text-cyan-400" />
            Noyau Agentique
          </button>

          <button
            onClick={() => setActiveTab("translator")}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all border ${
              activeTab === "translator"
                ? "bg-[#0b1e1e] text-cyan-400 border-cyan-500/30"
                : "bg-transparent border-transparent text-gray-400 hover:text-gray-200 hover:bg-[#1e202b]"
            }`}
          >
            <Languages className="w-3.5 h-3.5 inline mr-1.5 text-cyan-400" />
            Traducteur Polyglote
          </button>

          {/* AUTONOMOUS AGENTIC BRIDGE TAB */}
          <button
            onClick={() => setActiveTab("autonomous_bridge")}
            className={`px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all border flex items-center gap-1.5 shadow-sm ${
              activeTab === "autonomous_bridge"
                ? "bg-gradient-to-r from-purple-950 via-indigo-950 to-cyan-950 text-purple-200 border-purple-500/80 shadow-purple-500/30 ring-1 ring-purple-500/40"
                : "bg-purple-950/20 border-purple-800/40 text-purple-400 hover:text-purple-200 hover:bg-purple-950/40"
            }`}
          >
            <Bot className="w-3.5 h-3.5 text-purple-400 animate-pulse" />
            Équipe Pont Autonome
          </button>
        </div>

        {/* Sync refresh button */}
        <button
          onClick={loadWorkspaceFiles}
          disabled={isLoadingFiles}
          className="p-1.5 hover:bg-[#1e202b] text-gray-400 rounded-lg transition-all"
          title="Synchroniser le Workspace"
        >
          <RefreshCw className={`w-4 h-4 ${isLoadingFiles ? 'animate-spin text-orange-500' : ''}`} />
        </button>
      </div>

      {/* 2.5 DEDICATED TAB AGENTIC TRANSMUTATION & QUANTUM AUTONOMY HUD */}
      <TabAgenticTeamBar 
        activeTab={activeTab} 
        onNavigateTab={(tab) => setActiveTab(tab as any)} 
      />

      {/* 3. CORE CONTENT SPLIT FRAME */}
      <main className="flex-1 flex flex-col lg:flex-row overflow-hidden relative">
        
        {/* ACTIVE MODULE VIEW CONTAINER */}
        <div className="flex-1 p-6 overflow-y-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="h-full"
            >
              {activeTab === "studio" && (
                <GoogleAiStudioConsole 
                  files={files} 
                  onRefreshFiles={loadWorkspaceFiles} 
                />
              )}

              {activeTab === "evolution" && (
                <div className="h-full">
                  <PermanentEvolutionMemoryViewer 
                    onSelectFile={(filePath) => {
                      setActiveTab("ide");
                    }} 
                  />
                </div>
              )}

              {activeTab === "telemetry" && (
                <QuantumHardwareTelemetryMatrix />
              )}

              {activeTab === "machine" && (
                <OmniMachineCartographerMatrix />
              )}

              {activeTab === "cosmic" && (
                <MachineHeartCosmicSource />
              )}

              {activeTab === "dictionary" && (
                <SymbolEquationDictionary />
              )}

              {activeTab === "dependencies" && (
                <div className="h-full">
                  <FileDependencyGraphView 
                    files={files} 
                    onSelectFile={(path) => {
                      setActiveTab("ide");
                    }}
                  />
                </div>
              )}

              {activeTab === "tests" && (
                <div className="h-full overflow-y-auto">
                  <SentinelTestRunnerPanel />
                </div>
              )}

              {activeTab === "ide" && (
                <CodeProgrammingStudio 
                  files={files}
                  onRefreshFiles={loadWorkspaceFiles}
                />
              )}

              {activeTab === "notebook" && (
                <NotebookLMTool 
                  files={files}
                />
              )}

              {activeTab === "budget" && (
                <TokenBudgetCalibrator />
              )}

              {activeTab === "sandbox" && (
                <VirtualEvolutionSandbox />
              )}

              {activeTab === "quantum" && (
                <EngaticResonanceConsole />
              )}

              {activeTab === "repair" && (
                <AutoRepairPanel />
              )}

              {activeTab === "mesh" && (
                <UnifiedAgentMeshPanel />
              )}

              {activeTab === "introspection" && (
                <InnerIntrospectionKernel />
              )}

              {activeTab === "agentic" && (
                <AgenticServerInitTab />
              )}

              {activeTab === "translator" && (
                <PolyglotTranslatorPanel />
              )}

              {activeTab === "autonomous_bridge" && (
                <AutonomousAgenticBridgeTab />
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* ACTIVE MATRIX EVOLVING LIVE WIDGETS DRAWER (SIDEBAR) */}
        {injectedWidgets.length > 0 && (
          <aside className="w-full lg:w-80 border-t lg:border-t-0 lg:border-l border-[#1f2029] bg-[#121319] p-4 overflow-y-auto shrink-0 flex flex-col gap-4 relative z-20">
            <div className="flex items-center justify-between border-b border-[#1f2029] pb-2">
              <span className="text-[11px] text-orange-400 font-extrabold uppercase tracking-widest flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-orange-500 animate-spin" style={{ animationDuration: '6s' }} /> ZONE D'INJECTION Φ_SOI
              </span>
              <button 
                onClick={() => setInjectedWidgets([])}
                className="text-[10px] text-red-400 hover:underline"
              >
                Tout vider
              </button>
            </div>

            <div className="space-y-4">
              {injectedWidgets.map(widget => (
                <div key={widget.id} className="p-3 bg-[#0b0c10] border border-[#2b2d3a] rounded-xl relative space-y-3 group shadow-lg">
                  
                  {/* Cancel button */}
                  <button
                    onClick={() => handleRemoveWidget(widget.id)}
                    className="absolute top-2 right-2 p-1 bg-[#14151a] border border-[#2b2d3a] text-gray-500 hover:text-red-400 rounded transition-colors"
                  >
                    <X className="w-3 h-3" />
                  </button>

                  <div className="text-[9px] text-gray-500 font-bold uppercase tracking-widest">
                    CIBLE : <span className="text-orange-400">{widget.selector}</span>
                  </div>

                  <p className="text-[10px] text-gray-400 leading-relaxed italic border-l-2 border-orange-500/40 pl-2">
                    {widget.explanation}
                  </p>

                  {/* Dynamic execution widget */}
                  <div className="pt-2 border-t border-[#1f2029]">
                    {widget.type === "calculatrice" && <QuantumCalculator />}
                    {widget.type === "todo" && <MatriceTaskManager />}
                    {widget.type === "meteo" && <ClimatologicalWidget />}
                    {widget.type === "generic" && <GenericValidationBadge />}
                  </div>

                </div>
              ))}
            </div>
          </aside>
        )}

      </main>

      {/* 4. OVERLAY MOUSE TARGETING MATRIX INJECTOR */}
      <LiveUiInspectorOverlay 
        isActive={isInspectorActive}
        onClose={() => setIsInspectorActive(false)}
        onInjectWidget={handleInjectWidget}
      />

      {/* 5. ALCHEMICAL KEY & ROUTING SETTINGS DRAWER MODAL */}
      <AlchemicalSettingsModal 
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
      />

      {/* 5.1 1-CLICK LOCAL DEPLOYMENT BUNDLE MODAL */}
      <LocalDeploymentBundleModal 
        isOpen={isLocalDeploymentModalOpen}
        onClose={() => setIsLocalDeploymentModalOpen(false)}
        files={files}
      />

      {/* 5.2 MODALE D'AUDIT DE VÉRITÉ & TRANSPARENCE DES DONNÉES */}
      <AnimatePresence>
        {isAuditModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-3xl bg-[#0e1017] border border-cyan-800/60 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              {/* Modal Header */}
              <div className="p-5 bg-[#141724] border-b border-[#21253a] flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-cyan-950 border border-cyan-700/50 text-cyan-400">
                    <Shield className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-black text-gray-100 uppercase tracking-wider">
                      Audit de Réalité & Vérité des Données
                    </h3>
                    <p className="text-[11px] text-gray-400">
                      Rapport d'authenticité de l'ensemble des modules et capteurs du système
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setIsAuditModalOpen(false)}
                  className="p-1.5 rounded-lg bg-[#1e2235] hover:bg-[#2a2f48] text-gray-400 hover:text-white transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Modal Content */}
              <div className="p-6 overflow-y-auto space-y-5 text-xs">
                
                {/* Global statement */}
                <div className="p-4 rounded-xl bg-cyan-950/40 border border-cyan-800/60 text-cyan-200 text-xs space-y-1">
                  <div className="font-bold flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                    <span>Transparence Totale Activée : Zéro Donnée Falsifiée</span>
                  </div>
                  <p className="text-gray-300 text-[11px] leading-relaxed">
                    Toutes les sondes sont connectées aux canaux réels du système hôte. Si un service externe ou un composant matériel physique n'est pas détecté, une erreur explicite est affichée au lieu de données simulées.
                  </p>
                </div>

                {/* Grid of reality statuses */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  {/* Item 1: Filesystem & Workspace */}
                  <div className="p-4 rounded-xl bg-[#131520] border border-emerald-900/40 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-gray-200">1. Système de Fichiers & Code</span>
                      <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px] font-bold">
                        100% RÉEL
                      </span>
                    </div>
                    <p className="text-gray-400 text-[11px] leading-relaxed">
                      Les {files.length} fichiers manipulés sont stockés physiquement sur le disque du conteneur serveur. Les opérations d'écriture, lecture, linting et tests opèrent sur le vrai code source.
                    </p>
                  </div>

                  {/* Item 2: Gemini AI API */}
                  <div className="p-4 rounded-xl bg-[#131520] border border-emerald-900/40 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-gray-200">2. Inférence Gemini Cloud</span>
                      <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px] font-bold">
                        100% RÉELLE
                      </span>
                    </div>
                    <p className="text-gray-400 text-[11px] leading-relaxed">
                      Les requêtes utilisent le SDK officiel <code>@google/genai</code> avec le modèle <code>gemini-3.8-flash</code>. Un routeur de résilience bascule automatiquement en cas d'erreur de quota.
                    </p>
                  </div>

                  {/* Item 3: Sentinel Tests & Math Engine */}
                  <div className="p-4 rounded-xl bg-[#131520] border border-emerald-900/40 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-gray-200">3. Tests & Moteur Mathématique</span>
                      <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px] font-bold">
                        100% RÉEL
                      </span>
                    </div>
                    <p className="text-gray-400 text-[11px] leading-relaxed">
                      L'agent <code>@sentinel</code> et les algorithmes géométriques (Shoelace, Gauss, SO(2)) tournent en TypeScript natif à 0$ de token sans simulation probabiliste.
                    </p>
                  </div>

                  {/* Item 4: vLLM GPU Server (Port 8000) */}
                  <div className={`p-4 rounded-xl bg-[#131520] border space-y-2 ${
                    systemHealth.vllmOnline ? "border-emerald-900/40" : "border-amber-800/40"
                  }`}>
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-gray-200">4. Serveur vLLM GPU Local (8000)</span>
                      <span className={`px-2 py-0.5 rounded border text-[10px] font-bold ${
                        systemHealth.vllmOnline 
                          ? "bg-emerald-950 text-emerald-300 border-emerald-800" 
                          : "bg-amber-950 text-amber-300 border-amber-800"
                      }`}>
                        {systemHealth.vllmOnline ? "SONDÉ & EN LIGNE" : "SONDÉ : NON DÉTECTÉ"}
                      </span>
                    </div>
                    <p className="text-gray-400 text-[11px] leading-relaxed">
                      Sondé en direct via <code>http://localhost:8000/v1/models</code>. Si le port est inactif, le système indique l'erreur et vous invite à lancer le conteneur vLLM local ou à exporter le pack 1-Clic.
                    </p>
                  </div>

                  {/* Item 5: Windows Companion (Port 11434) */}
                  <div className="p-4 rounded-xl bg-[#131520] border border-gray-800 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-gray-200">5. Compagnon Ollama (11434)</span>
                      <span className="px-2 py-0.5 rounded bg-gray-900 text-gray-400 border border-gray-700 text-[10px] font-bold">
                        SONDÉ EN DIRECT
                      </span>
                    </div>
                    <p className="text-gray-400 text-[11px] leading-relaxed">
                      Sondé en direct sur le port 11434. Statut inactif si aucun service Ollama n'est en cours d'exécution sur la machine hôte.
                    </p>
                  </div>

                  {/* Item 6: Victron USB / LiFePO4 BMS Hardware */}
                  <div className="p-4 rounded-xl bg-[#131520] border border-red-900/50 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-gray-200">6. Matériel Solaire Victron USB</span>
                      <span className="px-2 py-0.5 rounded bg-red-950 text-red-300 border border-red-800 text-[10px] font-bold">
                        {systemHealth.victronConnected ? "CONNECTÉ" : "NON DÉTECTÉ (ALERTE ACTIVE)"}
                      </span>
                    </div>
                    <p className="text-gray-400 text-[11px] leading-relaxed">
                      Les ports série <code>/dev/ttyUSB*</code> sont scannés. En l'absence de contrôleur physique USB VE.Direct branché, le système affiche des tirets <code>---</code> et une bannière d'erreur rouge pour garantir l'absence totale d'hallucination.
                    </p>
                  </div>

                </div>

                {/* Close action */}
                <div className="pt-3 border-t border-[#21253a] flex justify-end">
                  <button
                    onClick={() => setIsAuditModalOpen(false)}
                    className="px-5 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 text-black font-bold text-xs uppercase tracking-wider transition-all"
                  >
                    Fermer le Rapport
                  </button>
                </div>

              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* 6. OMNIPRESENT TAB CONVERSATIONAL LLM & AGENTIC TEAM FLOATING DOCK (DÉPLAÇABLE & TAILLE MOYENNE) */}
      {!isFloatingChatOpen ? (
        <div className="fixed bottom-4 right-4 z-40">
          <button
            onClick={() => setIsFloatingChatOpen(true)}
            className="flex items-center gap-2.5 px-4 py-2.5 rounded-full bg-gradient-to-r from-purple-950 via-indigo-950 to-cyan-950 border border-purple-500/70 text-purple-200 text-xs font-bold shadow-2xl hover:scale-105 transition-all group backdrop-blur-md ring-1 ring-purple-400/30"
            title={`Ouvrir le chat de dialogue déplaçable synchronisé avec l'onglet [${activeTab.toUpperCase()}]`}
          >
            <div className="relative">
              <Bot className="w-4 h-4 text-purple-300 animate-pulse" />
              <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            </div>
            <span className="font-extrabold tracking-wide">LLM Onglet [{activeTab.toUpperCase()}]</span>
            <span className="px-2 py-0.5 rounded-full bg-purple-900/80 text-[10px] text-cyan-300 font-extrabold border border-purple-500/50">
              Moyen • Déplaçable
            </span>
          </button>
        </div>
      ) : (
        <DraggableMovableChatWrapper
          isOpen={isFloatingChatOpen}
          onClose={() => setIsFloatingChatOpen(false)}
          activeTab={activeTab}
        >
          <OmniTabConversationalLLM
            activeTab={activeTab}
            files={files}
            onRefreshFiles={loadWorkspaceFiles}
            onNavigateTab={(tab) => setActiveTab(tab as any)}
            isFloating={true}
            onClose={() => setIsFloatingChatOpen(false)}
          />
        </DraggableMovableChatWrapper>
      )}

    </div>
  );
}
