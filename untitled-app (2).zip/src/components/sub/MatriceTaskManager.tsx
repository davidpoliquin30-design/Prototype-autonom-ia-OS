import React, { useState, useEffect } from 'react';
import { Check, Plus, Trash2 } from 'lucide-react';

export default function MatriceTaskManager() {
  const [tasks, setTasks] = useState<{ id: string; text: string; done: boolean }[]>([]);
  const [input, setInput] = useState('');

  useEffect(() => {
    const saved = localStorage.getItem('phi_sol_tasks');
    if (saved) {
      try {
        setTasks(JSON.parse(saved));
      } catch (_) {}
    }
  }, []);

  const save = (newTasks: any[]) => {
    setTasks(newTasks);
    localStorage.setItem('phi_sol_tasks', JSON.stringify(newTasks));
  };

  const addTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    const item = { id: Date.now().toString(), text: input.trim(), done: false };
    save([...tasks, item]);
    setInput('');
  };

  const toggleTask = (id: string) => {
    save(tasks.map(t => t.id === id ? { ...t, done: !t.done } : t));
  };

  const removeTask = (id: string) => {
    save(tasks.filter(t => t.id !== id));
  };

  const clearDone = () => {
    save(tasks.filter(t => !t.done));
  };

  return (
    <div id="matrice-tasks-container" className="p-4 bg-[#14151a] border border-[#2b2d3a] rounded-xl text-white max-w-sm mx-auto shadow-2xl font-mono">
      <div className="text-[10px] text-emerald-400 font-mono mb-1.5 tracking-widest font-bold uppercase">🎯 DIRECTIVES DE TÂCHES Φ</div>
      
      <form onSubmit={addTask} className="flex gap-2 mb-3">
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder="Nouvel objectif d'évolution..."
          className="flex-1 bg-[#0b0c10] border border-[#2b2d3a] px-3 py-2 text-xs rounded-lg focus:outline-none focus:border-emerald-500/60 text-gray-200 placeholder-gray-600"
        />
        <button type="submit" className="px-3 bg-emerald-500 hover:bg-emerald-600 text-black font-bold rounded-lg text-xs transition-colors">
          <Plus className="w-4 h-4" />
        </button>
      </form>
      
      <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
        {tasks.length === 0 ? (
          <div className="text-[10px] text-gray-500 text-center py-4">Aucune directive de tâche active.</div>
        ) : (
          tasks.map(t => (
            <div key={t.id} className="flex items-center justify-between p-2 rounded-lg bg-[#0b0c10] border border-[#1f2029]">
              <span 
                className={`text-xs select-text truncate cursor-pointer flex-1 ${t.done ? 'line-through text-gray-600' : 'text-gray-300'}`} 
                onClick={() => toggleTask(t.id)}
              >
                {t.done ? '✓ ' : '○ '} {t.text}
              </span>
              <button 
                onClick={() => removeTask(t.id)} 
                className="text-gray-600 hover:text-red-400 p-1 transition-colors ml-1"
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          ))
        )}
      </div>
      
      {tasks.some(t => t.done) && (
        <button 
          onClick={clearDone} 
          className="mt-3 w-full p-1 border border-red-950/40 hover:bg-red-950/80 text-red-400 rounded-lg text-[9px] uppercase tracking-widest font-bold transition-colors"
        >
          Nettoyer terminées
        </button>
      )}
    </div>
  );
}
