import React from 'react';
import { Cloud, Wind, Droplets, Sun } from 'lucide-react';

export default function ClimatologicalWidget() {
  return (
    <div id="climatology-widget" className="p-4 bg-[#14151a] border border-[#2b2d3a] rounded-xl text-white max-w-xs mx-auto shadow-2xl font-mono">
      <div className="text-[10px] text-blue-400 font-bold mb-2 tracking-widest uppercase">🌀 MÉTÉO CLIMATOLOGIQUE</div>
      
      <div className="flex items-center justify-between my-2 border-b border-[#1f2029] pb-3">
        <div>
          <div className="text-2xl font-bold font-sans tracking-tight">19.8°C</div>
          <div className="text-[9px] text-blue-400 uppercase tracking-wider font-semibold">Réflexion Atmosphérique</div>
        </div>
        <div className="relative">
          <Sun className="w-8 h-8 text-orange-400 animate-spin" style={{ animationDuration: '20s' }} />
          <Cloud className="w-6 h-6 text-gray-400 absolute -bottom-1 -right-1" />
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-2 text-[10px] text-gray-300">
        <div className="flex items-center gap-1 bg-[#0b0c10] p-1.5 rounded border border-[#1f2029]">
          <Droplets className="w-3 h-3 text-blue-400" />
          <span>Humidité : 44%</span>
        </div>
        <div className="flex items-center gap-1 bg-[#0b0c10] p-1.5 rounded border border-[#1f2029]">
          <Wind className="w-3 h-3 text-gray-400" />
          <span>Vent : 18 km/h</span>
        </div>
        <div className="flex items-center gap-1 bg-[#0b0c10] p-1.5 rounded border border-[#1f2029]">
          <span className="text-blue-500 font-bold">Reflex :</span>
          <span>HyperStable</span>
        </div>
        <div className="flex items-center gap-1 bg-[#0b0c10] p-1.5 rounded border border-[#1f2029]">
          <span className="text-orange-500 font-bold">Zone :</span>
          <span>Quantum</span>
        </div>
      </div>
    </div>
  );
}
