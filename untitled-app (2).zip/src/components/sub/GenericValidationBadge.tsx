import React from 'react';
import { ShieldCheck, Cpu } from 'lucide-react';

export default function GenericValidationBadge() {
  return (
    <div className="p-4 bg-[#14151a] border border-emerald-900 rounded-xl text-white max-w-xs mx-auto shadow-xl text-center font-mono">
      <div className="flex justify-center mb-2">
        <div className="p-2 bg-emerald-950/40 rounded-full border border-emerald-500/30 animate-pulse">
          <ShieldCheck className="w-6 h-6 text-emerald-400" />
        </div>
      </div>
      <div className="text-[10px] font-bold text-emerald-400 uppercase tracking-widest mb-1">AUTOMATE Φ_SOI INJECTÉ</div>
      <p className="text-[10px] text-gray-400 leading-relaxed">
        Le composant d'auto-évolution local s'est compilé et s'est interfacé avec succès sur la couche graphique.
      </p>
      <div className="mt-2.5 pt-2 border-t border-[#1f2029] text-[9px] text-gray-500 flex items-center justify-center gap-1">
        <Cpu className="w-3 h-3 text-gray-600" />
        <span>Conformité d'assemblage : 100%</span>
      </div>
    </div>
  );
}
