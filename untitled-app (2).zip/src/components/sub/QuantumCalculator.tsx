import React, { useState } from "react";
import { Calculator, Sparkles, Activity, ShieldCheck } from "lucide-react";

export interface QuantumCalculatorProps {
  initialLength?: number;
  initialWidth?: number;
  initialDepth?: number;
}

export default function QuantumCalculator({
  initialLength = 10,
  initialWidth = 2,
  initialDepth = 1.2,
}: QuantumCalculatorProps) {
  const [length, setLength] = useState<number>(initialLength);
  const [width, setWidth] = useState<number>(initialWidth);
  const [depth, setDepth] = useState<number>(initialDepth);
  const [soilType, setSoilType] = useState<"standard" | "clay" | "rock">("clay");

  const swellingFactors = {
    standard: 1.25,
    clay: 1.30,
    rock: 1.50,
  };

  const netVolume = length * width * depth;
  const factor = swellingFactors[soilType];
  const grossVolume = netVolume * factor;
  const truckCount = Math.ceil(grossVolume / 12); // Camions 10 roues (12 m3)

  return (
    <div className="p-4 bg-[#0d0f1a] border border-cyan-900/40 rounded-xl text-gray-200 font-mono text-xs">
      <div className="flex items-center justify-between mb-3 border-b border-cyan-900/30 pb-2">
        <div className="flex items-center gap-2">
          <Calculator className="w-4 h-4 text-cyan-400" />
          <span className="font-bold text-cyan-200 text-sm">Calculateur Déterministe Plan Alpha</span>
        </div>
        <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800">
          Ξ ≡ 1.000 (0$ Token)
        </span>
      </div>

      <div className="grid grid-cols-3 gap-3 mb-3">
        <div>
          <label className="text-[10px] text-gray-400 block mb-1">Longueur (m)</label>
          <input
            type="number"
            value={length}
            onChange={(e) => setLength(parseFloat(e.target.value) || 0)}
            className="w-full bg-[#07080d] border border-cyan-900/50 rounded p-1.5 text-cyan-300"
          />
        </div>
        <div>
          <label className="text-[10px] text-gray-400 block mb-1">Largeur (m)</label>
          <input
            type="number"
            value={width}
            onChange={(e) => setWidth(parseFloat(e.target.value) || 0)}
            className="w-full bg-[#07080d] border border-cyan-900/50 rounded p-1.5 text-cyan-300"
          />
        </div>
        <div>
          <label className="text-[10px] text-gray-400 block mb-1">Profondeur (m)</label>
          <input
            type="number"
            value={depth}
            onChange={(e) => setDepth(parseFloat(e.target.value) || 0)}
            className="w-full bg-[#07080d] border border-cyan-900/50 rounded p-1.5 text-cyan-300"
          />
        </div>
      </div>

      <div className="mb-3">
        <label className="text-[10px] text-gray-400 block mb-1">Type de Sol (Foisonnement)</label>
        <select
          value={soilType}
          onChange={(e) => setSoilType(e.target.value as any)}
          className="w-full bg-[#07080d] border border-cyan-900/50 rounded p-1.5 text-cyan-300 text-xs"
        >
          <option value="standard">Terre Standard (x1.25)</option>
          <option value="clay">Argile Nordique (x1.30)</option>
          <option value="rock">Roc / Gravier Fracturé (x1.50)</option>
        </select>
      </div>

      <div className="p-3 bg-[#05060b] border border-[#1f243b] rounded-lg space-y-1 text-[11px]">
        <div className="flex justify-between">
          <span className="text-gray-400">Volume Net :</span>
          <span className="text-cyan-300 font-bold">{netVolume.toFixed(2)} m³</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-400">Volume Foisonné ({factor}) :</span>
          <span className="text-emerald-400 font-bold">{grossVolume.toFixed(2)} m³</span>
        </div>
        <div className="flex justify-between border-t border-gray-800 pt-1 mt-1">
          <span className="text-gray-400">Camions 10 roues (12 m³) :</span>
          <span className="text-amber-400 font-bold">{truckCount} voyage(s)</span>
        </div>
      </div>
    </div>
  );
}
