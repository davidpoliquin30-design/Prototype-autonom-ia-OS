import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Network, Cpu, Layers, ShieldCheck, Zap, Globe, FileCode, CheckCircle, 
  HelpCircle, Sparkles, Terminal, Activity, ArrowRight, Code, Key
} from "lucide-react";
import { WorkspaceFile, CodeStudioContract } from "../types";

interface SynapticPipelineViewerProps {
  activeFile: string | null;
  files: WorkspaceFile[];
  isDirty: boolean;
  linterStatus: "CLEAN" | "WARNING" | "ERROR";
}

export default function SynapticPipelineViewer({ 
  activeFile, 
  files, 
  isDirty,
  linterStatus 
}: SynapticPipelineViewerProps) {
  const [activePhase, setActivePhase] = useState<1 | 2 | 3 | 4>(1);
  const [isContractExpanded, setIsContractExpanded] = useState(false);

  // Synaptic agent definition and static meta-data
  const PHASES_INFO = {
    1: {
      title: "Phase I : Intention & Guidage Optique",
      description: "Capte l'intention de l'utilisateur, structure la mémoire vive instantanée et fait le pont vers le fichier physique ciblé par le clic.",
      agents: [
        { id: "user_intent_analyst", name: "UserIntentAnalystAgent", desc: "Analyse le contexte écran global et génère le fichier temporaire UserIntentContext_Realtime.json." },
        { id: "inspector_mode_controller", name: "InspectorModeControllerAgent", desc: "Capture les sélecteurs physiques CSS et guide optiquement l'IDE." },
        { id: "inspector_ide_translator", name: "InspectorIdeTranslatorAgent", desc: "Associe l'élément sélectionné à son fichier source (ex: /src/components/TopBar.tsx)." }
      ]
    },
    2: {
      title: "Phase II : Moissonnage & AST",
      description: "Analyse l'Arbre de Syntaxe Abstraite (AST) pour identifier les points de greffage et pré-charger les types et schémas requis.",
      agents: [
        { id: "source_code_analyzer", name: "SourceCodeAnalyzerAgent", desc: "Extrait la signature typée, les imports du fichier et cartographie l'arbre AST." },
        { id: "tool_reconfigurator", name: "ToolResourceFetcherAgent / Reconfigurator", desc: "Moissonne les signatures de dépendances nécessaires pour garantir la viabilité de la greffe." }
      ]
    },
    3: {
      title: "Phase III : Synthèse & Arbitrage",
      description: "Écrit le code source modifié en appliquant la logique métier et en arbitrant la conformité sémantique.",
      agents: [
        { id: "pro_coder", name: "ProCoderAgent (LLM)", desc: "Génère le patch de code TypeScript / TSX enrichi de classes Tailwind de précision." },
        { id: "code_synchronizer", name: "CodeSynchronizerAgent", desc: "Valide la cohérence du patch, prévient les régressions et garantit l'intégrité avant écriture." }
      ]
    },
    4: {
      title: "Phase IV : Déploiement Hot-Swap & Intégration",
      description: "Applique la mutation à chaud directement dans le DOM et valide l'esthétique finale globale.",
      agents: [
        { id: "live_ide_executor", name: "LiveIDEExecutorAgent", desc: "Prépare l'application du patch de code au runtime." },
        { id: "deployer_agent", name: "DeployerAgent", desc: "Réalise un Hot-Swap instantané dans l'arborescence du DOM utilisateur sans rechargement de page." },
        { id: "visual_structural_orchestrator", name: "VisualStructuralIntegrationOrchestratorAgent", desc: "Valide l'alignement visuel final et conclut la séquence." }
      ]
    }
  };

  // Build current live contract mirroring CodeStudioContract signature
  const liveContract: CodeStudioContract = {
    activeFile: activeFile,
    fileTreeSnapshot: files,
    activeMutation: isDirty ? {
      description: `Mutation à chaud en cours de rédaction dans /${activeFile || "src"}`,
      timestamp: new Date().toLocaleTimeString(),
      patchLength: 124
    } : null,
    linterStatus: linterStatus,
    hotSwapActive: true,
    attachedAgents: [
      "pro_coder", 
      "source_code_analyzer", 
      "live_ide_executor", 
      "code_synchronizer", 
      "tool_reconfigurator", 
      "inspector_mode_controller", 
      "inspector_ide_translator",
      "user_intent_analyst",
      "deployer_agent",
      "visual_structural_orchestrator"
    ]
  };

  return (
    <div className="bg-[#14151a] border border-[#2b2d3a] rounded-xl p-4 font-mono text-xs text-gray-200 flex flex-col space-y-4">
      
      {/* HEADER SECTION */}
      <div className="flex items-center justify-between border-b border-[#2b2d3a] pb-2">
        <div className="flex items-center gap-2">
          <Network className="w-4 h-4 text-orange-500 animate-pulse" />
          <span className="font-bold uppercase text-[11px] tracking-wider text-gray-300">Schéma Synaptique (Bus IDE)</span>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
          <span className="text-[9px] text-emerald-400 uppercase font-black tracking-widest">Autonome</span>
        </div>
      </div>

      {/* SYNAPTIC BUS FLOW CHART */}
      <div className="p-2.5 bg-[#08090d] border border-[#1f2029] rounded-lg">
        <div className="text-[10px] text-gray-500 uppercase font-black mb-2 tracking-wider flex items-center gap-1">
          <Activity className="w-3.5 h-3.5 text-orange-400" /> Flux Séquentiel de l'Orchestration :
        </div>
        
        <div className="grid grid-cols-4 gap-1.5 text-center text-[10px] select-none">
          {[1, 2, 3, 4].map((phNum) => {
            const isActive = activePhase === phNum;
            return (
              <button
                key={phNum}
                onClick={() => setActivePhase(phNum as any)}
                className={`p-2 rounded border transition-all ${
                  isActive 
                    ? "bg-orange-500/10 border-orange-500 text-orange-400 font-bold"
                    : "bg-[#121319]/50 border-[#1f2029] text-gray-500 hover:text-gray-300 hover:border-[#2b2d3a]"
                }`}
              >
                <div>PHASE {phNum === 1 ? 'I' : phNum === 2 ? 'II' : phNum === 3 ? 'III' : 'IV'}</div>
                <div className="text-[8px] opacity-75 mt-0.5 truncate">
                  {phNum === 1 ? 'Captation' : phNum === 2 ? 'AST' : phNum === 3 ? 'Synthèse' : 'Hot-Swap'}
                </div>
              </button>
            );
          })}
        </div>

        {/* Phase Details Card */}
        <div className="mt-3 bg-[#121319] border border-[#1f2029] p-3 rounded-lg space-y-2">
          <div className="text-[11px] font-bold text-white flex items-center gap-1.5">
            <span className="text-orange-400">⚡</span>
            {PHASES_INFO[activePhase].title}
          </div>
          <p className="text-[10px] text-gray-400 leading-relaxed italic">
            {PHASES_INFO[activePhase].description}
          </p>

          <div className="space-y-2 pt-1 border-t border-[#1f2029]/50">
            <div className="text-[9px] text-orange-400 uppercase tracking-widest font-extrabold">Micro-Agents Assignés :</div>
            {PHASES_INFO[activePhase].agents.map((ag) => (
              <div key={ag.id} className="p-2 bg-[#08090d] border border-[#1f2029] rounded-md space-y-1">
                <div className="flex items-center justify-between text-[10px]">
                  <span className="text-gray-300 font-bold flex items-center gap-1">
                    <Cpu className="w-3 h-3 text-emerald-400 animate-pulse" />
                    {ag.name}
                  </span>
                  <div className="flex items-center gap-1">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                    <span className="text-[8px] text-emerald-500 uppercase">Synchronisé</span>
                  </div>
                </div>
                <p className="text-[9px] text-gray-500 leading-relaxed">
                  {ag.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* CODE STUDIO CONTRACT SECTION */}
      <div className="border border-[#1f2029] bg-[#0b0c10] rounded-lg overflow-hidden">
        <button
          onClick={() => setIsContractExpanded(!isContractExpanded)}
          className="w-full px-3 py-2 bg-[#121319] hover:bg-[#1a1c27] flex items-center justify-between text-left transition-colors"
        >
          <div className="flex items-center gap-1.5">
            <Code className="w-3.5 h-3.5 text-orange-400" />
            <span className="text-[10px] uppercase font-bold text-gray-300">Contrat d'Interface (CodeStudioContract)</span>
          </div>
          <span className="text-[9px] text-gray-500">
            {isContractExpanded ? "Cacher" : "Afficher"}
          </span>
        </button>

        <AnimatePresence>
          {isContractExpanded && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="border-t border-[#1f2029] p-3 text-[10px] space-y-2 overflow-hidden bg-[#06070a]"
            >
              <div className="text-[9px] text-gray-500 leading-relaxed mb-2">
                Le bus de communication synaptique (<span className="text-orange-400 font-bold">agentCommunicationBus</span>) valide continuellement ce contrat d'interface en direct avec 0ms de latence.
              </div>

              <div className="p-2 bg-[#08090d] border border-[#1f2029] rounded text-[10px] text-emerald-400 select-all font-mono whitespace-pre overflow-x-auto leading-relaxed max-h-56">
                {JSON.stringify({
                  activeFile: liveContract.activeFile,
                  fileTreeSnapshotCount: liveContract.fileTreeSnapshot.length,
                  activeMutation: liveContract.activeMutation,
                  linterStatus: liveContract.linterStatus,
                  hotSwapActive: liveContract.hotSwapActive,
                  attachedAgents: liveContract.attachedAgents
                }, null, 2)}
              </div>
              
              <div className="text-[9px] text-gray-500 italic mt-1 text-center border-t border-[#1f2029]/30 pt-1.5">
                💡 Copiez ce contrat d'interface JSON pour l'injecter directement.
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

    </div>
  );
}
