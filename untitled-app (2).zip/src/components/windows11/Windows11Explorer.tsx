import React, { useState } from 'react';
import { 
  Folder, 
  FileText, 
  ChevronRight, 
  HardDrive, 
  Monitor, 
  Download, 
  Clock, 
  Star, 
  ArrowLeft, 
  ArrowRight, 
  ArrowUp, 
  RefreshCw, 
  Search, 
  X, 
  Minus, 
  Maximize2,
  Sliders
} from 'lucide-react';
import { WorkspaceFile } from '../../types';

interface Windows11ExplorerProps {
  files: WorkspaceFile[];
  onClose: () => void;
  onMinimize: () => void;
  onSwitchToStudio: () => void;
  onRefreshFiles: () => void;
}

export const Windows11Explorer: React.FC<Windows11ExplorerProps> = ({
  files,
  onClose,
  onMinimize,
  onSwitchToStudio,
  onRefreshFiles
}) => {
  const [currentPath, setCurrentPath] = useState<string>('Ce PC > Disque Local (C:) > Workspace');
  const [selectedFile, setSelectedFile] = useState<WorkspaceFile | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredFiles = files.filter(f => 
    f.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    f.path.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="flex flex-col h-full bg-[#1e1f29]/95 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl text-gray-100 overflow-hidden select-none">
      {/* Title bar with tabs */}
      <div className="h-10 bg-[#16171f] border-b border-white/5 flex items-center justify-between px-3">
        {/* Active tab */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 px-3 py-1 bg-[#1e1f29] rounded-t-lg border-t border-x border-white/10 text-xs font-medium text-gray-200">
            <Folder className="w-3.5 h-3.5 text-amber-400 fill-amber-400/20" />
            <span>Explorateur de Fichiers - Workspace</span>
            <span className="text-[10px] text-gray-400 font-mono">({files.length} fichiers)</span>
          </div>
        </div>

        {/* Window controls */}
        <div className="flex items-center gap-1">
          <button 
            onClick={onMinimize}
            className="w-7 h-6 rounded hover:bg-white/10 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>
          <button 
            className="w-7 h-6 rounded hover:bg-white/10 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
          >
            <Maximize2 className="w-3 h-3" />
          </button>
          <button 
            onClick={onClose}
            className="w-7 h-6 rounded hover:bg-red-600 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Navigation bar & Breadcrumb */}
      <div className="h-11 bg-[#1a1b24] border-b border-white/5 flex items-center gap-2 px-3">
        <div className="flex items-center gap-1 text-gray-400">
          <button className="p-1 rounded hover:bg-white/10 hover:text-white transition-colors disabled:opacity-30" disabled>
            <ArrowLeft className="w-3.5 h-3.5" />
          </button>
          <button className="p-1 rounded hover:bg-white/10 hover:text-white transition-colors disabled:opacity-30" disabled>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
          <button className="p-1 rounded hover:bg-white/10 hover:text-white transition-colors">
            <ArrowUp className="w-3.5 h-3.5" />
          </button>
          <button 
            onClick={onRefreshFiles} 
            className="p-1 rounded hover:bg-white/10 hover:text-white transition-colors"
            title="Actualiser les fichiers réels"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Breadcrumb Path Box */}
        <div className="flex-1 bg-[#242531] border border-white/10 rounded-lg px-2.5 py-1 text-xs text-gray-300 flex items-center gap-1.5 overflow-hidden">
          <HardDrive className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
          <span className="truncate">{currentPath}</span>
        </div>

        {/* Search Box */}
        <div className="w-48 bg-[#242531] border border-white/10 rounded-lg px-2 py-1 text-xs text-gray-300 flex items-center gap-1.5">
          <Search className="w-3.5 h-3.5 text-gray-400 shrink-0" />
          <input
            type="text"
            placeholder="Rechercher..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-transparent border-none outline-none text-xs w-full text-white placeholder-gray-500"
          />
        </div>
      </div>

      {/* Main content: Sidebar + File Grid */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Tree Sidebar */}
        <div className="w-44 bg-[#181922] border-r border-white/5 p-2 text-xs text-gray-300 space-y-1 shrink-0 overflow-y-auto font-sans">
          <div className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-gray-500">Accès rapide</div>
          
          <button 
            onClick={() => setCurrentPath('Ce PC > Disque Local (C:) > Workspace')}
            className="w-full flex items-center gap-2 px-2 py-1.5 rounded-lg bg-blue-600/20 text-blue-300 border border-blue-500/30 font-medium"
          >
            <HardDrive className="w-3.5 h-3.5 text-blue-400" />
            <span>Workspace (C:)</span>
          </button>

          <button 
            onClick={() => setCurrentPath('Ce PC > Bureau')}
            className="w-full flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-white/5 text-gray-300 transition-colors"
          >
            <Monitor className="w-3.5 h-3.5 text-cyan-400" />
            <span>Bureau IA</span>
          </button>

          <div className="pt-2 px-2 py-1 text-[10px] font-bold uppercase tracking-wider text-gray-500">Modules Spéciaux</div>
          <button 
            onClick={onSwitchToStudio}
            className="w-full flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-purple-950/40 text-purple-300 border border-purple-800/40 transition-colors text-left"
          >
            <Sliders className="w-3.5 h-3.5 text-purple-400 shrink-0" />
            <span className="truncate">Atelier Studio Φ</span>
          </button>
        </div>

        {/* File Grid */}
        <div className="flex-1 p-4 overflow-y-auto bg-[#1b1c25]">
          {filteredFiles.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-gray-500 text-xs gap-2">
              <Folder className="w-8 h-8 opacity-40" />
              <span>Aucun fichier correspondant</span>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2">
              {filteredFiles.map((file) => {
                const isSelected = selectedFile?.path === file.path;
                const isCode = file.name.endsWith('.ts') || file.name.endsWith('.tsx') || file.name.endsWith('.json');
                return (
                  <div
                    key={file.path}
                    onClick={() => setSelectedFile(file)}
                    onDoubleClick={onSwitchToStudio}
                    className={`p-2.5 rounded-xl border flex flex-col items-center text-center gap-1.5 cursor-pointer transition-all ${
                      isSelected
                        ? 'bg-blue-600/30 border-blue-500 text-white shadow-md'
                        : 'bg-[#222430]/60 border-white/5 hover:bg-[#2a2c3a] text-gray-300'
                    }`}
                    title={`Double-cliquez pour ouvrir dans l'Atelier Studio : ${file.path}`}
                  >
                    {file.type === 'directory' ? (
                      <Folder className="w-8 h-8 text-amber-400 fill-amber-400/30" />
                    ) : (
                      <FileText className={`w-8 h-8 ${isCode ? 'text-cyan-400' : 'text-gray-400'}`} />
                    )}
                    <span className="text-[11px] font-medium truncate w-full" title={file.name}>
                      {file.name}
                    </span>
                    <span className="text-[9px] text-gray-500 font-mono">
                      {file.type === 'directory' ? 'Dossier' : 'Fichier'}
                    </span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Bottom Status bar */}
      <div className="h-7 bg-[#16171f] border-t border-white/5 flex items-center justify-between px-3 text-[11px] text-gray-400">
        <div>{filteredFiles.length} éléments</div>
        <div className="flex items-center gap-3">
          {selectedFile && (
            <span className="text-cyan-300">Sélection : {selectedFile.name}</span>
          )}
          <button
            onClick={onSwitchToStudio}
            className="text-purple-400 hover:text-purple-300 font-medium flex items-center gap-1"
          >
            <Sliders className="w-3 h-3" />
            <span>Ouvrir dans l'Atelier Studio</span>
          </button>
        </div>
      </div>
    </div>
  );
};
