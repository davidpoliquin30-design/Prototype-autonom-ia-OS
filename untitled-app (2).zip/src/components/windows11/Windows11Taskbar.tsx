import React, { useState, useEffect } from 'react';
import { 
  Folder, 
  Terminal as TerminalIcon, 
  Settings as SettingsIcon, 
  Search, 
  Layers, 
  Wifi, 
  Volume2, 
  Battery, 
  ChevronUp, 
  Sliders, 
  Sparkles,
  Monitor
} from 'lucide-react';
import { WindowsLogo, CopilotLogo } from './Windows11Icon';

interface Windows11TaskbarProps {
  isStartOpen: boolean;
  onToggleStart: () => void;
  openWindows: {
    copilot: boolean;
    explorer: boolean;
    terminal: boolean;
    settings: boolean;
  };
  activeWindow: string | null;
  onToggleApp: (app: 'copilot' | 'explorer' | 'terminal' | 'settings') => void;
  onSwitchToStudio: () => void;
  onQuickSearch: () => void;
}

export const Windows11Taskbar: React.FC<Windows11TaskbarProps> = ({
  isStartOpen,
  onToggleStart,
  openWindows,
  activeWindow,
  onToggleApp,
  onSwitchToStudio,
  onQuickSearch
}) => {
  const [timeStr, setTimeStr] = useState('');
  const [dateStr, setDateStr] = useState('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
      setDateStr(now.toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit', year: 'numeric' }));
    };
    updateTime();
    const timer = setInterval(updateTime, 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="h-12 bg-[#12131b]/90 backdrop-blur-3xl border-t border-white/10 flex items-center justify-between px-3 text-gray-200 select-none relative z-50">
      
      {/* Left section: Weather / Widgets widget */}
      <div className="hidden md:flex items-center gap-2 px-2.5 py-1 rounded-lg hover:bg-white/10 transition-colors cursor-pointer text-xs">
        <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
        <div className="flex flex-col text-[10px] leading-tight">
          <span className="font-bold text-gray-200">Φ_SOI IA</span>
          <span className="text-gray-400">Prêt • 21°C</span>
        </div>
      </div>

      {/* Center section: Windows 11 Taskbar Icons */}
      <div className="flex-1 flex items-center justify-center gap-1.5">
        
        {/* Windows Start Button */}
        <button
          onClick={onToggleStart}
          className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
            isStartOpen ? 'bg-white/20' : 'hover:bg-white/10'
          }`}
          title="Démarrer (Menu Windows 11)"
        >
          <WindowsLogo size={18} />
        </button>

        {/* Windows Search Bar Button */}
        <button
          onClick={onQuickSearch}
          className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-gray-400 hover:text-white transition-all w-44"
          title="Rechercher avec Copilot IA"
        >
          <Search className="w-3.5 h-3.5" />
          <span className="text-[11px] truncate">Rechercher...</span>
        </button>

        {/* Task View */}
        <button
          className="w-10 h-10 rounded-xl hover:bg-white/10 flex items-center justify-center text-gray-300 transition-colors"
          title="Affichage des tâches"
        >
          <Layers className="w-4 h-4 text-cyan-400" />
        </button>

        {/* File Explorer Icon */}
        <button
          onClick={() => onToggleApp('explorer')}
          className={`w-10 h-10 rounded-xl flex flex-col items-center justify-center relative transition-all ${
            activeWindow === 'explorer' ? 'bg-white/15' : 'hover:bg-white/10'
          }`}
          title="Explorateur de Fichiers"
        >
          <Folder className="w-5 h-5 text-amber-400 fill-amber-400/20" />
          {openWindows.explorer && (
            <span className={`w-1.5 h-0.5 rounded-full mt-0.5 ${
              activeWindow === 'explorer' ? 'bg-blue-400 w-3' : 'bg-gray-400'
            }`} />
          )}
        </button>

        {/* Windows Terminal / PowerShell Icon */}
        <button
          onClick={() => onToggleApp('terminal')}
          className={`w-10 h-10 rounded-xl flex flex-col items-center justify-center relative transition-all ${
            activeWindow === 'terminal' ? 'bg-white/15' : 'hover:bg-white/10'
          }`}
          title="Terminal Windows PowerShell"
        >
          <TerminalIcon className="w-4 h-4 text-cyan-300" />
          {openWindows.terminal && (
            <span className={`w-1.5 h-0.5 rounded-full mt-0.5 ${
              activeWindow === 'terminal' ? 'bg-cyan-400 w-3' : 'bg-gray-400'
            }`} />
          )}
        </button>

        {/* Windows Copilot IA Icon */}
        <button
          onClick={() => onToggleApp('copilot')}
          className={`w-10 h-10 rounded-xl flex flex-col items-center justify-center relative transition-all ${
            activeWindow === 'copilot' ? 'bg-purple-600/30' : 'hover:bg-white/10'
          }`}
          title="Windows Copilot IA"
        >
          <CopilotLogo size={20} />
          {openWindows.copilot && (
            <span className={`w-1.5 h-0.5 rounded-full mt-0.5 ${
              activeWindow === 'copilot' ? 'bg-purple-400 w-3' : 'bg-gray-400'
            }`} />
          )}
        </button>

        {/* PARAMÈTRES SYSTÈME (EXPLICIT DEMAND) */}
        <button
          onClick={() => onToggleApp('settings')}
          className={`w-10 h-10 rounded-xl flex flex-col items-center justify-center relative transition-all ${
            activeWindow === 'settings' ? 'bg-blue-600/30' : 'hover:bg-white/10'
          }`}
          title="Paramètres Système (Bascule vers Atelier Studio)"
        >
          <SettingsIcon className="w-4 h-4 text-blue-400" />
          {openWindows.settings && (
            <span className={`w-1.5 h-0.5 rounded-full mt-0.5 ${
              activeWindow === 'settings' ? 'bg-blue-400 w-3' : 'bg-gray-400'
            }`} />
          )}
        </button>

        {/* PROMINENT ATELIER STUDIO SWITCH BUTTON IN TASKBAR */}
        <button
          onClick={onSwitchToStudio}
          className="px-3 py-1 rounded-xl bg-gradient-to-r from-purple-900 via-indigo-900 to-cyan-900 hover:from-purple-800 hover:to-cyan-800 border border-purple-500/50 text-cyan-200 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-lg shadow-purple-900/30 transition-all cursor-pointer ml-1"
          title="Basculer immédiatement dans l'Atelier Studio Multi-Agents"
        >
          <Sliders className="w-3.5 h-3.5 text-cyan-300" />
          <span className="hidden lg:inline text-[11px]">Atelier Studio</span>
        </button>

      </div>

      {/* Right section: System Tray & Clock */}
      <div className="flex items-center gap-2">
        <button 
          className="p-1 rounded hover:bg-white/10 text-gray-400 hover:text-white transition-colors"
          title="Afficher les icônes cachées"
        >
          <ChevronUp className="w-3.5 h-3.5" />
        </button>

        {/* Status Indicators Pill */}
        <div 
          onClick={() => onToggleApp('settings')}
          className="flex items-center gap-1.5 px-2 py-1 rounded-lg hover:bg-white/10 cursor-pointer transition-colors text-gray-300"
          title="Réseau, Son, Batterie (Ouvrir Paramètres)"
        >
          <Wifi className="w-3.5 h-3.5 text-gray-300" />
          <Volume2 className="w-3.5 h-3.5 text-gray-300" />
          <Battery className="w-3.5 h-3.5 text-emerald-400" />
        </div>

        {/* Clock & Date */}
        <div 
          className="flex flex-col text-right px-2 py-0.5 rounded-lg hover:bg-white/10 cursor-pointer transition-colors leading-tight"
          title={`${timeStr} - ${dateStr}`}
        >
          <span className="text-xs font-medium text-gray-100">{timeStr}</span>
          <span className="text-[10px] text-gray-400">{dateStr}</span>
        </div>

        {/* Copilot mini toggle on right */}
        <button
          onClick={() => onToggleApp('copilot')}
          className="w-8 h-8 rounded-lg hover:bg-white/10 flex items-center justify-center transition-colors"
          title="Windows Copilot IA"
        >
          <CopilotLogo size={16} />
        </button>

        {/* Show desktop vertical sliver at extreme right */}
        <div className="w-1.5 h-8 border-l border-white/20 hover:bg-white/30 cursor-pointer" title="Afficher le bureau" />
      </div>

    </div>
  );
};
