import React from 'react';
import { 
  Settings as SettingsIcon, 
  Folder, 
  Terminal as TerminalIcon, 
  Bot, 
  Sparkles, 
  Power, 
  Search, 
  Sliders, 
  FileText, 
  Activity, 
  Lock, 
  RotateCcw,
  Layers,
  ArrowRight
} from 'lucide-react';
import { CopilotLogo, WindowsLogo } from './Windows11Icon';
import { WorkspaceFile } from '../../types';

interface Windows11StartMenuProps {
  onClose: () => void;
  onOpenApp: (app: 'copilot' | 'explorer' | 'terminal' | 'settings') => void;
  onSwitchToStudio: () => void;
  files: WorkspaceFile[];
}

export const Windows11StartMenu: React.FC<Windows11StartMenuProps> = ({
  onClose,
  onOpenApp,
  onSwitchToStudio,
  files
}) => {
  return (
    <div 
      className="w-[540px] max-w-[95vw] bg-[#1d1f2b]/95 backdrop-blur-3xl border border-white/10 rounded-2xl shadow-2xl overflow-hidden text-gray-100 flex flex-col font-sans select-none z-50 animate-in fade-in slide-in-from-bottom-6 duration-200"
      onClick={(e) => e.stopPropagation()}
    >
      {/* Search Input Bar */}
      <div className="p-5 pb-2">
        <div className="relative">
          <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Tapez ici pour rechercher des applications, fichiers, paramètres..."
            className="w-full bg-[#14151e] border border-white/10 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-gray-400 focus:outline-none focus:border-cyan-500 shadow-inner"
            autoFocus
          />
        </div>
      </div>

      {/* DIRECT JUMP TO STUDIO BANNER IN START MENU */}
      <div className="px-5 py-2">
        <button
          onClick={() => {
            onClose();
            onSwitchToStudio();
          }}
          className="w-full p-3 rounded-xl bg-gradient-to-r from-purple-900/80 via-indigo-900/80 to-cyan-900/80 hover:from-purple-800 hover:to-cyan-800 border border-purple-500/50 shadow-lg flex items-center justify-between transition-all group cursor-pointer"
        >
          <div className="flex items-center gap-3 text-left">
            <div className="p-2 rounded-lg bg-purple-950 border border-purple-600 text-cyan-300">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <div className="text-xs font-bold text-white flex items-center gap-1.5">
                <span>Atelier Studio Multi-Agents Φ_SOI</span>
                <span className="px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 text-[9px] font-extrabold border border-cyan-700">
                  ACTIF
                </span>
              </div>
              <div className="text-[11px] text-purple-200">
                Basculer vers l'interface présente (IDE, Télémétrie, Agents)
              </div>
            </div>
          </div>
          <ArrowRight className="w-4 h-4 text-cyan-300 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>

      {/* Pinned Applications Grid */}
      <div className="px-5 py-3 space-y-2">
        <div className="flex items-center justify-between text-xs font-bold text-gray-300 px-1">
          <span>Épinglé</span>
          <span className="text-[11px] text-gray-500 font-normal">Toutes les applications &gt;</span>
        </div>

        <div className="grid grid-cols-4 gap-2">
          {/* Paramètres Système (Bouton essentiel demandé) */}
          <button
            onClick={() => {
              onClose();
              onOpenApp('settings');
            }}
            className="p-3 rounded-xl hover:bg-white/10 flex flex-col items-center gap-2 text-center transition-all group"
          >
            <div className="p-2.5 rounded-xl bg-blue-600/20 group-hover:bg-blue-600/30 border border-blue-500/40 text-blue-400">
              <SettingsIcon className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-medium text-gray-200">Paramètres</span>
          </button>

          {/* Windows Copilot IA */}
          <button
            onClick={() => {
              onClose();
              onOpenApp('copilot');
            }}
            className="p-3 rounded-xl hover:bg-white/10 flex flex-col items-center gap-2 text-center transition-all group"
          >
            <div className="p-2.5 rounded-xl bg-purple-600/20 group-hover:bg-purple-600/30 border border-purple-500/40">
              <CopilotLogo size={20} />
            </div>
            <span className="text-[11px] font-medium text-gray-200">Copilot IA</span>
          </button>

          {/* Explorateur de Fichiers */}
          <button
            onClick={() => {
              onClose();
              onOpenApp('explorer');
            }}
            className="p-3 rounded-xl hover:bg-white/10 flex flex-col items-center gap-2 text-center transition-all group"
          >
            <div className="p-2.5 rounded-xl bg-amber-600/20 group-hover:bg-amber-600/30 border border-amber-500/40 text-amber-400">
              <Folder className="w-5 h-5 fill-amber-400/20" />
            </div>
            <span className="text-[11px] font-medium text-gray-200">Explorateur</span>
          </button>

          {/* Terminal PowerShell */}
          <button
            onClick={() => {
              onClose();
              onOpenApp('terminal');
            }}
            className="p-3 rounded-xl hover:bg-white/10 flex flex-col items-center gap-2 text-center transition-all group"
          >
            <div className="p-2.5 rounded-xl bg-slate-700/30 group-hover:bg-slate-700/50 border border-slate-500/40 text-cyan-300">
              <TerminalIcon className="w-5 h-5" />
            </div>
            <span className="text-[11px] font-medium text-gray-200">PowerShell</span>
          </button>
        </div>
      </div>

      {/* Recommended Section (Real Workspace Files) */}
      <div className="px-5 py-3 space-y-2 border-t border-white/5">
        <div className="flex items-center justify-between text-xs font-bold text-gray-300 px-1">
          <span>Recommandé (Fichiers du Workspace)</span>
          <span className="text-[11px] text-gray-500 font-normal">Plus &gt;</span>
        </div>

        <div className="grid grid-cols-2 gap-2">
          {files.slice(0, 4).map((f) => (
            <div
              key={f.path}
              onClick={() => {
                onClose();
                onSwitchToStudio();
              }}
              className="p-2 rounded-xl hover:bg-white/10 flex items-center gap-2 cursor-pointer transition-colors"
              title="Ouvrir dans l'Atelier Studio"
            >
              <FileText className="w-4 h-4 text-cyan-400 shrink-0" />
              <div className="truncate">
                <div className="text-xs font-medium text-gray-200 truncate">{f.name}</div>
                <div className="text-[10px] text-gray-500 truncate">Modifié récemment</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Bottom Profile & Power Footer */}
      <div className="h-14 bg-[#14151f]/90 border-t border-white/5 px-6 flex items-center justify-between">
        {/* User Profile */}
        <div className="flex items-center gap-2.5 cursor-pointer hover:opacity-80 transition-opacity">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center font-bold text-white text-xs shadow-md">
            DP
          </div>
          <div>
            <div className="text-xs font-semibold text-gray-200">David Poliquin</div>
            <div className="text-[10px] text-gray-500">Noyau Connecté</div>
          </div>
        </div>

        {/* Quick studio jump + Power icon */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              onClose();
              onSwitchToStudio();
            }}
            className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-gray-300 font-medium flex items-center gap-1.5 transition-colors"
          >
            <Sliders className="w-3.5 h-3.5 text-orange-400" />
            <span>Vers Studio</span>
          </button>

          <button 
            className="p-2 rounded-lg hover:bg-white/10 text-gray-400 hover:text-white transition-colors"
            title="Options d'alimentation"
          >
            <Power className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
