import React, { useState } from 'react';
import { 
  Settings as SettingsIcon, 
  Cpu, 
  HardDrive, 
  Server, 
  Bot, 
  Shield, 
  Sliders, 
  Sparkles, 
  Monitor, 
  Wifi, 
  Lock, 
  RefreshCw, 
  X, 
  Minus, 
  Maximize2,
  ArrowRight,
  CheckCircle2,
  Zap,
  Download,
  FolderCode
} from 'lucide-react';

interface Windows11SettingsProps {
  onClose: () => void;
  onMinimize: () => void;
  onSwitchToStudio: () => void;
  systemHealth: {
    vllmOnline: boolean;
    geminiStatus: string;
    ramUsedMb: number;
    ramTotalMb: number;
    victronConnected: boolean;
  };
}

export const Windows11Settings: React.FC<Windows11SettingsProps> = ({
  onClose,
  onMinimize,
  onSwitchToStudio,
  systemHealth
}) => {
  const [activeCategory, setActiveCategory] = useState<'system' | 'ai' | 'bridge' | 'antigravity' | 'about'>('system');

  return (
    <div className="flex flex-col h-full bg-[#1b1c24]/95 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl text-gray-100 overflow-hidden font-sans select-none">
      {/* Title bar */}
      <div className="h-10 bg-[#15161e] border-b border-white/5 flex items-center justify-between px-3">
        <div className="flex items-center gap-2">
          <SettingsIcon className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-semibold tracking-wide text-gray-200">Paramètres Windows 11 IA</span>
        </div>

        {/* Window controls */}
        <div className="flex items-center gap-1">
          <button 
            onClick={onMinimize}
            className="w-7 h-6 rounded hover:bg-white/10 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>
          <button 
            className="w-7 h-6 rounded hover:bg-white/10 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
          >
            <Maximize2 className="w-3 h-3" />
          </button>
          <button 
            onClick={onClose}
            className="w-7 h-6 rounded hover:bg-red-600 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Main Settings Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left Menu Sidebar */}
        <div className="w-52 bg-[#171822] border-r border-white/5 p-3 space-y-1 shrink-0 text-xs">
          <div className="flex items-center gap-2.5 p-2 mb-3 rounded-xl bg-white/5">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-blue-600 to-purple-600 flex items-center justify-center font-bold text-white text-xs shadow-md">
              DP
            </div>
            <div className="truncate">
              <div className="font-bold text-gray-200 text-xs truncate">David Poliquin</div>
              <div className="text-[10px] text-gray-400 truncate">Administrateur Système</div>
            </div>
          </div>

          <button
            onClick={() => setActiveCategory('system')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left font-medium transition-all ${
              activeCategory === 'system'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-gray-300 hover:bg-white/5'
            }`}
          >
            <Monitor className="w-4 h-4" />
            <span>Système & Performance</span>
          </button>

          <button
            onClick={() => setActiveCategory('ai')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left font-medium transition-all ${
              activeCategory === 'ai'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-gray-300 hover:bg-white/5'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            <span>Copilot & Intelligence IA</span>
          </button>

          <button
            onClick={() => setActiveCategory('bridge')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left font-medium transition-all ${
              activeCategory === 'bridge'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-gray-300 hover:bg-white/5'
            }`}
          >
            <Bot className="w-4 h-4" />
            <span>Pont Matériel & Flotte</span>
          </button>

          <button
            onClick={() => setActiveCategory('antigravity')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left font-medium transition-all ${
              activeCategory === 'antigravity'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-gray-300 hover:bg-white/5'
            }`}
          >
            <FolderCode className="w-4 h-4 text-cyan-400" />
            <span>Antigravity IDE</span>
          </button>

          <button
            onClick={() => setActiveCategory('about')}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left font-medium transition-all ${
              activeCategory === 'about'
                ? 'bg-blue-600 text-white shadow-md'
                : 'text-gray-300 hover:bg-white/5'
            }`}
          >
            <Shield className="w-4 h-4" />
            <span>À Propos de Φ_SOI</span>
          </button>

          {/* Direct Switch to Studio Button in Settings Sidebar */}
          <div className="pt-4 mt-4 border-t border-white/5">
            <button
              onClick={onSwitchToStudio}
              className="w-full p-2.5 rounded-xl bg-gradient-to-r from-purple-950 via-indigo-950 to-cyan-950 hover:from-purple-900 hover:to-cyan-900 border border-purple-500/50 text-purple-200 text-left space-y-1 shadow-lg transition-all group"
            >
              <div className="flex items-center justify-between text-xs font-bold text-cyan-300">
                <span className="flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-purple-400" />
                  Atelier Studio
                </span>
                <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
              <p className="text-[10px] text-gray-400 leading-tight">
                Basculer vers l'interface complète de développement
              </p>
            </button>
          </div>
        </div>

        {/* Right Settings Pane */}
        <div className="flex-1 p-6 overflow-y-auto space-y-6 bg-[#1a1b25]">
          
          {/* HUGE HERO CARD: SWITCH TO STUDIO */}
          <div className="p-5 rounded-2xl bg-gradient-to-r from-purple-950/90 via-indigo-950/80 to-blue-950/90 border border-purple-500/40 shadow-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-full bg-purple-900/60 border border-purple-500 text-[10px] font-extrabold text-purple-300 uppercase">
                  BASCULEMENT MAÎTRE
                </span>
                <span className="flex items-center gap-1 text-[11px] text-emerald-400 font-semibold">
                  <CheckCircle2 className="w-3 h-3" />
                  Atelier En Direct Prêt
                </span>
              </div>
              <h2 className="text-base font-black text-white tracking-wide">
                Atelier Studio Multi-Agents Φ_SOI
              </h2>
              <p className="text-xs text-gray-300 max-w-lg leading-relaxed">
                Accédez à l'environnement complet : IDE, Télémétrie Quantique, Maillage Agentique, Auto-Réparation et Dictionnaire Alchimique.
              </p>
            </div>

            <button
              onClick={onSwitchToStudio}
              className="px-5 py-3 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-purple-600 hover:from-cyan-400 hover:to-purple-500 text-white font-extrabold text-xs uppercase tracking-wider shadow-xl shadow-blue-500/25 flex items-center justify-center gap-2 transition-all transform hover:scale-105 active:scale-95 shrink-0"
            >
              <Sliders className="w-4 h-4" />
              <span>Basculer dans l'Atelier Studio</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* System Telemetry Overview */}
          {activeCategory === 'system' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-gray-200 uppercase tracking-wider flex items-center gap-2">
                <Cpu className="w-4 h-4 text-cyan-400" />
                <span>Ressources Matérielles en Temps Réel</span>
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="p-4 rounded-xl bg-[#222432] border border-white/5 space-y-2">
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <span>RAM Node.js</span>
                    <Cpu className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="text-lg font-bold text-white">
                    {systemHealth.ramUsedMb > 0 ? `${systemHealth.ramUsedMb} Mo` : '42 Mo'}
                  </div>
                  <div className="text-[10px] text-emerald-400">
                    Alloué au processus serveur hôte
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-[#222432] border border-white/5 space-y-2">
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <span>VRAM GPU vLLM</span>
                    <Server className="w-4 h-4 text-cyan-400" />
                  </div>
                  <div className="text-lg font-bold text-white">
                    {systemHealth.vllmOnline ? 'Port 8000 Actif' : 'Prêt (Port 8000)'}
                  </div>
                  <div className="text-[10px] text-gray-400">
                    {systemHealth.vllmOnline ? 'Accélération RTX active' : 'En attente de connexion daemon local'}
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-[#222432] border border-white/5 space-y-2">
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <span>Modèle IA Primaire</span>
                    <Sparkles className="w-4 h-4 text-purple-400" />
                  </div>
                  <div className="text-sm font-bold text-purple-300 truncate">
                    Gemini 3.8 Flash
                  </div>
                  <div className="text-[10px] text-gray-400">
                    Synaptique aveugle & sans dérive
                  </div>
                </div>
              </div>

              {/* Windows 11 Specs Box */}
              <div className="p-4 rounded-xl bg-[#222432] border border-white/5 space-y-3">
                <h4 className="text-xs font-bold text-gray-200 uppercase tracking-wider">
                  Spécifications de l'Édition Windows 11 IA
                </h4>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-gray-500">Édition :</span>{' '}
                    <span className="text-gray-300 font-medium">Windows 11 Pro IA</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Version :</span>{' '}
                    <span className="text-gray-300 font-medium">24H2 (Build 26100)</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Noyau Réflexif :</span>{' '}
                    <span className="text-orange-400 font-mono">Φ_SOI / AROA v8.0</span>
                  </div>
                  <div>
                    <span className="text-gray-500">Signature :</span>{' '}
                    <span className="text-cyan-400 font-mono">Ξ ≡ 1 (Certifié)</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* AI Settings */}
          {activeCategory === 'ai' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-gray-200 uppercase tracking-wider flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-purple-400" />
                <span>Configuration de Windows Copilot IA</span>
              </h3>

              <div className="p-4 rounded-xl bg-[#222432] border border-white/5 space-y-3 text-xs">
                <div className="flex items-center justify-between pb-3 border-b border-white/5">
                  <div>
                    <div className="font-bold text-white">Mode Autonome Φ_SOI</div>
                    <div className="text-[11px] text-gray-400">Permet à Copilot d'agir comme agent réflexif sans token disrésonant</div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-700 text-[10px] font-bold">
                    ACTIVÉ
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-bold text-white">Routage Hybride Local GPU / Cloud</div>
                    <div className="text-[11px] text-gray-400">Bascule automatique sur votre Nvidia locale si disponible</div>
                  </div>
                  <span className="px-2 py-0.5 rounded bg-blue-950 text-blue-300 border border-blue-700 text-[10px] font-bold">
                    AUTOMATIQUE
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Bridge Fleet Settings */}
          {activeCategory === 'bridge' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-gray-200 uppercase tracking-wider flex items-center gap-2">
                <Bot className="w-4 h-4 text-cyan-400" />
                <span>Flotte Agentique du Pont Local</span>
              </h3>

              <div className="p-4 rounded-xl bg-[#222432] border border-white/5 space-y-2 text-xs">
                <p className="text-gray-300">
                  Quatre agents surveillent en permanence les entrées matérielles pour relier votre PC réel au jumeau numérique :
                </p>
                <ul className="space-y-1.5 text-gray-400 text-[11px]">
                  <li>• <strong className="text-purple-300">@local_hardware_scout</strong> : Scan des ports vLLM, Ollama, USB</li>
                  <li>• <strong className="text-cyan-300">@tunnel_synapse_agent</strong> : Canal bi-directionnel chiffré</li>
                  <li>• <strong className="text-emerald-300">@sentinel_guard_agent</strong> : Validation déterministe (0$ token)</li>
                  <li>• <strong className="text-blue-300">@supervisor_autonomous_router</strong> : Arbitrage VRAM GPU</li>
                </ul>
              </div>
            </div>
          )}

          {/* Antigravity IDE Integration Settings */}
          {activeCategory === 'antigravity' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-gray-200 uppercase tracking-wider flex items-center gap-2">
                  <FolderCode className="w-4 h-4 text-cyan-400" />
                  <span>Module d'Intégration Antigravity IDE</span>
                </h3>
                <span className="px-2 py-0.5 rounded-full bg-emerald-950/80 text-emerald-400 border border-emerald-500/30 text-[10px] font-mono">
                  Dossier : /antigravity-ide-plugin
                </span>
              </div>

              <div className="p-4 rounded-xl bg-gradient-to-br from-[#1c2238] to-[#161722] border border-cyan-500/30 space-y-3 text-xs leading-relaxed text-gray-300">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold text-sm text-cyan-200">Package d'Extension Antigravity IDE</h4>
                    <p className="text-[11px] text-gray-400">
                      Incorpore le Bureau Windows 11 IA, le panneau Copilot et l'Atelier Studio directement dans votre environnement Antigravity.
                    </p>
                  </div>
                  <a
                    href="/api/antigravity/plugin-zip"
                    download="antigravity-phiso-win11.zip"
                    className="flex items-center gap-2 px-3 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs transition-colors shadow-lg shadow-cyan-600/30"
                  >
                    <Download className="w-4 h-4" />
                    <span>Télécharger ZIP</span>
                  </a>
                </div>

                <div className="pt-2 border-t border-white/5 grid grid-cols-2 gap-2 text-[11px]">
                  <div className="p-2.5 rounded-lg bg-black/40 border border-white/5 space-y-1">
                    <span className="font-bold text-gray-300">📁 Fichiers Inclus :</span>
                    <p className="text-gray-400 font-mono text-[10px]">
                      • antigravity.manifest.json<br />
                      • antigravity-extension.ts<br />
                      • antigravity-bridge.ts<br />
                      • install.bat & install.sh
                    </p>
                  </div>
                  <div className="p-2.5 rounded-lg bg-black/40 border border-white/5 space-y-1">
                    <span className="font-bold text-gray-300">⌨️ Raccourci Déclaré :</span>
                    <p className="text-cyan-300 font-mono text-[10px]">
                      Ctrl + Alt + W : Bascule instantanée Windows 11 / Studio
                    </p>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-[#0d0f17] border border-white/5 font-mono text-[11px] space-y-1">
                  <div className="text-gray-400"># Commande d'installation automatique dans Antigravity :</div>
                  <div className="text-emerald-400 select-all font-bold">
                    bash antigravity-ide-plugin/install.sh
                  </div>
                  <div className="text-gray-400 text-[10px]">ou double-clic sur install.bat sous Windows 11</div>
                </div>
              </div>
            </div>
          )}

          {/* About Settings */}
          {activeCategory === 'about' && (
            <div className="space-y-4">
              <h3 className="text-sm font-bold text-gray-200 uppercase tracking-wider flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-400" />
                <span>Architecture Φ_SOI</span>
              </h3>

              <div className="p-4 rounded-xl bg-[#222432] border border-white/5 space-y-3 text-xs leading-relaxed text-gray-300">
                <p>
                  Ce bureau virtuel Windows 11 IA est entièrement unifié avec le jumeau numérique et le serveur Node.js en temps réel.
                </p>
                <div className="p-3 rounded-lg bg-[#181a24] font-mono text-[11px] text-cyan-300 border border-cyan-800/30">
                  Φ_SOI = ∮_σ [ ((∇Ψ ⊗ T_p) ★ H_∞) / (ρ_m · (1 + D_c)^λ_sep) ] · ΔOTel = Ξ ≡ 1
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};
