import React, { useState } from 'react';
import { 
  Folder, 
  Terminal as TerminalIcon, 
  Settings as SettingsIcon, 
  Bot, 
  Sliders, 
  Trash2, 
  HardDrive, 
  Sparkles, 
  Cpu, 
  Server, 
  ShieldCheck, 
  ArrowRight,
  Monitor
} from 'lucide-react';
import { WindowsLogo, CopilotLogo } from './Windows11Icon';
import { Windows11Taskbar } from './Windows11Taskbar';
import { Windows11StartMenu } from './Windows11StartMenu';
import { Windows11Copilot } from './Windows11Copilot';
import { Windows11Explorer } from './Windows11Explorer';
import { Windows11Terminal } from './Windows11Terminal';
import { Windows11Settings } from './Windows11Settings';
import { WorkspaceFile } from '../../types';

interface Windows11DesktopProps {
  onSwitchToStudio: () => void;
  files: WorkspaceFile[];
  onRefreshFiles: () => void;
  systemHealth: {
    vllmOnline: boolean;
    geminiStatus: string;
    ramUsedMb: number;
    ramTotalMb: number;
    victronConnected: boolean;
  };
}

export const Windows11Desktop: React.FC<Windows11DesktopProps> = ({
  onSwitchToStudio,
  files,
  onRefreshFiles,
  systemHealth
}) => {
  const [isStartOpen, setIsStartOpen] = useState(false);
  const [activeWindow, setActiveWindow] = useState<string | null>('copilot');

  // Open windows state (Copilot starts open as an AI desktop)
  const [openWindows, setOpenWindows] = useState({
    copilot: true,
    explorer: false,
    terminal: false,
    settings: false
  });

  const toggleApp = (app: 'copilot' | 'explorer' | 'terminal' | 'settings') => {
    setIsStartOpen(false);
    setOpenWindows(prev => {
      const willBeOpen = !prev[app];
      if (willBeOpen) {
        setActiveWindow(app);
      } else if (activeWindow === app) {
        setActiveWindow(null);
      }
      return { ...prev, [app]: willBeOpen };
    });
  };

  const openApp = (app: 'copilot' | 'explorer' | 'terminal' | 'settings') => {
    setIsStartOpen(false);
    setOpenWindows(prev => ({ ...prev, [app]: true }));
    setActiveWindow(app);
  };

  const closeApp = (app: 'copilot' | 'explorer' | 'terminal' | 'settings') => {
    setOpenWindows(prev => ({ ...prev, [app]: false }));
    if (activeWindow === app) setActiveWindow(null);
  };

  const minimizeApp = (app: 'copilot' | 'explorer' | 'terminal' | 'settings') => {
    if (activeWindow === app) setActiveWindow(null);
  };

  return (
    <div 
      className="relative w-full h-screen overflow-hidden select-none flex flex-col font-sans"
      onClick={() => isStartOpen && setIsStartOpen(false)}
    >
      {/* 1. WINDOWS 11 BLOOM SIGNATURE WALLPAPER */}
      <div className="absolute inset-0 bg-[#0c0f1d] overflow-hidden -z-10">
        {/* Deep ambient gradients simulating the Windows 11 Bloom aesthetic */}
        <div className="absolute -top-[20%] left-[20%] w-[60vw] h-[60vw] rounded-full bg-gradient-to-br from-blue-600/25 via-indigo-600/20 to-transparent blur-[140px] pointer-events-none" />
        <div className="absolute bottom-[10%] right-[10%] w-[50vw] h-[50vw] rounded-full bg-gradient-to-tl from-purple-600/30 via-cyan-600/20 to-transparent blur-[160px] pointer-events-none" />
        <div className="absolute top-[40%] left-[45%] -translate-x-1/2 -translate-y-1/2 w-[35vw] h-[35vw] rounded-full bg-gradient-to-tr from-cyan-500/15 via-blue-500/25 to-pink-500/15 blur-[120px] pointer-events-none" />

        {/* Abstract 3D Bloom Petals effect */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] opacity-35 pointer-events-none">
          <div className="w-full h-full rounded-full border border-cyan-400/20 rotate-45 transform scale-90 blur-[1px]"></div>
          <div className="w-full h-full rounded-full border border-blue-500/30 -rotate-12 transform scale-110 blur-[1px] absolute inset-0"></div>
          <div className="w-full h-full rounded-full border border-purple-500/20 rotate-75 transform scale-75 blur-[2px] absolute inset-0"></div>
        </div>
      </div>

      {/* 2. TOP FLOATING SYSTEM BAR (Direct Switch + Status) */}
      <div className="h-10 bg-[#090b14]/70 backdrop-blur-md border-b border-white/5 px-6 flex items-center justify-between text-xs text-gray-300 z-10 shrink-0">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 font-bold text-gray-100">
            <WindowsLogo size={14} />
            <span>Windows 11 IA Edition</span>
            <span className="text-gray-500 font-mono text-[10px]">| Noyau Φ_SOI</span>
          </div>

          <div className="hidden sm:flex items-center gap-2 text-[11px] text-gray-400 border-l border-white/10 pl-3">
            <span className="flex items-center gap-1 text-emerald-400 font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              En Ligne
            </span>
            <span>•</span>
            <span>RAM Node : {systemHealth.ramUsedMb || 45} Mo</span>
            <span>•</span>
            <span>GPU vLLM : {systemHealth.vllmOnline ? 'Actif' : 'Prêt (Port 8000)'}</span>
          </div>
        </div>

        {/* PROMINENT SWITCH BUTTON IN TOP BAR */}
        <button
          onClick={onSwitchToStudio}
          className="px-3.5 py-1.5 rounded-lg bg-gradient-to-r from-purple-600 via-indigo-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white font-extrabold text-[11px] uppercase tracking-wider shadow-lg shadow-purple-600/20 flex items-center gap-2 transition-all transform hover:scale-105 active:scale-95 cursor-pointer"
          title="Basculer vers l'Atelier Studio Multi-Agents (IDE, Télémétrie, Agents)"
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>Basculer vers l'Atelier Studio</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* 3. DESKTOP WORKSPACE AREA (ICONS + WINDOWS) */}
      <div className="flex-1 relative p-4 overflow-hidden">
        
        {/* Desktop Icons Grid */}
        <div className="grid grid-flow-col grid-rows-6 gap-3 w-fit z-0">
          
          {/* Ce PC */}
          <button
            onDoubleClick={() => openApp('explorer')}
            onClick={() => {}}
            className="w-20 p-2 rounded-xl hover:bg-white/10 flex flex-col items-center gap-1.5 text-center text-gray-200 text-xs transition-colors group cursor-pointer"
          >
            <div className="p-2 rounded-xl bg-blue-600/20 group-hover:bg-blue-600/30 border border-blue-500/30 text-blue-400 shadow-md">
              <HardDrive className="w-6 h-6" />
            </div>
            <span className="text-[11px] font-medium leading-tight drop-shadow">Ce PC (Φ_SOI)</span>
          </button>

          {/* Windows Copilot IA */}
          <button
            onDoubleClick={() => openApp('copilot')}
            onClick={() => openApp('copilot')}
            className="w-20 p-2 rounded-xl hover:bg-white/10 flex flex-col items-center gap-1.5 text-center text-gray-200 text-xs transition-colors group cursor-pointer"
          >
            <div className="p-2 rounded-xl bg-purple-600/20 group-hover:bg-purple-600/30 border border-purple-500/30 shadow-md">
              <CopilotLogo size={24} />
            </div>
            <span className="text-[11px] font-medium leading-tight drop-shadow">Copilot IA</span>
          </button>

          {/* Explorateur de Fichiers */}
          <button
            onDoubleClick={() => openApp('explorer')}
            onClick={() => openApp('explorer')}
            className="w-20 p-2 rounded-xl hover:bg-white/10 flex flex-col items-center gap-1.5 text-center text-gray-200 text-xs transition-colors group cursor-pointer"
          >
            <div className="p-2 rounded-xl bg-amber-600/20 group-hover:bg-amber-600/30 border border-amber-500/30 text-amber-400 shadow-md">
              <Folder className="w-6 h-6 fill-amber-400/20" />
            </div>
            <span className="text-[11px] font-medium leading-tight drop-shadow">Explorateur</span>
          </button>

          {/* Terminal PowerShell */}
          <button
            onDoubleClick={() => openApp('terminal')}
            onClick={() => openApp('terminal')}
            className="w-20 p-2 rounded-xl hover:bg-white/10 flex flex-col items-center gap-1.5 text-center text-gray-200 text-xs transition-colors group cursor-pointer"
          >
            <div className="p-2 rounded-xl bg-slate-800/40 group-hover:bg-slate-800/60 border border-slate-600/40 text-cyan-300 shadow-md">
              <TerminalIcon className="w-6 h-6" />
            </div>
            <span className="text-[11px] font-medium leading-tight drop-shadow">PowerShell</span>
          </button>

          {/* PARAMÈTRES SYSTÈME (EXPLICIT DEMAND) */}
          <button
            onDoubleClick={() => openApp('settings')}
            onClick={() => openApp('settings')}
            className="w-20 p-2 rounded-xl hover:bg-white/10 flex flex-col items-center gap-1.5 text-center text-gray-200 text-xs transition-colors group cursor-pointer"
          >
            <div className="p-2 rounded-xl bg-blue-600/25 group-hover:bg-blue-600/40 border border-blue-400/40 text-blue-300 shadow-md">
              <SettingsIcon className="w-6 h-6" />
            </div>
            <span className="text-[11px] font-medium leading-tight drop-shadow">Paramètres</span>
          </button>

          {/* ATELIER STUDIO MULTI-AGENTS (DIRECT JUMP ON DESKTOP) */}
          <button
            onDoubleClick={onSwitchToStudio}
            onClick={onSwitchToStudio}
            className="w-20 p-2 rounded-xl hover:bg-white/10 flex flex-col items-center gap-1.5 text-center text-purple-200 text-xs transition-colors group cursor-pointer"
          >
            <div className="p-2 rounded-xl bg-gradient-to-tr from-purple-700/40 to-cyan-600/40 group-hover:from-purple-600/60 group-hover:to-cyan-500/60 border border-purple-400/50 text-cyan-300 shadow-lg shadow-purple-600/20">
              <Sliders className="w-6 h-6 animate-pulse" />
            </div>
            <span className="text-[11px] font-bold leading-tight drop-shadow text-cyan-200">Atelier Studio</span>
          </button>
        </div>

        {/* 4. ACTIVE WINDOWS FLOATING ON DESKTOP */}

        {/* Windows Copilot IA Window */}
        {openWindows.copilot && (
          <div 
            onClick={() => setActiveWindow('copilot')}
            className={`absolute right-4 top-4 bottom-4 w-[420px] max-w-[92vw] transition-all duration-200 ${
              activeWindow === 'copilot' ? 'z-30 ring-1 ring-cyan-500/30' : 'z-20 opacity-95'
            }`}
          >
            <Windows11Copilot
              onClose={() => closeApp('copilot')}
              onMinimize={() => minimizeApp('copilot')}
              onSwitchToStudio={onSwitchToStudio}
              systemHealth={systemHealth}
            />
          </div>
        )}

        {/* Windows File Explorer Window */}
        {openWindows.explorer && (
          <div 
            onClick={() => setActiveWindow('explorer')}
            className={`absolute left-28 top-8 w-[680px] h-[480px] max-w-[90vw] max-h-[85vh] transition-all duration-200 ${
              activeWindow === 'explorer' ? 'z-30 ring-1 ring-blue-500/30' : 'z-20 opacity-95'
            }`}
          >
            <Windows11Explorer
              files={files}
              onClose={() => closeApp('explorer')}
              onMinimize={() => minimizeApp('explorer')}
              onSwitchToStudio={onSwitchToStudio}
              onRefreshFiles={onRefreshFiles}
            />
          </div>
        )}

        {/* Windows PowerShell Terminal Window */}
        {openWindows.terminal && (
          <div 
            onClick={() => setActiveWindow('terminal')}
            className={`absolute left-36 top-16 w-[640px] h-[440px] max-w-[90vw] max-h-[80vh] transition-all duration-200 ${
              activeWindow === 'terminal' ? 'z-30 ring-1 ring-cyan-500/30' : 'z-20 opacity-95'
            }`}
          >
            <Windows11Terminal
              files={files}
              onClose={() => closeApp('terminal')}
              onMinimize={() => minimizeApp('terminal')}
              onSwitchToStudio={onSwitchToStudio}
            />
          </div>
        )}

        {/* Windows Settings (Paramètres) Window */}
        {openWindows.settings && (
          <div 
            onClick={() => setActiveWindow('settings')}
            className={`absolute left-20 top-6 w-[740px] h-[520px] max-w-[92vw] max-h-[88vh] transition-all duration-200 ${
              activeWindow === 'settings' ? 'z-30 ring-1 ring-purple-500/30' : 'z-20 opacity-95'
            }`}
          >
            <Windows11Settings
              onClose={() => closeApp('settings')}
              onMinimize={() => minimizeApp('settings')}
              onSwitchToStudio={onSwitchToStudio}
              systemHealth={systemHealth}
            />
          </div>
        )}

      </div>

      {/* 5. START MENU POPUP (Centered over Taskbar) */}
      {isStartOpen && (
        <div className="absolute bottom-14 left-1/2 -translate-x-1/2 z-50">
          <Windows11StartMenu
            onClose={() => setIsStartOpen(false)}
            onOpenApp={openApp}
            onSwitchToStudio={onSwitchToStudio}
            files={files}
          />
        </div>
      )}

      {/* 6. WINDOWS 11 CENTERED TASKBAR */}
      <Windows11Taskbar
        isStartOpen={isStartOpen}
        onToggleStart={() => setIsStartOpen(!isStartOpen)}
        openWindows={openWindows}
        activeWindow={activeWindow}
        onToggleApp={toggleApp}
        onSwitchToStudio={onSwitchToStudio}
        onQuickSearch={() => openApp('copilot')}
      />

    </div>
  );
};
