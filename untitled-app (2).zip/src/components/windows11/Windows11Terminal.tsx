import React, { useState, useRef, useEffect } from 'react';
import { Terminal as TerminalIcon, X, Minus, Maximize2, Sliders } from 'lucide-react';
import { WorkspaceFile } from '../../types';

interface Windows11TerminalProps {
  files: WorkspaceFile[];
  onClose: () => void;
  onMinimize: () => void;
  onSwitchToStudio: () => void;
}

export const Windows11Terminal: React.FC<Windows11TerminalProps> = ({
  files,
  onClose,
  onMinimize,
  onSwitchToStudio
}) => {
  const [history, setHistory] = useState<Array<{ text: string; type: 'cmd' | 'output' | 'error' | 'success' }>>([
    { text: 'Windows PowerShell [Version 11.0.26100.1882] IA Edition', type: 'output' },
    { text: '(c) Microsoft Corporation & Noyau Φ_SOI. Tous droits réservés.', type: 'output' },
    { text: 'Tapez "help" pour voir la liste des commandes ou "studio" pour ouvrir l\'Atelier.', type: 'success' },
    { text: '', type: 'output' }
  ]);
  const [currentCmd, setCurrentCmd] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [history]);

  const handleCommand = (cmd: string) => {
    const trimmed = cmd.trim();
    if (!trimmed) return;

    const newHistory = [...history, { text: `PS C:\\Users\\Administrator> ${trimmed}`, type: 'cmd' as const }];
    const parts = trimmed.split(' ');
    const main = parts[0].toLowerCase();

    switch (main) {
      case 'help':
        newHistory.push({
          text: `Commandes disponibles :
  • studio / atelier  : Basculer dans l'Atelier Studio Multi-Agents
  • systeminfo        : Afficher les spécifications du système Windows 11 IA
  • dir / ls          : Lister les fichiers réels du workspace
  • status            : Afficher la télémétrie des agents et du GPU
  • cls / clear       : Effacer l'écran du terminal
  • exit              : Fermer la console`,
          type: 'output'
        });
        break;

      case 'studio':
      case 'atelier':
      case 'open-studio':
        newHistory.push({ text: "Basculement vers l'Atelier Studio Multi-Agents...", type: 'success' });
        setTimeout(() => onSwitchToStudio(), 300);
        break;

      case 'systeminfo':
        newHistory.push({
          text: `Nom de l'hôte           : PHISOI-WIN11-AI
Nom du système d'expl.  : Microsoft Windows 11 Pro IA - Kernel Φ_SOI
Version du système      : 11.0.26100 N/A build 26100
Fabricant du système    : Google AI Studio Sandbox
Processeurs             : 4 Processeur(s) virtuels installés
Mémoire physique totale : 8 192 Mo
Modèle d'IA Actif       : Gemini 3.8 Flash & Agentic Mesh v8.0
Indice de Réalité       : Ξ ≡ 1 (Disrésonance Cognitive = 0)`,
          type: 'output'
        });
        break;

      case 'dir':
      case 'ls':
        const fileLines = files.map(f => `  ${f.type === 'directory' ? '<DIR>' : '     '}  ${f.name}`).join('\n');
        newHistory.push({
          text: ` Répertoire de C:\\Users\\Administrator\\Workspace\n\n${fileLines}\n\n       ${files.length} fichier(s) réels`,
          type: 'output'
        });
        break;

      case 'status':
        newHistory.push({
          text: `Statut Télémétrie :
  [OK] Serveur Node.js Port 3000 opérationnel
  [OK] 4 Agents Autonomes actifs (@local_hardware_scout, @tunnel_synapse_agent...)
  [OK] Prêt pour GPU vLLM local (Port 8000) et Ollama (Port 11434)`,
          type: 'success'
        });
        break;

      case 'cls':
      case 'clear':
        setHistory([]);
        setCurrentCmd('');
        return;

      case 'exit':
        onClose();
        return;

      default:
        newHistory.push({
          text: `"${trimmed}" n’est pas reconnu en tant que commande interne ou externe. Tapez "help" pour obtenir de l'aide.`,
          type: 'error'
        });
        break;
    }

    setHistory(newHistory);
    setCurrentCmd('');
  };

  return (
    <div className="flex flex-col h-full bg-[#0c0d12]/95 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl text-gray-100 overflow-hidden font-mono select-none">
      {/* Title bar */}
      <div className="h-10 bg-[#14151e] border-b border-white/5 flex items-center justify-between px-3">
        <div className="flex items-center gap-2">
          <TerminalIcon className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-semibold tracking-wide text-gray-200">Terminal Windows PowerShell</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onSwitchToStudio}
            className="px-2.5 py-0.5 rounded bg-purple-950/80 hover:bg-purple-900 text-purple-300 border border-purple-700/50 text-[10px] font-sans font-bold flex items-center gap-1 transition-all"
          >
            <Sliders className="w-3 h-3" />
            <span>Ouvrir l'Atelier</span>
          </button>

          <div className="flex items-center gap-1">
            <button 
              onClick={onMinimize}
              className="w-7 h-6 rounded hover:bg-white/10 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
            >
              <Minus className="w-3.5 h-3.5" />
            </button>
            <button 
              className="w-7 h-6 rounded hover:bg-white/10 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
            >
              <Maximize2 className="w-3 h-3" />
            </button>
            <button 
              onClick={onClose}
              className="w-7 h-6 rounded hover:bg-red-600 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Terminal Body */}
      <div className="flex-1 p-4 overflow-y-auto text-xs space-y-1.5 bg-[#090a0f]">
        {history.map((line, idx) => (
          <div 
            key={idx} 
            className={`whitespace-pre-wrap leading-relaxed ${
              line.type === 'cmd' 
                ? 'text-yellow-300 font-bold' 
                : line.type === 'error' 
                ? 'text-red-400' 
                : line.type === 'success' 
                ? 'text-emerald-400 font-semibold' 
                : 'text-gray-300'
            }`}
          >
            {line.text}
          </div>
        ))}

        {/* Current Prompt Line */}
        <div className="flex items-center gap-2 pt-1">
          <span className="text-cyan-400 font-bold shrink-0">PS C:\Users\Administrator&gt;</span>
          <input
            type="text"
            value={currentCmd}
            onChange={(e) => setCurrentCmd(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleCommand(currentCmd)}
            className="flex-1 bg-transparent border-none outline-none text-white text-xs font-mono"
            autoFocus
          />
        </div>
        <div ref={bottomRef} />
      </div>
    </div>
  );
};
