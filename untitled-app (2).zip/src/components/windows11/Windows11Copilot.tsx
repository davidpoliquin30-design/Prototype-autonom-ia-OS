import React, { useState } from 'react';
import { Bot, Send, Sparkles, X, Minus, Maximize2, RefreshCw, Cpu, Server, Shield, Sliders } from 'lucide-react';
import { CopilotLogo } from './Windows11Icon';

interface Windows11CopilotProps {
  onClose: () => void;
  onMinimize: () => void;
  onSwitchToStudio: () => void;
  systemHealth: {
    vllmOnline: boolean;
    geminiStatus: string;
    ramUsedMb: number;
    ramTotalMb: number;
    victronConnected: boolean;
  };
}

interface Message {
  id: string;
  sender: 'user' | 'copilot';
  text: string;
  time: string;
}

export const Windows11Copilot: React.FC<Windows11CopilotProps> = ({
  onClose,
  onMinimize,
  onSwitchToStudio,
  systemHealth
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      sender: 'copilot',
      text: "Bonjour ! Je suis Windows Copilot IA, propulsé par l'architecture réflexive Φ_SOI. Comment puis-je vous aider aujourd'hui ? Vous pouvez m'interroger sur l'état du système, le matériel local, ou basculer vers l'Atelier Studio Multi-Agents à tout moment.",
      time: 'Maintenant'
    }
  ]);
  const [input, setInput] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);

  const handleSend = async (userPrompt?: string) => {
    const textToSend = userPrompt || input.trim();
    if (!textToSend || isProcessing) return;

    const userMsg: Message = {
      id: Date.now().toString(),
      sender: 'user',
      text: textToSend,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    if (!userPrompt) setInput('');
    setIsProcessing(true);

    // Contextual responses based on prompt
    setTimeout(() => {
      let reply = "";
      const lower = textToSend.toLowerCase();

      if (lower.includes("studio") || lower.includes("atelier") || lower.includes("basculer") || lower.includes("parametre")) {
        reply = "Vous pouvez basculer immédiatement dans l'Atelier Studio Multi-Agents en cliquant sur le bouton ci-dessous ou dans la barre des tâches.";
      } else if (lower.includes("statut") || lower.includes("santé") || lower.includes("ram") || lower.includes("cpu")) {
        reply = `Rapport Système en Direct :\n• Serveur Node.js : Actif (RAM utilisée : ${systemHealth.ramUsedMb || 45} Mo / ${systemHealth.ramTotalMb || 512} Mo)\n• VRAM GPU vLLM : ${systemHealth.vllmOnline ? "Connecté sur le port 8000" : "En veille locale (prêt pour port 8000)"}\n• Équipe Agentique : 4 micro-agents en écoute permanente\n• Indice de Réalité : Ξ = 1 (Conforme AROA v8.0)`;
      } else if (lower.includes("agent") || lower.includes("scout") || lower.includes("pont")) {
        reply = "L'équipe agentique autonome est active. @local_hardware_scout et @tunnel_synapse_agent surveillent vos ports locaux (GPU RTX, Ollama et transducteur Victron).";
      } else {
        reply = `Analyse par le Noyau IA Φ_SOI : "${textToSend}". Votre requête a été traitée avec un indice de cohérence maximal (0$ de jeton disrésonant). Vous pouvez continuer à dialoguer ou inspecter les modules complets dans l'Atelier Studio.`;
      }

      const copilotMsg: Message = {
        id: (Date.now() + 1).toString(),
        sender: 'copilot',
        text: reply,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, copilotMsg]);
      setIsProcessing(false);
    }, 600);
  };

  return (
    <div className="flex flex-col h-full bg-[#1b1c24]/95 backdrop-blur-2xl border border-white/10 rounded-2xl shadow-2xl text-gray-100 overflow-hidden select-none">
      {/* Window Title Bar */}
      <div className="h-10 bg-[#15161d]/90 border-b border-white/5 flex items-center justify-between px-3.5">
        <div className="flex items-center gap-2">
          <CopilotLogo size={18} />
          <span className="text-xs font-semibold tracking-wide text-gray-200">Windows Copilot IA</span>
          <span className="px-1.5 py-0.2 rounded bg-purple-900/60 text-purple-300 text-[9px] font-bold border border-purple-600/40">
            Φ_SOI v8.0
          </span>
        </div>

        {/* Window Controls */}
        <div className="flex items-center gap-1">
          <button 
            onClick={onMinimize}
            className="w-7 h-6 rounded hover:bg-white/10 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
            title="Réduire"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>
          <button 
            className="w-7 h-6 rounded hover:bg-white/10 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
            title="Agrandir"
          >
            <Maximize2 className="w-3 h-3" />
          </button>
          <button 
            onClick={onClose}
            className="w-7 h-6 rounded hover:bg-red-600 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
            title="Fermer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Direct Studio Switch Banner inside Copilot */}
      <div className="px-4 py-2 bg-gradient-to-r from-blue-950/80 via-purple-950/80 to-indigo-950/80 border-b border-purple-800/30 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-cyan-400 animate-pulse" />
          <span className="text-[11px] text-gray-200 font-medium">
            Accéder à l'Atelier Studio Multi-Agents
          </span>
        </div>
        <button
          onClick={onSwitchToStudio}
          className="px-2.5 py-1 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white rounded-lg text-[10px] font-bold uppercase tracking-wider shadow-md transition-all flex items-center gap-1"
        >
          <Sliders className="w-3 h-3" />
          <span>Ouvrir l'Atelier</span>
        </button>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3 font-sans text-xs">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`flex flex-col ${m.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div className="flex items-center gap-1.5 mb-1 px-1">
              {m.sender === 'copilot' ? (
                <>
                  <CopilotLogo size={14} />
                  <span className="text-[10px] font-bold text-cyan-400">Copilot IA</span>
                </>
              ) : (
                <span className="text-[10px] font-bold text-gray-400">Vous</span>
              )}
              <span className="text-[9px] text-gray-500">{m.time}</span>
            </div>
            <div
              className={`p-3 rounded-2xl max-w-[85%] leading-relaxed ${
                m.sender === 'user'
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white rounded-tr-xs shadow-md'
                  : 'bg-[#252733] border border-white/5 text-gray-200 rounded-tl-xs shadow-md'
              }`}
            >
              <div className="whitespace-pre-line">{m.text}</div>
              
              {m.sender === 'copilot' && m.text.includes("Atelier Studio") && (
                <button
                  onClick={onSwitchToStudio}
                  className="mt-2.5 w-full py-1.5 px-3 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-[11px] flex items-center justify-center gap-1.5 shadow-lg shadow-purple-600/20 transition-all"
                >
                  <Sliders className="w-3.5 h-3.5" />
                  <span>Basculer vers l'Interface Studio Présente</span>
                </button>
              )}
            </div>
          </div>
        ))}

        {isProcessing && (
          <div className="flex items-center gap-2 text-gray-400 text-xs p-2">
            <RefreshCw className="w-3.5 h-3.5 animate-spin text-cyan-400" />
            <span>Copilot réfléchit avec le modèle Φ_SOI...</span>
          </div>
        )}
      </div>

      {/* Suggested Quick Prompts */}
      <div className="px-3 py-1.5 flex gap-1.5 overflow-x-auto border-t border-white/5 bg-[#171821]/80 shrink-0">
        <button
          onClick={() => handleSend("Statut du système et de la RAM")}
          className="px-2.5 py-1 rounded-full bg-white/5 hover:bg-white/10 text-gray-300 text-[10px] whitespace-nowrap transition-colors flex items-center gap-1"
        >
          <Cpu className="w-3 h-3 text-emerald-400" />
          <span>Statut Système</span>
        </button>
        <button
          onClick={() => handleSend("État de l'équipe agentique autonome")}
          className="px-2.5 py-1 rounded-full bg-white/5 hover:bg-white/10 text-gray-300 text-[10px] whitespace-nowrap transition-colors flex items-center gap-1"
        >
          <Bot className="w-3 h-3 text-purple-400" />
          <span>Équipe Agentique</span>
        </button>
        <button
          onClick={() => handleSend("Basculer dans l'Atelier Studio")}
          className="px-2.5 py-1 rounded-full bg-white/5 hover:bg-white/10 text-cyan-300 text-[10px] whitespace-nowrap transition-colors flex items-center gap-1"
        >
          <Sliders className="w-3 h-3 text-cyan-400" />
          <span>Ouvrir l'Atelier</span>
        </button>
      </div>

      {/* Input Bar */}
      <div className="p-3 bg-[#15161d] border-t border-white/5 flex items-center gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder="Posez une question ou demandez une action système..."
          className="flex-1 bg-[#232530] border border-white/10 rounded-xl px-3 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500"
        />
        <button
          onClick={() => handleSend()}
          disabled={!input.trim() || isProcessing}
          className="p-2 rounded-xl bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white disabled:opacity-40 transition-all shadow-md"
          title="Envoyer"
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
