import React from 'react';

export const WindowsLogo: React.FC<{ className?: string; size?: number }> = ({ className = "w-4 h-4", size }) => {
  const style = size ? { width: size, height: size } : undefined;
  return (
    <div className={`grid grid-cols-2 gap-0.5 ${className}`} style={style} title="Windows 11">
      <div className="bg-[#0078d4] rounded-[1px]"></div>
      <div className="bg-[#0078d4] rounded-[1px]"></div>
      <div className="bg-[#0078d4] rounded-[1px]"></div>
      <div className="bg-[#0078d4] rounded-[1px]"></div>
    </div>
  );
};

export const CopilotLogo: React.FC<{ className?: string; size?: number }> = ({ className = "w-5 h-5", size }) => {
  const style = size ? { width: size, height: size } : undefined;
  return (
    <div className={`relative flex items-center justify-center ${className}`} style={style} title="Windows Copilot IA">
      <div className="absolute inset-0 rounded-full bg-gradient-to-tr from-[#0078d4] via-[#8936f4] to-[#f7630c] opacity-80 blur-[2px] animate-pulse"></div>
      <div className="relative w-full h-full rounded-full bg-gradient-to-tr from-[#0078d4] via-[#8936f4] to-[#ff5d6c] p-0.5 flex items-center justify-center shadow-sm">
        <div className="w-full h-full rounded-full bg-[#12131a] flex items-center justify-center">
          <span className="text-[9px] font-black text-transparent bg-clip-text bg-gradient-to-tr from-cyan-400 to-purple-300">
            AI
          </span>
        </div>
      </div>
    </div>
  );
};
