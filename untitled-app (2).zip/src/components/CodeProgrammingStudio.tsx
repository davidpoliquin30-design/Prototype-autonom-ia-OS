import React, { useState, useEffect, useRef } from "react";
import { 
  Folder, File, Plus, Trash2, Save, Terminal, Play, 
  Code2, Sparkles, ChevronDown, ChevronRight, FileCode, Check 
} from "lucide-react";
import ProCoderExpertLlmPanel from "./ProCoderExpertLlmPanel";
import SynapticPipelineViewer from "./SynapticPipelineViewer";
import QuantumIdeChat from "./code/QuantumIdeChat";
import { WorkspaceFile } from "../types";

interface CodeProgrammingStudioProps {
  files: WorkspaceFile[];
  onRefreshFiles: () => void;
  onSelectFile?: (path: string, content: string) => void;
}

export default function CodeProgrammingStudio({ 
  files, 
  onRefreshFiles, 
  onSelectFile 
}: CodeProgrammingStudioProps) {
  const [activeFilePath, setActiveFilePath] = useState<string>("");
  const [activeFileContent, setActiveFileContent] = useState<string>("");
  const [isDirty, setIsDirty] = useState<boolean>(false);
  const [expandedFolders, setExpandedFolders] = useState<{ [path: string]: boolean }>({ "src": true });
  const [rightSidebarTab, setRightSidebarTab] = useState<"procoder" | "synaptic" | "copilot">("copilot");
  
  // Create File / Folder states
  const [showCreateInput, setShowCreateInput] = useState<"file" | "folder" | null>(null);
  const [createPathParent, setCreatePathParent] = useState<string>("");
  const [createName, setCreateName] = useState<string>("");

  // Simulated Console output state
  const [consoleLogs, setConsoleLogs] = useState<string[]>([
    "Systeme Φ_SOI IDE Simulator v1.0.0 initialized.",
    "Ready for filesystem orchestration."
  ]);
  const [isCompiling, setIsCompiling] = useState<boolean>(false);

  // Load selected file
  const handleFileClick = async (filePath: string) => {
    try {
      const res = await fetch("/api/files/read", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ filePath }),
      });
      const data = await res.json();
      if (data.content !== undefined) {
        setActiveFilePath(filePath);
        setActiveFileContent(data.content);
        setIsDirty(false);
        if (onSelectFile) onSelectFile(filePath, data.content);
        
        // Add log
        addConsoleLog(`Loaded file /${filePath} (${data.content.length} characters).`);
      }
    } catch (err: any) {
      addConsoleLog(`Error reading /${filePath}: ${err.message}`);
    }
  };

  const handleSaveFile = async () => {
    if (!activeFilePath) return;
    try {
      const res = await fetch("/api/files/write", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ filePath: activeFilePath, content: activeFileContent }),
      });
      const data = await res.json();
      if (data.success) {
        setIsDirty(false);
        addConsoleLog(`File /${activeFilePath} written successfully to workspace filesystem.`);
        onRefreshFiles();
        
        // Trigger compiler simulation automatically
        runSimulatedCompiler();
      }
    } catch (err: any) {
      addConsoleLog(`Error writing /${activeFilePath}: ${err.message}`);
    }
  };

  const handleCreateItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!createName.trim()) return;

    const fullPath = createPathParent 
      ? `${createPathParent}/${createName.trim()}`
      : createName.trim();

    try {
      if (showCreateInput === "file") {
        const res = await fetch("/api/files/write", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ filePath: fullPath, content: `// File created automatically\nexport {};\n` }),
        });
        const data = await res.json();
        if (data.success) {
          addConsoleLog(`Created file /${fullPath}`);
          handleFileClick(fullPath);
        }
      } else {
        // Create folder inside Express (folders are auto created on file writes, or we write a placeholder)
        const placeholderPath = `${fullPath}/.placeholder`;
        const res = await fetch("/api/files/write", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ filePath: placeholderPath, content: "" }),
        });
        const data = await res.json();
        if (data.success) {
          addConsoleLog(`Created directory /${fullPath}`);
        }
      }
      
      onRefreshFiles();
      setShowCreateInput(null);
      setCreateName("");
    } catch (err: any) {
      addConsoleLog(`Error creating item: ${err.message}`);
    }
  };

  const handleDeleteItem = async (filePath: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm(`Confirmer la suppression de /${filePath} ?`)) return;

    try {
      const res = await fetch("/api/files/delete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ filePath }),
      });
      const data = await res.json();
      if (data.success) {
        addConsoleLog(`Deleted /${filePath}`);
        if (activeFilePath === filePath) {
          setActiveFilePath("");
          setActiveFileContent("");
          setIsDirty(false);
        }
        onRefreshFiles();
      }
    } catch (err: any) {
      addConsoleLog(`Error deleting /${filePath}: ${err.message}`);
    }
  };

  const runSimulatedCompiler = () => {
    setIsCompiling(true);
    addConsoleLog(`$ npm run lint && npm run build`);
    
    setTimeout(() => {
      addConsoleLog(`🔬 [Compilateur] Analyse syntaxique globale lancée...`);
    }, 500);

    setTimeout(() => {
      addConsoleLog(`🏗️ [ProCoder] Optimisation incrémentale et type-checking...`);
    }, 1200);

    setTimeout(() => {
      setIsCompiling(false);
      addConsoleLog(`✔ [Linter] Succès : Aucun avertissement ni erreur trouvés dans l'espace de travail !`);
    }, 2200);
  };

  const addConsoleLog = (text: string) => {
    const time = new Date().toLocaleTimeString();
    setConsoleLogs(prev => [...prev, `[${time}] ${text}`]);
  };

  // Helper folder toggler
  const toggleFolder = (path: string) => {
    setExpandedFolders(prev => ({ ...prev, [path]: !prev[path] }));
  };

  // Recursive Node Renderer for the file tree
  const renderFileNode = (node: WorkspaceFile) => {
    const isFolder = node.type === "directory";
    const isExpanded = expandedFolders[node.path] || false;
    const isSelected = activeFilePath === node.path;

    return (
      <div key={node.path} className="select-none text-xs font-mono">
        <div 
          onClick={() => isFolder ? toggleFolder(node.path) : handleFileClick(node.path)}
          className={`group flex items-center justify-between py-1 px-2 rounded-lg cursor-pointer transition-colors ${
            isSelected 
              ? "bg-[#1e130c] text-orange-400 border-l-2 border-orange-500" 
              : "hover:bg-[#14151a] text-gray-400 hover:text-gray-200"
          }`}
        >
          <div className="flex items-center gap-1.5 truncate">
            {isFolder ? (
              <>
                {isExpanded ? <ChevronDown className="w-3.5 h-3.5 text-gray-500" /> : <ChevronRight className="w-3.5 h-3.5 text-gray-500" />}
                <Folder className="w-3.5 h-3.5 text-orange-400/80 shrink-0" />
              </>
            ) : (
              <>
                <File className="w-3.5 h-3.5 text-gray-400 shrink-0" />
              </>
            )}
            <span className="truncate">{node.name}</span>
          </div>

          {/* Action buttons visible on hover */}
          <div className="opacity-0 group-hover:opacity-100 flex items-center gap-1">
            {isFolder && (
              <>
                <button 
                  onClick={(e) => {
                    e.stopPropagation();
                    setCreatePathParent(node.path);
                    setShowCreateInput("file");
                  }}
                  title="Nouveau Fichier"
                  className="p-0.5 hover:bg-[#282a39] text-gray-400 rounded transition-colors"
                >
                  <Plus className="w-3 h-3" />
                </button>
              </>
            )}
            <button 
              onClick={(e) => handleDeleteItem(node.path, e)}
              title="Supprimer"
              className="p-0.5 hover:bg-red-950/50 hover:text-red-400 text-gray-500 rounded transition-colors"
            >
              <Trash2 className="w-3 h-3" />
            </button>
          </div>
        </div>

        {isFolder && isExpanded && node.children && (
          <div className="pl-3.5 border-l border-[#1f2029]/60 ml-3 mt-0.5 space-y-0.5">
            {node.children.map(child => renderFileNode(child))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div id="code-studio-container" className="h-full flex flex-col md:flex-row bg-[#0b0c10] border border-[#1f2029] rounded-xl overflow-hidden shadow-xl text-gray-200">
      
      {/* 1. FILE EXPLORER SIDEBAR */}
      <div className="w-full md:w-64 border-r border-[#1f2029] bg-[#121319] flex flex-col shrink-0 min-h-[250px] md:h-full">
        <div className="p-3 border-b border-[#1f2029] flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <Code2 className="w-4 h-4 text-orange-500" />
            <span className="text-xs font-mono font-bold uppercase tracking-wider text-gray-300">EXPLORATEUR Φ</span>
          </div>
          
          <div className="flex gap-1">
            <button
              onClick={() => {
                setCreatePathParent("");
                setShowCreateInput("file");
              }}
              title="Créer Fichier Racine"
              className="p-1 hover:bg-[#1e202b] hover:text-orange-400 text-gray-400 rounded transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Create Input Modal Box */}
        {showCreateInput && (
          <form onSubmit={handleCreateItem} className="p-2.5 bg-[#14151a] border-b border-[#2b2d3a] font-mono text-xs space-y-1.5">
            <div className="text-[9px] text-gray-400 uppercase tracking-wider">
              Créer {showCreateInput === "file" ? "Fichier" : "Dossier"} {createPathParent ? `dans /${createPathParent}` : "à la racine"}
            </div>
            <div className="flex gap-1.5">
              <input
                value={createName}
                onChange={e => setCreateName(e.target.value)}
                placeholder={showCreateInput === "file" ? "index.ts" : "composants"}
                className="flex-1 bg-[#0b0c10] border border-[#2b2d3a] p-1 text-[11px] rounded focus:outline-none focus:border-orange-500 text-gray-200"
                autoFocus
              />
              <button type="submit" className="px-2 bg-orange-500 text-black font-bold rounded text-xs">OK</button>
              <button type="button" onClick={() => setShowCreateInput(null)} className="px-1.5 hover:bg-[#282a39] text-gray-400 rounded text-xs">X</button>
            </div>
          </form>
        )}

        {/* Tree Container */}
        <div className="flex-1 p-3 overflow-y-auto space-y-1">
          {files.map(node => renderFileNode(node))}
        </div>
      </div>

      {/* 2. CENTRAL EDITOR & CONSOLE AREA */}
      <div className="flex-1 flex flex-col h-full overflow-hidden bg-[#08090d]">
        
        {/* Editor Info & File Control Bar */}
        <div className="flex items-center justify-between px-4 py-2 bg-[#14151a] border-b border-[#1f2029]">
          <div className="flex items-center gap-2">
            <FileCode className="w-4 h-4 text-orange-400" />
            <span className="text-xs font-mono font-bold text-gray-300">
              {activeFilePath ? `/${activeFilePath}` : "Aucun fichier ouvert"}
            </span>
            {isDirty && (
              <span className="text-[10px] bg-orange-950/40 border border-orange-500/20 text-orange-400 px-1.5 py-0.5 rounded animate-pulse">
                Modifié
              </span>
            )}
          </div>

          <button
            onClick={handleSaveFile}
            disabled={!activeFilePath || !isDirty}
            className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold flex items-center gap-1.5 transition-all ${
              isDirty 
                ? "bg-orange-500 hover:bg-orange-600 text-black shadow-md shadow-orange-500/10 cursor-pointer"
                : "bg-gray-800 text-gray-500 cursor-not-allowed"
            }`}
          >
            <Save className="w-3.5 h-3.5" />
            Sauvegarder
          </button>
        </div>

        {/* Actual Code Input */}
        <div className="flex-1 flex overflow-hidden min-h-[300px]">
          {activeFilePath ? (
            <textarea
              value={activeFileContent}
              onChange={(e) => {
                setActiveFileContent(e.target.value);
                setIsDirty(true);
              }}
              className="w-full h-full bg-[#08090d] text-gray-300 p-4 font-mono text-xs leading-relaxed resize-none focus:outline-none select-text custom-scrollbar selection:bg-orange-500/20"
              placeholder="// Saisissez votre code..."
              spellCheck={false}
            />
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-gray-500 gap-2 font-mono">
              <Code2 className="w-10 h-10 text-orange-500/40 animate-pulse" />
              <span className="text-sm">Aucun fichier chargé dans l'éditeur.</span>
              <span className="text-[10px] text-gray-600">Sélectionnez un fichier dans l'explorateur de gauche.</span>
            </div>
          )}
        </div>

        {/* 3. SIMULATED LINUX / COMPILER CONSOLE */}
        <div className="h-44 border-t border-[#1f2029] bg-[#0b0c10] flex flex-col shrink-0 overflow-hidden font-mono text-xs">
          <div className="px-4 py-1.5 bg-[#121319] border-b border-[#1f2029] flex items-center justify-between text-gray-400">
            <div className="flex items-center gap-1.5">
              <Terminal className="w-4 h-4 text-emerald-500" />
              <span className="font-bold text-[10px] uppercase tracking-wider">Console d'Exécution & Linter</span>
            </div>

            <button
              onClick={runSimulatedCompiler}
              disabled={isCompiling}
              className="px-2 py-0.5 bg-[#1e202b] hover:bg-[#282a39] hover:text-emerald-400 border border-[#2b2d3a] rounded text-[10px] flex items-center gap-1 transition-all"
            >
              <Play className="w-3 h-3 text-emerald-500" />
              Lancer Compilation
            </button>
          </div>

          <div className="flex-1 p-3 overflow-y-auto space-y-1 bg-[#06070a] select-text text-gray-300">
            {consoleLogs.map((log, index) => (
              <div key={index} className="leading-relaxed truncate">{log}</div>
            ))}
            {isCompiling && (
              <div className="flex items-center gap-1 text-orange-400 animate-pulse font-semibold">
                <span>●</span>
                <span>Traitement réflexif en cours...</span>
              </div>
            )}
          </div>
        </div>

      </div>

      {/* 4. PROCODER LLM AGENT PANEL (RIGHT SIDEBAR) */}
      <div className="w-full md:w-80 border-t md:border-t-0 md:border-l border-[#1f2029] bg-[#121319] flex flex-col shrink-0 overflow-y-auto h-full">
        {/* Tab selector for Right Sidebar */}
        <div className="flex border-b border-[#1f2029] bg-[#0c0d12] shrink-0">
          <button
            onClick={() => setRightSidebarTab("copilot")}
            className={`flex-1 py-2.5 px-2 text-[9px] font-bold uppercase tracking-wider transition-all text-center border-b-2 ${
              rightSidebarTab === "copilot"
                ? "border-orange-500 text-orange-400 bg-[#121319]"
                : "border-transparent text-gray-400 hover:text-gray-200"
            }`}
          >
            Copilote
          </button>
          <button
            onClick={() => setRightSidebarTab("procoder")}
            className={`flex-1 py-2.5 px-2 text-[9px] font-bold uppercase tracking-wider transition-all text-center border-b-2 ${
              rightSidebarTab === "procoder"
                ? "border-orange-500 text-orange-400 bg-[#121319]"
                : "border-transparent text-gray-400 hover:text-gray-200"
            }`}
          >
            Expert
          </button>
          <button
            onClick={() => setRightSidebarTab("synaptic")}
            className={`flex-1 py-2.5 px-2 text-[9px] font-bold uppercase tracking-wider transition-all text-center border-b-2 ${
              rightSidebarTab === "synaptic"
                ? "border-orange-500 text-orange-400 bg-[#121319]"
                : "border-transparent text-gray-400 hover:text-gray-200"
            }`}
          >
            Bus
          </button>
        </div>

        <div className="p-2">
          {rightSidebarTab === "copilot" ? (
            <QuantumIdeChat 
              activeFile={activeFilePath || null}
              onRefreshFiles={onRefreshFiles}
              onSelectFile={(path, content) => {
                handleFileClick(path);
              }}
              addConsoleLog={addConsoleLog}
            />
          ) : rightSidebarTab === "procoder" ? (
            <ProCoderExpertLlmPanel 
              activeFilePath={activeFilePath}
              activeFileContent={activeFileContent}
              onApplyOptimization={(newContent) => {
                setActiveFileContent(newContent);
                setIsDirty(true);
                addConsoleLog(`Refactoring applied from ProCoder Agent to editor cache.`);
              }}
            />
          ) : (
            <SynapticPipelineViewer 
              activeFile={activeFilePath || null}
              files={files}
              isDirty={isDirty}
              linterStatus={isDirty ? "WARNING" : "CLEAN"}
            />
          )}
        </div>
      </div>

    </div>
  );
}
