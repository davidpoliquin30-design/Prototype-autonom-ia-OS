import React, { useState } from "react";
import { 
  Cpu, Network, Shield, Zap, Play, History, Terminal, 
  ArrowRight, Lock, RefreshCw, CheckCircle2, AlertTriangle, HelpCircle
} from "lucide-react";
import { AgentInfo, SynapticMessage } from "../../services/agentMeshHub";

interface SidebarControlDockProps {
  agents: AgentInfo[];
  logs: SynapticMessage[];
  isTransmitting: boolean;
  coherenceScore: number;
  systemLoad: number;
  executeTransaction: (sender: string, receiver: string, input: string) => Promise<any>;
  onRefresh: () => void;
}

export default function SidebarControlDock({
  agents,
  logs,
  isTransmitting,
  coherenceScore,
  systemLoad,
  executeTransaction,
  onRefresh,
}: SidebarControlDockProps) {
  const [activeSubTab, setActiveSubTab] = useState<"commander" | "agents" | "logs">("commander");
  
  // Custom signal state
  const [sender, setSender] = useState<string>("@human_language_master");
  const [receiver, setReceiver] = useState<string>("@supervisor");
  const [signalPayload, setSignalPayload] = useState<string>(
    "Analyser la conformité sémantique de l'architecture locale"
  );
  
  const [lastTxResult, setLastTxResult] = useState<SynapticMessage | null>(null);

  const handleSendSignal = async () => {
    if (!signalPayload.trim()) return;
    const result = await executeTransaction(sender, receiver, signalPayload);
    if (result) {
      setLastTxResult(result);
    }
  };

  return (
    <div className="w-full bg-[#080a0f] border border-[#14161f] rounded-none p-4 flex flex-col gap-4">
      
      {/* Dock navigation tabs */}
      <div className="flex border-b border-[#14151e] pb-1.5 gap-2">
        <button
          onClick={() => setActiveSubTab("commander")}
          className={`px-3 py-1.5 text-[10px] font-black uppercase tracking-wider rounded transition-all ${
            activeSubTab === "commander"
              ? "bg-[#1d140e] text-orange-400 border border-orange-500/20"
              : "text-gray-500 hover:text-gray-300"
          }`}
        >
          <Zap className="w-3.5 h-3.5 inline mr-1" />
          Synapse Commander
        </button>
        
        <button
          onClick={() => setActiveSubTab("agents")}
          className={`px-3 py-1.5 text-[10px] font-black uppercase tracking-wider rounded transition-all ${
            activeSubTab === "agents"
              ? "bg-[#1d140e] text-orange-400 border border-orange-500/20"
              : "text-gray-500 hover:text-gray-300"
          }`}
        >
          <Network className="w-3.5 h-3.5 inline mr-1" />
          Réseau Flotte
        </button>

        <button
          onClick={() => setActiveSubTab("logs")}
          className={`px-3 py-1.5 text-[10px] font-black uppercase tracking-wider rounded transition-all ${
            activeSubTab === "logs"
              ? "bg-[#1d140e] text-orange-400 border border-orange-500/20"
              : "text-gray-500 hover:text-gray-300"
          }`}
        >
          <History className="w-3.5 h-3.5 inline mr-1" />
          Télémétrie & Logs
        </button>
      </div>

      {/* SUBTAB 1: SYNAPSE COMMANDER */}
      {activeSubTab === "commander" && (
        <div className="space-y-4">
          
          {/* Signal path definition fields */}
          <div className="space-y-2">
            <div className="text-[9px] font-extrabold uppercase text-gray-500 tracking-wider">
              Définition de la Passerelle Synaptique
            </div>
            
            <div className="grid grid-cols-2 gap-2">
              <div className="space-y-1">
                <label className="text-[8px] text-gray-600 uppercase font-bold">Émetteur</label>
                <select 
                  value={sender} 
                  onChange={(e) => setSender(e.target.value)}
                  className="w-full bg-[#050609] border border-[#181923] text-gray-300 text-[10px] px-2 py-1.5 focus:outline-none focus:border-orange-500/40 font-mono"
                >
                  {agents.map(ag => (
                    <option key={`send-${ag.id}`} value={ag.id}>{ag.name}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[8px] text-gray-600 uppercase font-bold">Destinataire</label>
                <select 
                  value={receiver} 
                  onChange={(e) => setReceiver(e.target.value)}
                  className="w-full bg-[#050609] border border-[#181923] text-gray-300 text-[10px] px-2 py-1.5 focus:outline-none focus:border-orange-500/40 font-mono"
                >
                  {agents.map(ag => (
                    <option key={`recv-${ag.id}`} value={ag.id}>{ag.name}</option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Payload and Vault Encryption notice */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <div className="text-[9px] font-extrabold uppercase text-gray-500 tracking-wider">
                Signal à Transmettre (Signal Input)
              </div>
              <span className="text-[7.5px] text-emerald-500 font-bold flex items-center gap-1 uppercase">
                <Lock className="w-3 h-3 text-emerald-500" /> Plan Bêta Chiffrement Actif
              </span>
            </div>

            <textarea
              value={signalPayload}
              onChange={(e) => setSignalPayload(e.target.value)}
              placeholder="Saisissez la directive ou le signal..."
              rows={3}
              className="w-full bg-[#050609] border border-[#181923] text-gray-300 text-[10px] p-2 focus:outline-none focus:border-orange-500/40 font-mono leading-relaxed resize-none"
            />
          </div>

          {/* SRE Action Trigger Button */}
          <button
            onClick={handleSendSignal}
            disabled={isTransmitting || !signalPayload.trim()}
            className="w-full py-2 bg-orange-500 hover:bg-orange-600 disabled:bg-[#13151c] text-black disabled:text-gray-600 font-black text-[10px] uppercase tracking-wider transition-all flex items-center justify-center gap-2"
          >
            {isTransmitting ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                Transit Synaptique en cours...
              </>
            ) : (
              <>
                <Play className="w-3 h-3 text-black" />
                Lancer la transaction sémantique (Ξ=1)
              </>
            )}
          </button>

          {/* Real-time transaction report panel */}
          {lastTxResult && (
            <div className="p-3 bg-[#040508] border border-[#131520] rounded-none space-y-2 text-[10px]">
              <div className="flex items-center justify-between border-b border-[#14151e] pb-1">
                <span className="font-extrabold text-orange-400 uppercase tracking-widest text-[8px] flex items-center gap-1.5">
                  <Terminal className="w-3 h-3" /> Rapport de transaction sémantique
                </span>
                <span className="text-[7.5px] text-gray-500">{lastTxResult.id}</span>
              </div>
              
              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-gray-500">Bouclage Shield (Plan Bêta) :</span>
                  <span className="text-emerald-400 font-bold">{lastTxResult.tokensMaskedCount} tokens masqués</span>
                </div>
                <div className="p-1 bg-[#06070a] border border-[#0d0e14] text-gray-400 font-mono text-[8.5px] truncate">
                  {lastTxResult.sanitizedSignal}
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-gray-500">Réfles Physique (Plan Alpha) :</span>
                  <span className={lastTxResult.invariantsViolated ? "text-amber-400 font-bold" : "text-emerald-400 font-bold"}>
                    {lastTxResult.invariantsViolated ? "Invariants Violés" : "Invariants Valides"}
                  </span>
                </div>
                <p className="text-[8.5px] text-gray-500 italic pl-1 border-l border-orange-500/30">
                  {lastTxResult.physicalResult}
                </p>
              </div>

              <div className="space-y-1 pt-1 border-t border-[#0e0f15]">
                <span className="text-gray-500">Directive Cognitive Réhydratée :</span>
                <div className="p-1.5 bg-[#050608] border border-[#101118] text-white font-mono text-[8.5px] overflow-x-auto whitespace-pre-wrap leading-relaxed max-h-24">
                  {lastTxResult.outputPayload}
                </div>
              </div>
            </div>
          )}

        </div>
      )}

      {/* SUBTAB 2: AGENT FLOTTE */}
      {activeSubTab === "agents" && (
        <div className="space-y-3">
          <div className="flex justify-between items-center text-[9px] font-extrabold uppercase text-gray-500 tracking-wider">
            <span>Annuaire des Agents Actifs</span>
            <button onClick={onRefresh} className="hover:text-orange-400 transition-colors">
              <RefreshCw className="w-3 h-3" />
            </button>
          </div>

          <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
            {agents.map(ag => (
              <div 
                key={ag.id} 
                className="p-2.5 bg-[#050609] border border-[#12131b] hover:border-[#1d2030] transition-all flex flex-col gap-1.5"
              >
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-1.5">
                    <span className={`w-1.5 h-1.5 rounded-full ${
                      ag.pole === "direction" ? "bg-blue-500" :
                      ag.pole === "gouvernance" ? "bg-red-500" :
                      ag.pole === "code" ? "bg-purple-500" : "bg-emerald-500"
                    }`} />
                    <span className="font-extrabold text-[10px] text-gray-100">{ag.name}</span>
                  </div>
                  <span className="text-[7.5px] px-1 py-0.5 rounded bg-[#101118] text-emerald-400 font-bold uppercase tracking-wider">
                    {ag.status}
                  </span>
                </div>
                
                <p className="text-[8.5px] text-gray-500 leading-relaxed line-clamp-2">
                  {ag.role}
                </p>

                <div className="flex justify-between text-[7.5px] font-mono text-gray-600 border-t border-[#0f1016] pt-1">
                  <span>EQUATION: <span className="text-gray-400">{ag.equation}</span></span>
                  <span>LATENCY: <span className="text-gray-400">{ag.latency}ms</span></span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUBTAB 3: TELEMETRY LOGS */}
      {activeSubTab === "logs" && (
        <div className="space-y-3">
          <div className="text-[9px] font-extrabold uppercase text-gray-500 tracking-wider">
            Chronologie des Flux Synaptiques
          </div>

          <div className="space-y-1.5 max-h-80 overflow-y-auto pr-1">
            {logs.length === 0 ? (
              <div className="text-center py-6 text-gray-600 text-[9px] font-bold">
                Aucune transaction dans le cache synaptique.
              </div>
            ) : (
              logs.map(log => (
                <div 
                  key={log.id} 
                  className="p-2 bg-[#040508] border border-[#0f1016] space-y-1.5 text-[8.5px]"
                >
                  <div className="flex justify-between text-gray-500 font-mono text-[7.5px]">
                    <span>{log.id} // {log.timestamp.split("T")[1].substring(0, 8)}</span>
                    <span className={log.invariantsViolated ? "text-amber-500 font-bold" : "text-emerald-500 font-bold"}>
                      {log.invariantsViolated ? "REFLEX_ALERT" : "REFLEX_OK"}
                    </span>
                  </div>

                  <div className="flex items-center gap-1.5 text-gray-300">
                    <span className="font-bold text-sky-400">{log.sender}</span>
                    <ArrowRight className="w-3 h-3 text-gray-600" />
                    <span className="font-bold text-purple-400">{log.receiver}</span>
                  </div>

                  <p className="text-gray-500 truncate">
                    INPUT: "{log.rawInput}"
                  </p>

                  <div className="flex justify-between items-center text-[7.5px] text-gray-600 border-t border-[#0b0c11] pt-1">
                    <span>VAULT_SHIELD: {log.tokensMaskedCount} keys</span>
                    <span>COGNITIVE: BRIDGED & COMMITTED</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

    </div>
  );
}
