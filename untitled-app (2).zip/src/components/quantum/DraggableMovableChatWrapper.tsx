import React, { useState, useEffect, useRef, useCallback } from "react";
import { 
  GripHorizontal, 
  Move, 
  Maximize2, 
  Minimize2, 
  RotateCcw, 
  Compass, 
  X,
  Sparkles,
  Bot
} from "lucide-react";

export type ChatSizeMode = "compact" | "medium" | "large";

interface DraggableMovableChatWrapperProps {
  isOpen: boolean;
  onClose: () => void;
  activeTab: string;
  children: React.ReactNode;
}

const SIZE_CONFIGS: Record<ChatSizeMode, { width: number; height: number; label: string }> = {
  compact: { width: 420, height: 420, label: "Compact (420×420)" },
  medium: { width: 520, height: 500, label: "Moyen (520×500) • Recommandé" },
  large: { width: 640, height: 560, label: "Élargi (640×560)" },
};

export default function DraggableMovableChatWrapper({
  isOpen,
  onClose,
  activeTab,
  children
}: DraggableMovableChatWrapperProps) {
  const [sizeMode, setSizeMode] = useState<ChatSizeMode>("medium");
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [position, setPosition] = useState<{ x: number; y: number }>({ x: 20, y: 80 });
  const [isInitialized, setIsInitialized] = useState<boolean>(false);
  const [showSnapMenu, setShowSnapMenu] = useState<boolean>(false);

  const dragStartRef = useRef<{ startX: number; startY: number; initX: number; initY: number }>({
    startX: 0,
    startY: 0,
    initX: 0,
    initY: 0
  });

  const currentSize = SIZE_CONFIGS[sizeMode];

  // Helper to clamp position within screen
  const clampPosition = useCallback((x: number, y: number, w: number, h: number) => {
    if (typeof window === "undefined") return { x, y };
    const minX = 8;
    const maxX = Math.max(minX, window.innerWidth - w - 8);
    const minY = 52; // below main navbar
    const maxY = Math.max(minY, window.innerHeight - h - 8);

    return {
      x: Math.min(Math.max(x, minX), maxX),
      y: Math.min(Math.max(y, minY), maxY)
    };
  }, []);

  // Initial positioning: load from storage or default to bottom-right medium
  useEffect(() => {
    if (typeof window === "undefined") return;

    try {
      const savedX = localStorage.getItem("omni_chat_pos_x");
      const savedY = localStorage.getItem("omni_chat_pos_y");
      const savedSize = localStorage.getItem("omni_chat_size") as ChatSizeMode | null;

      if (savedSize && SIZE_CONFIGS[savedSize]) {
        setSizeMode(savedSize);
      }

      const activeW = savedSize && SIZE_CONFIGS[savedSize] ? SIZE_CONFIGS[savedSize].width : currentSize.width;
      const activeH = savedSize && SIZE_CONFIGS[savedSize] ? SIZE_CONFIGS[savedSize].height : currentSize.height;

      if (savedX !== null && savedY !== null) {
        const parsedX = parseFloat(savedX);
        const parsedY = parseFloat(savedY);
        setPosition(clampPosition(parsedX, parsedY, activeW, activeH));
      } else {
        // Default: Bottom-Right with margin
        const defaultX = Math.max(8, window.innerWidth - activeW - 24);
        const defaultY = Math.max(60, window.innerHeight - activeH - 24);
        setPosition({ x: defaultX, y: defaultY });
      }
    } catch (e) {
      // Fallback bottom-right
      const defaultX = Math.max(8, window.innerWidth - currentSize.width - 24);
      const defaultY = Math.max(60, window.innerHeight - currentSize.height - 24);
      setPosition({ x: defaultX, y: defaultY });
    }

    setIsInitialized(true);
  }, []);

  // Save coordinates
  const savePosition = (newX: number, newY: number) => {
    try {
      localStorage.setItem("omni_chat_pos_x", newX.toString());
      localStorage.setItem("omni_chat_pos_y", newY.toString());
    } catch (e) {
      // ignore storage errors
    }
  };

  // Re-clamp on window resize
  useEffect(() => {
    const handleResize = () => {
      setPosition(prev => clampPosition(prev.x, prev.y, currentSize.width, currentSize.height));
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [currentSize, clampPosition]);

  // Pointer Drag Handlers
  const handlePointerDown = (e: React.PointerEvent) => {
    // Only drag from target drag handle (ignore buttons or inputs inside header)
    const target = e.target as HTMLElement;
    if (target.closest("button") || target.closest("select") || target.closest("input")) {
      return;
    }

    e.preventDefault();
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);

    setIsDragging(true);
    dragStartRef.current = {
      startX: e.clientX,
      startY: e.clientY,
      initX: position.x,
      initY: position.y
    };
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    e.preventDefault();

    const deltaX = e.clientX - dragStartRef.current.startX;
    const deltaY = e.clientY - dragStartRef.current.startY;

    const rawX = dragStartRef.current.initX + deltaX;
    const rawY = dragStartRef.current.initY + deltaY;

    const clamped = clampPosition(rawX, rawY, currentSize.width, currentSize.height);
    setPosition(clamped);
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (!isDragging) return;
    setIsDragging(false);
    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch (err) {
      // Ignore
    }
    savePosition(position.x, position.y);
  };

  // Quick corner snaps
  const snapTo = (corner: "bottom-right" | "bottom-left" | "top-right" | "top-left" | "center") => {
    const w = currentSize.width;
    const h = currentSize.height;
    let targetX = 20;
    let targetY = 70;

    switch (corner) {
      case "bottom-right":
        targetX = window.innerWidth - w - 20;
        targetY = window.innerHeight - h - 20;
        break;
      case "bottom-left":
        targetX = 20;
        targetY = window.innerHeight - h - 20;
        break;
      case "top-right":
        targetX = window.innerWidth - w - 20;
        targetY = 64;
        break;
      case "top-left":
        targetX = 20;
        targetY = 64;
        break;
      case "center":
        targetX = (window.innerWidth - w) / 2;
        targetY = (window.innerHeight - h) / 2;
        break;
    }

    const clamped = clampPosition(targetX, targetY, w, h);
    setPosition(clamped);
    savePosition(clamped.x, clamped.y);
    setShowSnapMenu(false);
  };

  // Change size mode
  const handleChangeSize = (newMode: ChatSizeMode) => {
    setSizeMode(newMode);
    try {
      localStorage.setItem("omni_chat_size", newMode);
    } catch (e) {}

    const newConfig = SIZE_CONFIGS[newMode];
    setPosition(prev => {
      const clamped = clampPosition(prev.x, prev.y, newConfig.width, newConfig.height);
      savePosition(clamped.x, clamped.y);
      return clamped;
    });
  };

  if (!isOpen) return null;

  return (
    <div
      style={{
        position: "fixed",
        left: `${position.x}px`,
        top: `${position.y}px`,
        width: typeof window !== "undefined" && window.innerWidth < currentSize.width ? "94vw" : `${currentSize.width}px`,
        height: `${currentSize.height}px`,
        zIndex: 50,
      }}
      className={`flex flex-col rounded-2xl overflow-hidden shadow-2xl border border-purple-500/60 bg-[#070912] backdrop-blur-2xl transition-shadow ${
        isDragging ? "ring-4 ring-cyan-500/50 shadow-cyan-500/30 select-none cursor-grabbing" : "ring-1 ring-purple-500/30"
      }`}
    >
      {/* DRAG HANDLE BAR (Le chat peut être déplacé n'importe où dans l'onglet) */}
      <div
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        className="bg-gradient-to-r from-[#101426] via-[#151a32] to-[#101426] border-b border-[#252c4a] px-3 py-1.5 flex items-center justify-between gap-2 select-none cursor-grab active:cursor-grabbing text-xs text-gray-300 touch-none shrink-0"
        title="Maintenez le clic et glissez pour déplacer le chat n'importe où dans la page"
      >
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 text-cyan-400 bg-[#19203c] px-1.5 py-0.5 rounded border border-cyan-500/40">
            <GripHorizontal className="w-3.5 h-3.5" />
            <Move className="w-3 h-3 text-cyan-300" />
            <span className="text-[10px] font-bold uppercase tracking-wider text-cyan-200">Déplaçable</span>
          </div>

          <span className="text-[11px] font-semibold text-gray-200 hidden sm:inline">
            Chat [{activeTab.toUpperCase()}]
          </span>

          <span className="text-[9px] px-1.5 py-0.5 rounded bg-purple-950/80 text-purple-300 border border-purple-800 hidden md:inline">
            Taille : {sizeMode === "medium" ? "Moyenne" : sizeMode === "compact" ? "Compacte" : "Élargie"}
          </span>
        </div>

        {/* CONTROLS: SIZE, SNAP, RESET, CLOSE */}
        <div className="flex items-center gap-1.5">
          {/* Quick Corner Snap Button & Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowSnapMenu(!showSnapMenu)}
              className="p-1 rounded hover:bg-[#202744] text-gray-400 hover:text-cyan-300 transition-colors"
              title="Ancrer rapidement dans un coin (Bas-Droit, Haut-Droit, etc.)"
            >
              <Compass className="w-3.5 h-3.5" />
            </button>

            {showSnapMenu && (
              <div className="absolute right-0 top-7 w-44 bg-[#0e111d] border border-[#2b3558] rounded-xl shadow-2xl p-2 z-50 text-[11px] space-y-1 backdrop-blur-md">
                <div className="text-[9px] font-bold uppercase text-gray-400 px-2 py-0.5 border-b border-[#1c223a]">
                  Positionnement Rapide
                </div>
                <button
                  onClick={() => snapTo("bottom-right")}
                  className="w-full text-left px-2 py-1 rounded hover:bg-cyan-950/60 hover:text-cyan-300 flex items-center justify-between"
                >
                  <span>↘️ Bas-Droit (Défaut)</span>
                </button>
                <button
                  onClick={() => snapTo("top-right")}
                  className="w-full text-left px-2 py-1 rounded hover:bg-cyan-950/60 hover:text-cyan-300 flex items-center justify-between"
                >
                  <span>↗️ Haut-Droit</span>
                </button>
                <button
                  onClick={() => snapTo("bottom-left")}
                  className="w-full text-left px-2 py-1 rounded hover:bg-cyan-950/60 hover:text-cyan-300 flex items-center justify-between"
                >
                  <span>↙️ Bas-Gauche</span>
                </button>
                <button
                  onClick={() => snapTo("top-left")}
                  className="w-full text-left px-2 py-1 rounded hover:bg-cyan-950/60 hover:text-cyan-300 flex items-center justify-between"
                >
                  <span>↖️ Haut-Gauche</span>
                </button>
                <button
                  onClick={() => snapTo("center")}
                  className="w-full text-left px-2 py-1 rounded hover:bg-cyan-950/60 hover:text-cyan-300 flex items-center justify-between"
                >
                  <span>🎯 Centrer</span>
                </button>
              </div>
            )}
          </div>

          {/* Size Switcher Pills */}
          <div className="hidden sm:flex items-center bg-[#0a0d18] p-0.5 rounded-lg border border-[#1e2540] text-[9px] font-bold">
            <button
              onClick={() => handleChangeSize("compact")}
              className={`px-1.5 py-0.5 rounded transition-all ${
                sizeMode === "compact"
                  ? "bg-purple-900 text-cyan-300 shadow"
                  : "text-gray-400 hover:text-gray-200"
              }`}
              title="Taille Compacte (420×420)"
            >
              Compact
            </button>
            <button
              onClick={() => handleChangeSize("medium")}
              className={`px-1.5 py-0.5 rounded transition-all ${
                sizeMode === "medium"
                  ? "bg-purple-900 text-cyan-300 shadow"
                  : "text-gray-400 hover:text-gray-200"
              }`}
              title="Taille Moyenne (520×500) - Optimale"
            >
              Moyen
            </button>
            <button
              onClick={() => handleChangeSize("large")}
              className={`px-1.5 py-0.5 rounded transition-all ${
                sizeMode === "large"
                  ? "bg-purple-900 text-cyan-300 shadow"
                  : "text-gray-400 hover:text-gray-200"
              }`}
              title="Taille Élargie (640×560)"
            >
              Large
            </button>
          </div>

          {/* Reset position to default */}
          <button
            onClick={() => snapTo("bottom-right")}
            className="p-1 rounded hover:bg-[#202744] text-gray-400 hover:text-amber-300 transition-colors"
            title="Réinitialiser la position en bas à droite"
          >
            <RotateCcw className="w-3 h-3" />
          </button>

          {/* Close Window */}
          <button
            onClick={onClose}
            className="p-1 rounded hover:bg-red-950 text-gray-400 hover:text-red-300 transition-colors ml-1"
            title="Fermer le chat"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* CHAT CONTENT */}
      <div className="flex-1 min-h-0 overflow-hidden flex flex-col">
        {children}
      </div>
    </div>
  );
}
