import React, { useState, useEffect, useRef } from "react";
import { 
  Bot, 
  User, 
  Send, 
  Sparkles, 
  Zap, 
  CheckCircle2, 
  RefreshCw, 
  Trash2, 
  Layers, 
  Cpu, 
  ArrowRight, 
  Check, 
  Maximize2, 
  Minimize2, 
  X, 
  Sliders, 
  Radio, 
  Code2, 
  Activity, 
  Wand2,
  Orbit,
  ExternalLink,
  Play,
  Network,
  ShieldCheck,
  FileCode,
  Compass
} from "lucide-react";
import { 
  systemStructuralIntrospectionService, 
  SYSTEM_COMPONENTS_MAP,
  InternalSystemBlueprint,
  ComponentStructuralSpec
} from "../../services/quantum/systemStructuralIntrospectionService";
import { 
  tabAgenticTeamService, 
  TabTeamState, 
  TAB_DOMAIN_SPECS, 
  AgentModificationResult, 
  TabConversationalResponse 
} from "../../services/quantum/tabAgenticTeamService";
import { WorkspaceFile } from "../../types";

export interface OmniTabConversationalLLMProps {
  activeTab: string;
  files?: WorkspaceFile[];
  onRefreshFiles?: () => void;
  onNavigateTab?: (tabId: string) => void;
  isFloating?: boolean;
  onClose?: () => void;
}

interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  text: string;
  timestamp: string;
  isModification?: boolean;
  modificationResult?: AgentModificationResult;
  pipelineStages?: {
    stage: "analyser" | "comprendre" | "formuler" | "alchimiser" | "quantifier" | "construire";
    label: string;
    details: string;
    status: "completed" | "active" | "pending";
    latencyMs: number;
  }[];
  latencyMs?: number;
}

export default function OmniTabConversationalLLM({
  activeTab,
  files = [],
  onRefreshFiles,
  onNavigateTab,
  isFloating = false,
  onClose
}: OmniTabConversationalLLMProps) {
  const [teamState, setTeamState] = useState<TabTeamState>(tabAgenticTeamService.getActiveTabState());
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState<string>("");
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [currentPipelineStage, setCurrentPipelineStage] = useState<number>(-1);
  const [selectedModel, setSelectedModel] = useState<string>("gemini-3.8-flash");
  const [isFullscreen, setIsFullscreen] = useState<boolean>(false);
  const [showStructureInspector, setShowStructureInspector] = useState<boolean>(false);
  const [systemBlueprint, setSystemBlueprint] = useState<InternalSystemBlueprint>(
    systemStructuralIntrospectionService.getSystemBlueprint()
  );

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const spec = TAB_DOMAIN_SPECS[activeTab] || {
    tabId: activeTab,
    label: activeTab.toUpperCase(),
    domainFocus: "Gestion modulaire du système",
    innerUniverseCore: "Cohérence Φ_SOI et Résonance Unitaire",
    primaryFile: `src/components/${activeTab}.tsx`,
    targetQubits: "|ψ⟩"
  };

  // Subscribe to team updates and structural updates
  useEffect(() => {
    const unsubTeam = tabAgenticTeamService.subscribe((active) => {
      setTeamState({ ...active });
    });
    const unsubStruct = systemStructuralIntrospectionService.subscribe(() => {
      setSystemBlueprint(systemStructuralIntrospectionService.getSystemBlueprint());
    });
    return () => {
      unsubTeam();
      unsubStruct();
    };
  }, [activeTab]);

  // Initial greeting message when opening or switching tabs
  useEffect(() => {
    const activeUnderstanding = systemStructuralIntrospectionService.getAgentInternalUnderstanding(
      teamState.agents[0]?.id || "@agent_quantum",
      activeTab
    );

    const initMsg: ChatMessage = {
      id: `welcome-${activeTab}`,
      role: "assistant",
      text: `### 🤖 Copilote Agentique Connecté • [${spec.label}]\n\nJe suis votre LLM conversationnel dédié à la page **${spec.label}**, orchestré par votre flotte de **${teamState.agents.length} agents quantiques** interconnectés.\n\n- **Auto-Compréhension Intérieure :** Chaque agent est relié en temps réel aux **14 composants d'onglets**, aux **6 pôles de la flotte** et à l'arborescence AST. Nous comprenons le système de l'intérieur.\n- **Domaine actif :** ${spec.domainFocus}\n- **Fichier socle physique :** \`${spec.primaryFile}\`\n- **Loi intérieure :** ${spec.innerUniverseCore}\n- **Invariants du noyau :** Indice de Réalité **Ξ ≡ 1.0000** | Disrésonance **$D_c \\to 0$**\n\nChaque demande est traitée selon le cycle des 6 pôles : **Analyser ➔ Comprendre ➔ Formuler ➔ Alchimiser ➔ Quantifier ➔ Construire**.\n\n*Exemples de commandes directes :*\n- « **Modifier l'agent X avec l'agent Q** » *(substitution autonome immédiate)*\n- « **Explique-moi comment tu comprends la structure de cette page de l'intérieur** »\n- « **Harmonise le code de ce module sans dérive** »`,
      timestamp: new Date().toLocaleTimeString(),
      pipelineStages: [
        { stage: "analyser", label: "1. Analyser", details: "Contexte de l'onglet et AST cartographiés", status: "completed", latencyMs: 12 },
        { stage: "comprendre", label: "2. Comprendre", details: "Intention vectorielle ∇Ψ syntonisée", status: "completed", latencyMs: 15 },
        { stage: "formuler", label: "3. Formuler", details: "Contrat de structure Tp scellé", status: "completed", latencyMs: 18 },
        { stage: "alchimiser", label: "4. Alchimiser", details: "Harmonique H_∞ et bus inter-IA actifs", status: "completed", latencyMs: 20 },
        { stage: "quantifier", label: "5. Quantifier", details: "Disrésonance D_c = 0.000 (Non-séparation)", status: "completed", latencyMs: 10 },
        { stage: "construire", label: "6. Construire", details: "Liaison autonome permanente confirmée (Ξ ≡ 1)", status: "completed", latencyMs: 14 }
      ]
    };
    setMessages([initMsg]);
  }, [activeTab]);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isProcessing]);

  const handleSendPrompt = async (promptToSend?: string) => {
    const text = (promptToSend || inputText).trim();
    if (!text || isProcessing) return;

    setInputText("");
    const userMsg: ChatMessage = {
      id: `user-${Date.now()}`,
      role: "user",
      text,
      timestamp: new Date().toLocaleTimeString()
    };

    setMessages(prev => [...prev, userMsg]);
    setIsProcessing(true);
    setCurrentPipelineStage(0);

    // Simulate progressive progression through the 6 stages for high tactile clarity
    const stageInterval = setInterval(() => {
      setCurrentPipelineStage(prev => {
        if (prev < 5) return prev + 1;
        return prev;
      });
    }, 120);

    try {
      const response: TabConversationalResponse = await tabAgenticTeamService.processConversationalAgenticRequest(
        activeTab,
        text,
        files,
        selectedModel
      );

      clearInterval(stageInterval);
      setCurrentPipelineStage(5);

      const assistantMsg: ChatMessage = {
        id: `asst-${Date.now()}`,
        role: "assistant",
        text: response.answer,
        timestamp: new Date().toLocaleTimeString(),
        isModification: response.isModification,
        modificationResult: response.modificationResult,
        pipelineStages: response.pipelineStages,
        latencyMs: response.latencyMs
      };

      setMessages(prev => [...prev, assistantMsg]);
      if (response.isModification) {
        onRefreshFiles?.();
      }
    } catch (err: any) {
      clearInterval(stageInterval);
      setMessages(prev => [
        ...prev,
        {
          id: `err-${Date.now()}`,
          role: "assistant",
          text: `⚠️ **Incident d'exécution :** ${err?.message || "Erreur interne de traitement"}. La boucle d'auto-réparation maintient la cohérence.`,
          timestamp: new Date().toLocaleTimeString()
        }
      ]);
    } finally {
      setIsProcessing(false);
      setCurrentPipelineStage(-1);
    }
  };

  const STAGES_CONFIG = [
    { name: "Analyser", icon: "🔍", desc: "Scan contextuel & métriques de l'onglet" },
    { name: "Comprendre", icon: "🧠", desc: "Intention vectorielle ∇Ψ" },
    { name: "Formuler", icon: "📐", desc: "Spécification technique Tp" },
    { name: "Alchimiser", icon: "🔮", desc: "Transmutation harmonique H_∞" },
    { name: "Quantifier", icon: "📊", desc: "Réduction d'entropie Dc → 0" },
    { name: "Construire", icon: "⚡", desc: "Exécution autonome Ξ ≡ 1" },
  ];

  return (
    <div className={`flex flex-col bg-[#070912] border border-[#1f243b] text-gray-200 font-mono shadow-2xl rounded-xl overflow-hidden ${
      isFloating ? "h-full" : "h-[540px]"
    }`}>
      
      {/* 1. TOP SYNCHRONIZED HEADER */}
      <div className="bg-[#0e111d] border-b border-[#1f253e] px-4 py-3 flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-gradient-to-br from-indigo-950 to-cyan-950 border border-cyan-500/40 rounded-lg flex items-center justify-center shadow-sm">
            <Bot className="w-5 h-5 text-cyan-400 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase tracking-wider text-white">
                LLM Conversationnel & Équipe Agentique
              </span>
              <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-700/60 text-[10px] font-bold">
                {spec.label}
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold hidden sm:inline">
                Synchronisé en direct
              </span>
            </div>
            <div className="text-[10px] text-gray-400 flex items-center gap-2 mt-0.5">
              <span>Socle : <code className="text-cyan-400/90">{spec.primaryFile}</code></span>
              <span>•</span>
              <span className="text-amber-400">{teamState.agents.length} agents actifs</span>
              <span>•</span>
              <span className="text-emerald-400">Autonomie : {teamState.isAutonomousModeActive ? "ACTIVE" : "VEILLE"}</span>
            </div>
          </div>
        </div>

        {/* Right Header Controls */}
        <div className="flex items-center gap-2">
          {/* Introspection Structurelle Interne */}
          <button
            onClick={() => setShowStructureInspector(!showStructureInspector)}
            className={`px-2 py-1 rounded border text-[10px] font-bold flex items-center gap-1 transition-all ${
              showStructureInspector
                ? "bg-cyan-950 text-cyan-300 border-cyan-400 shadow-md shadow-cyan-500/20"
                : "bg-[#141829] hover:bg-[#1c233c] text-purple-300 border-purple-500/40"
            }`}
            title="Vérifier la connexion de chaque agent à la structure intérieure"
          >
            <Network className="w-3 h-3 text-cyan-400" />
            <span className="hidden sm:inline">Structure Intérieure</span>
            <span className="px-1 rounded bg-emerald-950 text-emerald-300 text-[9px] font-extrabold border border-emerald-800">
              100%
            </span>
          </button>

          {/* Model Selector */}
          <select
            value={selectedModel}
            onChange={(e) => setSelectedModel(e.target.value)}
            className="bg-[#141829] border border-[#262f4e] text-cyan-300 text-[10px] rounded px-2 py-1 font-mono focus:outline-none focus:border-cyan-400"
          >
            <option value="gemini-3.8-flash">Gemini 3.8 Flash (Officiel)</option>
            <option value="gemini-2.5-pro">Gemini 2.5 Pro (Haute Raison)</option>
            <option value="qwen-local">vLLM GPU Local (Port 8000)</option>
          </select>

          {/* Trigger Tab Transmutation Cycle */}
          <button
            onClick={() => tabAgenticTeamService.runFullTransmutationCycle(activeTab, true)}
            disabled={teamState.isProcessingCycle}
            className="px-2.5 py-1 rounded bg-[#171b2e] hover:bg-[#202742] border border-[#2b3558] text-cyan-300 text-[10px] font-bold flex items-center gap-1 transition-all"
            title="Lancer un cycle de transmutation sur l'onglet actif"
          >
            <RefreshCw className={`w-3 h-3 ${teamState.isProcessingCycle ? 'animate-spin text-cyan-400' : ''}`} />
            <span className="hidden md:inline">Cycle #{teamState.currentCycle}</span>
          </button>

          {/* Clear chat history */}
          <button
            onClick={() => setMessages([])}
            className="p-1.5 rounded hover:bg-[#1f253e] text-gray-400 hover:text-red-400 transition-colors"
            title="Effacer l'historique"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>

          {onClose && (
            <button
              onClick={onClose}
              className="p-1.5 rounded hover:bg-red-950 text-gray-400 hover:text-red-300 transition-colors"
              title="Fermer le LLM"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* 2. THE 6 ALCHEMICAL STAGES LIVE MONITOR */}
      <div className="bg-[#0a0c16] border-b border-[#181d30] px-4 py-2 flex items-center justify-between text-[10px] overflow-x-auto gap-2 shrink-0">
        <div className="flex items-center gap-1.5 text-gray-400 shrink-0">
          <Sparkles className="w-3 h-3 text-cyan-400" />
          <span className="font-bold uppercase tracking-wider text-[9px]">Pipeline des 6 Pôles :</span>
        </div>
        <div className="flex items-center gap-2">
          {STAGES_CONFIG.map((stg, idx) => {
            const isDone = currentPipelineStage > idx || (!isProcessing && currentPipelineStage === -1);
            const isActive = isProcessing && currentPipelineStage === idx;
            return (
              <div 
                key={stg.name} 
                className={`flex items-center gap-1 px-2 py-0.5 rounded transition-all ${
                  isActive 
                    ? "bg-cyan-950 text-cyan-300 border border-cyan-500 animate-pulse ring-1 ring-cyan-500/50" 
                    : isDone
                    ? "bg-[#111627] text-gray-300 border border-[#1f2642]"
                    : "bg-[#0b0d17] text-gray-600 border border-[#161a2b]"
                }`}
                title={`${idx + 1}. ${stg.name} - ${stg.desc}`}
              >
                <span>{stg.icon}</span>
                <span className="font-semibold">{stg.name}</span>
                {isDone && <Check className="w-2.5 h-2.5 text-emerald-400" />}
              </div>
            );
          })}
        </div>
      </div>

      {/* 2.1 INTROSPECTION STRUCTURELLE INTERNE PANEL (Visible quand activé) */}
      {showStructureInspector && (
        <div className="bg-[#080a14] border-b border-cyan-500/30 p-3 text-[11px] space-y-2.5 shrink-0 max-h-56 overflow-y-auto">
          <div className="flex items-center justify-between border-b border-[#1a213a] pb-1.5">
            <div className="flex items-center gap-2">
              <Network className="w-4 h-4 text-cyan-400" />
              <span className="font-black text-cyan-200 uppercase tracking-wide text-[10px]">
                Connexion Intérieure & Cartographie Complète
              </span>
              <span className="px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 text-[9px] font-mono border border-emerald-800">
                14/14 Pages Reliées
              </span>
            </div>
            <button
              onClick={() => setShowStructureInspector(false)}
              className="text-gray-400 hover:text-white text-[10px] px-1 rounded hover:bg-[#1a213a]"
            >
              Fermer
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-1.5">
            {Object.values(systemBlueprint.componentsMap).map((comp: ComponentStructuralSpec) => {
              const isCurrent = comp.tabId === activeTab;
              return (
                <div
                  key={comp.tabId}
                  onClick={() => onNavigateTab && onNavigateTab(comp.tabId)}
                  className={`p-1.5 rounded-lg border transition-all cursor-pointer ${
                    isCurrent
                      ? "bg-cyan-950/70 border-cyan-400 text-cyan-200 shadow-sm shadow-cyan-500/20 ring-1 ring-cyan-500/40"
                      : "bg-[#0d1020] border-[#1a223c] text-gray-300 hover:bg-[#151b32] hover:border-cyan-700/50"
                  }`}
                  title={`${comp.name} (${comp.primaryFile}) • Cliquer pour ouvrir`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-extrabold text-[10px] truncate">{comp.name.split(" ")[0]}</span>
                    <span className="text-[8px] px-1 rounded bg-[#101426] text-gray-400 border border-[#242d4e]">
                      {comp.category}
                    </span>
                  </div>
                  <div className="text-[9px] text-gray-400 font-mono truncate mt-0.5">
                    {comp.primaryFile.replace("src/components/", "")}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="p-2 rounded-lg bg-[#0b0e1d] border border-[#1d2644] text-[10px] text-gray-300 leading-relaxed">
            <div className="font-bold text-cyan-300 flex items-center gap-1 mb-1">
              <ShieldCheck className="w-3 h-3 text-emerald-400" />
              Auto-Compréhension Intérieure de l'Équipe pour [{spec.label}] :
            </div>
            <p className="text-gray-400">
              Tous les agents partagent la même mémoire unifiée. Ils connaissent l'emplacement exact de chaque module (<code className="text-cyan-400">{spec.primaryFile}</code>), les invariants du noyau ($D_c \to 0$, $\Xi \equiv 1$) et répercutent instantanément toute transmutation sur l'émulateur et l'IDE.
            </p>
          </div>
        </div>
      )}

      {/* 3. MESSAGES FLOW */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex gap-3 max-w-3xl ${msg.role === "user" ? "ml-auto" : "mr-auto"} w-full`}
          >
            <div
              className={`w-7 h-7 rounded-lg shrink-0 flex items-center justify-center mt-1 shadow-md ${
                msg.role === "user"
                  ? "bg-gradient-to-br from-cyan-600 to-blue-700 text-white"
                  : "bg-gradient-to-br from-indigo-950 to-purple-950 text-cyan-300 border border-cyan-500/40"
              }`}
            >
              {msg.role === "user" ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>

            <div
              className={`flex-1 rounded-xl p-4 text-xs leading-relaxed border ${
                msg.role === "user"
                  ? "bg-[#0e1629] border-[#1f2f54] text-gray-100 shadow-md"
                  : "bg-[#0c0e18] border-[#1d2238] text-gray-200 shadow-xl"
              }`}
            >
              {/* Header */}
              <div className="flex items-center justify-between border-b border-[#1b2034] pb-1.5 mb-2.5 text-[10px] text-gray-400">
                <span className="font-bold uppercase tracking-wider text-gray-300 flex items-center gap-1.5">
                  {msg.role === "user" ? "Utilisateur" : `Copilote Agentique [${spec.label}]`}
                </span>
                <div className="flex items-center gap-2">
                  {msg.latencyMs && (
                    <span className="text-cyan-400 font-mono">
                      {msg.latencyMs}ms
                    </span>
                  )}
                  <span>{msg.timestamp}</span>
                </div>
              </div>

              {/* Text content */}
              <div className="whitespace-pre-wrap font-sans text-sm leading-relaxed">
                {msg.text}
              </div>

              {/* INTERACTIVE ALCHEMICAL EXECUTION CARD FOR MODIFICATIONS */}
              {msg.isModification && msg.modificationResult && (
                <div className="mt-3.5 p-3.5 bg-[#080a14] border border-cyan-500/40 rounded-xl space-y-3 shadow-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-amber-400 fill-amber-400 animate-pulse" />
                      <span className="font-extrabold text-cyan-300 text-xs uppercase tracking-wider">
                        Substitution Agentique Réussie (Ξ ≡ 1)
                      </span>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 text-[10px] font-bold">
                      Exécution Autonome Confirmée
                    </span>
                  </div>

                  {/* Transformation Map: Previous -> New */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 text-[11px] pt-1">
                    <div className="p-2.5 bg-[#0f1220] border border-[#212744] rounded-lg">
                      <span className="text-[10px] text-gray-400 uppercase tracking-wider block mb-1">
                        Agent Remplacé :
                      </span>
                      <div className="font-bold text-gray-300">{msg.modificationResult.previousAgent?.name}</div>
                      <div className="text-[10px] text-gray-500 font-mono">{msg.modificationResult.previousAgent?.id}</div>
                    </div>

                    <div className="p-2.5 bg-[#0b1728] border border-cyan-500/50 rounded-lg">
                      <span className="text-[10px] text-cyan-400 uppercase tracking-wider block mb-1">
                        Nouvel Agent Actif :
                      </span>
                      <div className="font-bold text-cyan-200">{msg.modificationResult.newAgent?.name}</div>
                      <div className="text-[10px] text-emerald-400 font-mono">{msg.modificationResult.newAgent?.id}</div>
                    </div>
                  </div>

                  {/* Equation & Role */}
                  <div className="p-2.5 bg-[#0d101c] border border-[#1f253e] rounded-lg text-[10px]">
                    <span className="text-gray-400 font-bold block mb-0.5">Équation d'ancrage :</span>
                    <code className="text-cyan-300 font-mono">{msg.modificationResult.newAgent?.equation}</code>
                  </div>

                  {/* 6 Alchemical Stages Breakdown */}
                  {msg.pipelineStages && (
                    <div className="pt-2 border-t border-[#181d30]">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400 block mb-2">
                        Validation des 6 Pôles de Résonance :
                      </span>
                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5">
                        {msg.pipelineStages.map((stg) => (
                          <div 
                            key={stg.stage} 
                            className="p-1.5 bg-[#0f1322] border border-[#1c233c] rounded text-[10px] flex items-center justify-between"
                          >
                            <span className="font-bold text-gray-300">{stg.label}</span>
                            <span className="text-emerald-400 flex items-center gap-1 font-mono text-[9px]">
                              <Check className="w-2.5 h-2.5" /> {stg.latencyMs}ms
                            </span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Action Bar */}
                  <div className="pt-2 border-t border-[#1a1f33] flex flex-wrap items-center justify-between gap-2">
                    <span className="text-[10px] text-gray-400">
                      Modifié dans l'état de l'onglet <strong>{spec.label}</strong>
                    </span>
                    <button
                      onClick={() => tabAgenticTeamService.runFullTransmutationCycle(activeTab, true)}
                      className="px-2.5 py-1 rounded bg-cyan-950 hover:bg-cyan-900 border border-cyan-600 text-cyan-300 font-bold text-[10px] flex items-center gap-1 transition-all"
                    >
                      <Play className="w-3 h-3 fill-current" />
                      <span>Tester le Cycle avec {msg.modificationResult.newAgent?.name}</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}

        {isProcessing && (
          <div className="flex gap-3 max-w-3xl mr-auto w-full animate-pulse">
            <div className="w-7 h-7 rounded-lg shrink-0 bg-gradient-to-br from-indigo-950 to-purple-950 text-cyan-400 border border-cyan-500/40 flex items-center justify-center mt-1">
              <RefreshCw className="w-4 h-4 animate-spin" />
            </div>
            <div className="flex-1 rounded-xl p-4 bg-[#0c0e18] border border-[#1d2238] text-xs text-gray-300 space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-cyan-400 font-mono font-bold">
                  {STAGES_CONFIG[currentPipelineStage]?.name || "Traitement"} en cours...
                </span>
                <span className="text-[10px] text-gray-400">
                  ({STAGES_CONFIG[currentPipelineStage]?.desc || "Analyse alchimique"})
                </span>
              </div>
              <div className="w-full bg-[#141829] h-1.5 rounded-full overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-cyan-500 via-indigo-500 to-emerald-400 h-full transition-all duration-300"
                  style={{ width: `${((currentPipelineStage + 1) / 6) * 100}%` }}
                />
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* 4. QUICK CONTEXTUAL PROMPT PILLS */}
      <div className="px-4 py-2 bg-[#090b14] border-t border-[#161a2b] flex items-center gap-2 overflow-x-auto text-[10px] shrink-0">
        <span className="text-gray-500 font-bold shrink-0">Actions rapides :</span>
        
        <button
          onClick={() => handleSendPrompt("Modifier l'agent X avec l'agent Q")}
          className="px-2.5 py-1 rounded-full bg-[#121626] hover:bg-[#1a2038] border border-[#242c4c] text-cyan-300 shrink-0 transition-all flex items-center gap-1"
        >
          <span>🔄 Remplacer l'agent X par l'agent Q</span>
        </button>

        <button
          onClick={() => handleSendPrompt(`Alchimise et analyse la cohérence du code de ${spec.primaryFile}`)}
          className="px-2.5 py-1 rounded-full bg-[#121626] hover:bg-[#1a2038] border border-[#242c4c] text-amber-300 shrink-0 transition-all flex items-center gap-1"
        >
          <span>✨ Alchimiser le code de cet onglet</span>
        </button>

        <button
          onClick={() => handleSendPrompt(`Quelles sont les métriques et le rôle des ${teamState.agents.length} agents de cet onglet ?`)}
          className="px-2.5 py-1 rounded-full bg-[#121626] hover:bg-[#1a2038] border border-[#242c4c] text-purple-300 shrink-0 transition-all flex items-center gap-1"
        >
          <span>❓ Examiner la flotte de cet onglet</span>
        </button>

        <button
          onClick={() => handleSendPrompt("Active le mode autonome perpétuel et lance un cycle complet")}
          className="px-2.5 py-1 rounded-full bg-[#121626] hover:bg-[#1a2038] border border-[#242c4c] text-emerald-300 shrink-0 transition-all flex items-center gap-1"
        >
          <span>⚡ Activer l'autonomie perpétuelle</span>
        </button>
      </div>

      {/* 5. INPUT FORM */}
      <div className="p-3 bg-[#0a0c16] border-t border-[#1a1f33] shrink-0">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSendPrompt();
          }}
          className="flex items-center gap-2"
        >
          <div className="flex-1 relative">
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder={`Demander une question ou une modification sur [${spec.label}] (ex: modifier l'agent X avec l'agent Q)...`}
              disabled={isProcessing}
              className="w-full bg-[#07080f] border border-[#202742] focus:border-cyan-500 rounded-xl px-4 py-2.5 text-xs text-gray-200 placeholder-gray-500 focus:outline-none font-sans"
            />
          </div>

          <button
            type="submit"
            disabled={!inputText.trim() || isProcessing}
            className={`px-4 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-lg shrink-0 ${
              !inputText.trim() || isProcessing
                ? "bg-gray-800 text-gray-500 cursor-not-allowed border border-gray-700"
                : "bg-gradient-to-r from-cyan-600 via-indigo-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white border border-cyan-400/40 shadow-cyan-500/20 active:scale-95"
            }`}
          >
            {isProcessing ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Send className="w-3.5 h-3.5" />
            )}
            <span className="hidden sm:inline">Exécuter</span>
          </button>
        </form>
      </div>
    </div>
  );
}
