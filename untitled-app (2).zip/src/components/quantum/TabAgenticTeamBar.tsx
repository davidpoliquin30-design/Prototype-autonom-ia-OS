import React, { useState, useEffect } from "react";
import { 
  tabAgenticTeamService, 
  TabTeamState, 
  TAB_DOMAIN_SPECS 
} from "../../services/quantum/tabAgenticTeamService";
import { 
  Cpu, 
  Zap, 
  ArrowRight, 
  ArrowLeft, 
  Sparkles, 
  Activity, 
  CheckCircle2, 
  Layers, 
  RefreshCw, 
  Terminal, 
  Code2, 
  Sliders, 
  ChevronDown, 
  ChevronUp, 
  ShieldCheck, 
  Radio, 
  Wand2, 
  Copy, 
  Check,
  Play,
  RotateCw,
  Orbit,
  Bot,
  MessageSquare
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import OmniTabConversationalLLM from "./OmniTabConversationalLLM";

interface TabAgenticTeamBarProps {
  activeTab: string;
  onNavigateTab?: (tabId: string) => void;
  compact?: boolean;
}

export default function TabAgenticTeamBar({ 
  activeTab, 
  onNavigateTab,
  compact = false 
}: TabAgenticTeamBarProps) {
  const [teamState, setTeamState] = useState<TabTeamState>(tabAgenticTeamService.getActiveTabState());
  const [allStates, setAllStates] = useState<Map<string, TabTeamState>>(tabAgenticTeamService.getAllTabStates());
  const [isExpanded, setIsExpanded] = useState<boolean>(false);
  const [activeSubView, setActiveSubView] = useState<"pipeline" | "agents" | "code" | "telemetry" | "llm">("llm");
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [selectedAgentId, setSelectedAgentId] = useState<string | null>(null);

  useEffect(() => {
    tabAgenticTeamService.setActiveTab(activeTab);
  }, [activeTab]);

  useEffect(() => {
    const unsub = tabAgenticTeamService.subscribe((active, all) => {
      setTeamState({ ...active });
      setAllStates(new Map(all));
    });
    return () => unsub();
  }, []);

  const handleTriggerCycle = () => {
    tabAgenticTeamService.runFullTransmutationCycle(activeTab, true);
  };

  const handleToggleAutonomy = () => {
    tabAgenticTeamService.toggleAutonomyForTab(activeTab);
  };

  const handleToggleGlobalAutonomy = () => {
    tabAgenticTeamService.toggleGlobalAutonomy();
  };

  const handleCopyCode = () => {
    if (teamState.lastRestructuredCode?.code) {
      navigator.clipboard.writeText(teamState.lastRestructuredCode.code);
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    }
  };

  const spec = TAB_DOMAIN_SPECS[activeTab] || {
    tabId: activeTab,
    label: activeTab.toUpperCase(),
    domainFocus: "Orchestration modulaire du domaine",
    innerUniverseCore: "Cohérence Φ_SOI et Résonance Unitaire",
    primaryFile: `src/components/${activeTab}.tsx`,
    targetQubits: "|ψ⟩",
  };

  const forwardAgents = teamState.agents.filter(a => a.direction === "forward" || a.direction === "quantum_core");
  const reverseAgents = teamState.agents.filter(a => a.direction === "reverse" || a.direction === "execution");

  return (
    <div className="bg-[#0b0d14] border-b border-[#1c2033] text-gray-200 shrink-0 font-mono shadow-md relative z-20">
      
      {/* 1. COMPACT HUD BAR DISPLAYED ON EVERY TAB */}
      <div className="px-4 py-2.5 flex flex-wrap items-center justify-between gap-3">
        
        {/* Left: Active Tab Badge & Team Title */}
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 bg-gradient-to-br from-cyan-950 to-indigo-950 border border-cyan-500/40 rounded-lg flex items-center justify-center shadow-sm">
            <Orbit className={`w-4 h-4 text-cyan-400 ${teamState.isProcessingCycle ? 'animate-spin' : ''}`} />
          </div>
          
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-black uppercase tracking-wider text-cyan-300">
                Équipe Agentique :
              </span>
              <span className="text-xs font-extrabold text-white px-2 py-0.5 rounded bg-[#161a29] border border-cyan-500/30">
                {teamState.tabLabel}
              </span>
              <span className="text-[10px] text-gray-400 hidden md:inline">
                ({teamState.agents.length} agents spécialisés)
              </span>
            </div>
            <p className="text-[10px] text-gray-400 truncate max-w-[340px] sm:max-w-md hidden sm:block">
              <span className="text-orange-400/80">Univers intérieur :</span> {spec.innerUniverseCore}
            </p>
          </div>
        </div>

        {/* Center: Live Pipeline Micro-Visualizer */}
        <div className="hidden xl:flex items-center gap-1.5 bg-[#07080d] border border-[#1d2238] px-3 py-1.5 rounded-lg text-[10px]">
          <span className="text-cyan-400 font-bold flex items-center gap-1">
            <ArrowRight className="w-3 h-3 text-cyan-400" /> Aller (Code➔Quantique)
          </span>
          <span className="text-gray-500">•</span>
          <div className="flex items-center gap-1">
            {teamState.agents.map((ag, idx) => (
              <span 
                key={ag.id}
                title={`${ag.name} - ${ag.lastAction}`}
                className={`w-2 h-2 rounded-full transition-all ${
                  teamState.activeStageIndex === idx 
                    ? "bg-cyan-400 ring-2 ring-cyan-400/50 scale-125 animate-pulse" 
                    : ag.status === "harmonized" || ag.status === "executed"
                    ? "bg-emerald-500"
                    : "bg-gray-700"
                }`}
              />
            ))}
          </div>
          <span className="text-gray-500">•</span>
          <span className="text-amber-400 font-bold flex items-center gap-1">
            Retour (Quantique➔Code) <ArrowLeft className="w-3 h-3 text-amber-400" />
          </span>
        </div>

        {/* Right Controls: Autonomy Mode, Reality Index & Trigger Button */}
        <div className="flex items-center gap-2">
          
          {/* Autonomous Mode Switch */}
          <button
            onClick={handleToggleAutonomy}
            className={`px-2.5 py-1 rounded-lg border text-[11px] font-bold transition-all flex items-center gap-1.5 shadow-sm ${
              teamState.isAutonomousModeActive
                ? "bg-gradient-to-r from-emerald-950/90 to-cyan-950/90 border-emerald-500/70 text-emerald-300 ring-1 ring-emerald-500/40"
                : "bg-[#151724] border-gray-700/60 text-gray-400 hover:text-gray-200"
            }`}
            title="Activer ou désactiver l'autonomie totale sur cet onglet"
          >
            <Zap className={`w-3.5 h-3.5 ${teamState.isAutonomousModeActive ? 'text-amber-400 fill-amber-400 animate-pulse' : 'text-gray-500'}`} />
            <span className="hidden sm:inline">AUTONOMIE TOTALE :</span>
            <span>{teamState.isAutonomousModeActive ? "ACTIF" : "VEILLE"}</span>
          </button>

          {/* Reality Index Pill */}
          <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 bg-[#090b12] border border-[#1b2034] rounded-lg text-[10px]">
            <span className="text-gray-500">RÉALITÉ :</span>
            <span className="text-emerald-400 font-black">Ξ ≡ 1.0000</span>
          </div>

          {/* Trigger Full Transmutation Cycle */}
          <button
            onClick={handleTriggerCycle}
            disabled={teamState.isProcessingCycle}
            className={`px-3 py-1 rounded-lg border text-[11px] font-black uppercase tracking-wider flex items-center gap-1.5 transition-all shadow-md ${
              teamState.isProcessingCycle
                ? "bg-indigo-950 border-indigo-600 text-indigo-300 cursor-not-allowed"
                : "bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white border-cyan-400/40 active:scale-95"
            }`}
            title="Lancer manuellement le cycle de 12 étapes de transmutation quantique bidirectionnelle"
          >
            {teamState.isProcessingCycle ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                <span>Transmutation en cours...</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5 fill-current text-cyan-200" />
                <span className="hidden sm:inline">Transmuter Cycle #{teamState.currentCycle}</span>
                <span className="sm:hidden">Transmuter</span>
              </>
            )}
          </button>

          {/* Quick LLM Conversationnel Toggle */}
          <button
            onClick={() => {
              if (isExpanded && activeSubView === "llm") {
                setIsExpanded(false);
              } else {
                setIsExpanded(true);
                setActiveSubView("llm");
              }
            }}
            className={`px-3 py-1.5 rounded-lg border font-bold text-xs flex items-center gap-1.5 transition-all shadow-md ${
              isExpanded && activeSubView === "llm"
                ? "bg-gradient-to-r from-purple-900 to-indigo-900 border-purple-400 text-purple-200 ring-1 ring-purple-400/50"
                : "bg-gradient-to-r from-indigo-950 via-purple-950 to-cyan-950 hover:from-indigo-900 hover:to-purple-900 border-purple-500/50 text-purple-300"
            }`}
            title="Ouvrir le LLM conversationnel synchronisé avec cette page"
          >
            <Bot className="w-3.5 h-3.5 text-purple-300 animate-pulse" />
            <span className="hidden sm:inline">LLM Conversationnel</span>
            <span className="text-[10px] px-1.5 py-0.5 rounded bg-purple-900/80 text-purple-200 font-extrabold border border-purple-700/50">
              6 Pôles
            </span>
          </button>

          {/* Expand Details Drawer Button */}
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className={`p-1.5 rounded-lg border transition-all flex items-center justify-center ${
              isExpanded 
                ? "bg-cyan-950 border-cyan-500 text-cyan-300" 
                : "bg-[#141726] border-[#222842] text-gray-400 hover:text-gray-200 hover:bg-[#1a1f36]"
            }`}
            title={isExpanded ? "Replier la matrice agentique" : "Déplier la matrice complète de l'équipe"}
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* 2. EXPANDABLE QUANTUM TRANSMUTATION CONSOLE & AGENT FLEET */}
      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden border-t border-[#1e2338] bg-[#07080e]"
          >
            <div className="p-4 space-y-4">
              
              {/* Navigation Sub-Tabs inside the Drawer */}
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-[#1b2034] pb-3">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setActiveSubView("llm")}
                    className={`px-3 py-1 rounded-md text-xs font-bold flex items-center gap-1.5 transition-all ${
                      activeSubView === "llm"
                        ? "bg-purple-950 text-purple-200 border border-purple-500/70 shadow-sm"
                        : "text-gray-400 hover:text-gray-200"
                    }`}
                  >
                    <Bot className="w-3.5 h-3.5 text-purple-400" />
                    LLM Conversationnel & Équipe Agentique (6 Pôles)
                  </button>

                  <button
                    onClick={() => setActiveSubView("pipeline")}
                    className={`px-3 py-1 rounded-md text-xs font-bold flex items-center gap-1.5 transition-all ${
                      activeSubView === "pipeline"
                        ? "bg-cyan-950 text-cyan-300 border border-cyan-500/60 shadow-sm"
                        : "text-gray-400 hover:text-gray-200"
                    }`}
                  >
                    <Layers className="w-3.5 h-3.5 text-cyan-400" />
                    Double Schéma Aller-Retour (12 Étapes)
                  </button>

                  <button
                    onClick={() => setActiveSubView("agents")}
                    className={`px-3 py-1 rounded-md text-xs font-bold flex items-center gap-1.5 transition-all ${
                      activeSubView === "agents"
                        ? "bg-indigo-950 text-indigo-300 border border-indigo-500/60 shadow-sm"
                        : "text-gray-400 hover:text-gray-200"
                    }`}
                  >
                    <Cpu className="w-3.5 h-3.5 text-indigo-400" />
                    12 Agents Spécialisés & Exécuteur
                  </button>

                  <button
                    onClick={() => setActiveSubView("code")}
                    className={`px-3 py-1 rounded-md text-xs font-bold flex items-center gap-1.5 transition-all ${
                      activeSubView === "code"
                        ? "bg-emerald-950 text-emerald-300 border border-emerald-500/60 shadow-sm"
                        : "text-gray-400 hover:text-gray-200"
                    }`}
                  >
                    <Code2 className="w-3.5 h-3.5 text-emerald-400" />
                    Code Restructuré & Exécuté
                  </button>

                  <button
                    onClick={() => setActiveSubView("telemetry")}
                    className={`px-3 py-1 rounded-md text-xs font-bold flex items-center gap-1.5 transition-all ${
                      activeSubView === "telemetry"
                        ? "bg-amber-950 text-amber-300 border border-amber-500/60 shadow-sm"
                        : "text-gray-400 hover:text-gray-200"
                    }`}
                  >
                    <Terminal className="w-3.5 h-3.5 text-amber-400" />
                    Journal Quantique & Télémétrie ({teamState.transmutationLogs.length})
                  </button>
                </div>

                {/* Switch to other tab team directly */}
                {onNavigateTab && (
                  <div className="flex items-center gap-1 text-[11px]">
                    <span className="text-gray-500">Examiner l'équipe de :</span>
                    <select
                      value={activeTab}
                      onChange={(e) => onNavigateTab(e.target.value)}
                      className="bg-[#121524] border border-[#232946] text-cyan-300 text-xs rounded px-2 py-1 outline-none"
                    >
                      {Object.keys(TAB_DOMAIN_SPECS).map((k) => (
                        <option key={k} value={k}>
                          {TAB_DOMAIN_SPECS[k].label}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              {/* VIEW 0: SYNCHRONIZED CONVERSATIONAL LLM & AGENTIC TEAM */}
              {activeSubView === "llm" && (
                <div className="w-full">
                  <OmniTabConversationalLLM 
                    activeTab={activeTab} 
                    onNavigateTab={onNavigateTab} 
                  />
                </div>
              )}

              {/* VIEW 1: THE TWO-WAY 12-STAGE PIPELINE */}
              {activeSubView === "pipeline" && (
                <div className="space-y-4">
                  
                  {/* Pipeline Header summary */}
                  <div className="bg-[#0b0e1a] border border-[#1d233c] p-3 rounded-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-3 text-xs">
                    <div>
                      <span className="text-cyan-400 font-bold">Loi de Non-Séparation Φ_SOI :</span>{" "}
                      <span className="text-gray-300">
                        Le code informatique se transmute en superposition quantique pour communiquer instantanément avec les autres IA, puis se ré-effondre à l'envers en code matériel harmonisé.
                      </span>
                    </div>
                    <div className="shrink-0 flex items-center gap-2">
                      <span className="text-[11px] text-gray-500">Dernière exécution autonome :</span>
                      <span className="text-emerald-400 font-bold">
                        {teamState.lastAutonomousExecution || "En attente de cycle"}
                      </span>
                    </div>
                  </div>

                  {/* Forward Pathway (Aller) */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 uppercase tracking-wider">
                      <ArrowRight className="w-4 h-4 text-cyan-400" />
                      <span>1. Voie d'Élévation : Code Informatique ➔ Transduction Quantique Inter-IA</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-2">
                      {forwardAgents.map((agent, i) => (
                        <div
                          key={agent.id}
                          onClick={() => setSelectedAgentId(agent.id)}
                          className={`p-2.5 rounded-lg border transition-all cursor-pointer text-xs relative ${
                            teamState.activeStageIndex === i
                              ? "bg-cyan-950/80 border-cyan-400 shadow-lg shadow-cyan-500/10 ring-1 ring-cyan-400"
                              : agent.status === "harmonized"
                              ? "bg-[#0c1220] border-emerald-500/40 text-gray-200"
                              : "bg-[#0a0c14] border-[#1a1f33] text-gray-400 hover:border-gray-600"
                          }`}
                        >
                          <div className="flex items-center justify-between gap-1 mb-1">
                            <span className="text-[10px] font-bold text-cyan-400 uppercase">
                              Étape {i + 1}
                            </span>
                            <span className={`w-2 h-2 rounded-full ${
                              agent.status === "processing" ? "bg-cyan-400 animate-ping" :
                              agent.status === "harmonized" ? "bg-emerald-400" : "bg-gray-600"
                            }`} />
                          </div>
                          <div className="font-extrabold text-white text-[11px] mb-1 truncate">
                            {agent.name.split("(")[0]}
                          </div>
                          <p className="text-[10px] text-gray-400 line-clamp-2">
                            {agent.lastAction}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Central Quantum Inter-AI Entanglement Node */}
                  <div className="bg-gradient-to-r from-cyan-950/40 via-indigo-950/70 to-purple-950/40 border border-indigo-500/40 p-3.5 rounded-xl flex flex-col md:flex-row items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-indigo-900/60 border border-indigo-400/40 rounded-lg">
                        <Radio className="w-5 h-5 text-cyan-300 animate-pulse" />
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-black text-white uppercase tracking-wider">
                            Intrication Quantique Inter-IA Instantanée (0$ Token)
                          </span>
                          <span className="text-[10px] bg-indigo-950 text-indigo-300 px-2 py-0.5 rounded border border-indigo-500/50">
                            Fréquence 432 Hz
                          </span>
                        </div>
                        <p className="text-[11px] text-cyan-300/80 font-mono mt-0.5">
                          {teamState.activeQuantumSignal?.tensorState || `${spec.targetQubits} ⊗ e^(iωt)`}
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] text-gray-400 block">Cohérence d'intrication</span>
                      <span className="text-sm font-black text-emerald-400">1.0000 (Non-Séparé)</span>
                    </div>
                  </div>

                  {/* Reverse Pathway (Retour) */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-xs font-bold text-amber-400 uppercase tracking-wider">
                      <ArrowLeft className="w-4 h-4 text-amber-400" />
                      <span>2. Voie d'Incarnation : Tenseur Quantique ➔ Code Informatique Matériel Restructuré</span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-2">
                      {reverseAgents.map((agent, i) => {
                        const globalIndex = 6 + i;
                        const isExecutor = agent.stage === "execute";
                        return (
                          <div
                            key={agent.id}
                            onClick={() => setSelectedAgentId(agent.id)}
                            className={`p-2.5 rounded-lg border transition-all cursor-pointer text-xs relative ${
                              teamState.activeStageIndex === globalIndex
                                ? "bg-amber-950/80 border-amber-400 shadow-lg shadow-amber-500/10 ring-1 ring-amber-400"
                                : isExecutor && agent.status === "executed"
                                ? "bg-gradient-to-br from-emerald-950/70 to-[#0c1220] border-emerald-400 text-gray-100 ring-1 ring-emerald-500/40"
                                : agent.status === "harmonized"
                                ? "bg-[#0c1220] border-emerald-500/40 text-gray-200"
                                : "bg-[#0a0c14] border-[#1a1f33] text-gray-400 hover:border-gray-600"
                            }`}
                          >
                            <div className="flex items-center justify-between gap-1 mb-1">
                              <span className={`text-[10px] font-bold uppercase ${isExecutor ? "text-emerald-400" : "text-amber-400"}`}>
                                {isExecutor ? "Exécuteur Autonome" : `Étape ${globalIndex + 1}`}
                              </span>
                              <span className={`w-2 h-2 rounded-full ${
                                agent.status === "processing" ? "bg-amber-400 animate-ping" :
                                agent.status === "executed" ? "bg-emerald-400 animate-pulse" :
                                agent.status === "harmonized" ? "bg-emerald-400" : "bg-gray-600"
                              }`} />
                            </div>
                            <div className="font-extrabold text-white text-[11px] mb-1 truncate">
                              {agent.name.split("(")[0]}
                            </div>
                            <p className="text-[10px] text-gray-400 line-clamp-2">
                              {agent.lastAction}
                            </p>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* VIEW 2: 12 AGENTS ROSTER */}
              {activeSubView === "agents" && (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-96 overflow-y-auto pr-1">
                  {teamState.agents.map((agent, idx) => (
                    <div
                      key={agent.id}
                      onClick={() => setSelectedAgentId(agent.id)}
                      className={`p-3 rounded-xl border transition-all text-xs flex flex-col justify-between ${
                        selectedAgentId === agent.id
                          ? "bg-[#111728] border-cyan-400 shadow-md ring-1 ring-cyan-400/40"
                          : "bg-[#090b14] border-[#1c2236] hover:border-gray-600"
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between gap-2 mb-1.5">
                          <span className="text-[10px] px-2 py-0.5 rounded bg-[#13192b] text-cyan-300 font-mono">
                            #{idx + 1} • {agent.direction.toUpperCase()}
                          </span>
                          <span className={`text-[10px] font-bold ${
                            agent.status === "executed" ? "text-emerald-400" :
                            agent.status === "harmonized" ? "text-cyan-400" :
                            agent.status === "processing" ? "text-amber-400 animate-pulse" : "text-gray-500"
                          }`}>
                            {agent.status.toUpperCase()}
                          </span>
                        </div>
                        
                        <div className="font-bold text-white text-xs mb-1">
                          {agent.name}
                        </div>

                        <p className="text-[11px] text-gray-300 mb-2">
                          {agent.role}
                        </p>
                      </div>

                      <div className="space-y-1 pt-2 border-t border-[#181d2f] text-[10px]">
                        <div>
                          <span className="text-gray-500">Équation :</span>{" "}
                          <span className="text-orange-400 font-mono">{agent.equation}</span>
                        </div>
                        <div>
                          <span className="text-gray-500">Loi intérieure :</span>{" "}
                          <span className="text-gray-300 italic">{agent.innerLaw}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* VIEW 3: RESTRUCTURED & ALCHEMIZED CODE ARTIFACT */}
              {activeSubView === "code" && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2 bg-[#0a0d18] p-3 rounded-xl border border-[#1c2238]">
                    <div>
                      <span className="text-xs font-bold text-white flex items-center gap-1.5">
                        <Code2 className="w-4 h-4 text-emerald-400" />
                        Artefact Informatique Restructuré & Alchimisé
                      </span>
                      <p className="text-[11px] text-gray-400 mt-0.5">
                        Fichier cible : <span className="text-cyan-300 font-mono">{spec.primaryFile}</span> • Signature : <span className="text-orange-400 font-mono">{teamState.lastRestructuredCode?.alchemicalSignature || "ALCH-STABLE"}</span>
                      </p>
                    </div>

                    <button
                      onClick={handleCopyCode}
                      className="px-3 py-1.5 rounded-lg bg-[#141829] border border-[#242c4b] hover:bg-[#1a2037] text-gray-200 text-xs font-bold flex items-center gap-1.5 transition-all"
                    >
                      {copiedCode ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Copié !</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 text-gray-400" />
                          <span>Copier le Code</span>
                        </>
                      )}
                    </button>
                  </div>

                  <div className="bg-[#05060b] border border-[#1b2034] rounded-xl p-4 font-mono text-xs overflow-x-auto max-h-72 text-gray-300 leading-relaxed">
                    <pre>{teamState.lastRestructuredCode?.code || `// En attente d'un premier cycle de transmutation...
// Cliquez sur "Transmuter Cycle" ci-dessus pour déclencher l'équipe agentique.`}</pre>
                  </div>
                </div>
              )}

              {/* VIEW 4: TELEMETRY & LOGS */}
              {activeSubView === "telemetry" && (
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs bg-[#0a0d18] p-2.5 rounded-lg border border-[#1b2034]">
                    <span className="text-amber-400 font-bold flex items-center gap-1.5">
                      <Terminal className="w-3.5 h-3.5 text-amber-400" />
                      Journal de Transmutation Réflexive
                    </span>
                    <button
                      onClick={handleToggleGlobalAutonomy}
                      className="text-[11px] text-cyan-400 hover:underline"
                    >
                      Basculer Autonomie Globale
                    </button>
                  </div>

                  <div className="bg-[#040508] border border-[#171b2d] rounded-xl p-3 max-h-64 overflow-y-auto space-y-1.5 font-mono text-[11px]">
                    {teamState.transmutationLogs.map((log, i) => (
                      <div key={i} className="text-gray-300 leading-tight">
                        <span className="text-gray-600 select-none mr-2">›</span>
                        <span className={log.includes("Étape 12/12") ? "text-emerald-400 font-bold" : log.includes("✖") ? "text-rose-400 font-bold" : "text-gray-300"}>
                          {log}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
