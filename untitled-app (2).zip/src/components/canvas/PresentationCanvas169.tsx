import React from "react";
import { CanvasElement } from "../../hooks/useUnifiedAgentEngine";

interface PresentationCanvas169Props {
  canvasElements: CanvasElement[];
  isTransmitting: boolean;
  activeSignalPath: { sender: string; receiver: string } | null;
  coherenceScore: number;
  systemLoad: number;
}

export default function PresentationCanvas169({
  canvasElements,
  isTransmitting,
  activeSignalPath,
  coherenceScore,
  systemLoad,
}: PresentationCanvas169Props) {
  // Center of our 16:9 system space (960 x 540 coordinate space)
  const cx = 960 / 2;
  const cy = 540 / 2;

  // Find coordinates of a node by ID for dynamic signal line drawing
  const getNodeCoords = (id: string) => {
    const node = canvasElements.find((el) => el.id === id);
    return node ? { x: node.x, y: node.y } : { x: cx, y: cy };
  };

  return (
    <div className="w-full max-w-5xl mx-auto">
      {/* 16:9 Bounding Box with absolute aesthetic discipline */}
      <div 
        id="presentation-canvas-169"
        className="relative w-full aspect-video bg-[#050608] border border-[#14161f] rounded-none overflow-hidden select-none pointer-events-none shadow-2xl Multiply shadow-black/80"
      >
        {/* Subtle grid underlay representing physical coordinates */}
        <div className="absolute inset-0 opacity-[0.03]" style={{
          backgroundImage: "radial-gradient(#f97316 1px, transparent 1px)",
          backgroundSize: "24px 24px"
        }} />

        {/* Outer frame technical indicators */}
        <div className="absolute top-3 left-4 text-[8px] font-mono text-gray-600 uppercase tracking-widest flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-orange-500 animate-pulse" />
          SYSTEME DE RECONSTRUCTION DE FLUX Φ_SOI // V4.0
        </div>
        <div className="absolute top-3 right-4 text-[8px] font-mono text-gray-600 tracking-widest">
          COORDINATES_SPACE: 960x540 // Ξ = 1
        </div>

        {/* SVG Drawing Layer */}
        <svg 
          viewBox="0 0 960 540" 
          className="w-full h-full text-xs font-mono"
        >
          <defs>
            {/* Gradients for glow and paths */}
            <radialGradient id="nodeGlow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#f97316" stopOpacity="0.15" />
              <stop offset="100%" stopColor="#f97316" stopOpacity="0" />
            </radialGradient>
            <linearGradient id="activeLineGrad" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.4" />
              <stop offset="50%" stopColor="#f97316" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#a855f7" stopOpacity="0.4" />
            </linearGradient>
          </defs>

          {/* Concentric mathematical circles representing physical harmonics (H_infinity) */}
          <circle cx={cx} cy={cy} r={180} fill="none" stroke="#1f2029" strokeWidth="1" strokeDasharray="4 4" />
          <circle cx={cx} cy={cy} r={120} fill="none" stroke="#14151a" strokeWidth="1" />
          <circle cx={cx} cy={cy} r={60} fill="none" stroke="#101116" strokeWidth="1" strokeDasharray="2 2" />

          {/* Mathematical crosshairs in background */}
          <line x1={cx - 240} y1={cy} x2={cx + 240} y2={cy} stroke="#101116" strokeWidth="1" />
          <line x1={cx} y1={cy - 240} x2={cx} y2={cy + 240} stroke="#101116" strokeWidth="1" />

          {/* Draw Synaptic Connections (synaptic lines) */}
          {canvasElements.map((el, i) => {
            // Draw connections to the next elements or supervisor
            const nextEl = canvasElements[(i + 1) % canvasElements.length];
            const isPathActive = isTransmitting && activeSignalPath && 
              ((activeSignalPath.sender === el.id && activeSignalPath.receiver === nextEl.id) ||
               (activeSignalPath.sender === nextEl.id && activeSignalPath.receiver === el.id));

            return (
              <g key={`link-${el.id}`}>
                <line
                  x1={el.x}
                  y1={el.y}
                  x2={nextEl.x}
                  y2={nextEl.y}
                  stroke={isPathActive ? "url(#activeLineGrad)" : "#13151c"}
                  strokeWidth={isPathActive ? 2 : 1}
                  className={isPathActive ? "animate-pulse" : ""}
                />
                {/* Connect every node optionally to the supervisor core in the center if it's not the supervisor itself */}
                {el.id !== "@supervisor" && (
                  <line
                    x1={el.x}
                    y1={el.y}
                    x2={cx}
                    y2={cy}
                    stroke="#0e1014"
                    strokeWidth="1"
                    strokeDasharray="2 4"
                  />
                )}
              </g>
            );
          })}

          {/* Active Synaptic Signal packet animation (The Cognitive Bridge flowing) */}
          {isTransmitting && activeSignalPath && (() => {
            const from = getNodeCoords(activeSignalPath.sender);
            const to = getNodeCoords(activeSignalPath.receiver);
            return (
              <g>
                <line 
                  x1={from.x} 
                  y1={from.y} 
                  x2={to.x} 
                  y2={to.y} 
                  stroke="#f97316" 
                  strokeWidth="2.5" 
                  strokeDasharray="10 15"
                >
                  <animate 
                    attributeName="stroke-dashoffset" 
                    values="100;0" 
                    dur="1.2s" 
                    repeatCount="indefinite" 
                  />
                </line>
                <circle cx={to.x} cy={to.y} r={14} fill="none" stroke="#f97316" strokeWidth="1" className="animate-ping" />
              </g>
            );
          })()}

          {/* Draw Nodes and Glowing Haloes */}
          {canvasElements.map((el) => {
            return (
              <g key={el.id} className="transition-all duration-300">
                {/* Outer pulsing ring */}
                <circle
                  cx={el.x}
                  cy={el.y}
                  r={22}
                  fill="url(#nodeGlow)"
                  className={isTransmitting ? "animate-pulse" : ""}
                />
                <circle
                  cx={el.x}
                  cy={el.y}
                  r={8}
                  fill="#06070a"
                  stroke={el.color}
                  strokeWidth="2.5"
                />
                {/* Small center dot */}
                <circle
                  cx={el.x}
                  cy={el.y}
                  r={3}
                  fill={el.color}
                />
                {/* Text Label offset */}
                <text
                  x={el.x}
                  y={el.y - 15}
                  textAnchor="middle"
                  fill="#9ca3af"
                  className="text-[9px] font-bold tracking-tight select-none font-mono"
                >
                  {el.label}
                </text>
                {/* Small indicator tag */}
                <text
                  x={el.x}
                  y={el.y + 18}
                  textAnchor="middle"
                  fill="#4b5563"
                  className="text-[7px] select-none font-mono"
                >
                  {el.id}
                </text>
              </g>
            );
          })}

          {/* Central Supervisor Core Visualizer */}
          <g>
            <circle cx={cx} cy={cy} r={32} fill="#050608" stroke="#ef4444" strokeWidth="1.5" strokeDasharray="3 3" />
            <circle cx={cx} cy={cy} r={22} fill="#0b0d13" stroke="#f97316" strokeWidth="2" className="animate-spin" style={{ transformOrigin: `${cx}px ${cy}px`, animationDuration: "12s" }} />
            <circle cx={cx} cy={cy} r={10} fill="#050608" stroke="#3b82f6" strokeWidth="2.5" />
            <text x={cx} y={cy - 38} textAnchor="middle" fill="#f97316" className="text-[10px] font-black tracking-widest">
              SUPERVISOR CORE
            </text>
            <text x={cx} y={cy + 42} textAnchor="middle" fill="#ef4444" className="text-[7.5px] font-bold">
              Φ_SOI = Ξ ≡ 1
            </text>
          </g>
        </svg>

        {/* Lower technical metrics layer displaying live mathematical state */}
        <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-[8px] font-mono text-gray-500">
          <div className="flex gap-4">
            <span>COHERENCE: <span className="text-emerald-400 font-bold">{coherenceScore.toFixed(1)}%</span></span>
            <span>SYSTEM_LOAD: <span className="text-sky-400 font-bold">{systemLoad.toFixed(1)}%</span></span>
            <span>STATUS: <span className="text-emerald-400">NOMINAL</span></span>
          </div>
          <div>
            SHA-256 SECURED CERTIFICATE // 8f9a2e1d...
          </div>
        </div>
      </div>
    </div>
  );
}
