import React, { useEffect, useRef, useState } from 'react';
import { useQuantumLocalBridge } from '../../hooks/useQuantumLocalBridge';
import { GeometricTuple } from '../../memory/GeometricExecutionBuffer';

interface QuantumStateFrame {
  quantumVector: [number, number, number]; // [∇Ψ, T_p, H_∞]
  coherenceIndex: number; // Ξ (cible: 1.0)
  disresonance: number; // D_c (cible: 0.0)
  activePlan: 'ALPHA' | 'BETA' | 'GAMMA' | 'DELTA';
}

export const QuantumGeometricInterface: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const { isLocalServerOnline, activeModel, executionStack, pushLocalInstruction } = useQuantumLocalBridge();

  const [quantumState] = useState<QuantumStateFrame>({
    quantumVector: [1.0, 1.0, 1.0],
    coherenceIndex: 1.0,
    disresonance: 0.0,
    activePlan: 'DELTA',
  });

  // Boucle de rendu 60 FPS sur le canevas 16:9 passif (Plan DELTA)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;

    const renderQuantumMesh = () => {
      // Configuration de la résolution 16:9
      canvas.width = 1920;
      canvas.height = 1080;

      // Nettoyage fond sombre alchimique
      ctx.fillStyle = '#0a0d14';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // 1. Grille Géométrique de Résonance (Plan ALPHA)
      ctx.strokeStyle = 'rgba(0, 229, 255, 0.08)';
      ctx.lineWidth = 1;
      const gridSize = 60;
      for (let x = 0; x < canvas.width; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, canvas.height);
        ctx.stroke();
      }
      for (let y = 0; y < canvas.height; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(canvas.width, y);
        ctx.stroke();
      }

      // 2. Projection des Tuples Géométriques du Buffer ([id, x, y, rot, scale])
      executionStack.forEach((tuple: GeometricTuple) => {
        const [, x, y, rot, scale] = tuple;
        ctx.save();
        ctx.translate(x * 10, y * 10);
        ctx.rotate((rot * Math.PI) / 180);
        ctx.scale(scale, scale);

        // Ombre portée 2.5D Multiply
        ctx.shadowColor = 'rgba(0, 0, 0, 0.6)';
        ctx.shadowBlur = 15;
        ctx.shadowOffsetY = 8;

        // Tracé géométrique vectoriel
        ctx.strokeStyle = '#00e5ff';
        ctx.lineWidth = 2;
        ctx.strokeRect(-25, -25, 50, 50);

        ctx.fillStyle = 'rgba(0, 229, 255, 0.15)';
        ctx.fillRect(-25, -25, 50, 50);
        ctx.restore();
      });

      // 3. Affichage du Sceau Résonant (Ξ = 1.0)
      ctx.fillStyle = '#00e5ff';
      ctx.font = '14px monospace';
      ctx.fillText(`Φ_SOI KERNEL | Ξ = ${quantumState.coherenceIndex.toFixed(4)} | D_c = ${quantumState.disresonance.toFixed(4)}`, 40, 50);
      ctx.fillText(`IA LOCALE GPU : ${isLocalServerOnline ? activeModel : 'HORS-LIGNE (FALLBACK ALPHA)'}`, 40, 75);

      animationFrameId = requestAnimationFrame(renderQuantumMesh);
    };

    renderQuantumMesh();

    return () => {
      cancelAnimationFrame(animationFrameId);
    };
  }, [executionStack, quantumState, isLocalServerOnline, activeModel]);

  return (
    <div className="relative w-full h-screen overflow-hidden bg-slate-950 flex flex-row">
      {/* CANEVAS 16:9 PASSIF (Plan DELTA - Hermétique) */}
      <div className="relative flex-1 h-full flex items-center justify-center p-4">
        <canvas
          ref={canvasRef}
          className="w-full h-auto aspect-video rounded-lg shadow-2xl pointer-events-none select-none border border-cyan-900/30"
        />
      </div>

      {/* DOCK DE CONTRÔLE EXTÉRIEUR (Plan ALPHA/GAMMA) */}
      <div className="w-80 h-full bg-slate-900/90 border-l border-slate-800 p-6 flex flex-col justify-between text-slate-200 text-sm">
        <div>
          <h2 className="text-xs font-mono uppercase tracking-widest text-cyan-400 mb-4">
            Dock Quantique Φ_SOI
          </h2>
          <div className="space-y-3 font-mono text-xs">
            <div className="flex justify-between p-2 bg-slate-800/50 rounded">
              <span>Serveur GPU Local :</span>
              <span className={isLocalServerOnline ? 'text-emerald-400' : 'text-rose-400'}>
                {isLocalServerOnline ? 'CONNECTÉ' : 'DÉCONNECTÉ'}
              </span>
            </div>
            <div className="flex justify-between p-2 bg-slate-800/50 rounded">
              <span>Plan Actif :</span>
              <span className="text-cyan-300">{quantumState.activePlan}</span>
            </div>
            <div className="flex justify-between p-2 bg-slate-800/50 rounded">
              <span>Tampon FIFO :</span>
              <span className="text-cyan-300">{executionStack.length} tuples</span>
            </div>
          </div>
        </div>

        <button
          onClick={() => pushLocalInstruction('MODULE_TERRASSEMENT', Math.random() * 100, Math.random() * 50, 45, 1.2)}
          className="w-full py-3 bg-cyan-600 hover:bg-cyan-500 font-mono text-xs uppercase tracking-wider rounded text-white font-semibold transition-colors"
        >
          Injecter Pulse Géométrique
        </button>
      </div>
    </div>
  );
};
