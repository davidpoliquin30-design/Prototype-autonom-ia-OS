import React, { useState, useEffect } from "react";
import { 
  DollarSign, Calculator, ShieldCheck, Scale, Award, 
  HelpCircle, Percent, AlertTriangle, CheckCircle 
} from "lucide-react";

export default function TokenBudgetCalibrator() {
  // Input states
  const [inputTokens, setInputTokens] = useState<number>(1250000); // Default 1.25M
  const [outputTokens, setOutputTokens] = useState<number>(380000); // Default 380k
  const [inputPrice, setInputPrice] = useState<number>(15.0); // Price per million (default $15 for Gemini Pro)
  const [outputPrice, setOutputPrice] = useState<number>(60.0); // Price per million (default $60 for Gemini Pro)
  
  const [inputMultiplier, setInputMultiplier] = useState<number>(1.5); // Overhead multiplier (default 1.5x)
  const [outputMultiplier, setOutputMultiplier] = useState<number>(2.0); // Overhead multiplier (default 2x)
  
  const [tpsTax, setTpsTax] = useState<boolean>(true); // 5%
  const [tvqTax, setTvqTax] = useState<boolean>(true); // 9.975%
  const [emergencyBudget, setEmergencyBudget] = useState<boolean>(true); // 7.5% contingency

  // Engineering compliance checklist state
  const [hasProfessionalStamp, setHasProfessionalStamp] = useState<boolean>(true);
  const [foundationStable, setFoundationStable] = useState<boolean>(true);
  const [slopeDrainagePercentage, setSlopeDrainagePercentage] = useState<number>(2.5); // Default 2.5% slope

  // Calculated values
  const [rawCost, setRawCost] = useState<number>(0);
  const [multiplierCost, setMultiplierCost] = useState<number>(0);
  const [taxes, setTaxes] = useState<number>(0);
  const [contingency, setContingency] = useState<number>(0);
  const [totalCost, setTotalCost] = useState<number>(0);
  
  // Compliance evaluation
  const [complianceRating, setComplianceRating] = useState<"excellent" | "warning" | "critical">("excellent");
  const [complianceDetails, setComplianceDetails] = useState<string[]>([]);

  useEffect(() => {
    // Calcul de base
    const rawIn = (inputTokens / 1000000) * inputPrice;
    const rawOut = (outputTokens / 1000000) * outputPrice;
    const baseRaw = rawIn + rawOut;
    setRawCost(baseRaw);

    // Cost with agent multipliers
    const multIn = rawIn * inputMultiplier;
    const multOut = rawOut * outputMultiplier;
    const baseMult = multIn + multOut;
    setMultiplierCost(baseMult);

    // Emergency Contingency
    let baseContingency = 0;
    if (emergencyBudget) {
      baseContingency = baseMult * 0.075; // 7.5% contingency
    }
    setContingency(baseContingency);

    // Sum subject to taxes
    const beforeTaxes = baseMult + baseContingency;

    // Taxes (TPS 5% and TVQ 9.975%)
    let baseTaxes = 0;
    if (tpsTax) baseTaxes += beforeTaxes * 0.05;
    if (tvqTax) baseTaxes += beforeTaxes * 0.09975;
    setTaxes(baseTaxes);

    // Grand total
    const finalTotal = beforeTaxes + baseTaxes;
    setTotalCost(finalTotal);

    // Evaluate Regulatory and Architectural compliance
    const details: string[] = [];
    let score = 100;

    // 1. Stamp audit
    if (!hasProfessionalStamp) {
      details.push("Manque de sceau professionnel d'ingénieur d'approbation (Requis par l'OIQ, art. 12).");
      score -= 30;
    } else {
      details.push("Sceau de validation professionnelle d'ingénierie active.");
    }

    // 2. Foundation audit
    if (!foundationStable) {
      details.push("Conformité des fondations compromise. Le rapport géotechnique local signale des risques d'instabilité.");
      score -= 30;
    } else {
      details.push("Fondations d'implantation conformes aux exigences structurelles locales.");
    }

    // 3. Slope audit
    if (slopeDrainagePercentage < 2.0) {
      details.push(`Conformité des pentes de drainage critique (${slopeDrainagePercentage}%). Le standard exige un minimum de 2.0% pour éviter l'érosion hydro-mécanique.`);
      score -= 25;
    } else {
      details.push(`Pentes de drainage conformes (${slopeDrainagePercentage}% >= 2.0% requis).`);
    }

    // 4. Budget cap audit
    if (finalTotal > 150) {
      details.push("Dépassement du budget d'ingénierie conseillé ($150 CAD par cycle d'évolution autonome).");
      score -= 15;
    } else {
      details.push("Enveloppe financière respectée.");
    }

    setComplianceDetails(details);

    if (score >= 85) {
      setComplianceRating("excellent");
    } else if (score >= 50) {
      setComplianceRating("warning");
    } else {
      setComplianceRating("critical");
    }

  }, [
    inputTokens, outputTokens, inputPrice, outputPrice, 
    inputMultiplier, outputMultiplier, tpsTax, tvqTax, 
    emergencyBudget, hasProfessionalStamp, foundationStable, 
    slopeDrainagePercentage
  ]);

  return (
    <div id="token-budget-calibrator" className="p-5 bg-[#0b0c10] border border-[#1f2029] rounded-xl shadow-xl text-gray-200 font-mono text-xs">
      
      {/* Title */}
      <div className="flex items-center gap-2 mb-4 pb-2 border-b border-[#1f2029]">
        <Calculator className="w-5 h-5 text-orange-500 animate-pulse" />
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider text-gray-300">Calibrateur de Budget Φ & Conformité Réglementaire</h2>
          <p className="text-[10px] text-gray-500">Modélisation financière d'ingénierie logicielle (Québec standards)</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        
        {/* LEFT COLUMN: FINANCIAL METRICS CONFIG */}
        <div className="space-y-4 bg-[#14151a] p-4 border border-[#2b2d3a] rounded-xl">
          <div className="text-[11px] text-orange-400 font-bold uppercase tracking-widest pb-1 border-b border-[#1f2029]/60">
            📊 PARAMÈTRES DU BUDGET DE TOKENS
          </div>

          {/* Token Volumes */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[10px] text-gray-400 uppercase tracking-wider mb-1">Volume Input Tokens :</label>
              <input
                type="number"
                value={inputTokens}
                onChange={e => setInputTokens(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full bg-[#0b0c10] border border-[#2b2d3a] p-2 rounded-lg text-gray-200 text-xs focus:outline-none focus:border-orange-500"
              />
            </div>
            <div>
              <label className="block text-[10px] text-gray-400 uppercase tracking-wider mb-1">Volume Output Tokens :</label>
              <input
                type="number"
                value={outputTokens}
                onChange={e => setOutputTokens(Math.max(0, parseInt(e.target.value) || 0))}
                className="w-full bg-[#0b0c10] border border-[#2b2d3a] p-2 rounded-lg text-gray-200 text-xs focus:outline-none focus:border-orange-500"
              />
            </div>
          </div>

          {/* Token Unit Prices */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[10px] text-gray-400 uppercase tracking-wider mb-1">Prix par Million (Input) :</label>
              <div className="relative">
                <span className="absolute left-2.5 top-2.5 text-gray-500">$</span>
                <input
                  type="number"
                  step="0.1"
                  value={inputPrice}
                  onChange={e => setInputPrice(Math.max(0, parseFloat(e.target.value) || 0))}
                  className="w-full bg-[#0b0c10] border border-[#2b2d3a] pl-6 p-2 rounded-lg text-gray-200 text-xs focus:outline-none focus:border-orange-500"
                />
              </div>
            </div>
            <div>
              <label className="block text-[10px] text-gray-400 uppercase tracking-wider mb-1">Prix par Million (Output) :</label>
              <div className="relative">
                <span className="absolute left-2.5 top-2.5 text-gray-500">$</span>
                <input
                  type="number"
                  step="0.1"
                  value={outputPrice}
                  onChange={e => setOutputPrice(Math.max(0, parseFloat(e.target.value) || 0))}
                  className="w-full bg-[#0b0c10] border border-[#2b2d3a] pl-6 p-2 rounded-lg text-gray-200 text-xs focus:outline-none focus:border-orange-500"
                />
              </div>
            </div>
          </div>

          {/* Agent Overhead Multipliers */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-[10px] text-gray-400 uppercase tracking-wider mb-1">Overhead Multiplier Input :</label>
              <input
                type="range"
                min="1.0"
                max="5.0"
                step="0.1"
                value={inputMultiplier}
                onChange={e => setInputMultiplier(parseFloat(e.target.value))}
                className="w-full accent-orange-500"
              />
              <div className="text-right text-[10px] text-orange-400 font-bold mt-1">{inputMultiplier}x</div>
            </div>
            <div>
              <label className="block text-[10px] text-gray-400 uppercase tracking-wider mb-1">Overhead Multiplier Output :</label>
              <input
                type="range"
                min="1.0"
                max="5.0"
                step="0.1"
                value={outputMultiplier}
                onChange={e => setOutputMultiplier(parseFloat(e.target.value))}
                className="w-full accent-orange-500"
              />
              <div className="text-right text-[10px] text-orange-400 font-bold mt-1">{outputMultiplier}x</div>
            </div>
          </div>

          {/* Taxes & Contingency Toggles */}
          <div className="border-t border-[#1f2029]/60 pt-3 space-y-2">
            <div className="text-[10px] text-gray-500 uppercase tracking-widest font-bold mb-1">Paramètres fiscaux & urgence :</div>
            
            <div className="flex items-center justify-between p-2 rounded bg-[#0b0c10] border border-[#1f2029]">
              <div className="flex items-center gap-2">
                <Percent className="w-3.5 h-3.5 text-gray-400" />
                <span>TPS Canada (5.0%)</span>
              </div>
              <input
                type="checkbox"
                checked={tpsTax}
                onChange={e => setTpsTax(e.target.checked)}
                className="accent-orange-500"
              />
            </div>

            <div className="flex items-center justify-between p-2 rounded bg-[#0b0c10] border border-[#1f2029]">
              <div className="flex items-center gap-2">
                <Percent className="w-3.5 h-3.5 text-gray-400" />
                <span>TVQ Québec (9.975%)</span>
              </div>
              <input
                type="checkbox"
                checked={tvqTax}
                onChange={e => setTvqTax(e.target.checked)}
                className="accent-orange-500"
              />
            </div>

            <div className="flex items-center justify-between p-2 rounded bg-[#0b0c10] border border-[#1f2029]">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-3.5 h-3.5 text-gray-400" />
                <span>Provision Contingence Urgence (7.5%)</span>
              </div>
              <input
                type="checkbox"
                checked={emergencyBudget}
                onChange={e => setEmergencyBudget(e.target.checked)}
                className="accent-orange-500"
              />
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: DETAILED REPORT & REGULATORY WORK COMPLIANCE */}
        <div className="space-y-4">
          
          {/* Detailed Financial Outcome Display */}
          <div className="bg-[#14151a] p-4 border border-[#2b2d3a] rounded-xl space-y-2.5">
            <div className="text-[11px] text-orange-400 font-bold uppercase tracking-widest pb-1 border-b border-[#1f2029]/60 flex items-center justify-between">
              <span>💵 ÉVALUATION DES COÛTS CAD</span>
              <DollarSign className="w-4 h-4" />
            </div>

            <div className="space-y-1.5 font-mono">
              <div className="flex justify-between">
                <span className="text-gray-400">Coût brut brut (Tokens purs) :</span>
                <span className="font-bold text-gray-200">${rawCost.toFixed(4)} CAD</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Coût avec Overhead d'Agents (Multiplicateurs) :</span>
                <span className="font-bold text-orange-400">${multiplierCost.toFixed(4)} CAD</span>
              </div>
              <div className="flex justify-between border-t border-[#1f2029]/60 pt-1.5">
                <span className="text-gray-400">Fonds d'urgence de réserve (7.5%) :</span>
                <span className="font-bold text-gray-300">${contingency.toFixed(4)} CAD</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Taxes combinées provinciales & fédérales :</span>
                <span className="font-bold text-gray-300">${taxes.toFixed(4)} CAD</span>
              </div>
              <div className="flex justify-between border-t border-orange-500/30 pt-1.5 text-sm">
                <span className="text-gray-200 font-bold">TOTAL DES TRAVAUX D'INGÉNIERIE :</span>
                <span className="font-black text-orange-400 underline decoration-double">${totalCost.toFixed(2)} CAD</span>
              </div>
            </div>
          </div>

          {/* REGULATORY COMPLIANCE VALIDATOR (OIQ, FOUNDATION, SLOPES) */}
          <div className="bg-[#14151a] p-4 border border-[#2b2d3a] rounded-xl space-y-3">
            <div className="text-[11px] text-orange-400 font-bold uppercase tracking-widest pb-1 border-b border-[#1f2029]/60 flex items-center justify-between">
              <span>📐 COMPLIANCE & LOIS DE L'INGÉNIERIE</span>
              <Scale className="w-4 h-4" />
            </div>

            {/* Compliance rating indicator */}
            <div className="flex items-center gap-3 p-2.5 rounded-lg border bg-[#0b0c10] border-[#1f2029]">
              <div className={`p-1.5 rounded-full ${
                complianceRating === "excellent" 
                  ? "bg-emerald-950/40 text-emerald-400" 
                  : complianceRating === "warning"
                  ? "bg-orange-950/40 text-orange-400"
                  : "bg-red-950/40 text-red-400 animate-pulse"
              }`}>
                {complianceRating === "excellent" ? <CheckCircle className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
              </div>
              <div>
                <div className="text-[10px] text-gray-500 uppercase tracking-widest font-bold">Statut de Conformité :</div>
                <div className={`text-xs font-bold uppercase ${
                  complianceRating === "excellent" 
                    ? "text-emerald-400" 
                    : complianceRating === "warning"
                    ? "text-orange-400"
                    : "text-red-400"
                }`}>
                  {complianceRating === "excellent" && "CONFORME & APPROUVÉ (Excellent)"}
                  {complianceRating === "warning" && "NON CONFORME NON CRITIQUE (Avertissement)"}
                  {complianceRating === "critical" && "VIOLATION DE CONFORMITÉ (Critique)"}
                </div>
              </div>
            </div>

            {/* Live Interactive Toggles */}
            <div className="space-y-2">
              <div className="flex items-center justify-between p-1.5 bg-[#0b0c10] border border-[#1f2029] rounded">
                <span className="text-[10px] text-gray-300">Sceau d'Ingénieur Professionnel (OIQ) :</span>
                <input
                  type="checkbox"
                  checked={hasProfessionalStamp}
                  onChange={e => setHasProfessionalStamp(e.target.checked)}
                  className="accent-emerald-500"
                />
              </div>

              <div className="flex items-center justify-between p-1.5 bg-[#0b0c10] border border-[#1f2029] rounded">
                <span className="text-[10px] text-gray-300">Stabilité des Fondations :</span>
                <input
                  type="checkbox"
                  checked={foundationStable}
                  onChange={e => setFoundationStable(e.target.checked)}
                  className="accent-emerald-500"
                />
              </div>

              <div className="flex items-center justify-between p-1.5 bg-[#0b0c10] border border-[#1f2029] rounded">
                <span className="text-[10px] text-gray-300">Pente de drainage du sol (min 2.0%) :</span>
                <div className="flex items-center gap-1.5">
                  <input
                    type="number"
                    step="0.1"
                    min="0"
                    max="10"
                    value={slopeDrainagePercentage}
                    onChange={e => setSlopeDrainagePercentage(Math.max(0, parseFloat(e.target.value) || 0))}
                    className="w-14 bg-[#14151a] border border-[#2b2d3a] p-0.5 text-center rounded text-gray-200"
                  />
                  <span>%</span>
                </div>
              </div>
            </div>

            {/* Audit details checklist */}
            <div className="bg-[#08090d] border border-[#1f2029] p-2.5 rounded-lg text-[10px] space-y-1 max-h-24 overflow-y-auto">
              <div className="text-[9px] text-gray-500 uppercase tracking-widest font-bold mb-1">Éléments du rapport réglementaire :</div>
              {complianceDetails.map((detail, index) => (
                <div key={index} className="flex items-start gap-1.5 leading-relaxed text-gray-400 select-text">
                  <span className="text-gray-600">•</span>
                  <span>{detail}</span>
                </div>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
