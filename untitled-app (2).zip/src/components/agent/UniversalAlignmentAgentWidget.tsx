import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Sparkles, CheckCircle2, ShieldAlert, Cpu, Sliders, 
  RefreshCw, Zap, Heart, Eye, ArrowRight, ToggleLeft, 
  ToggleRight, Check, Compass, Layers
} from "lucide-react";
import { 
  universalAlignmentAgent, 
  AlignmentSystemState, 
  AlignmentDecision 
} from "../../services/agent/universalAlignmentAgent";

interface UniversalAlignmentAgentWidgetProps {
  compact?: boolean;
}

export default function UniversalAlignmentAgentWidget({ compact = false }: UniversalAlignmentAgentWidgetProps) {
  const [state, setState] = useState<AlignmentSystemState>(universalAlignmentAgent.getState());
  const [isExpanded, setIsExpanded] = useState<boolean>(!compact);
  const [isHarmonizing, setIsHarmonizing] = useState<boolean>(false);

  useEffect(() => {
    const unsub = universalAlignmentAgent.subscribe(setState);
    return () => unsub();
  }, []);

  const handleForceHarmonize = () => {
    setIsHarmonizing(true);
    universalAlignmentAgent.forceIntegralHarmonization();
    setTimeout(() => {
      setIsHarmonizing(false);
    }, 600);
  };

  if (compact && !isExpanded) {
    return (
      <div 
        onClick={() => setIsExpanded(true)}
        className="cursor-pointer px-2.5 py-1.5 rounded-lg bg-[#0e111a] border border-[#232a40] hover:border-cyan-500/50 flex items-center gap-2 transition-all shadow-sm"
      >
        <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
        <span className="text-[11px] font-bold text-cyan-300 flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-cyan-400" />
          Agent Alignement : {(state.integralAlignmentScore * 100).toFixed(1)}%
        </span>
        <span className="text-[9px] px-1.5 py-0.2 rounded bg-rose-950 text-rose-300 border border-rose-800">
          Amr ≡ 1
        </span>
      </div>
    );
  }

  return (
    <div className="rounded-xl bg-[#090b12] border border-[#1e2338] overflow-hidden text-xs font-mono shadow-xl">
      
      {/* HEADER */}
      <div className="p-3 bg-gradient-to-r from-[#101422] to-[#0b0e18] border-b border-[#1c2236] flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <div className="relative">
            <div className="w-6 h-6 rounded-lg bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center text-white">
              <Cpu className="w-3.5 h-3.5 animate-pulse" />
            </div>
            <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-400" />
          </div>

          <div>
            <div className="text-[11px] font-black text-white uppercase flex items-center gap-1.5">
              <span>Agent IA d'Alignement Intégral</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                Arrière-Plan Actif
              </span>
            </div>
            <div className="text-[9px] text-gray-400">
              Harmonisation des Options & Protocole Source d'Amour
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {compact && (
            <button
              onClick={() => setIsExpanded(false)}
              className="text-gray-500 hover:text-gray-300 text-xs px-1"
            >
              ✕
            </button>
          )}

          <button
            onClick={handleForceHarmonize}
            disabled={isHarmonizing}
            className="px-2.5 py-1 rounded-lg bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white font-bold text-[10px] flex items-center gap-1 transition-all disabled:opacity-50"
          >
            <RefreshCw className={`w-3 h-3 ${isHarmonizing ? "animate-spin" : ""}`} />
            <span>Harmoniser Tout</span>
          </button>
        </div>
      </div>

      {/* STATUS & GAUGES */}
      <div className="p-3 grid grid-cols-3 gap-2 bg-[#06080e] border-b border-[#181c2c] text-[10px]">
        <div className="p-2 rounded-lg bg-[#0e111c] border border-[#1b2136]">
          <div className="text-gray-400">Alignement Intégral</div>
          <div className="text-emerald-400 font-bold text-xs mt-0.5">
            {(state.integralAlignmentScore * 100).toFixed(2)}%
          </div>
          <div className="text-[8px] text-gray-500">Objectif : Ξ ≡ 1</div>
        </div>

        <div className="p-2 rounded-lg bg-[#0e111c] border border-[#1b2136]">
          <div className="text-gray-400">Disrésonance (D_c)</div>
          <div className="text-cyan-400 font-bold text-xs mt-0.5">
            {state.cognitiveDissonanceDc.toFixed(4)}
          </div>
          <div className="text-[8px] text-gray-500">Zéro friction</div>
        </div>

        <div className="p-2 rounded-lg bg-[#0e111c] border border-[#1b2136]">
          <div className="text-gray-400">Amour Source (Amr)</div>
          <div className="text-rose-400 font-bold text-xs mt-0.5 flex items-center gap-1">
            <Heart className="w-3 h-3" fill="currentColor" />
            1.0000
          </div>
          <div className="text-[8px] text-gray-500">Source Première</div>
        </div>
      </div>

      {/* ACTIVE CHOICES CHOSEN BY THE AGENT */}
      <div className="p-3 space-y-2 border-b border-[#181c2c]">
        <div className="text-[10px] text-gray-400 uppercase font-bold flex items-center justify-between">
          <span>Options Système Verrouillées</span>
          <div className="flex items-center gap-1 text-[9px]">
            <span className="text-gray-400">Auto-Apply :</span>
            <button
              onClick={() => universalAlignmentAgent.toggleAutoApply()}
              className={`font-bold ${state.autoApplyChanges ? "text-emerald-400" : "text-gray-500"}`}
            >
              {state.autoApplyChanges ? "OUI" : "NON"}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-2 text-[10px]">
          <div className="p-1.5 rounded bg-[#101422] border border-[#1e253e]">
            <span className="text-gray-400">Modèle Sélectionné :</span>
            <div className="text-cyan-300 font-bold truncate">Gemini 2.5 Flash</div>
          </div>
          <div className="p-1.5 rounded bg-[#101422] border border-[#1e253e]">
            <span className="text-gray-400">Température & Top-P :</span>
            <div className="text-cyan-300 font-bold">0.70 / 0.95 (Optimal)</div>
          </div>
          <div className="p-1.5 rounded bg-[#101422] border border-[#1e253e]">
            <span className="text-gray-400">Sous-Sol Nordique :</span>
            <div className="text-emerald-300 font-bold truncate">Gel 48" • Maj. 10%</div>
          </div>
          <div className="p-1.5 rounded bg-[#101422] border border-[#1e253e]">
            <span className="text-gray-400">Flux de Lumière :</span>
            <div className="text-amber-300 font-bold">100% Rayonnant</div>
          </div>
        </div>
      </div>

      {/* DECISION LOGS IN REAL TIME */}
      <div className="p-3 space-y-2">
        <div className="text-[10px] text-gray-400 uppercase font-bold flex items-center justify-between">
          <span>Journal des Arbitrages en Arrière-Plan</span>
          <span className="text-[9px] text-cyan-400">{state.totalDecisionsCount} actions</span>
        </div>

        <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
          {state.recentDecisions.map(dec => (
            <div 
              key={dec.id}
              className="p-2 rounded-lg bg-[#0e111a] border border-[#1c2236] space-y-1 text-[10px]"
            >
              <div className="flex items-center justify-between text-gray-400">
                <span className="text-cyan-400 font-bold flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                  {dec.choiceName}
                </span>
                <span className="text-[9px] text-gray-500">{dec.timestamp}</span>
              </div>

              <div className="flex items-center gap-1.5 text-[9px] text-gray-300">
                <span className="text-gray-500 line-through truncate max-w-[90px]">{dec.previousValue}</span>
                <ArrowRight className="w-2.5 h-2.5 text-cyan-400 shrink-0" />
                <span className="text-emerald-300 font-bold truncate">{dec.selectedOptimalValue}</span>
              </div>

              <div className="text-[9px] text-gray-400 italic">
                {dec.reasoning}
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
