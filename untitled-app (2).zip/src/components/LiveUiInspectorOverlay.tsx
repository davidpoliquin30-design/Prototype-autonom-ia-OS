import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Crosshair, Cpu, Terminal, Sparkles, CheckCircle2, Play, AlertCircle, X, RefreshCw } from "lucide-react";
import { apiMatrixRoutingService } from "../services/agents/apiMatrixRoutingService";

// Predefined sub-components for instant local rendering based on injection type
import QuantumCalculator from "./sub/QuantumCalculator";
import MatriceTaskManager from "./sub/MatriceTaskManager";
import ClimatologicalWidget from "./sub/ClimatologicalWidget";
import GenericValidationBadge from "./sub/GenericValidationBadge";

interface LiveUiInspectorOverlayProps {
  isActive: boolean;
  onClose: () => void;
  onInjectWidget: (widget: InjectedWidget) => void;
}

export interface InjectedWidget {
  id: string;
  type: "calculatrice" | "todo" | "meteo" | "generic";
  selector: string;
  explanation: string;
  code: string;
  x: number;
  y: number;
}

export default function LiveUiInspectorOverlay({ isActive, onClose, onInjectWidget }: LiveUiInspectorOverlayProps) {
  const [hoveredElement, setHoveredElement] = useState<HTMLElement | null>(null);
  const [selectedElement, setSelectedElement] = useState<HTMLElement | null>(null);
  const [boundingBox, setBoundingBox] = useState<{ top: number; left: number; width: number; height: number } | null>(null);
  const [selectedBox, setSelectedBox] = useState<{ top: number; left: number; width: number; height: number } | null>(null);
  
  const [instruction, setInstruction] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [statusLog, setStatusLog] = useState<string>("Prêt pour ciblage d'élément...");
  const [marqueeLogs, setMarqueeLogs] = useState<string[]>([]);
  const [agentLogs, setAgentLogs] = useState<string[]>([
    "🔬 Compilateur: Analyse synaptique de l'UI prête.",
    "🏗️ ProCoder: Prêt pour refactoring in-situ.",
    "🎯 Expert d'Installation: Connexions prêtes."
  ]);

  // Handle active marquee state simulation
  useEffect(() => {
    if (!isProcessing) return;

    const logs = [
      "🔬 Compilateur: Enregistrement du fragment HTML...",
      "🏗️ ProCoder: Génération du modèle d'évolution...",
      "🔬 Compilateur: Analyse des styles Tailwind CSS...",
      "🎯 Expert d'Installation: Résolution des dépendances...",
      "🏗️ ProCoder: Structuration du composant React...",
      "🔬 Compilateur: Vérification de la compatibilité linter...",
      "🎯 Expert d'Installation: Préparation à l'injection locale..."
    ];

    let currentLogIndex = 0;
    const interval = setInterval(() => {
      if (currentLogIndex < logs.length) {
        setStatusLog(logs[currentLogIndex]);
        setMarqueeLogs(prev => [logs[currentLogIndex], ...prev].slice(0, 10));
        currentLogIndex++;
      } else {
        clearInterval(interval);
      }
    }, 1200);

    return () => clearInterval(interval);
  }, [isProcessing]);

  // Handle mouse move globally during hover scanning
  useEffect(() => {
    if (!isActive || selectedElement) return;

    const handleMouseMove = (e: MouseEvent) => {
      // Temporarily bypass pointer events on the overlay so we scan elements below
      const overlay = document.getElementById("matrix-inspection-overlay");
      if (overlay) overlay.style.pointerEvents = "none";

      const target = document.elementFromPoint(e.clientX, e.clientY) as HTMLElement;
      if (overlay) overlay.style.pointerEvents = "auto";

      if (target && target !== document.body && target !== document.documentElement && !overlay?.contains(target)) {
        setHoveredElement(target);
        const rect = target.getBoundingClientRect();
        setBoundingBox({
          top: rect.top + window.scrollY,
          left: rect.left + window.scrollX,
          width: rect.width,
          height: rect.height
        });
      } else {
        setHoveredElement(null);
        setBoundingBox(null);
      }
    };

    const handleMouseClick = (e: MouseEvent) => {
      if (hoveredElement) {
        e.preventDefault();
        e.stopPropagation();
        setSelectedElement(hoveredElement);
        const rect = hoveredElement.getBoundingClientRect();
        setSelectedBox({
          top: rect.top + window.scrollY,
          left: rect.left + window.scrollX,
          width: rect.width,
          height: rect.height
        });
        setStatusLog("Élément ciblé. Veuillez saisir votre consigne d'évolution.");
      }
    };

    window.addEventListener("mousemove", handleMouseMove);
    window.addEventListener("click", handleMouseClick, true);

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("click", handleMouseClick, true);
    };
  }, [isActive, hoveredElement, selectedElement]);

  const handleInjectSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedElement || !instruction.trim() || isProcessing) return;

    setIsProcessing(true);
    setStatusLog("Activation de la Matrice d'Automation...");
    
    // Build unique selector for targeted element
    const tag = selectedElement.tagName.toLowerCase();
    const id = selectedElement.id ? `#${selectedElement.id}` : "";
    const classes = selectedElement.className 
      ? `.${selectedElement.className.trim().split(/\s+/).slice(0, 2).join(".")}`
      : "";
    const selectorPath = `${tag}${id}${classes}`;

    try {
      const data = await apiMatrixRoutingService.executeAgentQuery("UiMesh", instruction, {
        targetedHtml: selectedElement.outerHTML.substring(0, 1000)
      });
      
      // Complete progression
      setTimeout(() => {
        setIsProcessing(false);
        
        // Trigger widget creation on dashboard
        const newWidget: InjectedWidget = {
          id: Math.random().toString(36).substring(7),
          type: data.type || "generic",
          selector: selectorPath,
          explanation: data.explanation || "Injection réussie.",
          code: data.codeToInject || "",
          x: selectedBox?.left || 100,
          y: (selectedBox?.top || 100) + (selectedBox?.height || 50) + 10
        };

        onInjectWidget(newWidget);
        
        // Clear selection
        setSelectedElement(null);
        setSelectedBox(null);
        setInstruction("");
        onClose();
      }, 5000); // Give time to experience logs

    } catch (err: any) {
      console.error(err);
      setIsProcessing(false);
      setStatusLog("Erreur critique d'orchestration.");
    }
  };

  if (!isActive) return null;

  return (
    <div 
      id="matrix-inspection-overlay"
      className="fixed inset-0 z-50 overflow-hidden bg-[#06070a]/80 flex flex-col justify-between"
      style={{ pointerEvents: "auto" }}
    >
      {/* Top action header */}
      <div className="bg-[#14151a]/95 border-b border-[#2b2d3a] px-6 py-3 flex items-center justify-between text-white shadow-lg">
        <div className="flex items-center gap-3">
          <Crosshair className="w-5 h-5 text-orange-500 animate-pulse" />
          <div>
            <h2 className="text-sm font-mono font-bold uppercase tracking-wider">Inspecteur de l'UI & Matrice d'Automation</h2>
            <p className="text-[10px] text-gray-400 font-mono">Survolez un composant pour cibler et injecter une fonctionnalité évolutive</p>
          </div>
        </div>
        
        <button 
          onClick={() => {
            setSelectedElement(null);
            setSelectedBox(null);
            onClose();
          }}
          className="p-1.5 bg-[#1e202b] hover:bg-red-950/40 hover:text-red-400 border border-[#2b2d3a] rounded-lg text-gray-400 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Hover Bounding Box */}
      {boundingBox && !selectedElement && (
        <div 
          className="absolute border border-orange-500 bg-orange-500/10 transition-all duration-75 pointer-events-none z-40"
          style={{
            top: boundingBox.top,
            left: boundingBox.left,
            width: boundingBox.width,
            height: boundingBox.height
          }}
        >
          <div className="absolute top-0 left-0 bg-orange-500 text-black font-mono text-[9px] px-1 font-bold">
            {hoveredElement?.tagName.toLowerCase()}
            {hoveredElement?.id ? `#${hoveredElement.id}` : ""}
          </div>
        </div>
      )}

      {/* Selected Box Highlights */}
      {selectedBox && (
        <div 
          className="absolute border-2 border-emerald-500 bg-emerald-500/15 pointer-events-none z-40"
          style={{
            top: selectedBox.top,
            left: selectedBox.left,
            width: selectedBox.width,
            height: selectedBox.height
          }}
        />
      )}

      {/* Agent Heartbeat / Marquee logs panel */}
      <div className="flex-1 flex items-center justify-center p-6 pointer-events-none">
        <AnimatePresence>
          {selectedElement && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-md bg-[#14151a]/95 border border-[#2b2d3a] rounded-xl text-white shadow-2xl p-5 pointer-events-auto z-50 font-mono"
            >
              <div className="flex items-center justify-between border-b border-[#2b2d3a] pb-3 mb-4">
                <div className="flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-emerald-400 animate-spin" />
                  <span className="text-xs font-bold uppercase text-emerald-400">Orchestrateur Synaptique</span>
                </div>
                <button 
                  onClick={() => { setSelectedElement(null); setSelectedBox(null); }}
                  className="text-gray-400 hover:text-white text-xs"
                >
                  Annuler Cible
                </button>
              </div>

              {/* Element descriptor */}
              <div className="bg-[#0b0c10] border border-[#1f2029] rounded-lg p-2.5 mb-4 text-[11px]">
                <div className="text-gray-500 uppercase tracking-widest text-[9px] mb-1">Cible ID :</div>
                <div className="text-emerald-400 truncate">
                  {selectedElement.tagName.toLowerCase()}
                  {selectedElement.id ? `#${selectedElement.id}` : ""}
                  {selectedElement.className ? `.${selectedElement.className.trim().split(/\s+/).join(".")}` : ""}
                </div>
              </div>

              {/* Action Form */}
              <form onSubmit={handleInjectSubmit} className="space-y-4">
                <div>
                  <label className="block text-[10px] text-gray-400 uppercase tracking-wider mb-1.5">Directives d'évolution :</label>
                  <input
                    value={instruction}
                    onChange={e => setInstruction(e.target.value)}
                    disabled={isProcessing}
                    placeholder="ex: Injecte une calculatrice, ou un gestionnaire de tâches..."
                    className="w-full bg-[#0b0c10] border border-[#2b2d3a] text-xs p-2.5 rounded-lg focus:outline-none focus:border-emerald-500 text-gray-100 placeholder-gray-600"
                    autoFocus
                  />
                </div>

                {/* Agent Activity logs */}
                <div className="bg-[#08090d] border border-[#1f2029] p-3 rounded-lg h-36 overflow-y-auto space-y-1.5 text-[10px] text-gray-400 select-text">
                  <div className="text-emerald-500 font-bold mb-1 border-b border-emerald-950/50 pb-1 flex items-center justify-between">
                    <span>📃 JOURNAL DES AGENTS INTERACTIFS</span>
                    <span className="animate-pulse">● ACTIF</span>
                  </div>
                  
                  {isProcessing ? (
                    <>
                      {marqueeLogs.map((log, i) => (
                        <div key={i} className="text-emerald-400/90 leading-relaxed">{log}</div>
                      ))}
                      <div className="text-orange-400 animate-pulse font-semibold">🧬 {statusLog}</div>
                    </>
                  ) : (
                    agentLogs.map((log, i) => (
                      <div key={i}>{log}</div>
                    ))
                  )}
                </div>

                {/* Actions buttons */}
                <div className="flex gap-2">
                  <button
                    type="submit"
                    disabled={isProcessing || !instruction.trim()}
                    className={`flex-1 py-2 rounded-lg text-xs font-bold text-center flex items-center justify-center gap-2 transition-all ${
                      isProcessing || !instruction.trim()
                        ? "bg-gray-800 text-gray-500 cursor-not-allowed"
                        : "bg-emerald-500 hover:bg-emerald-600 text-black shadow-lg shadow-emerald-500/10"
                    }`}
                  >
                    {isProcessing ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                        Compilation du plan...
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5" />
                        Inhiber la structure & Injecter
                      </>
                    )}
                  </button>
                </div>
              </form>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Footer System status message */}
      <div className="bg-[#14151a]/95 border-t border-[#2b2d3a] px-6 py-2 flex items-center justify-between text-xs font-mono text-gray-400">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-emerald-500" />
          <span>Statut : {selectedElement ? "En attente de directives d'injection" : "Mode ciblage actif (Cliquez sur un élément)"}</span>
        </div>
        <div className="text-[10px] text-emerald-500">Φ_SOI CORE v1.4.2</div>
      </div>
    </div>
  );
}
