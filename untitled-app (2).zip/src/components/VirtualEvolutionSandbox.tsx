import React, { useState, useEffect } from "react";
import { 
  Network, Server, Radio, ShieldAlert, Settings, ToggleLeft, 
  Terminal, RefreshCw, Zap, Sliders, Activity, Power 
} from "lucide-react";
import { AgentNode, AgentNetworkState } from "../types";

export default function VirtualEvolutionSandbox() {
  // Nodes initial state
  const [nodes, setNodes] = useState<AgentNode[]>([
    { id: "central", name: "🧬 @orchestrateur_central", role: "Coordination centrale du pipeline", status: "online", latency: 15, connections: ["main", "procoder", "compiler"] },
    { id: "main", name: "📁 @agent_main", role: "Analyse transversale de fichiers", status: "online", latency: 32, connections: ["central", "config"] },
    { id: "config", name: "⚙ @agent_config", role: "Vérificateur de variables et dépendances", status: "online", latency: 24, connections: ["main"] },
    { id: "procoder", name: "🏗️ @agent_procoder", role: "Refactorisation incrémentale d'IA", status: "online", latency: 45, connections: ["central"] },
    { id: "compiler", name: "🔬 @agent_compiler", role: "Validation statique et conformité linter", status: "online", latency: 18, connections: ["central"] }
  ]);

  const [globalInterconnect, setGlobalInterconnect] = useState<boolean>(true);
  const [sandboxLogs, setSandboxLogs] = useState<string[]>([
    "Sandbox system initialized. Loading virtual network topology.",
    "AgiServer listening on loopback sync channels.",
    "Mesh connection: central <-> main <-> config established."
  ]);
  const [networkLoad, setNetworkLoad] = useState<number>(38); // percentage

  // Simulate network heartbeat fluctuations
  useEffect(() => {
    const interval = setInterval(() => {
      // 1. Slightly adjust latencies of active nodes
      setNodes(prev => prev.map(node => {
        if (node.status === "offline") return node;
        const delta = Math.floor(Math.random() * 7) - 3; // -3 to +3
        const nextLatency = Math.max(5, node.latency + delta);
        return {
          ...node,
          latency: node.status === "degraded" ? nextLatency + 100 : nextLatency
        };
      }));

      // 2. Randomly log heartbeat checks
      const randomNode = nodes[Math.floor(Math.random() * nodes.length)];
      if (randomNode && randomNode.status !== "offline") {
        const hpm = Math.floor(Math.random() * 15) + 65; // HPM
        addLog(`[HEARTBEAT] Node ${randomNode.id} ping: ${randomNode.latency}ms | Pulse: ${hpm} HPM.`);
      }

      // 3. Modulate network load
      setNetworkLoad(prev => {
        const delta = Math.floor(Math.random() * 11) - 5;
        return Math.max(10, Math.min(95, prev + delta));
      });

    }, 3000);

    return () => clearInterval(interval);
  }, [nodes]);

  const addLog = (msg: string) => {
    const time = new Date().toLocaleTimeString();
    setSandboxLogs(prev => [`[${time}] ${msg}`, ...prev].slice(0, 30));
  };

  // Toggle node status (Online -> Degraded -> Offline)
  const toggleNodeStatus = (id: string) => {
    setNodes(prev => prev.map(node => {
      if (node.id === id) {
        let nextStatus: "online" | "degraded" | "offline" = "online";
        if (node.status === "online") nextStatus = "degraded";
        else if (node.status === "degraded") nextStatus = "offline";
        
        addLog(`Node ${node.name} status updated from ${node.status} to ${nextStatus}.`);
        return { ...node, status: nextStatus };
      }
      return node;
    }));
  };

  // Re-route connections dynamically
  const toggleConnection = (fromId: string, toId: string) => {
    setNodes(prev => prev.map(node => {
      if (node.id === fromId) {
        const hasConnection = node.connections.includes(toId);
        const nextConnections = hasConnection
          ? node.connections.filter(c => c !== toId)
          : [...node.connections, toId];
        
        addLog(`Route ${fromId} -> ${toId} ${hasConnection ? "severed" : "connected"}.`);
        return { ...node, connections: nextConnections };
      }
      return node;
    }));
  };

  const handleResetMesh = () => {
    setNodes([
      { id: "central", name: "🧬 @orchestrateur_central", role: "Coordination centrale du pipeline", status: "online", latency: 15, connections: ["main", "procoder", "compiler"] },
      { id: "main", name: "📁 @agent_main", role: "Analyse transversale de fichiers", status: "online", latency: 32, connections: ["central", "config"] },
      { id: "config", name: "⚙ @agent_config", role: "Vérificateur de variables et dépendances", status: "online", latency: 24, connections: ["main"] },
      { id: "procoder", name: "🏗️ @agent_procoder", role: "Refactorisation incrémentale d'IA", status: "online", latency: 45, connections: ["central"] },
      { id: "compiler", name: "🔬 @agent_compiler", role: "Validation statique et conformité linter", status: "online", latency: 18, connections: ["central"] }
    ]);
    setGlobalInterconnect(true);
    addLog("Central Network topology successfully reset to factory parameters.");
  };

  return (
    <div id="virtual-sandbox-widget" className="p-5 bg-[#0b0c10] border border-[#1f2029] rounded-xl shadow-xl text-gray-200 font-mono text-xs">
      
      {/* Title */}
      <div className="flex items-center justify-between pb-2 border-b border-[#1f2029] mb-4">
        <div className="flex items-center gap-2">
          <Network className="w-5 h-5 text-orange-500 animate-pulse" />
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider text-gray-300">Sandbox d'Évolution Virtuelle & Interconnexion Réseau</h2>
            <p className="text-[10px] text-gray-500">Console de monitoring bas niveau et de routage synaptique inter-agents</p>
          </div>
        </div>

        <button
          onClick={handleResetMesh}
          className="px-2.5 py-1.5 bg-[#14151a] hover:bg-[#20222f] border border-[#2b2d3a] rounded text-[10px] text-orange-400 flex items-center gap-1.5 transition-all"
        >
          <RefreshCw className="w-3 h-3" />
          Réinitialiser le maillage
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        
        {/* 1. AGENTS TOPOLOGY INTERACTIVE MAP */}
        <div className="lg:col-span-2 bg-[#14151a] p-4 border border-[#2b2d3a] rounded-xl space-y-4">
          <div className="flex items-center justify-between border-b border-[#1f2029]/60 pb-1.5">
            <span className="text-[11px] text-orange-400 font-bold uppercase tracking-widest flex items-center gap-1.5">
              <Server className="w-4 h-4 text-orange-500" /> TOPOLOGIE DU MAILLAGE SYNAPTIQUE
            </span>
            <div className="flex items-center gap-2">
              <span className="text-[9px] text-gray-500">Interconnexion globale :</span>
              <button
                onClick={() => {
                  setGlobalInterconnect(!globalInterconnect);
                  addLog(`Global interconnections ${!globalInterconnect ? "enabled" : "disabled"}.`);
                }}
                className={`px-2 py-0.5 rounded text-[9px] font-bold ${
                  globalInterconnect ? "bg-emerald-950 text-emerald-400 border border-emerald-900" : "bg-red-950 text-red-400 border border-red-900"
                }`}
              >
                {globalInterconnect ? "MESH ACTIF" : "MESH COUPÉ"}
              </button>
            </div>
          </div>

          {/* List of active nodes with interactive crash and latency diagnostics */}
          <div className="space-y-3">
            {nodes.map(node => {
              const offline = node.status === "offline";
              const degraded = node.status === "degraded";

              return (
                <div 
                  key={node.id} 
                  className={`p-3 rounded-xl border transition-all ${
                    offline 
                      ? "bg-red-950/10 border-red-900/30 text-gray-600 opacity-60" 
                      : degraded 
                      ? "bg-orange-950/10 border-orange-900/30 text-orange-200" 
                      : "bg-[#0b0c10] border-[#1f2029] hover:border-gray-700"
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    {/* Node descriptive Info */}
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-1.5">
                        <Activity className={`w-3.5 h-3.5 ${offline ? "text-red-500" : degraded ? "text-orange-500" : "text-emerald-500 animate-pulse"}`} />
                        <span className="font-bold text-gray-200">{node.name}</span>
                        <span className={`text-[9px] px-1.5 py-0.2 rounded font-bold ${
                          offline ? "bg-red-950 text-red-400" : degraded ? "bg-orange-950 text-orange-400" : "bg-emerald-950 text-emerald-400"
                        }`}>
                          {node.status.toUpperCase()}
                        </span>
                      </div>
                      <p className="text-[10px] text-gray-500 font-sans">{node.role}</p>
                    </div>

                    {/* Interactive controls */}
                    <div className="flex items-center gap-2 self-start sm:self-center">
                      {/* Latency meter */}
                      <div className="text-right text-[10px] text-gray-400 mr-2">
                        <div>LATENCE :</div>
                        <div className={`font-mono font-bold ${offline ? "text-red-500" : degraded ? "text-orange-400" : "text-emerald-400"}`}>
                          {offline ? "N/A" : `${node.latency}ms`}
                        </div>
                      </div>

                      {/* State switch */}
                      <button
                        onClick={() => toggleNodeStatus(node.id)}
                        title="Basculer l'état (Online / Dégradé / Offline)"
                        className={`p-1.5 rounded-lg border transition-all ${
                          offline 
                            ? "bg-red-950 text-red-400 border-red-900" 
                            : degraded 
                            ? "bg-orange-950 text-orange-400 border-orange-900" 
                            : "bg-[#14151a] border-[#2b2d3a] hover:bg-[#20222f] text-gray-300"
                        }`}
                      >
                        <Power className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Interconnected Link Routing controls */}
                  {!offline && globalInterconnect && (
                    <div className="mt-2.5 pt-2 border-t border-[#1f2029]/60 flex flex-wrap items-center gap-2">
                      <span className="text-[9px] text-gray-500 uppercase tracking-wider">Connexions synaptiques :</span>
                      {nodes.filter(n => n.id !== node.id).map(other => {
                        const isConnected = node.connections.includes(other.id);
                        return (
                          <button
                            key={other.id}
                            onClick={() => toggleConnection(node.id, other.id)}
                            className={`px-1.5 py-0.5 rounded text-[9px] transition-all border ${
                              isConnected 
                                ? "bg-[#1c221a] text-emerald-400 border-emerald-900/60" 
                                : "bg-[#1a1b24] text-gray-600 border-[#1f2029]"
                            }`}
                          >
                            {isConnected ? "✔" : "+"} {other.id}
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* 2. LIVE METRICS & NETWORK LOGS PANEL */}
        <div className="space-y-4">
          
          {/* Diagnostic Load panel */}
          <div className="bg-[#14151a] p-4 border border-[#2b2d3a] rounded-xl space-y-3">
            <div className="text-[11px] text-orange-400 font-bold uppercase tracking-widest pb-1 border-b border-[#1f2029]/60 flex items-center justify-between">
              <span>🔌 DIAGNOSTICS DE CHARGE</span>
              <Sliders className="w-4 h-4" />
            </div>

            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-[10px] text-gray-400 mb-1">
                  <span>Charge synaptique totale :</span>
                  <span className="font-bold text-orange-400">{networkLoad}%</span>
                </div>
                <div className="w-full bg-[#0b0c10] h-2 rounded overflow-hidden border border-[#1f2029]">
                  <div 
                    className={`h-full transition-all duration-1000 ${
                      networkLoad > 80 ? "bg-red-500 animate-pulse" : networkLoad > 60 ? "bg-orange-500" : "bg-emerald-500"
                    }`}
                    style={{ width: `${networkLoad}%` }}
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-[10px] text-gray-300">
                <div className="bg-[#0b0c10] p-2 rounded border border-[#1f2029]">
                  <div className="text-gray-500">CANAUX :</div>
                  <div className="text-xs font-bold text-emerald-400">Stable</div>
                </div>
                <div className="bg-[#0b0c10] p-2 rounded border border-[#1f2029]">
                  <div className="text-gray-500">MUTATIONS :</div>
                  <div className="text-xs font-bold text-orange-400">Active (Φ)</div>
                </div>
              </div>
            </div>
          </div>

          {/* Sandbox Terminal Console */}
          <div className="bg-[#14151a] p-4 border border-[#2b2d3a] rounded-xl space-y-2 flex flex-col h-64 overflow-hidden">
            <div className="text-[11px] text-orange-400 font-bold uppercase tracking-widest pb-1 border-b border-[#1f2029]/60 flex items-center justify-between">
              <span>📃 LOGS DE LA CONSOLE DE SURVEILLANCE</span>
              <Terminal className="w-4 h-4 text-orange-500" />
            </div>

            <div className="flex-1 bg-[#06070a] rounded-lg p-2.5 overflow-y-auto space-y-1 text-[10px] text-gray-400 select-text">
              {sandboxLogs.map((log, index) => (
                <div key={index} className="leading-relaxed font-mono truncate">{log}</div>
              ))}
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
