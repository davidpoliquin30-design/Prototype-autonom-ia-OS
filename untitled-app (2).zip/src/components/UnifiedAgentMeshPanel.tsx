import React, { useState } from "react";
import { motion } from "motion/react";
import { Network, Sparkles, HelpCircle, Shield, AlertCircle, Compass, Cpu, Layers, Wrench, Activity } from "lucide-react";
import { useUnifiedAgentEngine } from "../hooks/useUnifiedAgentEngine";
import PresentationCanvas169 from "./canvas/PresentationCanvas169";
import SidebarControlDock from "./dock/SidebarControlDock";
import AgentConstellationGraph from "./galaxy/AgentConstellationGraph";
import LiveArchitectureCartographerPanel from "./cartography/LiveArchitectureCartographerPanel";
import AgentInterconnectionCartography from "./telemetry/AgentInterconnectionCartography";
import { omniLiveArchitectureCartographer } from "../services/agent/omniLiveArchitectureCartographer";

export default function UnifiedAgentMeshPanel() {
  const [viewMode, setViewMode] = useState<"unified" | "classic" | "cartography" | "cartography_angles">("cartography_angles");
  
  const {
    agents,
    logs,
    isTransmitting,
    coherenceScore,
    systemLoad,
    activeSignalPath,
    canvasElements,
    executeTransaction,
    reloadEngineState
  } = useUnifiedAgentEngine();

  const cartoSnapshot = omniLiveArchitectureCartographer.getSnapshot();

  return (
    <div className="space-y-4 h-full flex flex-col">
      
      {/* Upper header section for Maillage Unifié */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-[#0b0c10] border border-[#14151e] p-4 rounded-xl shrink-0">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-[#1d140e] border border-orange-500/20 rounded-xl">
            <Network className="w-5 h-5 text-orange-500 animate-pulse" />
          </div>
          <div>
            <h2 className="text-sm font-black uppercase tracking-widest text-white flex items-center gap-2">
              <span>Réseau Maillage Unifié (AROA)</span>
              <span className="text-[9px] px-1.5 py-0.5 bg-orange-500/10 text-orange-400 border border-orange-500/20 rounded uppercase font-bold tracking-tight">Level 4 Autonomous</span>
            </h2>
            <p className="text-[10px] text-gray-400 font-mono mt-0.5">
              Reflet Concret du Système • {cartoSnapshot.totalAgentsCount} Agents • 4 Plans • 16 Outils • 14 Vues
            </p>
          </div>
        </div>

        {/* View Mode Toggle */}
        <div className="flex flex-wrap p-1 bg-[#050608] border border-[#1a1b24] rounded-lg text-[10px] gap-1">
          <button
            onClick={() => setViewMode("cartography_angles")}
            className={`px-3 py-1.5 font-bold uppercase rounded-md transition-all flex items-center gap-1.5 ${
              viewMode === "cartography_angles"
                ? "bg-gradient-to-r from-cyan-600 to-indigo-600 text-white shadow-md shadow-cyan-500/20"
                : "text-cyan-400 hover:text-cyan-200"
            }`}
          >
            <Compass className="w-3.5 h-3.5 text-cyan-300" />
            <span>Cartographie Multi-Angles (6 Pôles)</span>
          </button>
          <button
            onClick={() => setViewMode("unified")}
            className={`px-3 py-1.5 font-bold uppercase rounded-md transition-all ${
              viewMode === "unified"
                ? "bg-orange-500 text-black"
                : "text-gray-400 hover:text-gray-200"
            }`}
          >
            AROA Unifié (16:9)
          </button>
          <button
            onClick={() => setViewMode("cartography")}
            className={`px-3 py-1.5 font-bold uppercase rounded-md transition-all flex items-center gap-1.5 ${
              viewMode === "cartography"
                ? "bg-cyan-500 text-black"
                : "text-cyan-400 hover:text-cyan-200"
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Architecture Réelle</span>
          </button>
          <button
            onClick={() => setViewMode("classic")}
            className={`px-3 py-1.5 font-bold uppercase rounded-md transition-all ${
              viewMode === "classic"
                ? "bg-orange-500 text-black"
                : "text-gray-400 hover:text-gray-200"
            }`}
          >
            Constellation
          </button>
        </div>
      </div>

      {/* REALITY GROUNDING BANNER (Reflet Concret de l'Application) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2 p-2.5 bg-[#07080d] border border-[#151722] rounded-xl text-[10px] font-mono shrink-0">
        <div className="flex items-center gap-2 px-2 py-1 bg-[#0c0e17] rounded border border-[#1b1e2e]">
          <Cpu className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
          <div className="truncate">
            <span className="text-gray-400 block text-[9px]">Flotte Agents :</span>
            <span className="text-white font-bold">{agents.length} Actifs (6 Pôles)</span>
          </div>
        </div>

        <div className="flex items-center gap-2 px-2 py-1 bg-[#0c0e17] rounded border border-[#1b1e2e]">
          <Shield className="w-3.5 h-3.5 text-purple-400 shrink-0" />
          <div className="truncate">
            <span className="text-gray-400 block text-[9px]">Topologie :</span>
            <span className="text-purple-300 font-bold">4 Plans AROA</span>
          </div>
        </div>

        <div className="flex items-center gap-2 px-2 py-1 bg-[#0c0e17] rounded border border-[#1b1e2e]">
          <Wrench className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
          <div className="truncate">
            <span className="text-gray-400 block text-[9px]">Outils Concrets :</span>
            <span className="text-emerald-300 font-bold">16 Intégrés</span>
          </div>
        </div>

        <div className="flex items-center gap-2 px-2 py-1 bg-[#0c0e17] rounded border border-[#1b1e2e]">
          <Layers className="w-3.5 h-3.5 text-orange-400 shrink-0" />
          <div className="truncate">
            <span className="text-gray-400 block text-[9px]">Vues Applicatives :</span>
            <span className="text-orange-300 font-bold">14 Interactives</span>
          </div>
        </div>

        <div className="flex items-center gap-2 px-2 py-1 bg-[#0c0e17] rounded border border-[#1b1e2e]">
          <Activity className="w-3.5 h-3.5 text-rose-400 shrink-0" />
          <div className="truncate">
            <span className="text-gray-400 block text-[9px]">Invariants Nordiques :</span>
            <span className="text-rose-300 font-bold">Gel 48 po • 10-R</span>
          </div>
        </div>

        <div className="flex items-center gap-2 px-2 py-1 bg-[#0c0e17] rounded border border-[#1b1e2e]">
          <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <div className="truncate">
            <span className="text-gray-400 block text-[9px]">Indice de Réalité :</span>
            <span className="text-amber-300 font-bold">Ξ ≡ 1.0000</span>
          </div>
        </div>
      </div>

      {/* Primary Display Area */}
      <div className="flex-1 min-h-0 overflow-y-auto">
        {viewMode === "cartography_angles" ? (
          <div className="h-full">
            <AgentInterconnectionCartography />
          </div>
        ) : viewMode === "cartography" ? (
          <div className="h-full">
            <LiveArchitectureCartographerPanel embedded />
          </div>
        ) : viewMode === "unified" ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start pb-4">
            
            {/* Passive 16:9 Canvas (Plan Delta) */}
            <div className="lg:col-span-7 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-extrabold uppercase text-gray-400 tracking-widest flex items-center gap-1.5">
                  <Shield className="w-4 h-4 text-orange-500" /> Plan Delta : Rétine Contractuelle 16:9 Passive
                </span>
                <span className="text-[9px] text-gray-500 italic flex items-center gap-1">
                  <AlertCircle className="w-3.5 h-3.5" /> pointer-events-none active
                </span>
              </div>
              
              <PresentationCanvas169 
                canvasElements={canvasElements}
                isTransmitting={isTransmitting}
                activeSignalPath={activeSignalPath}
                coherenceScore={coherenceScore}
                systemLoad={systemLoad}
              />
              
              <div className="p-3 bg-[#08090d] border border-[#14151e] rounded-lg text-[10px] text-gray-400 leading-relaxed font-mono">
                <span className="font-extrabold text-white">CONTRAT DU PLAN DELTA :</span> Conformément aux spécifications, la rétine de projection ci-dessus est hermétiquement fermée aux clics (pointer-events-none absolu). Les émissions synaptiques réelles s'opèrent via le <span className="text-orange-400 font-bold">Synapse Commander</span> ci-contre.
              </div>
            </div>

            {/* Side Controller Dock (Sidebar Control Dock) */}
            <div className="lg:col-span-5">
              <SidebarControlDock 
                agents={agents}
                logs={logs}
                isTransmitting={isTransmitting}
                coherenceScore={coherenceScore}
                systemLoad={systemLoad}
                executeTransaction={executeTransaction}
                onRefresh={reloadEngineState}
              />
            </div>

          </div>
        ) : (
          <div className="h-full">
            <AgentConstellationGraph />
          </div>
        )}
      </div>

    </div>
  );
}
