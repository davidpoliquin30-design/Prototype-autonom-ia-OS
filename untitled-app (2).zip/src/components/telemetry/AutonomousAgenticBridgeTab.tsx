import React, { useState, useEffect } from 'react';
import { 
  Bot, 
  Cpu, 
  Shield, 
  Zap, 
  Network, 
  Activity, 
  Play, 
  Pause, 
  RefreshCw, 
  Terminal, 
  Copy, 
  Check, 
  Radio, 
  Server, 
  CheckCircle2, 
  AlertTriangle,
  HardDrive,
  Laptop
} from 'lucide-react';
import { autonomousAgenticBridgeFleet, AgenticBridgeState } from '../../services/quantum/autonomousAgenticBridgeFleet';

export const AutonomousAgenticBridgeTab: React.FC = () => {
  const [fleetState, setFleetState] = useState<AgenticBridgeState>(autonomousAgenticBridgeFleet.getState());
  const [isScanning, setIsScanning] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    const unsub = autonomousAgenticBridgeFleet.subscribe(() => {
      setFleetState({ ...autonomousAgenticBridgeFleet.getState() });
    });
    return unsub;
  }, []);

  const handleScanNow = async () => {
    setIsScanning(true);
    await autonomousAgenticBridgeFleet.triggerAutonomousScan();
    setTimeout(() => setIsScanning(false), 800);
  };

  const handleToggleAutoPilot = async () => {
    await autonomousAgenticBridgeFleet.toggleAutoPilot();
  };

  const oneLineCommand = `curl -s ${window.location.origin}/api/agentic-bridge/connector.js -o phisoi-bridge.js && node phisoi-bridge.js`;

  const handleCopyCommand = () => {
    navigator.clipboard.writeText(oneLineCommand);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-6 text-gray-200">
      
      {/* 1. Header Banner */}
      <div className="p-6 rounded-2xl bg-[#0e111d] border border-purple-800/40 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1.5">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-purple-950 border border-purple-700/50 text-purple-400">
              <Bot className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h1 className="text-lg font-black text-gray-100 tracking-wide uppercase flex items-center gap-2">
                Équipe Agentique Autonome : Pont Matériel & Local
                <span className="px-2.5 py-0.5 rounded-full bg-purple-900/60 text-purple-300 border border-purple-600 text-[10px] font-extrabold">
                  AUTOPILOTE Φ_SOI
                </span>
              </h1>
              <p className="text-xs text-gray-400">
                Orchestration autonome et auto-découverte des ressources matérielles locales (GPU vLLM, Ollama, USB Victron)
              </p>
            </div>
          </div>
        </div>

        {/* Global Action Controls */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleToggleAutoPilot}
            className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 border transition-all ${
              fleetState.isAutoPilotActive
                ? 'bg-emerald-950/80 border-emerald-600 text-emerald-300 hover:bg-emerald-900'
                : 'bg-amber-950/80 border-amber-600 text-amber-300 hover:bg-amber-900'
            }`}
          >
            {fleetState.isAutoPilotActive ? <Play className="w-3.5 h-3.5 fill-current" /> : <Pause className="w-3.5 h-3.5" />}
            <span>{fleetState.isAutoPilotActive ? 'Pilote Automatique : ACTIF' : 'Pilote : EN PAUSE'}</span>
          </button>

          <button
            onClick={handleScanNow}
            disabled={isScanning}
            className="px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold uppercase tracking-wider flex items-center gap-2 shadow-lg shadow-purple-600/20 disabled:opacity-50 transition-all"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? 'animate-spin' : ''}`} />
            <span>{isScanning ? 'Scan en cours...' : 'Scan Forcé'}</span>
          </button>
        </div>
      </div>

      {/* 2. Agent Team Fleet Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {fleetState.agents.map((agent) => (
          <div 
            key={agent.id}
            className="p-4 rounded-xl bg-[#111422] border border-[#232942] space-y-3 flex flex-col justify-between group hover:border-purple-600/50 transition-all"
          >
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-purple-400 uppercase tracking-wider">
                  {agent.pole}
                </span>
                <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-purple-950/80 text-purple-300 border border-purple-700/60 text-[9px] font-bold">
                  <Radio className="w-2.5 h-2.5 text-emerald-400 animate-ping" />
                  Actif
                </span>
              </div>

              <div>
                <h3 className="font-extrabold text-sm text-gray-100 group-hover:text-purple-300 transition-colors">
                  {agent.name}
                </h3>
                <span className="text-[10px] font-mono text-gray-500">{agent.id}</span>
              </div>

              <p className="text-[11px] text-gray-400 leading-relaxed">
                {agent.directive}
              </p>
            </div>

            <div className="pt-3 border-t border-[#1c2238] flex items-center justify-between text-[10px] text-gray-500">
              <span>Actions exécutées : <strong className="text-gray-300 font-mono">{agent.actionsExecuted}</strong></span>
              <span className="text-emerald-400 font-bold">0 $ Token</span>
            </div>
          </div>
        ))}
      </div>

      {/* 3. Real Local Node Connection & 1-Click Autonomous Script */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Left 2 Cols: Connected Local Nodes Status */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-[#0f121e] border border-[#1f253d] space-y-4">
          <div className="flex items-center justify-between border-b border-[#1c2238] pb-3">
            <div className="flex items-center gap-2.5">
              <Laptop className="w-5 h-5 text-cyan-400" />
              <h2 className="font-bold text-sm uppercase tracking-wider text-gray-100">
                Nœuds Locaux Détectés Autonomement
              </h2>
            </div>
            <span className={`px-2.5 py-1 rounded-full text-xs font-bold border ${
              fleetState.activeNodesCount > 0
                ? 'bg-emerald-950 text-emerald-300 border-emerald-700'
                : 'bg-amber-950/70 text-amber-300 border-amber-800'
            }`}>
              {fleetState.activeNodesCount > 0 ? `${fleetState.activeNodesCount} Nœud(s) En Ligne` : 'En attente de connexion'}
            </span>
          </div>

          {fleetState.nodes.length === 0 ? (
            <div className="p-6 rounded-xl bg-[#141829]/60 border border-dashed border-[#2b3352] text-center space-y-3">
              <Radio className="w-8 h-8 text-purple-400 mx-auto animate-pulse" />
              <div className="space-y-1">
                <h4 className="text-sm font-bold text-gray-300">
                  L'équipe agentique écoute en continu
                </h4>
                <p className="text-xs text-gray-500 max-w-md mx-auto">
                  Lancez le script autonome ci-contre sur votre ordinateur pour que les agents détectent automatiquement votre carte graphique Nvidia et vos ports USB locaux.
                </p>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              {fleetState.nodes.map((node) => (
                <div key={node.nodeId} className="p-4 rounded-xl bg-[#141829] border border-cyan-800/40 space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div className="p-1.5 rounded-lg bg-cyan-950 border border-cyan-700 text-cyan-300">
                        <Server className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="font-bold text-sm text-gray-100">{node.hostname}</div>
                        <div className="text-[10px] text-gray-400 font-mono">{node.nodeId} • {node.platform}</div>
                      </div>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-700 text-[10px] font-bold">
                      SYNCHRONISÉ
                    </span>
                  </div>

                  {/* GPU & Ollama detection summary */}
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2 pt-2 border-t border-[#1f263f] text-xs">
                    <div className="p-2 rounded bg-[#0e111d] border border-[#1d233a]">
                      <div className="text-[10px] text-gray-400">GPU VRAM Détectée</div>
                      <div className="font-bold text-cyan-300 mt-0.5">
                        {node.gpu ? `${node.gpu.name} (${node.gpu.vramTotalMb} MB)` : 'N/A'}
                      </div>
                    </div>
                    <div className="p-2 rounded bg-[#0e111d] border border-[#1d233a]">
                      <div className="text-[10px] text-gray-400">Modèles Ollama</div>
                      <div className="font-bold text-indigo-300 mt-0.5">
                        {node.ollama?.isRunning ? `${node.ollama.models.length} modèle(s)` : 'Inactif'}
                      </div>
                    </div>
                    <div className="p-2 rounded bg-[#0e111d] border border-[#1d233a]">
                      <div className="text-[10px] text-gray-400">Transducteur USB</div>
                      <div className="font-bold text-amber-300 mt-0.5">
                        {node.hardware?.victronConnected ? 'Victron Branché' : 'Port Libre'}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Right 1 Col: 1-Click Autonomous Script */}
        <div className="p-5 rounded-2xl bg-[#0f121e] border border-purple-900/40 space-y-4 flex flex-col justify-between">
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <Terminal className="w-5 h-5 text-purple-400" />
              <h3 className="font-bold text-sm uppercase tracking-wider text-gray-100">
                Connexion Autonome 1-Ligne
              </h3>
            </div>
            <p className="text-xs text-gray-400 leading-relaxed">
              Copiez et collez cette commande dans le terminal de votre PC personnel (Windows PowerShell, Linux ou macOS) :
            </p>

            <div className="p-3 rounded-xl bg-[#090b12] border border-[#212740] font-mono text-[11px] text-cyan-300 break-all relative group">
              <code>{oneLineCommand}</code>
              <button
                onClick={handleCopyCommand}
                className="mt-2 w-full py-1.5 rounded-lg bg-purple-950 hover:bg-purple-900 text-purple-200 border border-purple-700/60 font-sans text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Commande Copiée !' : 'Copier la Commande'}</span>
              </button>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-purple-950/30 border border-purple-800/40 space-y-1.5 text-[11px] text-gray-300">
            <div className="font-bold text-purple-300 flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              <span>Garantie Zéro Configuration</span>
            </div>
            <p className="text-gray-400 leading-relaxed text-[10px]">
              L'agent <code>@local_hardware_scout</code> détectera instantanément le signal, échangera la clé cryptographique et redirigera vos inférences vers votre GPU local.
            </p>
          </div>
        </div>

      </div>

      {/* 4. Live Agent Communication Bus Logs */}
      <div className="p-5 rounded-2xl bg-[#0c0e18] border border-[#1c2138] space-y-3">
        <div className="flex items-center justify-between border-b border-[#1b2034] pb-2.5">
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-emerald-400" />
            <h3 className="font-bold text-xs uppercase tracking-wider text-gray-200">
              Journal d'Activité Synaptique Autonome (ΔOTel)
            </h3>
          </div>
          <span className="text-[10px] text-gray-500 font-mono">
            Dernier cycle : {new Date(fleetState.lastAutonomousScan).toLocaleTimeString()}
          </span>
        </div>

        <div className="h-44 overflow-y-auto space-y-1 font-mono text-[11px] bg-[#07080f] p-3 rounded-xl border border-[#161a2b]">
          {fleetState.recentAgentLogs.map((log, idx) => (
            <div key={idx} className="text-gray-400 hover:text-gray-200 transition-colors">
              {log}
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
