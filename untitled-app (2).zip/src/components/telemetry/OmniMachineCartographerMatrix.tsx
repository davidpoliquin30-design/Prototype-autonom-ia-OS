import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Cpu, HardDrive, Network, Layers, Sparkles, RefreshCw, 
  Activity, Zap, Shield, CheckCircle2, AlertTriangle, ArrowRight, 
  Radio, Play, Terminal, Database, Send, Compass, Eye, Heart,
  Server, Sun, BatteryCharging, ChevronRight, Gauge, Sliders
} from "lucide-react";
import { 
  omniMachineCartographerService, 
  FullMachineSnapshot, 
  FleetAgentDispatchReceipt,
  FertileErrorEvent 
} from "../../services/quantum/omniMachineCartographerService";
import AgentInterconnectionCartography from "./AgentInterconnectionCartography";

export default function OmniMachineCartographerMatrix() {
  const [snapshot, setSnapshot] = useState<FullMachineSnapshot>(omniMachineCartographerService.getSnapshot());
  const [selectedStratum, setSelectedStratum] = useState<"all" | "hardware" | "kernel" | "network" | "ast" | "quantum" | "fleet">("all");
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [isBroadcasting, setIsBroadcasting] = useState<boolean>(false);
  const [isHealing, setIsHealing] = useState<boolean>(false);
  const [healingFeedback, setHealingFeedback] = useState<string | null>(null);
  const [selectedNodeDetails, setSelectedNodeDetails] = useState<string | null>("stratum-core");

  useEffect(() => {
    const unsub = omniMachineCartographerService.subscribe(() => {
      setSnapshot({ ...omniMachineCartographerService.getSnapshot() });
    });
    return () => unsub();
  }, []);

  const handleTriggerIntrospection = async () => {
    setIsScanning(true);
    try {
      await omniMachineCartographerService.runFullMachineIntrospection();
    } finally {
      setIsScanning(false);
    }
  };

  const handleBroadcastToFleet = async () => {
    setIsBroadcasting(true);
    try {
      await omniMachineCartographerService.dispatchToIntrospectionFleet();
    } finally {
      setIsBroadcasting(false);
    }
  };

  const handleInstantSelfHealing = async () => {
    setIsHealing(true);
    try {
      const res = await omniMachineCartographerService.triggerInstantSelfHealing();
      setHealingFeedback(`Auto-guérison instantanée validée : Stabilité portée à ${res.stability}% (σ_err absorbé).`);
      setTimeout(() => setHealingFeedback(null), 4000);
    } finally {
      setIsHealing(false);
    }
  };

  const toggleAutoScan = () => {
    omniMachineCartographerService.toggleAutoScan();
    setSnapshot({ ...omniMachineCartographerService.getSnapshot() });
  };

  const isAutoScanning = omniMachineCartographerService.getIsAutoScanning();

  return (
    <div className="space-y-6 font-mono text-gray-200">
      
      {/* 1. TOP HEADER & QUANTUM AGENT BADGE */}
      <div className="p-6 rounded-2xl bg-[#090b10] border border-[#1d202d] shadow-2xl relative overflow-hidden">
        {/* Glow ambient accent */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-cyan-500/10 via-purple-500/5 to-transparent rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col xl:flex-row items-start xl:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-cyan-900 via-[#10192e] to-indigo-900 border border-cyan-500/40 flex items-center justify-center shadow-lg shadow-cyan-500/20">
                <Compass className={`w-7 h-7 text-cyan-400 ${isScanning ? "animate-spin" : ""}`} style={{ animationDuration: "8s" }} />
              </div>
              <span className="absolute -bottom-1 -right-1 flex h-4 w-4">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-4 w-4 bg-emerald-500 border-2 border-[#090b10]"></span>
              </span>
            </div>

            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h1 className="text-lg font-black tracking-wide text-white uppercase flex items-center gap-2">
                  @omni_quantum_cartographer
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800 font-bold">
                    Agent d'Introspection Holistique
                  </span>
                </h1>
                <span className="text-[10px] px-2 py-0.5 rounded bg-[#161b2c] text-indigo-300 border border-indigo-800/40">
                  AROA v8.0 • Temps Nul (A_cc)
                </span>
              </div>
              <p className="text-xs text-gray-400 mt-1 max-w-3xl">
                Opère à l'intégralité des 6 strates de la machine (Matériel, Noyau OS, Réseau, Arborescence AST/DOM, Invariants Quantiques et Flotte Agentique).
                Synthétise et transmet l'état holistique à l'ensemble des agents.
              </p>
            </div>
          </div>

          {/* Action Control Buttons */}
          <div className="flex flex-wrap items-center gap-2 w-full xl:w-auto">
            <button
              onClick={handleTriggerIntrospection}
              disabled={isScanning}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-900/80 to-blue-900/80 hover:from-cyan-800 hover:to-blue-800 text-cyan-200 border border-cyan-500/50 text-xs font-bold transition-all flex items-center gap-2 shadow-lg shadow-cyan-950/50 disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? "animate-spin text-white" : "text-cyan-300"}`} />
              {isScanning ? "Introspection en cours..." : "Lancer Introspection Totale"}
            </button>

            <button
              onClick={handleBroadcastToFleet}
              disabled={isBroadcasting}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-indigo-950/80 to-purple-950/80 hover:from-indigo-900 hover:to-purple-900 text-indigo-200 border border-indigo-500/50 text-xs font-bold transition-all flex items-center gap-2 shadow-lg shadow-indigo-950/50 disabled:opacity-50"
            >
              <Send className={`w-3.5 h-3.5 ${isBroadcasting ? "animate-pulse text-white" : "text-indigo-300"}`} />
              {isBroadcasting ? "Diffusion en cours..." : "Diffuser à la Flotte"}
            </button>

            <button
              onClick={handleInstantSelfHealing}
              disabled={isHealing}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-950/80 to-teal-950/80 hover:from-emerald-900 hover:to-teal-900 text-emerald-200 border border-emerald-500/50 text-xs font-bold transition-all flex items-center gap-2 shadow-lg shadow-emerald-950/50 disabled:opacity-50"
            >
              <Zap className={`w-3.5 h-3.5 ${isHealing ? "animate-bounce text-emerald-400" : "text-emerald-400"}`} />
              {isHealing ? "Auto-Guérison..." : "Auto-Guérison (σ_err → Ξ)"}
            </button>

            <button
              onClick={toggleAutoScan}
              className={`p-2 rounded-xl border text-xs font-medium transition-all flex items-center gap-1.5 ${
                isAutoScanning
                  ? "bg-[#131b24] border-emerald-500/40 text-emerald-300"
                  : "bg-[#14151e] border-[#222533] text-gray-400 hover:text-gray-200"
              }`}
              title={isAutoScanning ? "Auto-Scan actif (toutes les 3.5s)" : "Auto-Scan en pause"}
            >
              <Radio className={`w-3.5 h-3.5 ${isAutoScanning ? "animate-pulse text-emerald-400" : "text-gray-500"}`} />
              <span className="text-[11px] hidden sm:inline">{isAutoScanning ? "Live 3.5s" : "Pause"}</span>
            </button>
          </div>
        </div>

        {/* Feedback alert for self-healing */}
        <AnimatePresence>
          {healingFeedback && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              className="mt-4 p-3 rounded-xl bg-emerald-950/70 border border-emerald-600/50 text-emerald-200 text-xs flex items-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{healingFeedback}</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Live Invariants Strip */}
        <div className="mt-5 pt-4 border-t border-[#1a1d29] grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
          <div className="p-2.5 rounded-xl bg-[#0f1118] border border-[#1f2334] text-center">
            <div className="text-[10px] text-gray-400 uppercase tracking-wider">Φ_SOI (Singularité)</div>
            <div className="text-sm font-black text-cyan-400 mt-0.5">
              {snapshot.quantumMrd.phiSoiValue.toFixed(4)}
            </div>
            <div className="text-[9px] text-emerald-400">Ξ ≡ 1.0000</div>
          </div>

          <div className="p-2.5 rounded-xl bg-[#0f1118] border border-[#1f2334] text-center">
            <div className="text-[10px] text-gray-400 uppercase tracking-wider">Disrésonance (Dc)</div>
            <div className="text-sm font-black text-emerald-400 mt-0.5">
              {snapshot.quantumMrd.cognitiveDisresonance.toFixed(4)}
            </div>
            <div className="text-[9px] text-gray-400">Silence absolu (σ²)</div>
          </div>

          <div className="p-2.5 rounded-xl bg-[#0f1118] border border-[#1f2334] text-center">
            <div className="text-[10px] text-gray-400 uppercase tracking-wider">CPU Total / VRAM</div>
            <div className="text-sm font-black text-indigo-300 mt-0.5">
              {snapshot.hardware.cpuUsagePercent}% / {snapshot.hardware.isGpuOnline ? `${(snapshot.hardware.vllmGpuVramUsedMb / 1024).toFixed(1)} GB` : '0 GB (Inactif)'}
            </div>
            <div className={`text-[9px] ${snapshot.hardware.isGpuOnline ? 'text-indigo-400' : 'text-amber-400 font-bold'}`}>
              {snapshot.hardware.cpuCores} Cœurs • {snapshot.hardware.isGpuOnline ? 'GPU vLLM Connecté' : 'Port 8000 Hors-ligne'}
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-[#0f1118] border border-[#1f2334] text-center">
            <div className="text-[10px] text-gray-400 uppercase tracking-wider">Énergie REH / Solaire</div>
            <div className="text-sm font-black text-amber-300 mt-0.5">
              {snapshot.hardware.isSolarConnected ? `${snapshot.hardware.solarMpptWatts} W` : '0 W'}
            </div>
            <div className={`text-[9px] ${snapshot.hardware.isSolarConnected ? 'text-amber-400' : 'text-red-400 font-bold'}`}>
              {snapshot.hardware.isSolarConnected 
                ? `${snapshot.hardware.batteryVoltageV}V • BMS Δ ${snapshot.hardware.bmsDeltaMillivolts}mV`
                : 'Câble USB Victron non branché'}
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-[#0f1118] border border-[#1f2334] text-center">
            <div className="text-[10px] text-gray-400 uppercase tracking-wider">AST / DOM Actif</div>
            <div className="text-sm font-black text-purple-300 mt-0.5">
              {snapshot.astCodeGraph.registeredModulesCount} mod. / {snapshot.astCodeGraph.activeDomNodesCount} nœuds
            </div>
            <div className="text-[9px] text-purple-400">{snapshot.astCodeGraph.mountedComponentsCount} composants montés</div>
          </div>

          <div className="p-2.5 rounded-xl bg-[#0f1118] border border-[#1f2334] text-center">
            <div className="text-[10px] text-gray-400 uppercase tracking-wider">Stabilité Auto-Guérison</div>
            <div className="text-sm font-black text-emerald-400 mt-0.5">
              {snapshot.quantumMrd.selfHealingStabilityScore}%
            </div>
            <div className="text-[9px] text-emerald-400">A_cc temps nul</div>
          </div>
        </div>
      </div>

      {/* 2. STRATA SELECTOR TABS */}
      <div className="flex flex-wrap items-center gap-2 border-b border-[#1f2130] pb-2">
        <button
          onClick={() => setSelectedStratum("all")}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
            selectedStratum === "all"
              ? "bg-gradient-to-r from-cyan-950 to-blue-950 text-cyan-300 border border-cyan-600/50"
              : "bg-[#11131c] text-gray-400 hover:text-gray-200 border border-transparent"
          }`}
        >
          <Layers className="w-3.5 h-3.5 text-cyan-400" />
          Vue Holistique (6 Strates)
        </button>

        <button
          onClick={() => setSelectedStratum("hardware")}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
            selectedStratum === "hardware"
              ? "bg-[#1a140f] text-amber-300 border border-amber-500/40"
              : "bg-[#11131c] text-gray-400 hover:text-gray-200 border border-transparent"
          }`}
        >
          <Cpu className="w-3.5 h-3.5 text-amber-400" />
          1. Matériel & Énergie
        </button>

        <button
          onClick={() => setSelectedStratum("kernel")}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
            selectedStratum === "kernel"
              ? "bg-[#151224] text-indigo-300 border border-indigo-500/40"
              : "bg-[#11131c] text-gray-400 hover:text-gray-200 border border-transparent"
          }`}
        >
          <Server className="w-3.5 h-3.5 text-indigo-400" />
          2. Noyau OS & Processus
        </button>

        <button
          onClick={() => setSelectedStratum("network")}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
            selectedStratum === "network"
              ? "bg-[#0d1c1a] text-teal-300 border border-teal-500/40"
              : "bg-[#11131c] text-gray-400 hover:text-gray-200 border border-transparent"
          }`}
        >
          <Network className="w-3.5 h-3.5 text-teal-400" />
          3. Réseau & Télémétrie OTel
        </button>

        <button
          onClick={() => setSelectedStratum("ast")}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
            selectedStratum === "ast"
              ? "bg-[#1b1222] text-purple-300 border border-purple-500/40"
              : "bg-[#11131c] text-gray-400 hover:text-gray-200 border border-transparent"
          }`}
        >
          <Layers className="w-3.5 h-3.5 text-purple-400" />
          4. AST & DOM Applicatif
        </button>

        <button
          onClick={() => setSelectedStratum("quantum")}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
            selectedStratum === "quantum"
              ? "bg-[#0b1f1a] text-emerald-300 border border-emerald-500/40"
              : "bg-[#11131c] text-gray-400 hover:text-gray-200 border border-transparent"
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
          5. Invariants MRD & Erreurs Fertiles
        </button>

        <button
          onClick={() => setSelectedStratum("fleet")}
          className={`px-3 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider transition-all flex items-center gap-1.5 ${
            selectedStratum === "fleet"
              ? "bg-[#1d162a] text-pink-300 border border-pink-500/40"
              : "bg-[#11131c] text-gray-400 hover:text-gray-200 border border-transparent"
          }`}
        >
          <Send className="w-3.5 h-3.5 text-pink-400" />
          6. Flotte Agentique & Diffusion
        </button>
      </div>

      {/* 3. CORE CONTENT AREA */}
      {(selectedStratum === "all" || selectedStratum === "hardware") && (
        <div className="p-5 rounded-xl bg-[#0b0d14] border border-[#1b1e2c] space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black uppercase tracking-wider text-amber-400 flex items-center gap-2">
              <Cpu className="w-4 h-4" />
              Strate 1 : Télémétrie Matérielle & Énergie Physique (Transducteur REH)
            </h3>
            <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
              Bus Physique {snapshot.hardware.physicalBusStatus.toUpperCase()}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-4 rounded-xl bg-[#111420] border border-[#202538]">
              <div className="flex items-center justify-between text-xs text-gray-400 mb-1">
                <span>Charge CPU</span>
                <span className="text-amber-400 font-bold">{snapshot.hardware.cpuUsagePercent}%</span>
              </div>
              <div className="w-full bg-[#1b1f30] rounded-full h-2 overflow-hidden">
                <div className="bg-amber-500 h-2 rounded-full transition-all duration-500" style={{ width: `${snapshot.hardware.cpuUsagePercent}%` }} />
              </div>
              <div className="text-[10px] text-gray-400 mt-2 flex justify-between">
                <span>{snapshot.hardware.cpuCores} Cœurs Physiques</span>
                <span>Clock stable</span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#111420] border border-[#202538]">
              <div className="flex items-center justify-between text-xs text-gray-400 mb-1">
                <span>Mémoire Vive (RAM)</span>
                <span className="text-indigo-400 font-bold">{snapshot.hardware.memoryUsedMb} / {snapshot.hardware.memoryTotalMb} MB</span>
              </div>
              <div className="w-full bg-[#1b1f30] rounded-full h-2 overflow-hidden">
                <div className="bg-indigo-500 h-2 rounded-full transition-all duration-500" style={{ width: `${(snapshot.hardware.memoryUsedMb / snapshot.hardware.memoryTotalMb) * 100}%` }} />
              </div>
              <div className="text-[10px] text-gray-400 mt-2 flex justify-between">
                <span>Libre: {snapshot.hardware.memoryFreeMb} MB</span>
                <span>Buffer OS sain</span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#111420] border border-[#202538] space-y-2">
              <div className="flex items-center justify-between text-xs text-gray-400 mb-1">
                <span>VRAM GPU vLLM Local (Port 8000)</span>
                <span className={`font-bold ${snapshot.hardware.isGpuOnline ? 'text-cyan-400' : 'text-amber-400'}`}>
                  {snapshot.hardware.isGpuOnline ? `${snapshot.hardware.vllmGpuVramUsedMb} / ${snapshot.hardware.vllmGpuVramTotalMb} MB` : '0 MB (Inactif)'}
                </span>
              </div>
              <div className="w-full bg-[#1b1f30] rounded-full h-2 overflow-hidden">
                <div 
                  className={`h-2 rounded-full transition-all duration-500 ${snapshot.hardware.isGpuOnline ? 'bg-cyan-500' : 'bg-gray-700'}`} 
                  style={{ width: snapshot.hardware.isGpuOnline ? `${(snapshot.hardware.vllmGpuVramUsedMb / snapshot.hardware.vllmGpuVramTotalMb) * 100}%` : '0%' }} 
                />
              </div>
              <div className="text-[10px] flex justify-between">
                <span className="text-gray-400">
                  {snapshot.hardware.isGpuOnline && snapshot.hardware.gpuTemperatureC ? `Temp: ${snapshot.hardware.gpuTemperatureC}°C` : 'Sonde GPU locale'}
                </span>
                <span className={snapshot.hardware.isGpuOnline ? "text-emerald-400" : "text-amber-400 font-bold"}>
                  {snapshot.hardware.gpuStatusMessage}
                </span>
              </div>
            </div>

            <div className="p-4 rounded-xl bg-[#111420] border border-[#202538] space-y-2">
              <div className="flex items-center justify-between text-xs text-gray-400 mb-1">
                <span>Énergie Solaire MPPT & Batterie</span>
                <span className={`font-bold ${snapshot.hardware.isSolarConnected ? 'text-emerald-400' : 'text-red-400'}`}>
                  {snapshot.hardware.isSolarConnected ? `${snapshot.hardware.solarMpptWatts} W` : '0 W (Déconnecté)'}
                </span>
              </div>
              <div className="w-full bg-[#1b1f30] rounded-full h-2 overflow-hidden">
                <div 
                  className={`h-2 rounded-full transition-all duration-500 ${snapshot.hardware.isSolarConnected ? 'bg-emerald-500' : 'bg-gray-700'}`} 
                  style={{ width: snapshot.hardware.isSolarConnected ? "85%" : "0%" }} 
                />
              </div>
              <div className="text-[10px] flex justify-between">
                <span className="text-gray-400">
                  {snapshot.hardware.isSolarConnected && snapshot.hardware.batteryVoltageV ? `Volthium ${snapshot.hardware.batteryVoltageV}V • Δ ${snapshot.hardware.bmsDeltaMillivolts}mV` : 'Ports /dev/ttyUSB* scannés'}
                </span>
                <span className={snapshot.hardware.isSolarConnected ? "text-emerald-400" : "text-red-400 font-bold"}>
                  {snapshot.hardware.solarStatusMessage}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {(selectedStratum === "all" || selectedStratum === "kernel" || selectedStratum === "network") && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {/* Strate 2: OS & Kernel */}
          <div className="p-5 rounded-xl bg-[#0b0d14] border border-[#1b1e2c] space-y-3">
            <h3 className="text-xs font-black uppercase tracking-wider text-indigo-400 flex items-center gap-2">
              <Server className="w-4 h-4" />
              Strate 2 : Noyau Système & Processus Serveur
            </h3>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-[#111420] border border-[#202538]">
                <div className="text-[10px] text-gray-400">Node Runtime / PID</div>
                <div className="text-indigo-300 font-bold mt-0.5">{snapshot.osKernel.nodeVersion} (PID {snapshot.osKernel.expressServerPid})</div>
              </div>
              <div className="p-3 rounded-lg bg-[#111420] border border-[#202538]">
                <div className="text-[10px] text-gray-400">Ports Écoutés</div>
                <div className="text-indigo-300 font-bold mt-0.5">{snapshot.osKernel.activePorts.join(", ")} (Nginx, vLLM, Companion)</div>
              </div>
              <div className="p-3 rounded-lg bg-[#111420] border border-[#202538]">
                <div className="text-[10px] text-gray-400">Tâches Fond / Fichiers</div>
                <div className="text-indigo-300 font-bold mt-0.5">{snapshot.osKernel.backgroundTasksCount} tâches • {snapshot.osKernel.activeFileDescriptors} descripteurs</div>
              </div>
              <div className="p-3 rounded-lg bg-[#111420] border border-[#202538]">
                <div className="text-[10px] text-gray-400">Lag Event Loop / Uptime</div>
                <div className="text-emerald-400 font-bold mt-0.5">{snapshot.osKernel.eventLoopLagMs} ms • {Math.floor(snapshot.osKernel.uptimeSeconds / 60)} min</div>
              </div>
            </div>
          </div>

          {/* Strate 3: Network & OTel */}
          <div className="p-5 rounded-xl bg-[#0b0d14] border border-[#1b1e2c] space-y-3">
            <h3 className="text-xs font-black uppercase tracking-wider text-teal-400 flex items-center gap-2">
              <Network className="w-4 h-4" />
              Strate 3 : Réseau & Télémétrie Active (ΔOTel)
            </h3>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-[#111420] border border-[#202538]">
                <div className="text-[10px] text-gray-400">Requêtes / Sec</div>
                <div className="text-teal-300 font-bold mt-0.5">{snapshot.networkTelemetry.requestsPerSecond} req/s (Flux continu)</div>
              </div>
              <div className="p-3 rounded-lg bg-[#111420] border border-[#202538]">
                <div className="text-[10px] text-gray-400">Spans OpenTelemetry</div>
                <div className="text-teal-300 font-bold mt-0.5">{snapshot.networkTelemetry.openTelemetrySpansCount} spans capturés</div>
              </div>
              <div className="p-3 rounded-lg bg-[#111420] border border-[#202538]">
                <div className="text-[10px] text-gray-400">Latence P50 / P95 / P99</div>
                <div className="text-emerald-400 font-bold mt-0.5">
                  {snapshot.networkTelemetry.latencyP50Ms}ms / {snapshot.networkTelemetry.latencyP95Ms}ms / {snapshot.networkTelemetry.latencyP99Ms}ms
                </div>
              </div>
              <div className="p-3 rounded-lg bg-[#111420] border border-[#202538]">
                <div className="text-[10px] text-gray-400">Volume Transféré</div>
                <div className="text-teal-300 font-bold mt-0.5">{(snapshot.networkTelemetry.bytesTransferredKb / 1024).toFixed(2)} MB</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {(selectedStratum === "all" || selectedStratum === "ast") && (
        <div className="p-5 rounded-xl bg-[#0b0d14] border border-[#1b1e2c] space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-black uppercase tracking-wider text-purple-400 flex items-center gap-2">
              <Layers className="w-4 h-4" />
              Strate 4 : Cartographie de l'Arborescence AST & DOM Applicatif
            </h3>
            <span className="text-[10px] px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800">
              Indice de Complexité : {snapshot.astCodeGraph.complexityIndex} (Harmonieux)
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="p-3 rounded-xl bg-[#121524] border border-purple-900/30 text-center">
              <div className="text-[10px] text-gray-400 uppercase">Modules Enregistrés</div>
              <div className="text-base font-black text-purple-300 mt-1">{snapshot.astCodeGraph.registeredModulesCount}</div>
              <div className="text-[9px] text-gray-500">Imports stricts top-level</div>
            </div>

            <div className="p-3 rounded-xl bg-[#121524] border border-purple-900/30 text-center">
              <div className="text-[10px] text-gray-400 uppercase">Composants Montés</div>
              <div className="text-base font-black text-purple-300 mt-1">{snapshot.astCodeGraph.mountedComponentsCount}</div>
              <div className="text-[9px] text-emerald-400">Zéro boucle infinie</div>
            </div>

            <div className="p-3 rounded-xl bg-[#121524] border border-purple-900/30 text-center">
              <div className="text-[10px] text-gray-400 uppercase">Nœuds DOM Actifs</div>
              <div className="text-base font-black text-purple-300 mt-1">{snapshot.astCodeGraph.activeDomNodesCount}</div>
              <div className="text-[9px] text-gray-500">Arbre propre et réactif</div>
            </div>

            <div className="p-3 rounded-xl bg-[#121524] border border-purple-900/30 text-center">
              <div className="text-[10px] text-gray-400 uppercase">Hooks & Écouteurs</div>
              <div className="text-base font-black text-purple-300 mt-1">
                {snapshot.astCodeGraph.reactHooksActiveCount} / {snapshot.astCodeGraph.eventListenersCount}
              </div>
              <div className="text-[9px] text-emerald-400">Nettoyage synchrone</div>
            </div>
          </div>
        </div>
      )}

      {/* STRATE 5: QUANTUM INVARIANTS & FERTILE ERROR BUFFER */}
      {(selectedStratum === "all" || selectedStratum === "quantum") && (
        <div className="p-5 rounded-xl bg-[#0b0d14] border border-[#1b1e2c] space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
            <h3 className="text-xs font-black uppercase tracking-wider text-emerald-400 flex items-center gap-2">
              <Sparkles className="w-4 h-4" />
              Strate 5 : Invariants MRD, Fulcrum de Silence & Tampon d'Erreurs Fertiles (σ_err)
            </h3>
            <div className="text-xs text-gray-400">
              Formule maîtresse : <span className="text-emerald-300 font-mono">S_f = e^(iωt) • A_cc = Émergence</span>
            </div>
          </div>

          <div className="space-y-2">
            <div className="text-xs font-bold text-gray-300 flex items-center gap-1.5">
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
              Journal des Événements d'Assimilation & Neutralisation à l'Unité :
            </div>

            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {snapshot.quantumMrd.fertileErrorsBuffer.map((err) => (
                <div key={err.id} className="p-3 rounded-lg bg-[#10131e] border border-emerald-950/60 flex flex-col md:flex-row md:items-center justify-between gap-2 text-xs">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white">{err.sourceModule}</span>
                      <span className="text-[10px] px-1.5 py-0.2 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
                        {err.nature}
                      </span>
                      <span className="text-[10px] text-gray-500">{err.timestamp}</span>
                    </div>
                    <div className="text-gray-400 text-[11px]">{err.description}</div>
                    <div className="text-emerald-400 text-[10px] flex items-center gap-1">
                      <ArrowRight className="w-3 h-3" /> Remède : {err.remedyAction}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-[10px] text-gray-400">σ_err: {err.sigmaErrValue}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-700/50 font-bold">
                      {err.status === "neutralized_at_unity" ? "Neutralisé à l'Unité (Ξ = 1)" : "Carburant Assimilé"}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* STRATE 6: AGENTIC FLEET DISPATCH LEDGER & MULTI-ANGLE CARTOGRAPHY */}
      {(selectedStratum === "all" || selectedStratum === "fleet") && (
        <div className="space-y-4">
          {/* Visual Interactive Multi-Angle Cartography */}
          <AgentInterconnectionCartography />

          <div className="p-5 rounded-xl bg-[#0b0d14] border border-[#1b1e2c] space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
              <h3 className="text-xs font-black uppercase tracking-wider text-pink-400 flex items-center gap-2">
                <Send className="w-4 h-4" />
                Strate 6 : Tableau de Bord de Transmission Synaptique à la Flotte (6 Pôles)
              </h3>
              <span className="text-[10px] px-2 py-0.5 rounded bg-pink-950 text-pink-300 border border-pink-800">
                Synchronisation Holistique {snapshot.fleetDispatches.length}/6 Agents ACK
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {snapshot.fleetDispatches.map((dispatch) => (
                <div key={dispatch.agentHandle} className="p-3.5 rounded-xl bg-[#111320] border border-[#222538] hover:border-pink-500/40 transition-all space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-black text-white">{dispatch.agentHandle}</span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                      {dispatch.ackStatus}
                    </span>
                  </div>

                  <div className="text-[10px] text-pink-400 font-medium">{dispatch.agentPole}</div>
                  <div className="text-[11px] text-gray-300 line-clamp-2">{dispatch.transmittedUnderstandingDigest}</div>

                  <div className="pt-2 border-t border-[#1d2030] flex items-center justify-between text-[10px] text-gray-400">
                    <span className="text-gray-500">{dispatch.lastSyncTimestamp}</span>
                    <span className="text-emerald-400 font-bold">Gain: {dispatch.cognitiveGainScore}% (Δ {dispatch.latencyDeltaMs}ms)</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* 4. REAL-TIME TELEMETRY EVENT STREAM */}
      <div className="p-4 rounded-xl bg-[#08090d] border border-[#1b1e2a] space-y-2">
        <div className="flex items-center justify-between text-xs text-gray-400">
          <div className="flex items-center gap-2">
            <Terminal className="w-3.5 h-3.5 text-cyan-400" />
            <span>Flux d'Introspection en Direct (@omni_quantum_cartographer)</span>
          </div>
          <span className="text-[10px] text-emerald-400 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
            Canal Synaptique Ouvert
          </span>
        </div>

        <div className="bg-[#050608] rounded-lg p-3 text-[11px] font-mono text-gray-300 space-y-1 max-h-36 overflow-y-auto border border-[#151622]">
          {snapshot.recentTelemetryLogs.map((log, index) => (
            <div key={index} className="leading-relaxed">
              {log}
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
