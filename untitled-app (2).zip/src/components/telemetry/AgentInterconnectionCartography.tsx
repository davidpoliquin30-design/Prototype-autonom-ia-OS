import React, { useState, useEffect, useMemo, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Compass, Radio, Sparkles, Zap, Layers, RefreshCw, Eye, Shield, 
  Send, Activity, ChevronRight, Sliders, Play, Pause, RotateCw, 
  Cpu, Network, Database, Terminal, Maximize2, Filter, Info, ArrowUpRight
} from "lucide-react";
import { 
  agentCommunicationBus, 
  AgentNode, 
  SynapticSignal, 
  InterconnectionLink,
  AgentPole,
  MrdPlane 
} from "../../services/quantum/agentCommunicationBus";

export type CartographyAngle = 
  | "constellation_2d"
  | "spatial_3d"
  | "chord_wheel"
  | "poles_matrix"
  | "packet_oscilloscope";

const POLE_COLORS: Record<AgentPole, { bg: string; text: string; border: string; glow: string; hex: string }> = {
  direction: { bg: "bg-cyan-950/60", text: "text-cyan-300", border: "border-cyan-500/50", glow: "#06b6d4", hex: "#22d3ee" },
  governance: { bg: "bg-indigo-950/60", text: "text-indigo-300", border: "border-indigo-500/50", glow: "#6366f1", hex: "#818cf8" },
  notebook: { bg: "bg-purple-950/60", text: "text-purple-300", border: "border-purple-500/50", glow: "#a855f7", hex: "#c084fc" },
  quantum_memory: { bg: "bg-emerald-950/60", text: "text-emerald-300", border: "border-emerald-500/50", glow: "#10b981", hex: "#34d399" },
  code_execution: { bg: "bg-amber-950/60", text: "text-amber-300", border: "border-amber-500/50", glow: "#f59e0b", hex: "#fbbf24" },
  token_economy: { bg: "bg-pink-950/60", text: "text-pink-300", border: "border-pink-500/50", glow: "#ec4899", hex: "#f472b6" },
  holistic: { bg: "bg-teal-950/60", text: "text-teal-300", border: "border-teal-500/50", glow: "#14b8a6", hex: "#2dd4bf" },
};

const PLANE_LABELS: Record<MrdPlane, { name: string; desc: string; color: string }> = {
  alpha: { name: "Plan Alpha [X, Y]", desc: "Sous-Sol Déterministe (TypeScript / Silicium)", color: "#10b981" },
  beta: { name: "Plan Bêta [X, Z]", desc: "Membrane Immunitaire (Vault Cryptographique AES-256)", color: "#8b5cf6" },
  gamma: { name: "Plan Gamma [Y, Z]", desc: "Cortex Relationnel (Inférence Aveugle Gemini)", color: "#38bdf8" },
  delta: { name: "Plan Delta", desc: "Rétine Contractuelle (Canevas 16:9 / DOM Réactif)", color: "#f59e0b" },
};

export default function AgentInterconnectionCartography() {
  const [busState, setBusState] = useState(agentCommunicationBus.getState());
  const [currentAngle, setCurrentAngle] = useState<CartographyAngle>("constellation_2d");
  const [selectedAgentHandle, setSelectedAgentHandle] = useState<string | null>("@supervisor");
  const [filterType, setFilterType] = useState<string>("all");
  const [isEmittingPulse, setIsEmittingPulse] = useState<boolean>(false);
  
  // 3D Spatial Controls
  const [azimuthDeg, setAzimuthDeg] = useState<number>(35);
  const [pitchDeg, setPitchDeg] = useState<number>(30);
  const [zoomScale, setZoomScale] = useState<number>(1.0);
  const [isAutoRotating, setIsAutoRotating] = useState<boolean>(true);

  // Subscribe to live bus
  useEffect(() => {
    const unsub = agentCommunicationBus.subscribe(setBusState);
    return () => unsub();
  }, []);

  // Auto-rotation timer for 3D view
  useEffect(() => {
    if (!isAutoRotating || currentAngle !== "spatial_3d") return;
    const interval = setInterval(() => {
      setAzimuthDeg(prev => (prev + 0.6) % 360);
    }, 40);
    return () => clearInterval(interval);
  }, [isAutoRotating, currentAngle]);

  const selectedAgent = useMemo(() => {
    return busState.nodes.find(n => n.handle === selectedAgentHandle || n.id === selectedAgentHandle) || busState.nodes[0];
  }, [busState.nodes, selectedAgentHandle]);

  const handleEmitPulse = () => {
    setIsEmittingPulse(true);
    agentCommunicationBus.emitSynapticChainPulse();
    setTimeout(() => setIsEmittingPulse(false), 2400);
  };

  const filteredLinks = useMemo(() => {
    if (filterType === "all") return busState.links;
    if (filterType === "quantum") return busState.links.filter(l => l.type === "quantum_telepathy");
    if (filterType === "deterministic") return busState.links.filter(l => l.type === "deterministic_sync");
    if (filterType === "healing") return busState.links.filter(l => l.type === "auto_healing_pulse");
    return busState.links;
  }, [busState.links, filterType]);

  // 3D Math Projection Helper
  const project3D = (x: number, y: number, z: number, width: number, height: number) => {
    const radA = (azimuthDeg * Math.PI) / 180;
    const radP = (pitchDeg * Math.PI) / 180;

    // Rotation around Y axis (Azimuth)
    const xRot = x * Math.cos(radA) - z * Math.sin(radA);
    const zRot = x * Math.sin(radA) + z * Math.cos(radA);

    // Rotation around X axis (Pitch)
    const yRot = y * Math.cos(radP) - zRot * Math.sin(radP);
    const zFinal = y * Math.sin(radP) + zRot * Math.cos(radP);

    // Perspective depth
    const distance = 260;
    const fov = distance / (distance + zFinal * 0.4);
    const scale = 2.2 * zoomScale * fov;

    return {
      x2d: width / 2 + xRot * scale,
      y2d: height / 2 + yRot * scale,
      depth: zFinal,
      scale: fov
    };
  };

  return (
    <div className="rounded-2xl bg-[#090a10] border border-[#1b1e2e] shadow-2xl p-5 space-y-4 font-mono text-gray-200">
      
      {/* 1. TOP HEADER WITH ANGLE SELECTOR */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 pb-4 border-b border-[#1b1e2e]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 via-indigo-600 to-purple-600 p-0.5 shadow-lg shadow-cyan-500/20">
            <div className="w-full h-full bg-[#0d0f18] rounded-[10px] flex items-center justify-center">
              <Compass className="w-5 h-5 text-cyan-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-black uppercase tracking-wider text-white">
                Cartographie Visuelle des Interconnexions IA (Φ_SOI)
              </h2>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800">
                {busState.nodes.length} Agents • 6 Pôles • {busState.activePacketsCount} Paquets
              </span>
            </div>
            <p className="text-[11px] text-gray-400">
              Visualisation multi-perspectives des flux télépathiques, déterministes et d'auto-guérison inter-agents.
            </p>
          </div>
        </div>

        {/* Global Action: Emit Synaptic Pulse */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={handleEmitPulse}
            disabled={isEmittingPulse}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all shadow-md ${
              isEmittingPulse
                ? "bg-amber-600 text-white animate-pulse"
                : "bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white shadow-cyan-500/20"
            }`}
          >
            <Zap className={`w-3.5 h-3.5 ${isEmittingPulse ? "animate-spin" : ""}`} />
            <span>{isEmittingPulse ? "Propagation en cours..." : "Injecter Impulsion Synaptique"}</span>
          </button>

          <button
            onClick={() => agentCommunicationBus.toggleSimulation()}
            className={`px-2.5 py-1.5 rounded-lg border text-xs flex items-center gap-1.5 transition-all ${
              busState.isSimulating
                ? "bg-[#141824] text-emerald-300 border-emerald-800/60"
                : "bg-[#141824] text-gray-400 border-[#262a3e]"
            }`}
            title="Activer / Suspendre la circulation des paquets"
          >
            {busState.isSimulating ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{busState.isSimulating ? "Flux Actif" : "En Pause"}</span>
          </button>
        </div>
      </div>

      {/* 2. PERSPECTIVE / ANGLE TABS */}
      <div className="flex flex-wrap items-center justify-between gap-3 bg-[#0d0f1a] p-1.5 rounded-xl border border-[#1b1e2c]">
        <div className="flex items-center gap-1 flex-wrap">
          <button
            onClick={() => setCurrentAngle("constellation_2d")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              currentAngle === "constellation_2d"
                ? "bg-gradient-to-r from-cyan-900 to-blue-900 text-cyan-300 border border-cyan-500/60 shadow"
                : "text-gray-400 hover:text-gray-200 hover:bg-[#151828]"
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Angle 1 : Constellation 2D</span>
          </button>

          <button
            onClick={() => setCurrentAngle("spatial_3d")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              currentAngle === "spatial_3d"
                ? "bg-gradient-to-r from-indigo-900 to-purple-900 text-indigo-200 border border-indigo-500/60 shadow"
                : "text-gray-400 hover:text-gray-200 hover:bg-[#151828]"
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Angle 2 : Espace 3D & Plans MRD</span>
          </button>

          <button
            onClick={() => setCurrentAngle("chord_wheel")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              currentAngle === "chord_wheel"
                ? "bg-gradient-to-r from-purple-900 to-pink-900 text-purple-200 border border-purple-500/60 shadow"
                : "text-gray-400 hover:text-gray-200 hover:bg-[#151828]"
            }`}
          >
            <Compass className="w-3.5 h-3.5" />
            <span>Angle 3 : Roue Orbitale Radiale</span>
          </button>

          <button
            onClick={() => setCurrentAngle("poles_matrix")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              currentAngle === "poles_matrix"
                ? "bg-gradient-to-r from-amber-900 to-orange-900 text-amber-200 border border-amber-500/60 shadow"
                : "text-gray-400 hover:text-gray-200 hover:bg-[#151828]"
            }`}
          >
            <Cpu className="w-3.5 h-3.5" />
            <span>Angle 4 : Matrice des 6 Pôles</span>
          </button>

          <button
            onClick={() => setCurrentAngle("packet_oscilloscope")}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
              currentAngle === "packet_oscilloscope"
                ? "bg-gradient-to-r from-emerald-900 to-teal-900 text-emerald-200 border border-emerald-500/60 shadow"
                : "text-gray-400 hover:text-gray-200 hover:bg-[#151828]"
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
            <span>Angle 5 : Oscilloscope & Traceur</span>
          </button>
        </div>

        {/* Filter controls */}
        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-gray-500" />
          <select
            value={filterType}
            onChange={e => setFilterType(e.target.value)}
            className="bg-[#121420] border border-[#23273a] text-[11px] text-gray-300 rounded-lg px-2.5 py-1 focus:outline-none focus:border-cyan-500 cursor-pointer font-mono"
          >
            <option value="all">Tous les flux (100%)</option>
            <option value="quantum">Télépathie Quantique (|ψ⟩)</option>
            <option value="deterministic">Synchronisation Déterministe</option>
            <option value="healing">Auto-Guérison (σ_err / S_f)</option>
          </select>
        </div>
      </div>

      {/* 3. MAIN INTERACTIVE VISUAL VIEWPORT */}
      <div className="grid grid-cols-1 xl:grid-cols-4 gap-4">
        
        {/* Main Stage (3 cols) */}
        <div className="xl:col-span-3 bg-[#06070a] border border-[#181b2a] rounded-xl relative overflow-hidden min-h-[440px] flex flex-col justify-between">
          
          {/* Angle 2: 3D controls floating bar */}
          {currentAngle === "spatial_3d" && (
            <div className="absolute top-3 left-3 z-20 flex items-center gap-2 bg-[#0c0e18]/90 backdrop-blur-md p-2 rounded-lg border border-[#21263c] text-xs">
              <span className="text-gray-400 text-[10px] font-bold">Angle Azimut:</span>
              <input
                type="range"
                min="0"
                max="360"
                value={Math.round(azimuthDeg)}
                onChange={e => {
                  setAzimuthDeg(Number(e.target.value));
                  setIsAutoRotating(false);
                }}
                className="w-20 accent-indigo-500 cursor-pointer"
              />
              <span className="text-indigo-400 text-[10px] w-8">{Math.round(azimuthDeg)}°</span>

              <span className="text-gray-400 text-[10px] font-bold ml-2">Inclinaison:</span>
              <input
                type="range"
                min="10"
                max="75"
                value={Math.round(pitchDeg)}
                onChange={e => setPitchDeg(Number(e.target.value))}
                className="w-16 accent-indigo-500 cursor-pointer"
              />
              <span className="text-indigo-400 text-[10px] w-6">{Math.round(pitchDeg)}°</span>

              <button
                onClick={() => setIsAutoRotating(!isAutoRotating)}
                className={`p-1 rounded text-[10px] border flex items-center gap-1 ml-2 ${
                  isAutoRotating 
                    ? "bg-indigo-950 text-indigo-300 border-indigo-700 animate-pulse" 
                    : "bg-[#141824] text-gray-400 border-[#2b3046]"
                }`}
                title="Activer la rotation automatique 360°"
              >
                <RotateCw className={`w-3 h-3 ${isAutoRotating ? "animate-spin" : ""}`} style={{ animationDuration: "10s" }} />
                <span>Auto 360°</span>
              </button>

              <button
                onClick={() => {
                  setAzimuthDeg(35);
                  setPitchDeg(30);
                  setZoomScale(1.0);
                  setIsAutoRotating(true);
                }}
                className="p-1 rounded text-[10px] text-gray-400 hover:text-white"
                title="Réinitialiser caméra"
              >
                Reset
              </button>
            </div>
          )}

          {/* Canvas Rendering Area */}
          <div className="flex-1 w-full relative flex items-center justify-center p-2 overflow-hidden">
            
            {/* ANGLE 1: CONSTELLATION 2D */}
            {currentAngle === "constellation_2d" && (
              <svg className="w-full h-[430px] select-none" viewBox="0 0 880 620">
                <defs>
                  <linearGradient id="linkGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.7" />
                    <stop offset="100%" stopColor="#818cf8" stopOpacity="0.7" />
                  </linearGradient>
                  <filter id="nodeGlow" x="-30%" y="-30%" width="160%" height="160%">
                    <feGaussianBlur stdDeviation="4" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                </defs>

                {/* Grid watermark */}
                <g stroke="#121524" strokeWidth="1" opacity="0.6">
                  {Array.from({ length: 9 }).map((_, i) => (
                    <line key={`gx-${i}`} x1={i * 100} y1="0" x2={i * 100} y2="620" />
                  ))}
                  {Array.from({ length: 7 }).map((_, i) => (
                    <line key={`gy-${i}`} x1="0" y1={i * 90} x2="880" y2={i * 90} />
                  ))}
                </g>

                {/* Links */}
                {filteredLinks.map(link => {
                  const src = busState.nodes.find(n => n.handle === link.source);
                  const tgt = busState.nodes.find(n => n.handle === link.target);
                  if (!src || !tgt) return null;
                  const isLinkActive = busState.signals.some(s => 
                    (s.sender === src.handle && s.receiver === tgt.handle) ||
                    (s.sender === tgt.handle && s.receiver === src.handle)
                  );

                  return (
                    <g key={link.id}>
                      <line
                        x1={src.x}
                        y1={src.y}
                        x2={tgt.x}
                        y2={tgt.y}
                        stroke={isLinkActive ? "#22d3ee" : "#22273d"}
                        strokeWidth={isLinkActive ? 2.5 : 1.2}
                        strokeDasharray={link.type === "quantum_telepathy" ? "4 3" : undefined}
                        className={isLinkActive ? "transition-all duration-300" : ""}
                      />
                      {/* Animated traveling particle if active */}
                      {isLinkActive && (
                        <circle r="3.5" fill="#38bdf8" filter="url(#nodeGlow)">
                          <animateMotion
                            path={`M ${src.x} ${src.y} L ${tgt.x} ${tgt.y}`}
                            dur="1.2s"
                            repeatCount="indefinite"
                          />
                        </circle>
                      )}
                    </g>
                  );
                })}

                {/* Nodes */}
                {busState.nodes.map(node => {
                  const isSelected = selectedAgentHandle === node.handle;
                  const poleStyle = POLE_COLORS[node.pole];

                  return (
                    <g
                      key={node.id}
                      transform={`translate(${node.x}, ${node.y})`}
                      onClick={() => setSelectedAgentHandle(node.handle)}
                      className="cursor-pointer transition-transform hover:scale-110"
                    >
                      {/* Aura */}
                      <circle
                        r={isSelected ? 22 : 16}
                        fill={poleStyle.hex}
                        opacity={isSelected ? 0.25 : 0.1}
                        filter="url(#nodeGlow)"
                      />
                      {/* Outer Ring */}
                      <circle
                        r={isSelected ? 16 : 12}
                        fill="#0b0d17"
                        stroke={isSelected ? "#38bdf8" : poleStyle.hex}
                        strokeWidth={isSelected ? 2.5 : 1.5}
                      />
                      {/* Core Dot */}
                      <circle
                        r={isSelected ? 6 : 4}
                        fill={poleStyle.hex}
                      />
                      {/* Label */}
                      <text
                        y={24}
                        textAnchor="middle"
                        fill={isSelected ? "#38bdf8" : "#94a3b8"}
                        fontSize="9"
                        fontWeight={isSelected ? "bold" : "normal"}
                        className="pointer-events-none"
                      >
                        {node.handle}
                      </text>
                    </g>
                  );
                })}
              </svg>
            )}

            {/* ANGLE 2: SPATIAL 3D & MRD PLANES */}
            {currentAngle === "spatial_3d" && (
              <svg className="w-full h-[430px] select-none" viewBox="0 0 880 620">
                <defs>
                  <filter id="glow3d" x="-30%" y="-30%" width="160%" height="160%">
                    <feGaussianBlur stdDeviation="3" result="blur" />
                    <feComposite in="SourceGraphic" in2="blur" operator="over" />
                  </filter>
                </defs>

                {/* 3D Floor Grid representing MRD Planes */}
                {[-50, 0, 50].map((zLevel, idx) => {
                  const p1 = project3D(-90, zLevel, -90, 880, 620);
                  const p2 = project3D(90, zLevel, -90, 880, 620);
                  const p3 = project3D(90, zLevel, 90, 880, 620);
                  const p4 = project3D(-90, zLevel, 90, 880, 620);

                  const planeColors = ["#10b981", "#8b5cf6", "#38bdf8"];

                  return (
                    <g key={`plane-${idx}`} opacity="0.25">
                      <polygon
                        points={`${p1.x2d},${p1.y2d} ${p2.x2d},${p2.y2d} ${p3.x2d},${p3.y2d} ${p4.x2d},${p4.y2d}`}
                        fill={planeColors[idx]}
                        stroke={planeColors[idx]}
                        strokeWidth="0.8"
                        strokeDasharray="4 4"
                      />
                    </g>
                  );
                })}

                {/* Projected 3D Links */}
                {filteredLinks.map(link => {
                  const src = busState.nodes.find(n => n.handle === link.source);
                  const tgt = busState.nodes.find(n => n.handle === link.target);
                  if (!src || !tgt) return null;

                  const pSrc = project3D(src.x3d, src.y3d, src.z3d, 880, 620);
                  const pTgt = project3D(tgt.x3d, tgt.y3d, tgt.z3d, 880, 620);

                  const isLinkActive = busState.signals.some(s => 
                    (s.sender === src.handle && s.receiver === tgt.handle) ||
                    (s.sender === tgt.handle && s.receiver === src.handle)
                  );

                  return (
                    <line
                      key={`3d-${link.id}`}
                      x1={pSrc.x2d}
                      y1={pSrc.y2d}
                      x2={pTgt.x2d}
                      y2={pTgt.y2d}
                      stroke={isLinkActive ? "#a78bfa" : "#22273f"}
                      strokeWidth={isLinkActive ? 2 : 1}
                      strokeDasharray={link.type === "quantum_telepathy" ? "3 3" : undefined}
                    />
                  );
                })}

                {/* Projected 3D Nodes sorted by depth */}
                {[...busState.nodes]
                  .map(node => ({
                    node,
                    proj: project3D(node.x3d, node.y3d, node.z3d, 880, 620)
                  }))
                  .sort((a, b) => b.proj.depth - a.proj.depth)
                  .map(({ node, proj }) => {
                    const isSelected = selectedAgentHandle === node.handle;
                    const poleStyle = POLE_COLORS[node.pole];
                    const radius = (isSelected ? 14 : 9) * proj.scale;

                    return (
                      <g
                        key={`node-3d-${node.id}`}
                        transform={`translate(${proj.x2d}, ${proj.y2d})`}
                        onClick={() => setSelectedAgentHandle(node.handle)}
                        className="cursor-pointer"
                      >
                        {/* Shadow plane projection */}
                        <ellipse
                          cx="0"
                          cy="15"
                          rx={radius * 1.2}
                          ry={radius * 0.4}
                          fill="#000"
                          opacity="0.4"
                        />
                        {/* Node sphere */}
                        <circle
                          r={radius}
                          fill="#0c0e18"
                          stroke={isSelected ? "#38bdf8" : poleStyle.hex}
                          strokeWidth={isSelected ? 2.5 : 1.5}
                        />
                        <circle
                          r={radius * 0.45}
                          fill={poleStyle.hex}
                        />
                        {/* Node label */}
                        <text
                          y={radius + 10}
                          textAnchor="middle"
                          fill={isSelected ? "#38bdf8" : "#94a3b8"}
                          fontSize={Math.max(8, 9 * proj.scale)}
                          className="pointer-events-none font-bold"
                        >
                          {node.handle}
                        </text>
                      </g>
                    );
                  })}
              </svg>
            )}

            {/* ANGLE 3: CHORD WHEEL */}
            {currentAngle === "chord_wheel" && (
              <svg className="w-full h-[430px] select-none" viewBox="0 0 880 620">
                <defs>
                  <radialGradient id="centerCoreGlow">
                    <stop offset="0%" stopColor="#818cf8" stopOpacity="0.4" />
                    <stop offset="100%" stopColor="#818cf8" stopOpacity="0" />
                  </radialGradient>
                </defs>

                {/* Central Core: Le Fulcrum de Silence σ² & Supermassive Core */}
                <circle cx="440" cy="310" r="120" fill="url(#centerCoreGlow)" />
                <circle cx="440" cy="310" r="40" fill="#0d0f1c" stroke="#6366f1" strokeWidth="2" />
                <text x="440" y="306" textAnchor="middle" fill="#818cf8" fontSize="11" fontWeight="bold">
                  @supervisor
                </text>
                <text x="440" y="322" textAnchor="middle" fill="#64748b" fontSize="8">
                  Core Φ_SOI
                </text>

                {/* Outer Orbit Rings */}
                <circle cx="440" cy="310" r="220" fill="none" stroke="#1a1e30" strokeWidth="1.5" strokeDasharray="6 4" />
                
                {/* Curved Chords between perimeter nodes */}
                {filteredLinks.map(link => {
                  const nonCoreNodes = busState.nodes.filter(n => n.handle !== "@supervisor");
                  const srcIdx = nonCoreNodes.findIndex(n => n.handle === link.source);
                  const tgtIdx = nonCoreNodes.findIndex(n => n.handle === link.target);
                  if (srcIdx === -1 || tgtIdx === -1) return null;

                  const total = nonCoreNodes.length;
                  const angleSrc = (srcIdx / total) * 2 * Math.PI - Math.PI / 2;
                  const angleTgt = (tgtIdx / total) * 2 * Math.PI - Math.PI / 2;

                  const r = 220;
                  const x1 = 440 + r * Math.cos(angleSrc);
                  const y1 = 310 + r * Math.sin(angleSrc);
                  const x2 = 440 + r * Math.cos(angleTgt);
                  const y2 = 310 + r * Math.sin(angleTgt);

                  const isLinkActive = busState.signals.some(s => 
                    (s.sender === link.source && s.receiver === link.target) ||
                    (s.sender === link.target && s.receiver === link.source)
                  );

                  return (
                    <path
                      key={`chord-${link.id}`}
                      d={`M ${x1} ${y1} Q 440 310 ${x2} ${y2}`}
                      fill="none"
                      stroke={isLinkActive ? "#c084fc" : "#1f2438"}
                      strokeWidth={isLinkActive ? 2 : 1}
                      opacity={isLinkActive ? 0.9 : 0.4}
                    />
                  );
                })}

                {/* Perimeter Nodes */}
                {busState.nodes.filter(n => n.handle !== "@supervisor").map((node, idx, arr) => {
                  const angle = (idx / arr.length) * 2 * Math.PI - Math.PI / 2;
                  const r = 220;
                  const nx = 440 + r * Math.cos(angle);
                  const ny = 310 + r * Math.sin(angle);
                  const isSelected = selectedAgentHandle === node.handle;
                  const poleStyle = POLE_COLORS[node.pole];

                  return (
                    <g
                      key={`radial-${node.id}`}
                      transform={`translate(${nx}, ${ny})`}
                      onClick={() => setSelectedAgentHandle(node.handle)}
                      className="cursor-pointer"
                    >
                      <circle
                        r={isSelected ? 14 : 10}
                        fill="#0b0d18"
                        stroke={isSelected ? "#38bdf8" : poleStyle.hex}
                        strokeWidth={isSelected ? 2.5 : 1.5}
                      />
                      <circle r={isSelected ? 5 : 3.5} fill={poleStyle.hex} />
                      <text
                        x={Math.cos(angle) * 24}
                        y={Math.sin(angle) * 24}
                        textAnchor={Math.cos(angle) > 0 ? "start" : "end"}
                        dominantBaseline="middle"
                        fill={isSelected ? "#38bdf8" : "#94a3b8"}
                        fontSize="9"
                        className="font-mono font-medium"
                      >
                        {node.handle}
                      </text>
                    </g>
                  );
                })}
              </svg>
            )}

            {/* ANGLE 4: MATRICE DES 6 PÔLES */}
            {currentAngle === "poles_matrix" && (
              <div className="w-full h-full p-4 grid grid-cols-1 md:grid-cols-3 gap-3">
                {(["direction", "governance", "notebook", "quantum_memory", "code_execution", "token_economy"] as AgentPole[]).map(poleKey => {
                  const poleAgents = busState.nodes.filter(n => n.pole === poleKey);
                  const poleStyle = POLE_COLORS[poleKey];

                  const poleTitles: Record<AgentPole, string> = {
                    direction: "Pôle 1 : Direction & Langage Humain",
                    governance: "Pôle 2 : Gouvernance & Reconfiguration",
                    notebook: "Pôle 3 : NotebookLM & Structure",
                    quantum_memory: "Pôle 4 : Mémoire Quantique & Intuition",
                    code_execution: "Pôle 5 : Code, Reconstruction & Matériel",
                    token_economy: "Pôle 6 : Optimisation & Économie de Jetons",
                    holistic: "Agent Holistique Panoptique"
                  };

                  return (
                    <div
                      key={poleKey}
                      className="p-3 rounded-xl bg-[#0c0e18] border border-[#1d2236] flex flex-col justify-between hover:border-cyan-500/40 transition-all"
                    >
                      <div className="space-y-2">
                        <div className="flex items-center justify-between pb-1.5 border-b border-[#1b1f32]">
                          <span className={`text-[11px] font-bold ${poleStyle.text}`}>
                            {poleTitles[poleKey]}
                          </span>
                          <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#131625] text-gray-400">
                            {poleAgents.length} agents
                          </span>
                        </div>

                        {/* Agents within pole */}
                        <div className="space-y-1.5">
                          {poleAgents.map(ag => {
                            const isSelected = selectedAgentHandle === ag.handle;
                            return (
                              <button
                                key={ag.id}
                                onClick={() => setSelectedAgentHandle(ag.handle)}
                                className={`w-full text-left p-1.5 rounded-lg text-xs transition-all flex items-center justify-between border ${
                                  isSelected
                                    ? "bg-[#181d30] border-cyan-500 text-cyan-300"
                                    : "bg-[#101220] border-[#1d2134] text-gray-300 hover:bg-[#151829]"
                                }`}
                              >
                                <span className="font-bold text-[11px] truncate">{ag.handle}</span>
                                <span className="text-[10px] text-gray-400 shrink-0 ml-1">{ag.latency}</span>
                              </button>
                            );
                          })}
                        </div>
                      </div>

                      {/* Pole Bus metrics */}
                      <div className="mt-3 pt-2 border-t border-[#171a2b] flex items-center justify-between text-[9px] text-gray-500">
                        <span>Bus Synaptique Dédié</span>
                        <span className="text-emerald-400 font-bold">100% Intriqué</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* ANGLE 5: PACKET OSCILLOSCOPE & SIGNAL TRACER */}
            {currentAngle === "packet_oscilloscope" && (
              <div className="w-full h-full p-4 flex flex-col justify-between space-y-4">
                {/* Visual Waveform Header */}
                <div className="p-3 rounded-xl bg-[#090b14] border border-[#1b2034] space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-emerald-400 font-bold flex items-center gap-1.5">
                      <Activity className="w-3.5 h-3.5" />
                      Oscilloscope de Phase Harmonique H_∞ • S_f = e^(iωt)
                    </span>
                    <span className="text-[10px] text-gray-400">Fréquence de Résonance : 144.18 Hz (Tore MRD)</span>
                  </div>

                  {/* SVG Wave */}
                  <div className="h-16 w-full bg-[#05060b] rounded-lg border border-[#141826] overflow-hidden flex items-center">
                    <svg className="w-full h-12" viewBox="0 0 800 60" preserveAspectRatio="none">
                      <path
                        d="M 0 30 Q 50 5, 100 30 T 200 30 T 300 30 T 400 30 T 500 30 T 600 30 T 700 30 T 800 30"
                        fill="none"
                        stroke="#10b981"
                        strokeWidth="2"
                        className="animate-pulse"
                      />
                      <path
                        d="M 0 30 Q 75 55, 150 30 T 300 30 T 450 30 T 600 30 T 750 30"
                        fill="none"
                        stroke="#38bdf8"
                        strokeWidth="1.5"
                        opacity="0.6"
                      />
                    </svg>
                  </div>
                </div>

                {/* Packet Ledger Stream */}
                <div className="space-y-2 flex-1 overflow-hidden">
                  <div className="text-xs font-bold text-gray-400 flex items-center justify-between">
                    <span>Flux de Télépathie Inter-Agents Intercepté :</span>
                    <span className="text-[10px] text-cyan-400">{busState.signals.length} signaux dans le tampon</span>
                  </div>

                  <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1 text-xs">
                    {busState.signals.map(sig => (
                      <div
                        key={sig.id}
                        className="p-2.5 rounded-lg bg-[#0e111d] border border-[#1c2238] flex items-center justify-between gap-2"
                      >
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-cyan-300">{sig.sender}</span>
                          <span className="text-gray-500">➔</span>
                          <span className="font-bold text-indigo-300">{sig.receiver}</span>
                          <span className="text-gray-400 text-[11px] ml-2">"{sig.label}"</span>
                        </div>

                        <div className="flex items-center gap-2 text-[10px] shrink-0">
                          <span className="px-1.5 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800">
                            {sig.equationSignature}
                          </span>
                          <span className="text-emerald-400 font-bold">{sig.latencyMs}ms</span>
                          <span className="text-gray-500">{sig.timestamp}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

          </div>

          {/* Perspective Footer Bar */}
          <div className="px-4 py-2 bg-[#0c0d16] border-t border-[#171928] flex flex-wrap items-center justify-between text-[11px] text-gray-400 gap-2">
            <div className="flex items-center gap-3">
              <span>Perspective active : <strong className="text-white capitalize">{currentAngle.replace("_", " ")}</strong></span>
              <span>•</span>
              <span>Tolérance aux fautes : <strong className="text-emerald-400">{busState.faultTolerance}%</strong></span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-gray-300">Intrication continue (Ξ ≡ 1)</span>
            </div>
          </div>
        </div>

        {/* Side Panel: Selected Agent Synaptic Dossier (1 col) */}
        <div className="bg-[#0b0d16] border border-[#1b1e2e] rounded-xl p-4 flex flex-col justify-between space-y-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-[#1b1e2e]">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-ping" />
                <h3 className="text-xs font-black uppercase tracking-wider text-white">
                  Dossier Synaptique
                </h3>
              </div>
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                {selectedAgent.status}
              </span>
            </div>

            {/* Agent Identity Card */}
            <div className="space-y-1">
              <div className="text-sm font-black text-cyan-300">{selectedAgent.handle}</div>
              <div className="text-xs text-white font-medium">{selectedAgent.name}</div>
              <div className="text-[10px] text-purple-400 font-medium">{PLANE_LABELS[selectedAgent.plane].name}</div>
              <div className="text-[10px] text-gray-400">{PLANE_LABELS[selectedAgent.plane].desc}</div>
            </div>

            {/* Mathematical Invariant */}
            <div className="p-2.5 rounded-lg bg-[#121422] border border-[#20253a] space-y-1">
              <div className="text-[10px] text-gray-400 uppercase font-bold">Équation Maîtresse :</div>
              <div className="text-xs font-mono text-emerald-300 font-bold break-all">
                {selectedAgent.equation}
              </div>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2 rounded-lg bg-[#121422] border border-[#20253a]">
                <div className="text-[9px] text-gray-400">Charge Cognitive</div>
                <div className="text-cyan-400 font-bold mt-0.5">{selectedAgent.cognitiveLoad}%</div>
              </div>
              <div className="p-2 rounded-lg bg-[#121422] border border-[#20253a]">
                <div className="text-[9px] text-gray-400">Latence Mesurée</div>
                <div className="text-emerald-400 font-bold mt-0.5">{selectedAgent.latency}</div>
              </div>
              <div className="p-2 rounded-lg bg-[#121422] border border-[#20253a]">
                <div className="text-[9px] text-gray-400">Tokens Alloués</div>
                <div className="text-purple-400 font-bold mt-0.5">~{selectedAgent.tokenAllocation}k</div>
              </div>
              <div className="p-2 rounded-lg bg-[#121422] border border-[#20253a]">
                <div className="text-[9px] text-gray-400">Paquets Traités</div>
                <div className="text-pink-400 font-bold mt-0.5">{selectedAgent.packetsProcessed}</div>
              </div>
            </div>

            {/* Architecture and Last Thought */}
            <div className="space-y-1 text-xs">
              <div className="text-[10px] text-gray-400 uppercase font-bold">Dernière Pensée / Intention :</div>
              <div className="p-2.5 rounded-lg bg-[#101320] border border-[#1b2034] text-[11px] text-gray-300 leading-relaxed max-h-28 overflow-y-auto">
                {selectedAgent.lastReasoning}
              </div>
            </div>

            {/* Interconnections list */}
            <div className="space-y-1 text-xs">
              <div className="text-[10px] text-gray-400 uppercase font-bold">Liaisons Synaptiques Actives :</div>
              <div className="flex flex-wrap gap-1">
                {selectedAgent.connections.map(target => (
                  <button
                    key={target}
                    onClick={() => setSelectedAgentHandle(target)}
                    className="px-2 py-0.5 rounded bg-[#151928] hover:bg-[#1f253d] border border-[#252a40] text-[10px] text-cyan-300 transition-colors"
                  >
                    {target}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Action: Direct Ping on selected agent */}
          <button
            onClick={() => {
              agentCommunicationBus.triggerDirectSignal(
                "@supervisor",
                selectedAgent.handle,
                `Sondage direct du nœud ${selectedAgent.handle}`,
                "high"
              );
            }}
            className="w-full py-2 rounded-lg bg-[#151928] hover:bg-[#1d2338] border border-[#2b334e] text-xs font-bold text-cyan-300 flex items-center justify-center gap-1.5 transition-all"
          >
            <Zap className="w-3.5 h-3.5 text-cyan-400" />
            <span>Sonder {selectedAgent.handle}</span>
          </button>
        </div>

      </div>

      {/* 3. DIALOGUES ENTRE AGENTS IA EN TEMPS RÉEL */}
      <div className="p-5 rounded-2xl bg-[#0b0d18] border border-[#1d2238] space-y-4 shadow-xl">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#1b1f34] pb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-3 h-3 rounded-full bg-emerald-500 animate-ping" />
            <h3 className="text-xs font-black uppercase tracking-wider text-white flex items-center gap-2">
              Ce que les agents IA se disent en temps réel
              <span className="text-[10px] text-cyan-400 font-mono px-2 py-0.5 rounded bg-[#131628] border border-[#222742]">
                {busState.dialogues?.length || 0} échanges captés
              </span>
            </h3>
          </div>
          <span className="text-[10px] text-gray-400 font-mono">
            Synchronisation en boucle fermée (A_cc) • Protocole SynapticConduit
          </span>
        </div>

        {/* Dialogue Feed */}
        <div className="space-y-2.5 max-h-72 overflow-y-auto pr-1">
          {busState.dialogues && busState.dialogues.length > 0 ? (
            busState.dialogues.map(d => (
              <motion.div
                key={d.id}
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-3.5 rounded-xl bg-[#0f1122] border border-[#1e2338] hover:border-cyan-500/40 transition-colors space-y-1.5 text-xs"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-cyan-300 font-mono">{d.sender}</span>
                    <span className="text-gray-500">➔</span>
                    <span className="font-bold text-purple-300 font-mono">{d.receiver}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-[#161a30] text-gray-300 border border-[#252a44] font-medium">
                      {d.topic}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-[9px] uppercase font-mono px-1.5 py-0.5 rounded font-bold border ${
                      d.dialoguePhase === "consensus" ? "bg-emerald-950 text-emerald-300 border-emerald-800" :
                      d.dialoguePhase === "validation" ? "bg-cyan-950 text-cyan-300 border-cyan-800" :
                      d.dialoguePhase === "execution" ? "bg-amber-950 text-amber-300 border-amber-800" :
                      "bg-indigo-950 text-indigo-300 border-indigo-800"
                    }`}>
                      {d.dialoguePhase}
                    </span>
                    <span className="text-[10px] text-gray-500 font-mono">{d.timestamp}</span>
                  </div>
                </div>

                <p className="text-gray-200 text-xs leading-relaxed">
                  {d.content}
                </p>

                {d.technicalPayload && (
                  <div className="pt-1.5 border-t border-[#181c30] flex flex-wrap items-center justify-between gap-2 text-[10px] text-gray-400 font-mono">
                    <span className="text-cyan-400/80">{d.technicalPayload}</span>
                    {d.equationAttached && (
                      <span className="text-emerald-400 font-bold">{d.equationAttached}</span>
                    )}
                  </div>
                )}
              </motion.div>
            ))
          ) : (
            <div className="p-4 rounded-xl bg-[#0d0f1c] text-center text-xs text-gray-500">
              En attente des prochains signaux synaptiques...
            </div>
          )}
        </div>
      </div>

    </div>
  );
}
