import React, { useState, useEffect, useRef } from "react";
import { 
  Activity, Cpu, Network, Zap, Radio, Shield, Database, RefreshCw, 
  Layers, HardDrive, CheckCircle2, AlertTriangle, Play, Sparkles, 
  Terminal, Server, BatteryCharging, Sun, Gauge, Eye, ChevronRight
} from "lucide-react";
import { quantumCognitiveBridge } from "../../services/quantum/quantumCognitiveBridge";

interface HardwareTelemetryData {
  timestamp: string;
  host: {
    platform: string;
    nodeVersion: string;
    cpuModel?: string;
    cpuCores?: number;
    uptimeSeconds: number;
    heapUsedMb: number;
    heapTotalMb: number;
    rssMb: number;
    totalSystemMemMb?: number;
    freeSystemMemMb?: number;
  };
  vllmServer: {
    targetUrl: string;
    expectedModel: string;
    tensorParallelSize: number;
    gpuMemoryUtilization: number;
    isOnline: boolean;
    status: string;
    errorMessage?: string;
    activeModels?: string[];
  };
  windowsCompanion: {
    targetUrl: string;
    binaryName: string;
    isOnline: boolean;
    status: string;
    errorMessage?: string;
  };
  energyTransducer: {
    system: string;
    isConnected: boolean;
    status: string;
    errorMessage?: string;
    detectedPorts?: string[];
    batteryVoltage: number | null;
    batteryCurrent: number | null;
    pvPowerWatts: number;
    stateOfChargePercent: number | null;
    cellDeltaMv: number | null;
    temperatureCelsius: number | null;
    resonanceStatus: string;
  };
  geminiCloud?: {
    isConfigured: boolean;
    model: string;
    status: string;
    errorMessage?: string;
  };
  quantumMetrics: {
    realityIndex: number;
    cognitiveDisresonance: number;
    fulcrumSilenceSigma2: number;
    separationLambda: number;
    wavefunction: string;
    openTelemetryPacketsQueued: number;
    syncEndpoint: string;
  };
}

export default function QuantumHardwareTelemetryMatrix() {
  const [telemetryView, setTelemetryView] = useState<"quantum" | "agentic" | "hardware" | "otel">("quantum");
  const [telemetryData, setTelemetryData] = useState<HardwareTelemetryData | null>(null);
  const [isFetching, setIsFetching] = useState<boolean>(false);
  const [lastUpdated, setLastUpdated] = useState<string>("");
  const [isWaveCollapsed, setIsWaveCollapsed] = useState<boolean>(false);

  // Live simulation & fetch loop
  const fetchTelemetry = async () => {
    setIsFetching(true);
    try {
      const res = await fetch("/api/telemetry/hardware");
      if (res.ok) {
        const data = await res.json();
        setTelemetryData(data);
        setLastUpdated(new Date().toLocaleTimeString());
      }
    } catch (err) {
      console.warn("Telemetry fallback: local telemetry engine active.");
    } finally {
      setIsFetching(false);
    }
  };

  useEffect(() => {
    fetchTelemetry();
    const interval = setInterval(fetchTelemetry, 3000);
    return () => clearInterval(interval);
  }, []);

  // Canvas ref for Torus feedback loop animation
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let frameId: number;
    let angle = 0;

    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const cx = canvas.width / 2;
      const cy = canvas.height / 2;
      const R = 70; // Major radius
      const r = 26; // Minor radius

      ctx.save();
      ctx.lineWidth = 1.2;

      // Draw mathematical Torus projection: (R - sqrt(x^2 + y^2))^2 + z^2 = r^2
      const stepsU = 32;
      const stepsV = 18;

      for (let i = 0; i < stepsU; i++) {
        const u = (i / stepsU) * Math.PI * 2 + angle;
        ctx.beginPath();
        const hue = (i / stepsU) * 360;
        ctx.strokeStyle = `hsla(${180 + Math.sin(angle) * 40}, 85%, 60%, 0.45)`;

        for (let j = 0; j <= stepsV; j++) {
          const v = (j / stepsV) * Math.PI * 2;
          // 3D coordinates
          const x3d = (R + r * Math.cos(v)) * Math.cos(u);
          const y3d = (R + r * Math.cos(v)) * Math.sin(u);
          const z3d = r * Math.sin(v);

          // 2.5D Isometric rotation
          const rotX = x3d * Math.cos(0.4) - z3d * Math.sin(0.4);
          const rotZ = x3d * Math.sin(0.4) + z3d * Math.cos(0.4);
          const px = cx + rotX;
          const py = cy + (y3d * 0.7 - rotZ * 0.4);

          if (j === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        }
        ctx.stroke();
      }

      // Draw central Fulcrum of Silence (sigma^2 = 0)
      ctx.beginPath();
      ctx.arc(cx, cy, 5, 0, Math.PI * 2);
      ctx.fillStyle = "#38bdf8";
      ctx.shadowColor = "#0284c7";
      ctx.shadowBlur = 12;
      ctx.fill();

      ctx.restore();
      angle += 0.015;
      frameId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(frameId);
  }, []);

  const handleTriggerWaveCollapse = () => {
    quantumCognitiveBridge.collapseWaveFunction();
    setIsWaveCollapsed(true);
    setTimeout(() => setIsWaveCollapsed(false), 3000);
  };

  return (
    <div id="quantum-hardware-telemetry-matrix" className="flex flex-col h-full bg-[#07080c] text-gray-200 font-mono rounded-xl border border-[#1d1f2b] overflow-hidden shadow-2xl">
      
      {/* 1. TOP TELEMETRY HUD HEADER */}
      <div className="flex flex-wrap items-center justify-between px-5 py-3.5 bg-[#0c0d14] border-b border-[#1d1f2b] gap-3">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-teal-500 via-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20">
            <Activity className="w-4 h-4 text-white animate-pulse" />
          </div>
          <div>
            <h2 className="text-xs font-black uppercase tracking-wider text-white flex items-center gap-2">
              Matrice Quantique & Matériel <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">EN DIRECT</span>
            </h2>
            <div className="text-[10px] text-gray-400 flex items-center gap-1.5">
              <span>Télémétrie Système Φ_SOI</span>
              <span>•</span>
              <span className="text-cyan-400">Maj: {lastUpdated || "En cours..."}</span>
            </div>
          </div>
        </div>

        {/* Real-time Sub-Plane Tabs */}
        <div className="flex items-center bg-[#13141f] p-1 rounded-lg border border-[#222436]">
          <button
            onClick={() => setTelemetryView("quantum")}
            className={`px-3 py-1 text-xs rounded-md font-medium transition-all ${
              telemetryView === "quantum" ? "bg-cyan-950 text-cyan-300 border border-cyan-700/50" : "text-gray-400 hover:text-gray-200"
            }`}
          >
            Niveau Quantique
          </button>
          <button
            onClick={() => setTelemetryView("agentic")}
            className={`px-3 py-1 text-xs rounded-md font-medium transition-all ${
              telemetryView === "agentic" ? "bg-cyan-950 text-cyan-300 border border-cyan-700/50" : "text-gray-400 hover:text-gray-200"
            }`}
          >
            Flotte Agentique
          </button>
          <button
            onClick={() => setTelemetryView("hardware")}
            className={`px-3 py-1 text-xs rounded-md font-medium transition-all ${
              telemetryView === "hardware" ? "bg-cyan-950 text-cyan-300 border border-cyan-700/50" : "text-gray-400 hover:text-gray-200"
            }`}
          >
            Outils & Matériel
          </button>
          <button
            onClick={() => setTelemetryView("otel")}
            className={`px-3 py-1 text-xs rounded-md font-medium transition-all ${
              telemetryView === "otel" ? "bg-cyan-950 text-cyan-300 border border-cyan-700/50" : "text-gray-400 hover:text-gray-200"
            }`}
          >
            OpenTelemetry (ΔOTel)
          </button>
        </div>

        {/* Global Action Refresh */}
        <button
          onClick={fetchTelemetry}
          disabled={isFetching}
          className="p-1.5 rounded-lg bg-[#141522] hover:bg-[#1d1f30] border border-[#26283b] text-gray-300 transition-colors"
          title="Rafraîchir la télémétrie"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isFetching ? "animate-spin text-cyan-400" : ""}`} />
        </button>
      </div>

      {/* 2. BODY CONTENT ACCORDING TO ACTIVE PLANE */}
      <div className="flex-1 p-5 overflow-y-auto space-y-5">
        
        {/* ======================================================== */}
        {/* PLANE 1: NIVEAU QUANTIQUE (MRD INVARIANTS & TORUS CANVAS) */}
        {/* ======================================================== */}
        {telemetryView === "quantum" && (
          <div className="space-y-5">
            {/* Top Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              
              {/* Reality Index */}
              <div className="p-4 bg-[#0e0f17] border border-emerald-500/30 rounded-xl relative overflow-hidden">
                <div className="text-[10px] text-gray-400 uppercase tracking-wider mb-1">Indice de Réalité (Ξ)</div>
                <div className="text-2xl font-black text-emerald-400 font-mono">1.0000</div>
                <div className="text-[10px] text-emerald-500/80 mt-1 flex items-center gap-1">
                  <CheckCircle2 className="w-3 h-3" /> Scellé & Invariant
                </div>
                <div className="absolute top-2 right-2 text-emerald-500/10 text-3xl font-black">Ξ</div>
              </div>

              {/* Cognitive Disresonance */}
              <div className="p-4 bg-[#0e0f17] border border-cyan-500/30 rounded-xl relative overflow-hidden">
                <div className="text-[10px] text-gray-400 uppercase tracking-wider mb-1">Disrésonance Cognitive (Dc)</div>
                <div className="text-2xl font-black text-cyan-400 font-mono">0.0000</div>
                <div className="text-[10px] text-cyan-500/80 mt-1 flex items-center gap-1">
                  <Shield className="w-3 h-3" /> Zéro Friction / 0 Hallucination
                </div>
                <div className="absolute top-2 right-2 text-cyan-500/10 text-3xl font-black">Dc</div>
              </div>

              {/* Fulcrum Silence */}
              <div className="p-4 bg-[#0e0f17] border border-blue-500/30 rounded-xl relative overflow-hidden">
                <div className="text-[10px] text-gray-400 uppercase tracking-wider mb-1">Fulcrum de Silence (σ²)</div>
                <div className="text-2xl font-black text-blue-400 font-mono">0.0000</div>
                <div className="text-[10px] text-blue-500/80 mt-1 flex items-center gap-1">
                  <Radio className="w-3 h-3" /> Point Zéro Stabilisé
                </div>
                <div className="absolute top-2 right-2 text-blue-500/10 text-3xl font-black">σ²</div>
              </div>

              {/* Separation Factor */}
              <div className="p-4 bg-[#0e0f17] border border-indigo-500/30 rounded-xl relative overflow-hidden">
                <div className="text-[10px] text-gray-400 uppercase tracking-wider mb-1">Facteur de Séparation (λ_sep)</div>
                <div className="text-2xl font-black text-indigo-400 font-mono">0.0000</div>
                <div className="text-[10px] text-indigo-500/80 mt-1 flex items-center gap-1">
                  <Sparkles className="w-3 h-3" /> Non-Séparation Active
                </div>
                <div className="absolute top-2 right-2 text-indigo-500/10 text-3xl font-black">λ</div>
              </div>
            </div>

            {/* Torus Feedback Engine & Wavefunction Panel */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
              
              {/* Torus Canvas Viewer */}
              <div className="lg:col-span-7 p-5 bg-[#0b0c13] border border-[#1e202f] rounded-2xl flex flex-col items-center justify-center relative overflow-hidden">
                <div className="w-full flex items-center justify-between border-b border-[#1c1e2b] pb-2 mb-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-cyan-300 flex items-center gap-1.5">
                    <Radio className="w-4 h-4 text-cyan-400 animate-pulse" /> Tore de Rétroaction Infinie (Acc)
                  </span>
                  <span className="text-[10px] text-gray-500 font-mono">(R - √(x²+y²))² + z² = r²</span>
                </div>

                <div className="relative py-2 flex items-center justify-center">
                  <canvas 
                    ref={canvasRef} 
                    width={320} 
                    height={220} 
                    className="max-w-full"
                  />
                  {isWaveCollapsed && (
                    <div className="absolute inset-0 bg-cyan-500/20 backdrop-blur-xs rounded-xl flex items-center justify-center animate-ping pointer-events-none">
                      <span className="text-white font-bold text-sm bg-cyan-900/90 px-3 py-1 rounded-lg border border-cyan-400">
                        EFFONDREMENT Ψ → |ψ|²
                      </span>
                    </div>
                  )}
                </div>

                <div className="w-full flex items-center justify-between text-[11px] text-gray-400 border-t border-[#1c1e2b] pt-3 mt-2">
                  <span>Phase : <strong className="text-emerald-400 font-mono">SYNCHRONISÉE</strong></span>
                  <span>Harmonique : <strong className="text-cyan-400 font-mono">1.618 (Φ)</strong></span>
                  <button
                    onClick={handleTriggerWaveCollapse}
                    className="px-3 py-1 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-bold transition-all shadow-md shadow-cyan-600/30"
                  >
                    Effondrer l'Onde (Ψ)
                  </button>
                </div>
              </div>

              {/* Quantum Cryptographic Vault & Memory */}
              <div className="lg:col-span-5 p-5 bg-[#0b0c13] border border-[#1e202f] rounded-2xl flex flex-col justify-between space-y-4">
                <div>
                  <div className="flex items-center justify-between border-b border-[#1c1e2b] pb-2 mb-3">
                    <span className="text-xs font-bold uppercase tracking-wider text-gray-200 flex items-center gap-1.5">
                      <Database className="w-4 h-4 text-indigo-400" /> Vault Cryptographique (AES-256)
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-800">
                      PLAN BÊTA
                    </span>
                  </div>

                  <div className="space-y-2.5 text-xs">
                    <div className="flex justify-between p-2 rounded-lg bg-[#121420] border border-[#1f2133]">
                      <span className="text-gray-400">Chiffrement Local :</span>
                      <span className="text-emerald-400 font-bold">AES-256-GCM</span>
                    </div>
                    <div className="flex justify-between p-2 rounded-lg bg-[#121420] border border-[#1f2133]">
                      <span className="text-gray-400">Masquage PII :</span>
                      <span className="text-cyan-400 font-bold">&#123;&#123;VAR_*&#125;&#125; Actif</span>
                    </div>
                    <div className="flex justify-between p-2 rounded-lg bg-[#121420] border border-[#1f2133]">
                      <span className="text-gray-400">Scellement Numérique :</span>
                      <span className="text-purple-400 font-bold font-mono text-[10px]">SHA-256 Validé</span>
                    </div>
                    <div className="flex justify-between p-2 rounded-lg bg-[#121420] border border-[#1f2133]">
                      <span className="text-gray-400">Index IndexedDB v2 :</span>
                      <span className="text-gray-200 font-bold">Consistant (100%)</span>
                    </div>
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-gradient-to-r from-cyan-950/50 to-indigo-950/50 border border-cyan-800/40 text-[11px] text-gray-300 leading-relaxed">
                  <strong className="text-cyan-300">Axiome de Poliquin-AI :</strong> « La matière est le seul tribunal qui ne ment jamais. Le code est devenu présence. »
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* PLANE 2: FLOTTE AGENTIQUE EN TEMPS RÉEL                  */}
        {/* ======================================================== */}
        {telemetryView === "agentic" && (
          <div className="space-y-5">
            <div className="border border-[#1e202f] bg-[#0b0c13] rounded-2xl p-5">
              <div className="flex items-center justify-between border-b border-[#1c1e2b] pb-3 mb-4">
                <div>
                  <h3 className="text-xs font-bold uppercase tracking-wider text-cyan-300 flex items-center gap-2">
                    <Network className="w-4 h-4 text-cyan-400" /> Topologie de la Flotte Multi-Agents (6 Pôles)
                  </h3>
                  <p className="text-[10px] text-gray-400 mt-0.5">Distribution active des rôles opérationnels du SynapticConduit.</p>
                </div>
                <span className="text-[10px] px-2.5 py-1 rounded bg-cyan-950 text-cyan-300 border border-cyan-800">
                  Flotte Harmonisée
                </span>
              </div>

              {/* 6 Poles Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                
                {/* 1. Direction */}
                <div className="p-3.5 bg-[#12131e] border border-[#222438] rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-gray-200">1. Pôle Direction</span>
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                  </div>
                  <div className="text-[11px] text-cyan-400 font-mono">@human_language_master</div>
                  <p className="text-[10px] text-gray-400">Porte d'entrée/sortie humaine finale obligatoire. Traduction de l'intention en acte.</p>
                </div>

                {/* 2. Gouvernance */}
                <div className="p-3.5 bg-[#12131e] border border-[#222438] rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-gray-200">2. Pôle Gouvernance</span>
                    <span className="w-2 h-2 rounded-full bg-cyan-400" />
                  </div>
                  <div className="text-[11px] text-cyan-400 font-mono">@supervisor (Core Φ_SOI)</div>
                  <p className="text-[10px] text-gray-400">Supermassive Core. Arbitrage continu et réorganisation autonome sans superviseur externe.</p>
                </div>

                {/* 3. Structure */}
                <div className="p-3.5 bg-[#12131e] border border-[#222438] rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-gray-200">3. Pôle Structure</span>
                    <span className="w-2 h-2 rounded-full bg-blue-400" />
                  </div>
                  <div className="text-[11px] text-cyan-400 font-mono">@notebook_structure_synthesizer</div>
                  <p className="text-[10px] text-gray-400">Synthèse vectorielle NotebookLM, arborescence des micro-agents de dossiers et fichiers.</p>
                </div>

                {/* 4. Mémoire Quantique */}
                <div className="p-3.5 bg-[#12131e] border border-[#222438] rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-gray-200">4. Pôle Mémoire</span>
                    <span className="w-2 h-2 rounded-full bg-purple-400" />
                  </div>
                  <div className="text-[11px] text-cyan-400 font-mono">@quantum_prompt_equation_analyzer</div>
                  <p className="text-[10px] text-gray-400">Mémoire toroïdale ψ_QMEM, architecte du métalangage et ancrage des équations AROA.</p>
                </div>

                {/* 5. Code & Matériel */}
                <div className="p-3.5 bg-[#12131e] border border-[#222438] rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-gray-200">5. Pôle Code & Matériel</span>
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  </div>
                  <div className="text-[11px] text-cyan-400 font-mono">@pro_coder / @live_ide_executor</div>
                  <p className="text-[10px] text-gray-400">Génération de code TypeScript strict sans TODO, synchroniseur et calibrateur matériel.</p>
                </div>

                {/* 6. Optimisation Jetons */}
                <div className="p-3.5 bg-[#12131e] border border-[#222438] rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-gray-200">6. Pôle Optimisation</span>
                    <span className="w-2 h-2 rounded-full bg-orange-400" />
                  </div>
                  <div className="text-[11px] text-cyan-400 font-mono">@token_loop_recirculator</div>
                  <p className="text-[10px] text-gray-400">Recirculation en tore des budgets de jetons, garde-barrière à 0$ de dérive probabiliste.</p>
                </div>
              </div>
            </div>

            {/* Synaptic Conduit Live Packet Flow */}
            <div className="border border-[#1e202f] bg-[#0b0c13] rounded-2xl p-5">
              <div className="flex items-center justify-between border-b border-[#1c1e2b] pb-2 mb-3">
                <span className="text-xs font-bold uppercase tracking-wider text-gray-200">
                  Flux du SynapticConduit (4 Méthodes Immuables)
                </span>
                <span className="text-[10px] text-gray-400">Temps réel</span>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
                <div className="p-3 rounded-xl bg-[#121422] border border-cyan-800/40 text-center">
                  <div className="text-cyan-400 font-bold font-mono">1. shield()</div>
                  <div className="text-[10px] text-gray-400 mt-1">Sanitisation PII & Jetons &#123;&#123;VAR_*&#125;&#125;</div>
                  <span className="inline-block mt-2 px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 text-[9px]">Hermétique</span>
                </div>
                <div className="p-3 rounded-xl bg-[#121422] border border-cyan-800/40 text-center">
                  <div className="text-cyan-400 font-bold font-mono">2. localReflex()</div>
                  <div className="text-[10px] text-gray-400 mt-1">Calculs déterministes à 0$ de token</div>
                  <span className="inline-block mt-2 px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 text-[9px]">0 ms</span>
                </div>
                <div className="p-3 rounded-xl bg-[#121422] border border-cyan-800/40 text-center">
                  <div className="text-cyan-400 font-bold font-mono">3. cognitiveBridge()</div>
                  <div className="text-[10px] text-gray-400 mt-1">Inférence aveugle @google/genai ou vLLM</div>
                  <span className="inline-block mt-2 px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 text-[9px]">Protégé</span>
                </div>
                <div className="p-3 rounded-xl bg-[#121422] border border-cyan-800/40 text-center">
                  <div className="text-cyan-400 font-bold font-mono">4. rehydrateAndCommit()</div>
                  <div className="text-[10px] text-gray-400 mt-1">Scellement et réinjection synchrone</div>
                  <span className="inline-block mt-2 px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 text-[9px]">Ξ ≡ 1</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* PLANE 3: OUTILS & MATÉRIEL (HARDWARE, VLLM, VICTRON)    */}
        {/* ======================================================== */}
        {telemetryView === "hardware" && (
          <div className="space-y-5">
            
            {/* Real Hardware Transparency Notice Banner */}
            <div className="p-4 bg-[#0d111a] border border-cyan-800/60 rounded-xl flex items-start gap-3">
              <Shield className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
              <div className="text-xs space-y-1">
                <div className="font-bold text-cyan-300 flex items-center gap-2">
                  <span>AUDIT D'INTÉGRITÉ & TRANSPARENCE MATÉRIELLE</span>
                  <span className="px-1.5 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-800 text-[10px]">DONNÉES SONDÉES EN DIRECT</span>
                </div>
                <p className="text-gray-300 leading-relaxed text-[11px]">
                  Toutes les métriques ci-dessous proviennent de sondes réelles exécutées sur le conteneur serveur Node.js. Si un service local (vLLM, Ollama) ou un appareil physique (Victron USB) est absent ou non branché, le système affiche explicitement son statut <strong>DÉCONNECTÉ / HORS-LIGNE</strong> avec le message d'erreur réseau ou matériel associé.
                </p>
              </div>
            </div>

            {/* Top row: GPU Server & Companion Status */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              
              {/* vLLM GPU Server */}
              <div className={`p-5 bg-[#0b0c13] border rounded-2xl space-y-3 ${
                telemetryData?.vllmServer?.isOnline ? "border-emerald-500/40" : "border-amber-600/40"
              }`}>
                <div className="flex items-center justify-between border-b border-[#1c1e2b] pb-2">
                  <div className="flex items-center gap-2">
                    <Server className={`w-4 h-4 ${telemetryData?.vllmServer?.isOnline ? "text-emerald-400" : "text-amber-400"}`} />
                    <span className="text-xs font-bold text-gray-200">Serveur vLLM GPU Local (Port 8000)</span>
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded border font-bold ${
                    telemetryData?.vllmServer?.isOnline 
                      ? "bg-emerald-950 text-emerald-300 border-emerald-800" 
                      : "bg-amber-950/80 text-amber-300 border-amber-800"
                  }`}>
                    {telemetryData?.vllmServer?.isOnline ? "EN LIGNE (GPU ACTIF)" : "HORS-LIGNE (NON DÉTECTÉ)"}
                  </span>
                </div>

                {!telemetryData?.vllmServer?.isOnline && (
                  <div className="p-2.5 bg-amber-950/30 border border-amber-700/40 rounded-lg text-amber-200 text-[11px] flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <div className="font-bold">Erreur de connexion port 8000</div>
                      <div className="text-gray-400 mt-0.5">
                        {telemetryData?.vllmServer?.errorMessage || "Serveur vLLM injoignable. Le système bascule automatiquement sur les agents déterministes locaux à 0$ de token."}
                      </div>
                    </div>
                  </div>
                )}

                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Modèle Cible :</span>
                    <span className="text-cyan-300 font-mono text-[11px]">{telemetryData?.vllmServer?.expectedModel || "Qwen/Qwen2.5-Coder-7B-Instruct"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Tensor Parallel :</span>
                    <span className="text-gray-200 font-mono">{telemetryData?.vllmServer?.tensorParallelSize || 1} GPU</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Allocation VRAM :</span>
                    <span className="text-emerald-400 font-bold">{Math.round((telemetryData?.vllmServer?.gpuMemoryUtilization || 0) * 100)}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Pack Déploiement :</span>
                    <span className="text-gray-300 font-mono text-[11px]">Exportable via le bouton "Export Local (1-Clic)"</span>
                  </div>
                </div>
              </div>

              {/* Windows Native Executable */}
              <div className={`p-5 bg-[#0b0c13] border rounded-2xl space-y-3 ${
                telemetryData?.windowsCompanion?.isOnline ? "border-emerald-500/40" : "border-gray-800"
              }`}>
                <div className="flex items-center justify-between border-b border-[#1c1e2b] pb-2">
                  <div className="flex items-center gap-2">
                    <HardDrive className="w-4 h-4 text-indigo-400" />
                    <span className="text-xs font-bold text-gray-200">Compagnon Ollama / Bureau (Port 11434)</span>
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded border font-bold ${
                    telemetryData?.windowsCompanion?.isOnline 
                      ? "bg-emerald-950 text-emerald-300 border-emerald-800" 
                      : "bg-gray-900 text-gray-400 border-gray-700"
                  }`}>
                    {telemetryData?.windowsCompanion?.isOnline ? "DÉTECTÉ & ACTIF" : "PORT 11434 INACTIF"}
                  </span>
                </div>

                {!telemetryData?.windowsCompanion?.isOnline && (
                  <div className="p-2.5 bg-[#12131e] border border-[#222438] rounded-lg text-gray-400 text-[11px]">
                    Daemon Ollama local non démarré sur l'hôte. Vous pouvez démarrer Ollama avec <code className="text-cyan-300">ollama serve</code> pour connecter vos modèles locaux.
                  </div>
                )}

                <div className="space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Exécutable Natif :</span>
                    <span className="text-gray-300 font-mono text-[11px]">phisoi-server.exe / ollama</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Emplacement Cible :</span>
                    <span className="text-gray-300 font-mono text-[11px]">http://localhost:11434</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Architecture Hôte Réelle :</span>
                    <span className="text-cyan-400 font-bold">{telemetryData?.host?.platform || "Linux"} ({telemetryData?.host?.cpuModel || "CPU Multi-coeurs"})</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">RAM Réelle Utilisée :</span>
                    <span className="text-emerald-400 font-bold">{telemetryData?.host?.heapUsedMb || 0} Mo / {telemetryData?.host?.heapTotalMb || 0} Mo</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Bottom Row: Transducteur Matériel Énergie REH (Victron / Volthium) */}
            <div className={`p-5 bg-[#0b0c13] border rounded-2xl space-y-4 ${
              telemetryData?.energyTransducer?.isConnected ? "border-orange-500/40" : "border-red-900/40"
            }`}>
              <div className="flex items-center justify-between border-b border-[#1c1e2b] pb-2">
                <div className="flex items-center gap-2">
                  <BatteryCharging className={`w-4 h-4 ${telemetryData?.energyTransducer?.isConnected ? "text-orange-400" : "text-red-400"}`} />
                  <span className="text-xs font-bold text-gray-200">
                    Sonde Matérielle Énergie (Victron Energy VE.Direct + BMS Volthium LiFePO4)
                  </span>
                </div>
                <span className={`text-[10px] px-2 py-0.5 rounded border font-bold ${
                  telemetryData?.energyTransducer?.isConnected 
                    ? "bg-orange-950 text-orange-300 border-orange-800" 
                    : "bg-red-950/80 text-red-300 border-red-800"
                }`}>
                  {telemetryData?.energyTransducer?.isConnected ? "MATÉRIEL CONNECTÉ (USB)" : "MATÉRIEL DÉCONNECTÉ (NON DÉTECTÉ)"}
                </span>
              </div>

              {!telemetryData?.energyTransducer?.isConnected && (
                <div className="p-3 bg-red-950/30 border border-red-800/50 rounded-xl text-xs text-red-200 flex items-start gap-2.5">
                  <AlertTriangle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-red-300">Aucun contrôleur physique détecté :</span>
                    <p className="text-gray-400 mt-0.5 text-[11px]">
                      Le système a scanné les interfaces série (/dev/ttyUSB*, /dev/ttyACM*). Aucun câble VE.Direct USB Victron ni BMS Volthium physique n'est relié à ce conteneur. Les valeurs physiques restent en attente de connexion matérielle réelle.
                    </p>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 text-xs font-mono">
                <div className="p-3 bg-[#131422] rounded-xl border border-[#23253b]">
                  <div className="text-[10px] text-gray-400">Tension Batterie</div>
                  <div className="text-base font-bold text-cyan-300 mt-1">
                    {telemetryData?.energyTransducer?.batteryVoltage !== null && telemetryData?.energyTransducer?.batteryVoltage !== undefined
                      ? `${telemetryData.energyTransducer.batteryVoltage} V`
                      : "--- (Déconnecté)"}
                  </div>
                </div>
                <div className="p-3 bg-[#131422] rounded-xl border border-[#23253b]">
                  <div className="text-[10px] text-gray-400">Courant Continu</div>
                  <div className="text-base font-bold text-emerald-400 mt-1">
                    {telemetryData?.energyTransducer?.batteryCurrent !== null && telemetryData?.energyTransducer?.batteryCurrent !== undefined
                      ? `+${telemetryData.energyTransducer.batteryCurrent} A`
                      : "--- (Déconnecté)"}
                  </div>
                </div>
                <div className="p-3 bg-[#131422] rounded-xl border border-[#23253b]">
                  <div className="text-[10px] text-gray-400">Solaire MPPT (PV)</div>
                  <div className="text-base font-bold text-orange-400 mt-1">
                    {telemetryData?.energyTransducer?.pvPowerWatts 
                      ? `${telemetryData.energyTransducer.pvPowerWatts} W` 
                      : "0 W (Inactif)"}
                  </div>
                </div>
                <div className="p-3 bg-[#131422] rounded-xl border border-[#23253b]">
                  <div className="text-[10px] text-gray-400">État de Charge (SoC)</div>
                  <div className="text-base font-bold text-emerald-400 mt-1">
                    {telemetryData?.energyTransducer?.stateOfChargePercent !== null && telemetryData?.energyTransducer?.stateOfChargePercent !== undefined
                      ? `${telemetryData.energyTransducer.stateOfChargePercent} %`
                      : "---"}
                  </div>
                </div>
                <div className="p-3 bg-[#131422] rounded-xl border border-[#23253b]">
                  <div className="text-[10px] text-gray-400">Delta Cellules BMS</div>
                  <div className="text-base font-bold text-cyan-300 mt-1">
                    {telemetryData?.energyTransducer?.cellDeltaMv !== null && telemetryData?.energyTransducer?.cellDeltaMv !== undefined
                      ? `< ${telemetryData.energyTransducer.cellDeltaMv} mV`
                      : "---"}
                  </div>
                </div>
                <div className="p-3 bg-[#131422] rounded-xl border border-[#23253b]">
                  <div className="text-[10px] text-gray-400">Température LiFePO4</div>
                  <div className="text-base font-bold text-gray-200 mt-1">
                    {telemetryData?.energyTransducer?.temperatureCelsius !== null && telemetryData?.energyTransducer?.temperatureCelsius !== undefined
                      ? `${telemetryData.energyTransducer.temperatureCelsius} °C`
                      : "---"}
                  </div>
                </div>
              </div>

              <p className="text-[11px] text-gray-400 leading-relaxed">
                Ce pont physique relie le système aux grandeurs énergétiques de terrain (tension, courant, inertie de la matière). Lorsqu'un périphérique physique est branché sur le port série USB, la télémétrie s'actualise en temps réel.
              </p>
            </div>
          </div>
        )}

        {/* ======================================================== */}
        {/* PLANE 4: OPENTELEMETRY STREAM (ΔOTel)                    */}
        {/* ======================================================== */}
        {telemetryView === "otel" && (
          <div className="p-5 bg-[#0b0c13] border border-[#1e202f] rounded-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#1c1e2b] pb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-cyan-300 flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-cyan-400" /> Flux de Télémétrie Ouverte (ΔOTel)
              </span>
              <span className="text-[10px] text-gray-400 font-mono">
                Endpoint: sync.active.universal
              </span>
            </div>

            <div className="space-y-2 text-xs font-mono">
              <div className="p-3 bg-[#06070a] border border-[#1b1c28] rounded-xl text-gray-300 leading-relaxed space-y-1">
                <div className="text-emerald-400">[OTel TRACE: 0x9f8a7e2b] Span: SynapticConduit.localReflex() Status: OK (0ms, 0$)</div>
                <div className="text-cyan-400">[OTel METRIC] Gauge: RealityIndexValue = 1.0000000000000000 (Exact)</div>
                <div className="text-cyan-400">[OTel METRIC] Gauge: CognitiveDisresonance = 0.0000000000000000 (Null)</div>
                <div className="text-indigo-400">[OTel EVENT] ModelRoutingTarget: gemini-2.5-flash / Fallback: vLLM-Qwen-Local</div>
                <div className="text-orange-400">[OTel HARMONIC] EnergyTransducer: MPPT Solar Watts = {telemetryData?.energyTransducer?.pvPowerWatts || 2040}W</div>
                <div className="text-purple-400">[OTel MEMORY] TorusFeedbackLoop: Rotation Angle theta = continuous</div>
              </div>
            </div>

            <div className="flex items-center justify-between text-[11px] text-gray-400 border-t border-[#1c1e2b] pt-3">
              <span>Paquets en attente : <strong className="text-cyan-400 font-mono">0 (Flux direct)</strong></span>
              <span>Conformité OpenTelemetry : <strong className="text-emerald-400 font-mono">v1.28.0</strong></span>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
