import React, { useState, useMemo, useRef, useEffect } from "react";
import { 
  Network, Search, ZoomIn, ZoomOut, RotateCcw, AlertTriangle, 
  CheckCircle2, Layers, Cpu, Box, FileCode, ArrowUpRight, 
  Sparkles, Filter, Info, ShieldCheck, Activity, Maximize2
} from "lucide-react";
import { WorkspaceFile } from "../../types";
import { 
  fileDependencyAnalyzer, 
  DependencyNode, 
  DependencyGraphData, 
  DependencyLink 
} from "../../services/ast/fileDependencyAnalyzer";

interface FileDependencyGraphViewProps {
  files: WorkspaceFile[];
  onSelectFile?: (filePath: string) => void;
}

export default function FileDependencyGraphView({
  files,
  onSelectFile,
}: FileDependencyGraphViewProps) {
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [activeCategoryFilter, setActiveCategoryFilter] = useState<string>("all");
  const [showCircularOnly, setShowCircularOnly] = useState<boolean>(false);
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [panOffset, setPanOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  const svgRef = useRef<SVGSVGElement | null>(null);

  // Compute graph data
  const graphData: DependencyGraphData = useMemo(() => {
    return fileDependencyAnalyzer.analyzeWorkspace(files);
  }, [files]);

  const selectedNode = useMemo(() => {
    return graphData.nodes.find((n) => n.id === selectedNodeId) || null;
  }, [graphData.nodes, selectedNodeId]);

  // Filtered nodes
  const filteredNodes = useMemo(() => {
    return graphData.nodes.filter((node) => {
      if (showCircularOnly && !node.hasCircularDependency) return false;
      if (activeCategoryFilter !== "all" && node.category !== activeCategoryFilter && node.pole !== activeCategoryFilter) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          node.label.toLowerCase().includes(q) ||
          node.path.toLowerCase().includes(q) ||
          node.exportsList.some((exp) => exp.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [graphData.nodes, activeCategoryFilter, showCircularOnly, searchQuery]);

  const filteredNodeIds = useMemo(() => new Set(filteredNodes.map((n) => n.id)), [filteredNodes]);

  // Active links connected to selected or highlighted nodes
  const relevantLinks = useMemo(() => {
    return graphData.links.filter((link) => {
      const srcVisible = filteredNodeIds.has(link.source);
      const tgtVisible = filteredNodeIds.has(link.target);
      if (!srcVisible || !tgtVisible) return false;

      if (selectedNodeId) {
        return link.source === selectedNodeId || link.target === selectedNodeId;
      }
      return true;
    });
  }, [graphData.links, filteredNodeIds, selectedNodeId]);

  // Handle Mouse Pan
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.target === svgRef.current || (e.target as HTMLElement).tagName === "rect") {
      setIsDragging(true);
      setDragStart({ x: e.clientX - panOffset.x, y: e.clientY - panOffset.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      setPanOffset({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y,
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  const handleZoom = (delta: number) => {
    setZoomLevel((prev) => Math.min(Math.max(prev + delta, 0.4), 2.5));
  };

  const resetView = () => {
    setZoomLevel(1);
    setPanOffset({ x: 0, y: 0 });
    setSelectedNodeId(null);
  };

  const getNodeColor = (pole: DependencyNode["pole"], isSelected: boolean, isCircular: boolean) => {
    if (isCircular) return "#ef4444";
    if (isSelected) return "#f97316";
    switch (pole) {
      case "alpha":
        return "#06b6d4"; // Cyan
      case "beta":
        return "#a855f7"; // Purple
      case "gamma":
        return "#3b82f6"; // Blue
      case "delta":
        return "#10b981"; // Emerald
      case "telemetry":
        return "#f59e0b"; // Amber
      default:
        return "#64748b";
    }
  };

  return (
    <div className="h-full flex flex-col bg-[#07090e] border border-[#1b2030] rounded-2xl overflow-hidden font-mono text-gray-200 select-none">
      
      {/* 1. TOP TOOLBAR & METRICS HUD */}
      <div className="bg-[#0c0f17] border-b border-[#1b2030] p-4 flex flex-wrap items-center justify-between gap-3 shrink-0">
        
        {/* Left: Title & Status */}
        <div className="flex items-center gap-3">
          <div className="p-2 bg-[#121927] border border-cyan-500/30 rounded-xl">
            <Network className="w-5 h-5 text-cyan-400 animate-pulse" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-gray-100 flex items-center gap-2">
              <span>Graphe Interactif de Dépendances</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950/80 text-cyan-400 border border-cyan-700/50">
                Cartographie 2D Φ_SOI
              </span>
            </h2>
            <p className="text-[11px] text-gray-400">
              Analyse structurelle en temps réel ({graphData.nodes.length} modules, {graphData.links.length} liaisons)
            </p>
          </div>
        </div>

        {/* Center: System Coherence & Invariance Pill */}
        <div className="flex items-center gap-2 text-xs">
          <div className="bg-[#060810] border border-cyan-900/50 px-3 py-1.5 rounded-lg flex items-center gap-2">
            <span className="text-gray-400">Cohérence (Ξ) :</span>
            <span className="text-emerald-400 font-bold">{(graphData.metrics.coherenceIndex * 1).toFixed(4)}</span>
          </div>

          <div className="bg-[#060810] border border-[#1b2030] px-3 py-1.5 rounded-lg flex items-center gap-2">
            <span className="text-gray-400">Cycles Circulaires :</span>
            {graphData.metrics.circularCyclesCount === 0 ? (
              <span className="text-emerald-400 font-bold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" /> 0 (Zéro Conflit)
              </span>
            ) : (
              <span className="text-rose-400 font-bold flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" /> {graphData.metrics.circularCyclesCount}
              </span>
            )}
          </div>
        </div>

        {/* Right: Search & Controls */}
        <div className="flex items-center gap-2">
          {/* Search Input */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-gray-400" />
            <input
              type="text"
              placeholder="Rechercher composant, service..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-[#05070c] border border-[#1f2639] rounded-lg pl-8 pr-3 py-1.5 text-xs text-cyan-200 placeholder-gray-500 focus:outline-none focus:border-cyan-500/60 w-52"
            />
          </div>

          {/* Zoom Buttons */}
          <div className="flex items-center bg-[#0e121d] border border-[#1f2639] rounded-lg p-0.5">
            <button
              onClick={() => handleZoom(0.15)}
              className="p-1.5 text-gray-400 hover:text-white hover:bg-[#182033] rounded"
              title="Zoomer (+)"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => handleZoom(-0.15)}
              className="p-1.5 text-gray-400 hover:text-white hover:bg-[#182033] rounded"
              title="Dézoomer (-)"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={resetView}
              className="p-1.5 text-gray-400 hover:text-white hover:bg-[#182033] rounded"
              title="Réinitialiser la Vue"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* 2. FILTER BAR */}
      <div className="bg-[#090b12] border-b border-[#1b2030] px-4 py-2 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-1.5 overflow-x-auto">
          <span className="text-[11px] text-gray-500 mr-1 flex items-center gap-1">
            <Filter className="w-3 h-3" /> Filtres :
          </span>

          {[
            { id: "all", label: "Tous les Modules" },
            { id: "component", label: "Composants React" },
            { id: "service", label: "Services & Logique" },
            { id: "agent", label: "Pôles Agentiques" },
            { id: "type", label: "Types & Interfaces" },
            { id: "telemetry", label: "Télémétrie & Matériel" },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                setActiveCategoryFilter(cat.id);
                setShowCircularOnly(false);
              }}
              className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all border ${
                activeCategoryFilter === cat.id && !showCircularOnly
                  ? "bg-cyan-950/80 text-cyan-300 border-cyan-500/50"
                  : "bg-transparent text-gray-400 border-transparent hover:bg-[#131826] hover:text-gray-200"
              }`}
            >
              {cat.label}
            </button>
          ))}

          {/* Toggle Circular Cycles Filter */}
          <button
            onClick={() => setShowCircularOnly(!showCircularOnly)}
            className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-all border flex items-center gap-1 ${
              showCircularOnly
                ? "bg-rose-950/90 text-rose-300 border-rose-500/80 shadow-rose-500/20"
                : "bg-transparent text-gray-400 border-transparent hover:bg-[#131826]"
            }`}
          >
            <AlertTriangle className="w-3 h-3 text-rose-400" />
            <span>Dépendances Circulaires</span>
          </button>
        </div>

        {/* Legend */}
        <div className="hidden lg:flex items-center gap-3 text-[10px] text-gray-400">
          <div className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-[#06b6d4]"></span> Plan Alpha</div>
          <div className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-[#a855f7]"></span> Plan Bêta</div>
          <div className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-[#3b82f6]"></span> Plan Gamma</div>
          <div className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-[#10b981]"></span> Plan Delta (UI)</div>
        </div>
      </div>

      {/* 3. MAIN WORKSPACE: CANVAS GRAPH + DETAIL SIDEBAR */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden relative">
        
        {/* SVG Interactive Visual Stage */}
        <div 
          className="flex-1 h-full relative cursor-grab active:cursor-grabbing overflow-hidden bg-[radial-gradient(#141a29_1px,transparent_1px)] [background-size:24px_24px]"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
        >
          <svg
            ref={svgRef}
            className="w-full h-full"
            viewBox="0 0 1000 760"
            preserveAspectRatio="xMidYMid meet"
          >
            <g
              transform={`translate(${panOffset.x}, ${panOffset.y}) scale(${zoomLevel})`}
              className="transition-transform duration-75"
            >
              {/* Background Concentric Radar Rings */}
              <circle cx="500" cy="380" r="200" fill="none" stroke="#131929" strokeWidth="1" strokeDasharray="4 4" />
              <circle cx="500" cy="380" r="280" fill="none" stroke="#131929" strokeWidth="1" strokeDasharray="4 4" />
              <circle cx="500" cy="380" r="350" fill="none" stroke="#131929" strokeWidth="1" strokeDasharray="4 4" />

              {/* Draw Dependency Links */}
              {relevantLinks.map((link, idx) => {
                const srcNode = graphData.nodes.find((n) => n.id === link.source);
                const tgtNode = graphData.nodes.find((n) => n.id === link.target);
                if (!srcNode || !tgtNode) return null;

                const isConnectedToSelected = selectedNodeId === link.source || selectedNodeId === link.target;
                const strokeColor = link.isCircular
                  ? "#f43f5e"
                  : isConnectedToSelected
                  ? "#f97316"
                  : "#1e293b";
                const strokeWidth = link.isCircular ? 2.5 : isConnectedToSelected ? 2 : 1;
                const strokeOpacity = isConnectedToSelected || link.isCircular ? 0.95 : 0.45;

                return (
                  <g key={`link-${idx}`}>
                    <line
                      x1={srcNode.x}
                      y1={srcNode.y}
                      x2={tgtNode.x}
                      y2={tgtNode.y}
                      stroke={strokeColor}
                      strokeWidth={strokeWidth}
                      strokeOpacity={strokeOpacity}
                      strokeDasharray={link.isCircular ? "4 3" : undefined}
                    />
                  </g>
                );
              })}

              {/* Draw Nodes */}
              {filteredNodes.map((node) => {
                const isSelected = selectedNodeId === node.id;
                const isImportedBySelected = selectedNode?.imports.includes(node.id);
                const importsSelected = selectedNode?.importedBy.includes(node.id);
                const isHighlighted = isSelected || isImportedBySelected || importsSelected;

                const nodeColor = getNodeColor(node.pole, isSelected, node.hasCircularDependency);
                const radius = isSelected ? 18 : 12;

                return (
                  <g
                    key={node.id}
                    transform={`translate(${node.x}, ${node.y})`}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedNodeId(node.id === selectedNodeId ? null : node.id);
                    }}
                    className="cursor-pointer transition-all"
                  >
                    {/* Outer Glow Halo for Selected or Circular */}
                    {(isSelected || node.hasCircularDependency) && (
                      <circle
                        r={radius + 8}
                        fill={nodeColor}
                        opacity="0.2"
                        className="animate-pulse"
                      />
                    )}

                    {/* Main Node Circle */}
                    <circle
                      r={radius}
                      fill="#07090e"
                      stroke={nodeColor}
                      strokeWidth={isSelected ? 3 : 2}
                      className="hover:scale-125 transition-transform"
                    />

                    {/* Inner Core Dot */}
                    <circle
                      r={radius - 6}
                      fill={nodeColor}
                      opacity={isSelected ? 0.9 : 0.6}
                    />

                    {/* Node Text Label */}
                    <text
                      y={radius + 14}
                      textAnchor="middle"
                      fill={isSelected ? "#f8fafc" : "#94a3b8"}
                      fontSize={isSelected ? "11px" : "9px"}
                      fontWeight={isSelected ? "bold" : "normal"}
                      className="pointer-events-none drop-shadow"
                    >
                      {node.label}
                    </text>
                  </g>
                );
              })}
            </g>
          </svg>

          {/* Quick HUD Helper Overlay on Canvas */}
          <div className="absolute bottom-3 left-3 bg-[#0c101a]/90 backdrop-blur border border-[#1e2638] rounded-xl p-2.5 text-[10px] text-gray-400 space-y-1">
            <div className="flex items-center gap-1.5 font-bold text-gray-200">
              <Info className="w-3.5 h-3.5 text-cyan-400" />
              <span>Navigation Nodale</span>
            </div>
            <div>• Glisser-déposer pour déplacer la vue</div>
            <div>• Cliquer sur un nœud pour afficher ses imports/exports</div>
          </div>
        </div>

        {/* Right Details Inspection Drawer */}
        <div className="w-full md:w-80 bg-[#090c14] border-t md:border-t-0 md:border-l border-[#1b2030] p-4 flex flex-col justify-between overflow-y-auto shrink-0">
          {selectedNode ? (
            <div className="space-y-4">
              {/* Header */}
              <div className="border-b border-[#1e2639] pb-3">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-[#131b2c] text-cyan-400 border border-cyan-800/40">
                    {selectedNode.category}
                  </span>
                  <span className="text-[10px] text-gray-500 font-mono">
                    {selectedNode.linesCount} lignes
                  </span>
                </div>
                <h3 className="text-sm font-bold text-white break-all">
                  {selectedNode.label}
                </h3>
                <p className="text-[10px] text-gray-400 font-mono break-all mt-0.5">
                  {selectedNode.path}
                </p>
              </div>

              {/* Status Alert for Circular Dependencies */}
              {selectedNode.hasCircularDependency && (
                <div className="p-3 bg-rose-950/40 border border-rose-500/50 rounded-xl text-rose-200 text-xs flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <div>
                    <div className="font-bold">Dépendance Circulaire Détectée</div>
                    <div className="text-[10px] text-rose-300 mt-1">
                      Cycle : {selectedNode.circularPath?.map((p) => p.split("/").pop()).join(" → ")}
                    </div>
                  </div>
                </div>
              )}

              {/* Direct Dependencies (Imports) */}
              <div>
                <div className="text-xs font-bold text-gray-300 mb-2 flex items-center justify-between">
                  <span>Fichiers Importés ({selectedNode.imports.length}) :</span>
                </div>
                {selectedNode.imports.length > 0 ? (
                  <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                    {selectedNode.imports.map((imp) => (
                      <div
                        key={imp}
                        onClick={() => setSelectedNodeId(imp)}
                        className="p-1.5 bg-[#0e1320] hover:bg-[#182034] border border-[#1c2438] rounded-lg text-[11px] text-cyan-300 flex items-center justify-between cursor-pointer transition-colors"
                      >
                        <span className="truncate">{imp.split("/").pop()}</span>
                        <ArrowUpRight className="w-3 h-3 text-gray-500" />
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-[10px] text-gray-500 italic">Aucun import local direct</p>
                )}
              </div>

              {/* Reverse Dependencies (Imported by) */}
              <div>
                <div className="text-xs font-bold text-gray-300 mb-2 flex items-center justify-between">
                  <span>Utilisé Par ({selectedNode.importedBy.length}) :</span>
                </div>
                {selectedNode.importedBy.length > 0 ? (
                  <div className="space-y-1.5 max-h-36 overflow-y-auto pr-1">
                    {selectedNode.importedBy.map((impBy) => (
                      <div
                        key={impBy}
                        onClick={() => setSelectedNodeId(impBy)}
                        className="p-1.5 bg-[#0e1320] hover:bg-[#182034] border border-[#1c2438] rounded-lg text-[11px] text-emerald-300 flex items-center justify-between cursor-pointer transition-colors"
                      >
                        <span className="truncate">{impBy.split("/").pop()}</span>
                        <ArrowUpRight className="w-3 h-3 text-gray-500" />
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-[10px] text-gray-500 italic">Module racine ou non-référencé</p>
                )}
              </div>

              {/* Exported Symbols */}
              {selectedNode.exportsList.length > 0 && (
                <div>
                  <div className="text-xs font-bold text-gray-300 mb-1.5">
                    Symboles Exportés ({selectedNode.exportsList.length}) :
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {selectedNode.exportsList.map((sym) => (
                      <span
                        key={sym}
                        className="px-2 py-0.5 rounded bg-[#121927] text-purple-300 border border-purple-800/40 text-[10px] font-mono"
                      >
                        {sym}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* External NPM Packages */}
              {selectedNode.externalImports.length > 0 && (
                <div>
                  <div className="text-xs font-bold text-gray-300 mb-1.5">
                    Packages NPM Externes :
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {selectedNode.externalImports.map((pkg) => (
                      <span
                        key={pkg}
                        className="px-2 py-0.5 rounded bg-[#0b1019] text-gray-400 border border-gray-800 text-[10px]"
                      >
                        {pkg}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Action Button */}
              {onSelectFile && (
                <button
                  onClick={() => onSelectFile(selectedNode.path)}
                  className="w-full mt-4 px-4 py-2 bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-black font-bold text-xs rounded-xl transition-all shadow-md flex items-center justify-center gap-2"
                >
                  <FileCode className="w-4 h-4" />
                  <span>Ouvrir dans l'Éditeur Studio</span>
                </button>
              )}
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-center p-4 text-gray-500 space-y-3">
              <Network className="w-10 h-10 text-gray-700" />
              <div>
                <h4 className="text-sm font-bold text-gray-400">Aucun Module Sélectionné</h4>
                <p className="text-[11px] text-gray-600 mt-1">
                  Cliquez sur un nœud dans la cartographie pour analyser ses dépendances, connexions et exports.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
