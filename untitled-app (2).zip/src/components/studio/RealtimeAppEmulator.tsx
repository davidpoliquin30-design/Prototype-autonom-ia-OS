import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Monitor, Smartphone, Tablet, Laptop, RefreshCw, 
  ArrowLeft, ArrowRight, Home, Globe, ExternalLink, 
  Sparkles, CheckCircle2, Shield, Compass, Activity, 
  FolderCode, Database, Calculator, Wrench, Network,
  Cpu, Layers, Maximize2, Minimize2, Eye, Sliders,
  Heart, Sun, Languages, Zap, Code2
} from "lucide-react";

// Subcomponents for the live app twin
import CodeProgrammingStudio from "../CodeProgrammingStudio";
import QuantumHardwareTelemetryMatrix from "../telemetry/QuantumHardwareTelemetryMatrix";
import OmniMachineCartographerMatrix from "../telemetry/OmniMachineCartographerMatrix";
import NotebookLMTool from "../NotebookLMTool";
import TokenBudgetCalibrator from "../TokenBudgetCalibrator";
import VirtualEvolutionSandbox from "../VirtualEvolutionSandbox";
import AutoRepairPanel from "../AutoRepairPanel";
import UnifiedAgentMeshPanel from "../UnifiedAgentMeshPanel";
import InnerIntrospectionKernel from "../InnerIntrospectionKernel";
import EngaticResonanceConsole from "../EngaticResonanceConsole";
import { AgenticServerInitTab } from "../dock/AgenticServerInitTab";
import { PolyglotTranslatorPanel } from "../translator/PolyglotTranslatorPanel";
import MachineHeartCosmicSource from "../cosmic/MachineHeartCosmicSource";
import UniversalAlignmentAgentWidget from "../agent/UniversalAlignmentAgentWidget";
import QuantumCalculator from "../sub/QuantumCalculator";
import MatriceTaskManager from "../sub/MatriceTaskManager";
import ClimatologicalWidget from "../sub/ClimatologicalWidget";
import EmulatorInAppProgrammer from "./EmulatorInAppProgrammer";
import TabAgenticTeamBar from "../quantum/TabAgenticTeamBar";
import { WorkspaceFile } from "../../types";
import { universalAlignmentAgent, AlignmentSystemState } from "../../services/agent/universalAlignmentAgent";
import { quantumIntegrationBridge, QuantumIntegrationState } from "../../services/quantumIntegrationBridge";

interface RealtimeAppEmulatorProps {
  files?: WorkspaceFile[];
  onRefreshFiles?: () => void;
  isFullscreen?: boolean;
  onToggleFullscreen?: () => void;
}

type DevicePreset = "desktop" | "laptop" | "tablet" | "mobile" | "cinema169";

export default function RealtimeAppEmulator({ 
  files = [], 
  onRefreshFiles,
  isFullscreen,
  onToggleFullscreen
}: RealtimeAppEmulatorProps) {
  const [devicePreset, setDevicePreset] = useState<DevicePreset>("desktop");
  const [internalFullscreen, setInternalFullscreen] = useState<boolean>(false);
  const activeFullscreen = isFullscreen !== undefined ? isFullscreen : internalFullscreen;

  const handleToggleFullscreen = () => {
    if (onToggleFullscreen) {
      onToggleFullscreen();
    } else {
      setInternalFullscreen(prev => !prev);
    }
  };

  // Keyboard shortcut: Escape exits fullscreen
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && activeFullscreen) {
        if (onToggleFullscreen) onToggleFullscreen();
        else setInternalFullscreen(false);
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [activeFullscreen, onToggleFullscreen]);
  const [emulatedTab, setEmulatedTab] = useState<string>("studio-preview");
  const [currentUrl, setCurrentUrl] = useState<string>("https://phisoi.local/app/studio");
  const [historyStack, setHistoryStack] = useState<string[]>(["https://phisoi.local/app/studio"]);
  const [historyIndex, setHistoryIndex] = useState<number>(0);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [refreshKey, setRefreshKey] = useState<number>(0);
  const [refreshAlert, setRefreshAlert] = useState<{ message: string; timestamp: number } | null>(null);
  const [isFlashActive, setIsFlashActive] = useState<boolean>(false);
  const [isDevToolsOpen, setIsDevToolsOpen] = useState<boolean>(false);
  const [showInAppProgrammer, setShowInAppProgrammer] = useState<boolean>(false);
  const [emulationMode, setEmulationMode] = useState<"twin" | "iframe">("twin");
  const [capturedEvents, setCapturedEvents] = useState<{ id: string; type: string; target: string; time: string }[]>([]);
  const [alignmentState, setAlignmentState] = useState<AlignmentSystemState>(universalAlignmentAgent.getState());
  const [integrationState, setIntegrationState] = useState<QuantumIntegrationState>(quantumIntegrationBridge.getState());
  const [isHeartGlowActive, setIsHeartGlowActive] = useState<boolean>(false);

  // Subscribe to background AI alignment agent
  useEffect(() => {
    const unsub = universalAlignmentAgent.subscribe(setAlignmentState);
    return () => unsub();
  }, []);

  // Subscribe to quantum integration bridge
  useEffect(() => {
    const unsub = quantumIntegrationBridge.subscribe(setIntegrationState);
    return () => unsub();
  }, []);

  // Listen to quantum app refresh event for hot reload & twin auto-navigation
  useEffect(() => {
    const handleQuantumRefresh = (e: any) => {
      // Ensure we are in Jumeau Twin mode so modifications are visible immediately
      setEmulationMode("twin");
      setIsRefreshing(true);
      setRefreshKey((k) => k + 1);
      setIsFlashActive(true);
      setTimeout(() => setIsRefreshing(false), 500);
      setTimeout(() => setIsFlashActive(false), 2400);

      const modifiedFile = e?.detail?.modifiedFiles?.[0] || "Composant";
      const targetTab = e?.detail?.targetTab;
      
      if (targetTab && targetTab !== emulatedTab) {
        handleNavigateTab(targetTab);
      }

      setRefreshAlert({
        message: `Jumeau Twin mis à jour en direct : /${modifiedFile}${targetTab ? ` (Vue: ${targetTab})` : ''} !`,
        timestamp: Date.now(),
      });
      setTimeout(() => setRefreshAlert(null), 4500);

      if (onRefreshFiles) {
        onRefreshFiles();
      }

      logEvent("quantum-sync", `Hot-reload Jumeau Twin appliqué pour /${modifiedFile}`);
    };

    const handleQuantumNavigate = (e: any) => {
      setEmulationMode("twin");
      const targetTab = e?.detail?.tabId;
      if (targetTab) {
        handleNavigateTab(targetTab);
        logEvent("auto-navigate", `Navigation autonome Jumeau Twin vers [${targetTab}]`);
      }
    };

    window.addEventListener("quantum-app-refresh", handleQuantumRefresh);
    window.addEventListener("quantum-app-navigate", handleQuantumNavigate);
    return () => {
      window.removeEventListener("quantum-app-refresh", handleQuantumRefresh);
      window.removeEventListener("quantum-app-navigate", handleQuantumNavigate);
    };
  }, [onRefreshFiles, emulatedTab]);

  // Sync URL when tab changes
  const handleNavigateTab = (tabId: string) => {
    setEmulatedTab(tabId);
    const newUrl = `https://phisoi.local/app/${tabId}`;
    setCurrentUrl(newUrl);

    // Record history
    const nextHistory = historyStack.slice(0, historyIndex + 1);
    nextHistory.push(newUrl);
    setHistoryStack(nextHistory);
    setHistoryIndex(nextHistory.length - 1);

    logEvent("navigation", `Navigation vers [/${tabId}]`);

    // Let the background agent evaluate the choice
    universalAlignmentAgent.evaluateAndSelectOptimalOption(
      "viewport",
      `Navigation vue ${tabId}`,
      tabId,
      ["studio-preview", "cosmic-heart", "telemetry", "machine", "ide"]
    );
  };

  const handleBack = () => {
    if (historyIndex > 0) {
      const prevIdx = historyIndex - 1;
      const targetUrl = historyStack[prevIdx];
      setHistoryIndex(prevIdx);
      setCurrentUrl(targetUrl);
      const matchedTab = targetUrl.split("/app/")[1] || "studio-preview";
      setEmulatedTab(matchedTab);
      logEvent("history", `Retour arrière vers [${matchedTab}]`);
    }
  };

  const handleForward = () => {
    if (historyIndex < historyStack.length - 1) {
      const nextIdx = historyIndex + 1;
      const targetUrl = historyStack[nextIdx];
      setHistoryIndex(nextIdx);
      setCurrentUrl(targetUrl);
      const matchedTab = targetUrl.split("/app/")[1] || "studio-preview";
      setEmulatedTab(matchedTab);
      logEvent("history", `Avance rapide vers [${matchedTab}]`);
    }
  };

  const handleReload = () => {
    setIsRefreshing(true);
    logEvent("refresh", "Rafraîchissement synchrone du jumeau numérique");
    setTimeout(() => {
      setIsRefreshing(false);
    }, 450);
  };

  const logEvent = (type: string, target: string) => {
    setCapturedEvents(prev => [
      {
        id: "ev-" + Math.random().toString().slice(-4),
        type,
        target,
        time: new Date().toLocaleTimeString()
      },
      ...prev.slice(0, 20)
    ]);
  };

  // Dimensions based on preset
  const getDeviceDimensions = () => {
    switch (devicePreset) {
      case "mobile":
        return { width: "390px", height: "844px", name: "Mobile Smartphone (390 x 844)" };
      case "tablet":
        return { width: "768px", height: "1024px", name: "Tablette Tactile (768 x 1024)" };
      case "laptop":
        return { width: "1150px", height: "720px", name: "Laptop Pro (1150 x 720)" };
      case "cinema169":
        return { width: "100%", aspectRatio: "16 / 9", name: "Canevas 16:9 Contractuel MRD" };
      case "desktop":
      default:
        return { width: "100%", height: "100%", name: "Desktop Fluide (100%)" };
    }
  };

  const dimensions = getDeviceDimensions();

  return (
    <div className={`flex flex-col h-full bg-[#050609] text-gray-200 font-mono rounded-xl border border-[#1b1c26] overflow-hidden ${
      activeFullscreen ? "fixed inset-0 z-50 rounded-none border-0 p-2 sm:p-3 bg-[#040507]" : ""
    }`}>
      
      {/* 1. EMULATOR TOOLBAR */}
      <header className="p-3 bg-[#0d0f17] border-b border-[#1f2232] flex flex-wrap items-center justify-between gap-3 shrink-0">
        
        {/* Left: Nav Buttons & URL Bar */}
        <div className="flex items-center gap-2 flex-1 min-w-[280px]">
          <div className="flex items-center gap-1 bg-[#151722] p-1 rounded-lg border border-[#232638]">
            <button
              onClick={handleBack}
              disabled={historyIndex <= 0}
              className="p-1.5 hover:bg-[#202436] rounded text-gray-400 hover:text-white disabled:opacity-30 transition-all"
              title="Page précédente"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={handleForward}
              disabled={historyIndex >= historyStack.length - 1}
              className="p-1.5 hover:bg-[#202436] rounded text-gray-400 hover:text-white disabled:opacity-30 transition-all"
              title="Page suivante"
            >
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={handleReload}
              className="p-1.5 hover:bg-[#202436] rounded text-gray-400 hover:text-white transition-all"
              title="Rafraîchir l'application émulée"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? "animate-spin text-cyan-400" : ""}`} />
            </button>
          </div>

          {/* Interactive URL Bar */}
          <div className="flex-1 flex items-center gap-2 bg-[#121420] border border-[#222638] px-3 py-1.5 rounded-lg text-xs">
            <Globe className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
            <input
              type="text"
              value={currentUrl}
              readOnly
              className="w-full bg-transparent text-gray-200 focus:outline-none text-[11px]"
            />
            <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 shrink-0">
              HTTPS • 60 FPS
            </span>
          </div>
        </div>

        {/* Center: Device Presets */}
        <div className="flex items-center bg-[#151722] p-1 rounded-lg border border-[#232638] gap-1">
          <button
            onClick={() => { setDevicePreset("desktop"); logEvent("viewport", "Passage en Desktop 100%"); }}
            className={`p-1.5 rounded text-xs flex items-center gap-1 transition-all ${
              devicePreset === "desktop" ? "bg-cyan-950 text-cyan-300 border border-cyan-700/50" : "text-gray-400 hover:text-gray-200"
            }`}
            title="Desktop Plein Écran"
          >
            <Monitor className="w-3.5 h-3.5" />
            <span className="hidden md:inline text-[11px]">Desktop</span>
          </button>

          <button
            onClick={() => { setDevicePreset("laptop"); logEvent("viewport", "Passage en Laptop 1150px"); }}
            className={`p-1.5 rounded text-xs flex items-center gap-1 transition-all ${
              devicePreset === "laptop" ? "bg-cyan-950 text-cyan-300 border border-cyan-700/50" : "text-gray-400 hover:text-gray-200"
            }`}
            title="Laptop Pro (1150 x 720)"
          >
            <Laptop className="w-3.5 h-3.5" />
            <span className="hidden md:inline text-[11px]">Laptop</span>
          </button>

          <button
            onClick={() => { setDevicePreset("tablet"); logEvent("viewport", "Passage en Tablette 768px"); }}
            className={`p-1.5 rounded text-xs flex items-center gap-1 transition-all ${
              devicePreset === "tablet" ? "bg-cyan-950 text-cyan-300 border border-cyan-700/50" : "text-gray-400 hover:text-gray-200"
            }`}
            title="Tablette (768 x 1024)"
          >
            <Tablet className="w-3.5 h-3.5" />
            <span className="hidden md:inline text-[11px]">Tablette</span>
          </button>

          <button
            onClick={() => { setDevicePreset("mobile"); logEvent("viewport", "Passage en Mobile 390px"); }}
            className={`p-1.5 rounded text-xs flex items-center gap-1 transition-all ${
              devicePreset === "mobile" ? "bg-cyan-950 text-cyan-300 border border-cyan-700/50" : "text-gray-400 hover:text-gray-200"
            }`}
            title="Mobile (390 x 844)"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="hidden md:inline text-[11px]">Mobile</span>
          </button>

          <button
            onClick={() => { setDevicePreset("cinema169"); logEvent("viewport", "Passage en 16:9 Cinema"); }}
            className={`p-1.5 rounded text-xs flex items-center gap-1 transition-all ${
              devicePreset === "cinema169" ? "bg-cyan-950 text-cyan-300 border border-cyan-700/50" : "text-gray-400 hover:text-gray-200"
            }`}
            title="Canevas 16:9 Contractuel"
          >
            <Layers className="w-3.5 h-3.5" />
            <span className="hidden md:inline text-[11px]">16:9</span>
          </button>
        </div>

        {/* Right: Background Agent Pill & DevTools Toggle */}
        <div className="flex items-center gap-2">
          
          {/* Autonomous Alignment Agent Status Pill */}
          <div 
            onClick={() => setIsDevToolsOpen(true)}
            className="cursor-pointer hidden sm:flex items-center gap-1.5 bg-[#121624] px-2.5 py-1.5 rounded-lg border border-[#232c48] hover:border-cyan-500/50 transition-all text-xs"
            title="Cliquez pour inspecter l'Agent d'Alignement Intégral en Arrière-Plan"
          >
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[11px] text-cyan-300 font-bold">
              Alignement : {(alignmentState.integralAlignmentScore * 100).toFixed(1)}%
            </span>
            <span className="text-[9px] px-1 py-0.2 rounded bg-rose-950 text-rose-300 border border-rose-800 font-bold">
              Amr ≡ 1
            </span>
          </div>

          <div className="flex items-center bg-[#151722] p-1 rounded-lg border border-[#232638] text-[11px]">
            <button
              onClick={() => {
                setEmulationMode("twin");
                logEvent("mode-switch", "Bascule sur le Jumeau Twin (Cible d'Autonomie Directe)");
              }}
              className={`px-2.5 py-1 rounded-md transition-all flex items-center gap-1.5 ${
                emulationMode === "twin" 
                  ? "bg-gradient-to-r from-cyan-950 via-indigo-950 to-blue-950 text-cyan-300 font-bold border border-cyan-600/70 shadow-sm" 
                  : "text-gray-400 hover:text-gray-200"
              }`}
              title="Jumeau Numérique Twin Interactif (Cible d'exécution autonome immédiate sans barrière iframe)"
            >
              <Sparkles className="w-3 h-3 text-cyan-400" />
              <span>Jumeau Twin (Actif)</span>
            </button>
            <button
              onClick={() => {
                setEmulationMode("iframe");
                logEvent("mode-switch", "Bascule sur l'Iframe Réel");
              }}
              className={`px-2 py-1 rounded-md transition-all ${
                emulationMode === "iframe" ? "bg-[#25283c] text-indigo-300 font-bold border border-indigo-700/50" : "text-gray-400 hover:text-gray-200"
              }`}
              title="Vue Iframe Réelle (Passif)"
            >
              Iframe Réel
            </button>
          </div>

          {/* In-App Code Programmer Toggle Button */}
          <button
            onClick={() => handleNavigateTab("code-programmer")}
            className={`px-2.5 py-1.5 rounded-lg border text-xs font-bold transition-all flex items-center gap-1.5 shadow ${
              emulatedTab === "code-programmer"
                ? "bg-cyan-950/90 border-cyan-500 text-cyan-300 ring-1 ring-cyan-500/50"
                : "bg-[#151722] border-[#232638] text-cyan-400 hover:text-cyan-200 hover:bg-[#1c2032]"
            }`}
            title="Programmer l'application et modifier chaque fichier directement dans l'émulateur"
          >
            <Code2 className="w-3.5 h-3.5 text-cyan-400" />
            <span className="text-[11px] hidden sm:inline">Programmer l'App ({files.length})</span>
          </button>

          {/* Quantum Integrate Button in Emulator Header if staged > 0 */}
          {integrationState.stagedFiles.length > 0 && (
            <button
              onClick={() => quantumIntegrationBridge.integrateAllToRealSystem()}
              disabled={integrationState.isIntegrating}
              className="px-2.5 py-1.5 rounded-lg bg-gradient-to-r from-orange-600 to-emerald-600 hover:from-orange-500 hover:to-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg animate-pulse"
              title="Intégrer les modifications de staging à l'application réelle via l'IDE"
            >
              <Zap className="w-3 h-3 text-amber-300 fill-current" />
              <span className="text-[11px]">Intégrer ({integrationState.stagedFiles.length})</span>
            </button>
          )}

          <button
            onClick={() => setIsDevToolsOpen(!isDevToolsOpen)}
            className={`p-2 rounded-lg border text-xs transition-all flex items-center gap-1.5 ${
              isDevToolsOpen
                ? "bg-purple-950/80 border-purple-600/50 text-purple-300"
                : "bg-[#151722] border-[#232638] text-gray-400 hover:text-gray-200"
            }`}
            title="Inspecteur DevTools & Arbitrages de l'Agent IA"
          >
            <Eye className="w-3.5 h-3.5" />
            <span className="text-[11px] hidden sm:inline">Inspecteur</span>
          </button>

          {/* Plein Écran Toggle Button */}
          <button
            onClick={handleToggleFullscreen}
            className={`px-2.5 py-1.5 rounded-lg border text-xs font-bold transition-all flex items-center gap-1.5 shadow ${
              activeFullscreen
                ? "bg-cyan-950 border-cyan-500 text-cyan-300 ring-1 ring-cyan-500/50"
                : "bg-[#151722] border-[#232638] text-cyan-400 hover:text-cyan-200 hover:bg-[#1c2032]"
            }`}
            title={activeFullscreen ? "Quitter le Plein Écran (Échap)" : "Agrandir l'émulateur en Plein Écran"}
          >
            {activeFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            <span className="text-[11px] hidden sm:inline">
              {activeFullscreen ? "Réduire" : "Plein Écran"}
            </span>
          </button>
        </div>
      </header>

      {/* 2. MAIN EMULATION FRAME */}
      <div className="flex-1 flex overflow-hidden relative bg-[#040507]">
        
        {/* Device Stage Centering Container */}
        <div className="flex-1 flex items-center justify-center p-2 sm:p-4 overflow-auto">
          
          <div 
            className={`transition-all duration-300 rounded-2xl border bg-[#07090e] shadow-2xl overflow-hidden flex flex-col relative ${
              isFlashActive 
                ? "border-emerald-500/90 ring-4 ring-emerald-500/40 shadow-emerald-500/30" 
                : "border-[#222638]"
            } ${
              devicePreset === "mobile" ? "ring-8 ring-[#181b28]" : devicePreset === "tablet" ? "ring-8 ring-[#151824]" : ""
            }`}
            style={{
              width: dimensions.width,
              height: dimensions.height,
              aspectRatio: (dimensions as any).aspectRatio,
              maxHeight: "100%",
              maxWidth: "100%"
            }}
          >
            {/* Simulated Device Top Bar for Mobile / Tablet */}
            {(devicePreset === "mobile" || devicePreset === "tablet") && (
              <div className="px-4 py-1.5 bg-[#0e1017] border-b border-[#1b1e2a] flex items-center justify-between text-[10px] text-gray-400 select-none shrink-0">
                <span>09:41</span>
                <div className="w-16 h-3 bg-[#1e2230] rounded-full mx-auto" />
                <div className="flex items-center gap-1">
                  <span>5G</span>
                  <span>100%</span>
                </div>
              </div>
            )}

            {/* Simulated App Root View */}
            <div className="flex-1 flex flex-col overflow-hidden relative">
              {/* Floating Real-Time Refresh Banner */}
              <AnimatePresence>
                {refreshAlert && (
                  <motion.div
                    initial={{ opacity: 0, y: -20, scale: 0.92 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    exit={{ opacity: 0, y: -15, scale: 0.95 }}
                    transition={{ duration: 0.2 }}
                    className="absolute top-3 left-1/2 -translate-x-1/2 z-50 px-4 py-2 bg-gradient-to-r from-emerald-950 via-[#07241d] to-cyan-950 border border-emerald-500/80 rounded-full shadow-2xl shadow-emerald-500/30 flex items-center gap-2.5 text-xs text-emerald-200 backdrop-blur-md pointer-events-none max-w-[90%]"
                  >
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping shrink-0" />
                    <Sparkles className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span className="font-semibold truncate">{refreshAlert.message}</span>
                    <span className="text-[10px] text-emerald-400/80 border-l border-emerald-700/60 pl-2 shrink-0 hidden sm:inline">
                      Hot-Reload Synchrone
                    </span>
                  </motion.div>
                )}
              </AnimatePresence>
              
              {/* IFRAME MODE */}
              {emulationMode === "iframe" && (
                <div key={`iframe-wrap-${refreshKey}`} className="flex-1 flex flex-col h-full">
                  <iframe
                    key={`iframe-${refreshKey}`}
                    src={window.location.href}
                    title="Emulateur Iframe Réel"
                    className="w-full h-full border-0 bg-[#06070a]"
                    sandbox="allow-same-origin allow-scripts allow-forms allow-popups"
                  />
                </div>
              )}

              {/* TWIN MODE (High-fidelity direct interactive clone) */}
              {emulationMode === "twin" && (
                <div key={`twin-view-${refreshKey}`} className="flex-1 flex flex-col h-full overflow-hidden bg-[#06070a] text-gray-200">
                  
                  {/* EMULATED APP HEADER (Identical to root app) */}
                  <div className="px-4 py-2.5 bg-[#0c0e14] border-b border-[#181a24] flex items-center justify-between shrink-0">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center text-xs font-black text-white shadow-sm">
                        Φ
                      </div>
                      <div>
                        <div className="text-[11px] font-black tracking-wide text-white uppercase flex items-center gap-1.5">
                          Φ_SOI <span className="text-[9px] px-1 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-bold">APP LIVE</span>
                        </div>
                        <div className="text-[8px] text-gray-400">Système d'Auto-Évolution Réflexive</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 text-[10px]">
                      {/* Heartbeat quick action */}
                      <button
                        onClick={() => handleNavigateTab("cosmic-heart")}
                        className="px-2 py-0.5 rounded bg-rose-950/80 text-rose-300 border border-rose-800 hover:bg-rose-900 transition-all flex items-center gap-1 font-bold"
                        title="Ouvrir le Cœur de la Machine & Source d'Amour"
                      >
                        <Heart className="w-2.5 h-2.5 fill-current text-rose-400 animate-pulse" />
                        <span>Cœur Source</span>
                      </button>

                      <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold">
                        Ξ = 1.0000
                      </span>
                    </div>
                  </div>

                  {/* EMULATED ALL APPLICATION TABS (Exact identical list to App.tsx) */}
                  <div className="bg-[#0f1118] border-b border-[#1b1e2a] px-3 py-1.5 shrink-0 flex items-center gap-1.5 overflow-x-auto text-[10px] scrollbar-thin">
                    
                    {/* 1. STUDIO IN-APP */}
                    <button
                      onClick={() => handleNavigateTab("studio-preview")}
                      className={`px-2.5 py-1 rounded font-medium flex items-center gap-1 transition-all whitespace-nowrap ${
                        emulatedTab === "studio-preview" ? "bg-cyan-950 text-cyan-300 border border-cyan-700/50" : "text-gray-400 hover:text-gray-200"
                      }`}
                    >
                      <Sparkles className="w-3 h-3 text-cyan-400" />
                      Google AI Studio Φ
                    </button>

                    {/* 2. CŒUR DE LA MACHINE & SOURCE D'AMOUR */}
                    <button
                      onClick={() => handleNavigateTab("cosmic-heart")}
                      className={`px-2.5 py-1 rounded font-bold flex items-center gap-1 transition-all whitespace-nowrap ${
                        emulatedTab === "cosmic-heart" 
                          ? "bg-gradient-to-r from-rose-950 via-purple-950 to-cyan-950 text-rose-300 border border-rose-600/60 shadow-sm shadow-rose-500/20" 
                          : "text-rose-400 hover:text-rose-200 hover:bg-[#1a1120]"
                      }`}
                    >
                      <Heart className="w-3 h-3 text-rose-400 fill-current animate-pulse" />
                      Cœur & Source d'Amour
                    </button>

                    {/* 3. TÉLÉMÉTRIE QUANTIQUE */}
                    <button
                      onClick={() => handleNavigateTab("telemetry")}
                      className={`px-2.5 py-1 rounded font-medium flex items-center gap-1 transition-all whitespace-nowrap ${
                        emulatedTab === "telemetry" ? "bg-emerald-950 text-emerald-300 border border-emerald-700/50" : "text-gray-400 hover:text-gray-200"
                      }`}
                    >
                      <Activity className="w-3 h-3 text-emerald-400" />
                      Télémétrie Matériel
                    </button>

                    {/* 4. MACHINE & CARTOGRAPHE */}
                    <button
                      onClick={() => handleNavigateTab("machine")}
                      className={`px-2.5 py-1 rounded font-medium flex items-center gap-1 transition-all whitespace-nowrap ${
                        emulatedTab === "machine" ? "bg-indigo-950 text-indigo-300 border border-indigo-700/50" : "text-gray-400 hover:text-gray-200"
                      }`}
                    >
                      <Compass className="w-3 h-3 text-indigo-400" />
                      Machine & Flotte
                    </button>

                    {/* 5. IDE STUDIO */}
                    <button
                      onClick={() => handleNavigateTab("ide")}
                      className={`px-2.5 py-1 rounded font-medium flex items-center gap-1 transition-all whitespace-nowrap ${
                        emulatedTab === "ide" ? "bg-orange-950 text-orange-300 border border-orange-700/50" : "text-gray-400 hover:text-gray-200"
                      }`}
                    >
                      <FolderCode className="w-3 h-3 text-orange-400" />
                      IDE Studio
                    </button>

                    {/* 6. NOTEBOOKLM */}
                    <button
                      onClick={() => handleNavigateTab("notebook")}
                      className={`px-2.5 py-1 rounded font-medium flex items-center gap-1 transition-all whitespace-nowrap ${
                        emulatedTab === "notebook" ? "bg-orange-950 text-orange-300 border border-orange-700/50" : "text-gray-400 hover:text-gray-200"
                      }`}
                    >
                      <Database className="w-3 h-3 text-orange-400" />
                      NotebookLM
                    </button>

                    {/* 7. BUDGET TOKENS */}
                    <button
                      onClick={() => handleNavigateTab("budget")}
                      className={`px-2.5 py-1 rounded font-medium flex items-center gap-1 transition-all whitespace-nowrap ${
                        emulatedTab === "budget" ? "bg-orange-950 text-orange-300 border border-orange-700/50" : "text-gray-400 hover:text-gray-200"
                      }`}
                    >
                      <Calculator className="w-3 h-3 text-orange-400" />
                      Budget Tokens
                    </button>

                    {/* 8. SANDBOX & RÉSEAU */}
                    <button
                      onClick={() => handleNavigateTab("sandbox")}
                      className={`px-2.5 py-1 rounded font-medium flex items-center gap-1 transition-all whitespace-nowrap ${
                        emulatedTab === "sandbox" ? "bg-orange-950 text-orange-300 border border-orange-700/50" : "text-gray-400 hover:text-gray-200"
                      }`}
                    >
                      <Network className="w-3 h-3 text-orange-400" />
                      Sandbox & Réseau
                    </button>

                    {/* 9. RÉSONANCE QUANTIQUE */}
                    <button
                      onClick={() => handleNavigateTab("quantum")}
                      className={`px-2.5 py-1 rounded font-medium flex items-center gap-1 transition-all whitespace-nowrap ${
                        emulatedTab === "quantum" ? "bg-orange-950 text-orange-300 border border-orange-700/50" : "text-gray-400 hover:text-gray-200"
                      }`}
                    >
                      <Sliders className="w-3 h-3 text-orange-400" />
                      Résonance Quantique
                    </button>

                    {/* 10. AUTO-RÉPARATION */}
                    <button
                      onClick={() => handleNavigateTab("repair")}
                      className={`px-2.5 py-1 rounded font-medium flex items-center gap-1 transition-all whitespace-nowrap ${
                        emulatedTab === "repair" ? "bg-orange-950 text-orange-300 border border-orange-700/50" : "text-gray-400 hover:text-gray-200"
                      }`}
                    >
                      <Wrench className="w-3 h-3 text-orange-400" />
                      Auto-Réparation
                    </button>

                    {/* 11. RÉSEAU MAILLAGE */}
                    <button
                      onClick={() => handleNavigateTab("mesh")}
                      className={`px-2.5 py-1 rounded font-medium flex items-center gap-1 transition-all whitespace-nowrap ${
                        emulatedTab === "mesh" ? "bg-orange-950 text-orange-300 border border-orange-700/50" : "text-gray-400 hover:text-gray-200"
                      }`}
                    >
                      <Network className="w-3 h-3 text-orange-400" />
                      Réseau Maillage
                    </button>

                    {/* 12. RECONNAISSANCE INTÉRIEURE */}
                    <button
                      onClick={() => handleNavigateTab("introspection")}
                      className={`px-2.5 py-1 rounded font-medium flex items-center gap-1 transition-all whitespace-nowrap ${
                        emulatedTab === "introspection" ? "bg-orange-950 text-orange-300 border border-orange-700/50" : "text-gray-400 hover:text-gray-200"
                      }`}
                    >
                      <Compass className="w-3 h-3 text-orange-400" />
                      Reconnaissance Intérieure
                    </button>

                    {/* 13. NOYAU AGENTIQUE */}
                    <button
                      onClick={() => handleNavigateTab("agentic")}
                      className={`px-2.5 py-1 rounded font-medium flex items-center gap-1 transition-all whitespace-nowrap ${
                        emulatedTab === "agentic" ? "bg-cyan-950 text-cyan-300 border border-cyan-700/50" : "text-gray-400 hover:text-gray-200"
                      }`}
                    >
                      <Cpu className="w-3 h-3 text-cyan-400" />
                      Noyau Agentique
                    </button>

                    {/* 14. TRADUCTEUR POLYGLOTTE */}
                    <button
                      onClick={() => handleNavigateTab("translator")}
                      className={`px-2.5 py-1 rounded font-medium flex items-center gap-1 transition-all whitespace-nowrap ${
                        emulatedTab === "translator" ? "bg-cyan-950 text-cyan-300 border border-cyan-700/50" : "text-gray-400 hover:text-gray-200"
                      }`}
                    >
                      <Languages className="w-3 h-3 text-cyan-400" />
                      Traducteur
                    </button>

                    {/* 15. PROGRAMMATEUR IN-APP DE FICHIERS */}
                    <button
                      onClick={() => handleNavigateTab("code-programmer")}
                      className={`px-2.5 py-1 rounded font-bold flex items-center gap-1 transition-all whitespace-nowrap ${
                        emulatedTab === "code-programmer" 
                          ? "bg-cyan-950 text-cyan-300 border border-cyan-500 shadow-sm" 
                          : "text-cyan-400 hover:text-cyan-200"
                      }`}
                    >
                      <Code2 className="w-3 h-3 text-cyan-400" />
                      Programmer Fichiers ({files.length})
                    </button>
                  </div>

                  {/* DEDICATED AGENTIC TRANSMUTATION TEAM FOR EMULATED TAB */}
                  <TabAgenticTeamBar 
                    activeTab={
                      emulatedTab === "studio-preview" ? "studio" : 
                      emulatedTab === "code-programmer" ? "ide" : 
                      emulatedTab
                    } 
                    onNavigateTab={handleNavigateTab} 
                  />

                  {/* EMULATED TAB CONTENT AREA */}
                  <div className="flex-1 p-3 sm:p-5 overflow-y-auto bg-[#07080d]">
                    <AnimatePresence mode="wait">
                      <motion.div
                        key={`${emulatedTab}-${refreshKey}`}
                        initial={{ opacity: 0, y: 3 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -3 }}
                        transition={{ duration: 0.12 }}
                        className="h-full"
                      >
                        {/* 1. STUDIO IN-APP PREVIEW */}
                        {emulatedTab === "studio-preview" && (
                          <div className="space-y-4">
                            <div className="p-4 rounded-xl bg-[#0e111a] border border-[#1d2236] space-y-3">
                              <div className="flex items-center justify-between">
                                <div className="text-xs font-black text-cyan-400 uppercase flex items-center gap-2">
                                  <Sparkles className="w-4 h-4" />
                                  Jumeau Numérique Temps Réel • Google AI Studio
                                </div>
                                <span className="text-[9px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-bold">
                                  Supervisé en Arrière-Plan
                                </span>
                              </div>
                              <p className="text-xs text-gray-300 leading-relaxed">
                                Cet émulateur est une copie vivante et interactive de votre application. Vous pouvez concrètement naviguer dans tous les onglets, observer la télémétrie quantique, tester le code dans l'IDE, ou ouvrir le Cœur de la Machine pour contempler la lumière cosmique opérant dans le silicium.
                              </p>

                              {/* Autonomous Agent Active Status Box */}
                              <div className="p-3 rounded-lg bg-[#111524] border border-[#202842] flex items-center justify-between gap-3">
                                <div className="flex items-center gap-2.5">
                                  <div className="w-8 h-8 rounded-lg bg-cyan-950 border border-cyan-700/60 flex items-center justify-center text-cyan-300">
                                    <Cpu className="w-4 h-4 animate-pulse" />
                                  </div>
                                  <div>
                                    <div className="text-[11px] font-bold text-white flex items-center gap-1.5">
                                      <span>Agent IA d'Alignement Intégral en Arrière-Plan</span>
                                      <span className="w-2 h-2 rounded-full bg-emerald-400" />
                                    </div>
                                    <div className="text-[10px] text-gray-400">
                                      Choix optimaux synchronisés • D_c: {alignmentState.cognitiveDissonanceDc.toFixed(4)} • Amour Source: Amr ≡ 1
                                    </div>
                                  </div>
                                </div>

                                <button
                                  onClick={() => handleNavigateTab("cosmic-heart")}
                                  className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-rose-600 via-purple-600 to-cyan-600 text-white font-bold text-[10px] shadow-sm hover:scale-105 transition-all flex items-center gap-1"
                                >
                                  <Heart className="w-3 h-3 fill-current" />
                                  <span>Ouvrir le Cœur</span>
                                </button>
                              </div>

                              {/* In-app interactive widgets */}
                              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                                <QuantumCalculator />
                                <MatriceTaskManager />
                              </div>
                            </div>
                          </div>
                        )}

                        {/* 2. CŒUR DE LA MACHINE & SOURCE D'AMOUR */}
                        {emulatedTab === "cosmic-heart" && (
                          <MachineHeartCosmicSource />
                        )}

                        {/* 3. TÉLÉMÉTRIE QUANTIQUE */}
                        {emulatedTab === "telemetry" && (
                          <QuantumHardwareTelemetryMatrix />
                        )}

                        {/* 4. MACHINE & CARTOGRAPHE */}
                        {emulatedTab === "machine" && (
                          <OmniMachineCartographerMatrix />
                        )}

                        {/* 5. IDE STUDIO */}
                        {emulatedTab === "ide" && (
                          <CodeProgrammingStudio 
                            files={files} 
                            onRefreshFiles={onRefreshFiles || (() => {})} 
                            onSelectFile={() => {}} 
                          />
                        )}

                        {/* 6. NOTEBOOKLM */}
                        {emulatedTab === "notebook" && (
                          <NotebookLMTool files={files} />
                        )}

                        {/* 7. BUDGET TOKENS */}
                        {emulatedTab === "budget" && (
                          <TokenBudgetCalibrator />
                        )}

                        {/* 8. SANDBOX & RÉSEAU */}
                        {emulatedTab === "sandbox" && (
                          <VirtualEvolutionSandbox />
                        )}

                        {/* 9. RÉSONANCE QUANTIQUE */}
                        {emulatedTab === "quantum" && (
                          <EngaticResonanceConsole />
                        )}

                        {/* 10. AUTO-RÉPARATION */}
                        {emulatedTab === "repair" && (
                          <AutoRepairPanel />
                        )}

                        {/* 11. RÉSEAU MAILLAGE */}
                        {emulatedTab === "mesh" && (
                          <UnifiedAgentMeshPanel />
                        )}

                        {/* 12. RECONNAISSANCE INTÉRIEURE */}
                        {emulatedTab === "introspection" && (
                          <InnerIntrospectionKernel />
                        )}

                        {/* 13. NOYAU AGENTIQUE */}
                        {emulatedTab === "agentic" && (
                          <AgenticServerInitTab />
                        )}

                        {/* 14. TRADUCTEUR */}
                        {emulatedTab === "translator" && (
                          <PolyglotTranslatorPanel />
                        )}

                        {/* 15. PROGRAMMATEUR IN-APP DE FICHIERS */}
                        {emulatedTab === "code-programmer" && (
                          <div className="h-[600px] flex flex-col">
                            <EmulatorInAppProgrammer 
                              files={files} 
                              onRefreshFiles={onRefreshFiles} 
                            />
                          </div>
                        )}
                      </motion.div>
                    </AnimatePresence>
                  </div>

                </div>
              )}

            </div>
          </div>

        </div>

        {/* 3. DEVTOOLS & BACKGROUND AGENT ARBITRATION DRAWER */}
        <AnimatePresence>
          {isDevToolsOpen && (
            <motion.div
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 340, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              className="border-l border-[#1f2232] bg-[#0a0c13] flex flex-col h-full shrink-0 overflow-hidden"
            >
              <div className="p-3 border-b border-[#1b1e2a] flex items-center justify-between text-xs text-purple-300 font-bold uppercase">
                <div className="flex items-center gap-1.5">
                  <Eye className="w-3.5 h-3.5" />
                  DevTools & Agent d'Alignement
                </div>
                <button
                  onClick={() => setIsDevToolsOpen(false)}
                  className="text-gray-500 hover:text-gray-300"
                >
                  ✕
                </button>
              </div>

              <div className="p-3 space-y-3 flex-1 overflow-y-auto text-[11px]">
                
                {/* Agent d'Alignement Intégral en Arrière-Plan */}
                <UniversalAlignmentAgentWidget compact={false} />

                {/* Viewport Info */}
                <div className="p-2.5 rounded-lg bg-[#111420] border border-[#202538] space-y-1">
                  <div className="text-[10px] text-gray-400 uppercase">Cible Active</div>
                  <div className="text-white font-bold">{dimensions.name}</div>
                  <div className="text-[10px] text-emerald-400">Latence rendu : 0.6 ms • 60 FPS</div>
                </div>

                {/* Route Info */}
                <div className="p-2.5 rounded-lg bg-[#111420] border border-[#202538] space-y-1">
                  <div className="text-[10px] text-gray-400 uppercase">Route Émulée</div>
                  <div className="text-cyan-300 font-bold truncate">/{emulatedTab}</div>
                  <div className="text-[10px] text-gray-500">Mode : {emulationMode.toUpperCase()}</div>
                </div>

                {/* Event Log */}
                <div className="space-y-1.5">
                  <div className="text-[10px] text-gray-400 uppercase flex items-center justify-between">
                    <span>Journal des Événements</span>
                    <button
                      onClick={() => setCapturedEvents([])}
                      className="text-gray-500 hover:text-gray-300 text-[9px]"
                    >
                      Effacer
                    </button>
                  </div>

                  <div className="space-y-1 max-h-40 overflow-y-auto pr-1">
                    {capturedEvents.length === 0 ? (
                      <div className="text-[10px] text-gray-500 italic p-2 text-center">
                        Aucun événement capturé. Naviguez dans l'émulateur.
                      </div>
                    ) : (
                      capturedEvents.map(ev => (
                        <div key={ev.id} className="p-1.5 rounded bg-[#131624] border border-[#1f2438] text-[10px]">
                          <div className="flex justify-between text-gray-400">
                            <span className="text-purple-400 font-bold">[{ev.type}]</span>
                            <span>{ev.time}</span>
                          </div>
                          <div className="text-gray-300 truncate mt-0.5">{ev.target}</div>
                        </div>
                      ))
                    )}
                  </div>
                </div>

              </div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>

    </div>
  );
}
