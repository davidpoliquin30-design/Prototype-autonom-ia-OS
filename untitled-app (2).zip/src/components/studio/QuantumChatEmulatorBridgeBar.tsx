import React, { useState, useEffect } from "react";
import { 
  Zap, Bot, Cpu, ArrowRight, CheckCircle2, RefreshCw, 
  RotateCcw, Sparkles, Activity, ShieldCheck, FileCode,
  Eye, Check, ChevronDown, ChevronUp, Layers
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { 
  studioChatAutonomousTeam, 
  StudioChatTeamState,
  AutonomousExecutionRecord 
} from "../../services/quantum/studioChatAutonomousTeam";
import { 
  universalAlignmentAgent, 
  AlignmentSystemState 
} from "../../services/agent/universalAlignmentAgent";

interface QuantumChatEmulatorBridgeBarProps {
  onNavigateToEmulator?: () => void;
  compact?: boolean;
}

export default function QuantumChatEmulatorBridgeBar({ 
  onNavigateToEmulator,
  compact = false 
}: QuantumChatEmulatorBridgeBarProps) {
  const [state, setState] = useState<StudioChatTeamState>(studioChatAutonomousTeam.getState());
  const [alignmentState, setAlignmentState] = useState<AlignmentSystemState>(universalAlignmentAgent.getState());
  const [showHistory, setShowHistory] = useState<boolean>(false);
  const [revertingId, setRevertingId] = useState<string | null>(null);
  const [isAligning, setIsAligning] = useState<boolean>(false);

  useEffect(() => {
    const unsubTeam = studioChatAutonomousTeam.subscribe(setState);
    const unsubAlign = universalAlignmentAgent.subscribe(setAlignmentState);
    return () => {
      unsubTeam();
      unsubAlign();
    };
  }, []);

  const handleAlignAgents = () => {
    setIsAligning(true);
    universalAlignmentAgent.forceIntegralHarmonization();
    setTimeout(() => setIsAligning(false), 800);
  };

  const handleRevert = async (id: string) => {
    setRevertingId(id);
    await studioChatAutonomousTeam.revertExecution(id);
    setRevertingId(null);
  };

  const agents = [
    { id: "@ai_version_selector_expert", label: "@ai_version_selector_expert", pole: "Optimisation", desc: "Arbitrage de version IA" },
    { id: "@supervisor", label: "@supervisor", pole: "Gouvernance", desc: "Cadrage ontologique" },
    { id: "@quantum_prompt_equation_analyzer", label: "@analyzer", pole: "Intuition", desc: "AST & contexte" },
    { id: "@pro_coder", label: "@pro_coder", pole: "Code", desc: "Synthèse sans IA Slop" },
    { id: "@sentinel_auto_reconfigurator", label: "@sentinel", pole: "Immunité", desc: "Audit & validation" },
    { id: "@live_ide_executor", label: "@executor", pole: "Exécution", desc: "Écriture physique" },
    { id: "@omni_quantum_cartographer", label: "@cartographer", pole: "Émulateur", desc: "Hot-reload live" },
    { id: "@human_language_master", label: "@human_master", pole: "Direction", desc: "Langage humain & conseils" },
  ];

  return (
    <div className="bg-[#080a12] border-b border-[#1c2238] text-gray-200 font-mono text-xs select-none">
      
      {/* Primary Bar */}
      <div className="px-3.5 py-2 flex flex-wrap items-center justify-between gap-2.5">
        
        {/* Left: Team Identity & Status */}
        <div className="flex items-center gap-2.5">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-gradient-to-r from-cyan-950 via-indigo-950 to-purple-950 border border-cyan-500/40 shadow-sm">
            <Zap className="w-3.5 h-3.5 text-cyan-400 fill-current animate-pulse" />
            <span className="font-black tracking-wider text-[11px] text-cyan-200 uppercase">
              Équipe Agentique Quantique
            </span>
            <span className="text-[9px] px-1.5 py-0.2 rounded bg-cyan-900/60 text-cyan-300 font-bold border border-cyan-700/50">
              Chat ⇄ Émulateur
            </span>
          </div>

          {/* Autonomy Toggle Button */}
          <button
            onClick={() => studioChatAutonomousTeam.toggleAutonomousMode()}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all border ${
              state.isAutonomousModeActive
                ? "bg-emerald-950 text-emerald-300 border-emerald-700 shadow-sm shadow-emerald-900/20"
                : "bg-[#121524] text-gray-400 border-[#262c45] hover:text-gray-200"
            }`}
            title="Activer ou désactiver l'exécution autonome directe des demandes de changement"
          >
            <span className={`w-2 h-2 rounded-full ${state.isAutonomousModeActive ? "bg-emerald-400 animate-ping" : "bg-gray-500"}`} />
            <span>Autonomie : {state.isAutonomousModeActive ? "ACTIVÉE ⚡" : "MANUELLE"}</span>
          </button>

          {/* Align Agents Button */}
          <button
            onClick={handleAlignAgents}
            disabled={isAligning}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all border ${
              isAligning
                ? "bg-purple-900 text-white border-purple-400 animate-pulse"
                : "bg-gradient-to-r from-purple-950 via-indigo-950 to-cyan-950 text-purple-200 border-purple-700/60 hover:border-purple-400 hover:text-white"
            }`}
            title="Harmoniser et aligner instantanément les 8 agents IA (Ξ ≡ 1, D_c → 0, Amr ≡ 1)"
          >
            <Sparkles className={`w-3.5 h-3.5 text-purple-300 ${isAligning ? "animate-spin" : ""}`} />
            <span>{isAligning ? "Harmonisation..." : "Aligner les Agents"}</span>
            <span className="text-[9px] px-1 py-0.2 rounded bg-purple-900/80 text-purple-300 border border-purple-600/40">
              Ξ={(alignmentState.integralAlignmentScore * 1).toFixed(3)}
            </span>
          </button>
        </div>

        {/* Center: Realtime 6-Agent Synaptic Pipeline */}
        <div className="hidden xl:flex items-center gap-1 bg-[#05060b] px-2 py-1 rounded-lg border border-[#1b2034]">
          {agents.map((ag, idx) => {
            const isActive = state.currentAgent === ag.id && state.isExecuting;
            return (
              <React.Fragment key={ag.id}>
                <div 
                  className={`px-1.5 py-0.5 rounded text-[10px] font-semibold transition-all flex items-center gap-1 ${
                    isActive 
                      ? "bg-cyan-600 text-white shadow-md shadow-cyan-500/30 scale-105 animate-pulse" 
                      : "text-gray-400 hover:text-gray-200"
                  }`}
                  title={`${ag.label} (${ag.pole}) : ${ag.desc}`}
                >
                  <span>{ag.label}</span>
                </div>
                {idx < agents.length - 1 && (
                  <ArrowRight className="w-2.5 h-2.5 text-gray-600 shrink-0" />
                )}
              </React.Fragment>
            );
          })}
        </div>

        {/* Right: Last Action & History Toggle */}
        <div className="flex items-center gap-2">
          {state.lastExecution && (
            <div className="hidden md:flex items-center gap-1.5 text-[10px] bg-[#0e111d] px-2 py-1 rounded border border-[#222840] text-gray-300">
              <CheckCircle2 className="w-3 h-3 text-emerald-400 shrink-0" />
              <span className="truncate max-w-[170px]" title={state.lastExecution.userPrompt}>
                {state.lastExecution.userPrompt}
              </span>
              <span className="text-cyan-400 font-bold">({state.lastExecution.latencyTotalMs}ms)</span>
            </div>
          )}

          {state.executionHistory.length > 0 && (
            <button
              onClick={() => setShowHistory(!showHistory)}
              className="flex items-center gap-1 px-2 py-1 rounded bg-[#131627] hover:bg-[#1a1f36] text-[10px] text-cyan-300 border border-[#232945] transition-all"
            >
              <span>Actions ({state.executionHistory.length})</span>
              {showHistory ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
            </button>
          )}

          {onNavigateToEmulator && (
            <button
              onClick={onNavigateToEmulator}
              className="px-2 py-1 rounded bg-indigo-950/80 hover:bg-indigo-900 border border-indigo-700/60 text-indigo-300 text-[10px] font-bold flex items-center gap-1 transition-all"
              title="Voir directement dans l'émulateur"
            >
              <Eye className="w-3 h-3 text-indigo-400" />
              <span className="hidden sm:inline">Émulateur</span>
            </button>
          )}
        </div>
      </div>

      {/* Active Execution Animation Bar */}
      {state.isExecuting && (
        <div className="bg-[#0b0e1b] border-t border-[#1e253e] px-4 py-1.5 flex items-center justify-between text-[11px] text-cyan-300">
          <div className="flex items-center gap-2">
            <RefreshCw className="w-3.5 h-3.5 animate-spin text-cyan-400" />
            <span className="font-bold">{state.currentStage}</span>
          </div>
          <div className="flex items-center gap-3">
            <div className="w-32 bg-[#121626] rounded-full h-1.5 overflow-hidden border border-[#21273e]">
              <div 
                className="bg-gradient-to-r from-cyan-500 to-emerald-400 h-full transition-all duration-200"
                style={{ width: `${state.progressPercent}%` }}
              />
            </div>
            <span className="font-mono text-cyan-400 text-[10px]">{state.progressPercent}%</span>
          </div>
        </div>
      )}

      {/* Collapsible Execution History Drawer */}
      <AnimatePresence>
        {showHistory && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="border-t border-[#1a1f33] bg-[#05060b] p-3 space-y-2 overflow-hidden"
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-[10px] font-bold uppercase tracking-wider text-gray-400">
                Historique des transmutations autonomes (Chat ⇄ Émulateur)
              </span>
              <span className="text-[10px] text-gray-500">
                Total : {state.totalAutonomousExecutions} exécutions
              </span>
            </div>

            <div className="max-h-48 overflow-y-auto space-y-2 pr-1">
              {state.executionHistory.map((rec) => (
                <div 
                  key={rec.id}
                  className="p-2.5 rounded-lg bg-[#0a0d17] border border-[#1b2138] flex flex-wrap items-center justify-between gap-2 text-xs"
                >
                  <div className="flex items-center gap-2 flex-1 min-w-[200px]">
                    <span className="text-[10px] px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-400 border border-emerald-800">
                      ✓ Autonome
                    </span>
                    <span className="font-bold text-gray-200 truncate" title={rec.userPrompt}>
                      "{rec.userPrompt}"
                    </span>
                  </div>

                  <div className="flex items-center gap-3 text-[10px] text-gray-400">
                    <span className="text-cyan-400 font-mono">
                      {rec.targetFiles.join(", ")}
                    </span>
                    <span>{rec.timestamp}</span>
                    <button
                      onClick={() => handleRevert(rec.id)}
                      disabled={revertingId === rec.id}
                      className="px-2 py-0.5 rounded bg-red-950/60 hover:bg-red-900 border border-red-800 text-red-300 font-bold flex items-center gap-1 transition-all"
                      title="Annuler et restaurer le code précédent"
                    >
                      <RotateCcw className={`w-2.5 h-2.5 ${revertingId === rec.id ? "animate-spin" : ""}`} />
                      <span>Annuler</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
