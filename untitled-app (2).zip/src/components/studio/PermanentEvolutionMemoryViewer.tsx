import React, { useState, useEffect } from "react";
import { 
  Database, 
  History, 
  Sparkles, 
  ShieldCheck, 
  Search, 
  Download, 
  FileText, 
  Bot, 
  Clock, 
  CheckCircle2, 
  Layers, 
  ArrowUpRight,
  RefreshCw
} from "lucide-react";
import { permanentEvolutionMemory, EvolutionRecord } from "../../services/evolution/permanentEvolutionMemory";

export const PermanentEvolutionMemoryViewer: React.FC<{
  onSelectFile?: (filePath: string) => void;
  compact?: boolean;
}> = ({ onSelectFile, compact = false }) => {
  const [records, setRecords] = useState<EvolutionRecord[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedRecord, setSelectedRecord] = useState<EvolutionRecord | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  useEffect(() => {
    const unsub = permanentEvolutionMemory.subscribe((data) => {
      setRecords(data);
      if (!selectedRecord && data.length > 0) {
        setSelectedRecord(data[0]);
      }
    });

    const handleEvolutionRecorded = () => {
      permanentEvolutionMemory.loadInitialMemory();
    };

    window.addEventListener("phi-soi-evolution-recorded", handleEvolutionRecorded);
    return () => {
      unsub();
      window.removeEventListener("phi-soi-evolution-recorded", handleEvolutionRecorded);
    };
  }, []);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await permanentEvolutionMemory.loadInitialMemory();
    setTimeout(() => setIsRefreshing(false), 400);
  };

  const handleDownloadSnapshot = () => {
    const jsonStr = permanentEvolutionMemory.exportMemoryAsJson();
    const blob = new Blob([jsonStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `phi_soi_evolution_memory_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const filteredRecords = records.filter((rec) => {
    const matchesCategory = selectedCategory === "all" || rec.category === selectedCategory;
    const matchesSearch = 
      rec.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rec.prompt.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rec.summary.toLowerCase().includes(searchTerm.toLowerCase()) ||
      rec.targetFiles.some(f => f.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesCategory && matchesSearch;
  });

  const categoryLabels: Record<string, { label: string; color: string }> = {
    all: { label: "Toutes", color: "bg-gray-800 text-gray-300" },
    architecture: { label: "Architecture", color: "bg-purple-950 text-purple-300 border-purple-800" },
    autonomy_alignment: { label: "Autonomie & Twin", color: "bg-cyan-950 text-cyan-300 border-cyan-800" },
    api_pairing: { label: "Clé API & Réseau", color: "bg-emerald-950 text-emerald-300 border-emerald-800" },
    hardware_telemetry: { label: "Matériel & Télémétrie", color: "bg-amber-950 text-amber-300 border-amber-800" },
    ux_synchronization: { label: "UX & Synchronisation", color: "bg-blue-950 text-blue-300 border-blue-800" },
    feature: { label: "Fonctionnalité", color: "bg-teal-950 text-teal-300 border-teal-800" },
  };

  return (
    <div className="flex flex-col h-full bg-[#070911] text-gray-200 border border-[#1c2238] rounded-xl overflow-hidden shadow-2xl">
      {/* Header Bar */}
      <div className="px-4 py-3 bg-[#0c101d] border-b border-[#1b223a] flex flex-wrap items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded-lg bg-cyan-950/80 border border-cyan-700/60 text-cyan-400">
            <Database className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-gray-100 uppercase tracking-wider flex items-center gap-2">
              <span>Mémoire Permanente de l'Évolution</span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-300 border border-emerald-700/60 font-mono font-normal">
                {records.length} Jalons Scellés (Ξ ≡ 1)
              </span>
            </h2>
            <p className="text-[11px] text-gray-400">
              Journal immuable des mutations et alignements autonomes de l'application
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRefresh}
            className="px-2.5 py-1.5 rounded-lg bg-[#141829] hover:bg-[#1b213b] border border-[#242d4a] text-gray-300 hover:text-cyan-300 text-xs flex items-center gap-1.5 transition-all"
            title="Rafraîchir la mémoire"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? "animate-spin text-cyan-400" : ""}`} />
            <span className="hidden sm:inline">Actualiser</span>
          </button>
          <button
            onClick={handleDownloadSnapshot}
            className="px-2.5 py-1.5 rounded-lg bg-cyan-950/90 hover:bg-cyan-900 border border-cyan-600/70 text-cyan-300 text-xs font-bold flex items-center gap-1.5 transition-all shadow"
            title="Exporter l'archive JSON permanente"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Exporter Snapshot</span>
          </button>
        </div>
      </div>

      {/* Filter / Search Bar */}
      <div className="px-4 py-2.5 bg-[#090c17] border-b border-[#181e33] flex flex-wrap items-center justify-between gap-2 text-xs shrink-0">
        <div className="flex-1 min-w-[200px] relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-500" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Rechercher par prompt, titre, fichier..."
            className="w-full bg-[#101424] border border-[#1f2742] rounded-lg pl-8 pr-3 py-1.5 text-xs text-gray-200 placeholder-gray-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          {Object.entries(categoryLabels).map(([catKey, catMeta]) => (
            <button
              key={catKey}
              onClick={() => setSelectedCategory(catKey)}
              className={`px-2 py-1 rounded-md text-[11px] whitespace-nowrap transition-all ${
                selectedCategory === catKey
                  ? "bg-cyan-950 text-cyan-300 font-bold border border-cyan-600"
                  : "bg-[#101424] text-gray-400 hover:text-gray-200 border border-[#1f2742]"
              }`}
            >
              {catMeta.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content View: Split Master-Detail */}
      <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
        {/* Timeline list (Left) */}
        <div className="w-full md:w-5/12 border-b md:border-b-0 md:border-r border-[#1a2036] flex flex-col overflow-y-auto bg-[#070912]">
          {filteredRecords.length === 0 ? (
            <div className="p-8 text-center text-gray-500 text-xs">
              Aucun jalon d'évolution trouvé pour cette recherche.
            </div>
          ) : (
            <div className="divide-y divide-[#13182b]">
              {filteredRecords.map((record) => {
                const isSelected = selectedRecord?.id === record.id;
                const catInfo = categoryLabels[record.category] || { label: record.category, color: "bg-gray-800 text-gray-300" };

                return (
                  <div
                    key={record.id}
                    onClick={() => setSelectedRecord(record)}
                    className={`p-3 cursor-pointer transition-all ${
                      isSelected 
                        ? "bg-cyan-950/40 border-l-4 border-cyan-500 text-white" 
                        : "hover:bg-[#0d1120] text-gray-300"
                    }`}
                  >
                    <div className="flex items-center justify-between gap-1 mb-1">
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono font-bold text-xs text-cyan-400">{record.id}</span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#161c30] text-gray-400 font-mono">
                          {record.version}
                        </span>
                      </div>
                      <span className="text-[10px] text-gray-500 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(record.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>

                    <h4 className="text-xs font-semibold text-gray-200 line-clamp-1 mb-1">
                      {record.title}
                    </h4>

                    <p className="text-[11px] text-gray-400 line-clamp-2 mb-2 italic">
                      "{record.prompt}"
                    </p>

                    <div className="flex items-center justify-between text-[10px]">
                      <span className={`px-1.5 py-0.5 rounded border text-[9px] ${catInfo.color}`}>
                        {catInfo.label}
                      </span>
                      <div className="flex items-center gap-1 text-emerald-400 font-mono">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>Ξ = {record.realityIndex}</span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Record Detail (Right) */}
        <div className="flex-1 flex flex-col overflow-y-auto p-4 bg-[#05070e] text-xs">
          {selectedRecord ? (
            <div className="space-y-4">
              {/* Top Banner */}
              <div className="p-3.5 rounded-xl bg-[#0c101d] border border-[#1b223a] space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 font-mono font-bold text-xs border border-cyan-800">
                      {selectedRecord.id}
                    </span>
                    <span className="text-sm font-bold text-gray-100">
                      {selectedRecord.title}
                    </span>
                  </div>
                  <span className="text-[11px] font-mono text-emerald-400 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Réalité Scellée (Ξ ≡ {selectedRecord.realityIndex})</span>
                  </span>
                </div>

                <div className="text-[11px] text-gray-400 flex items-center gap-2 font-mono">
                  <span>Horodatage : {new Date(selectedRecord.timestamp).toLocaleString()}</span>
                  <span>•</span>
                  <span>Version : {selectedRecord.version}</span>
                </div>
              </div>

              {/* Prompt Request */}
              <div className="p-3 rounded-lg bg-[#0a0d18] border border-[#171d33] space-y-1">
                <div className="text-[10px] uppercase tracking-wider text-cyan-400 font-bold flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Requête d'Évolution Initiale</span>
                </div>
                <p className="text-gray-200 italic bg-[#060810] p-2.5 rounded border border-[#141829] font-sans">
                  "{selectedRecord.prompt}"
                </p>
              </div>

              {/* Summary of Action */}
              <div className="p-3 rounded-lg bg-[#0a0d18] border border-[#171d33] space-y-1.5">
                <div className="text-[10px] uppercase tracking-wider text-gray-400 font-bold flex items-center gap-1.5">
                  <FileText className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Synthèse de l'Action Réflexive</span>
                </div>
                <p className="text-gray-300 leading-relaxed">
                  {selectedRecord.summary}
                </p>
              </div>

              {/* Target Files */}
              <div className="p-3 rounded-lg bg-[#0a0d18] border border-[#171d33] space-y-2">
                <div className="text-[10px] uppercase tracking-wider text-gray-400 font-bold flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Fichiers Transmutés & Scellés ({selectedRecord.targetFiles.length})</span>
                </div>
                <div className="flex flex-wrap gap-2">
                  {selectedRecord.targetFiles.map((file) => (
                    <button
                      key={file}
                      onClick={() => onSelectFile?.(file)}
                      className="px-2.5 py-1 rounded bg-[#101424] hover:bg-cyan-950/70 border border-[#1f2742] hover:border-cyan-600 text-cyan-300 font-mono text-[11px] flex items-center gap-1 transition-all"
                      title={`Inspecter /${file}`}
                    >
                      <span>/{file}</span>
                      <ArrowUpRight className="w-3 h-3 text-gray-400" />
                    </button>
                  ))}
                </div>
              </div>

              {/* Agents Involved */}
              <div className="p-3 rounded-lg bg-[#0a0d18] border border-[#171d33] space-y-2">
                <div className="text-[10px] uppercase tracking-wider text-gray-400 font-bold flex items-center gap-1.5">
                  <Bot className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Flotte Agentique Sollicitée</span>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {selectedRecord.agentsInvolved.map((agent) => (
                    <span
                      key={agent}
                      className="px-2 py-0.5 rounded-full bg-[#13192c] text-indigo-300 border border-[#202946] text-[10px] font-mono"
                    >
                      {agent}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="p-12 text-center text-gray-500">
              Sélectionnez un jalon d'évolution pour afficher les détails.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PermanentEvolutionMemoryViewer;
