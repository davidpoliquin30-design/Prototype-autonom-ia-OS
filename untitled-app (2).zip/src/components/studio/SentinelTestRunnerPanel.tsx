import React, { useState, useEffect } from "react";
import { 
  ShieldCheck, Play, RefreshCw, CheckCircle2, XCircle, 
  AlertTriangle, Sparkles, Activity, Clock, Cpu, 
  Terminal, Layers, Check, Zap, Eye
} from "lucide-react";
import { 
  sentinelUnitTestRunner, 
  SentinelTestSuiteResult, 
  SentinelTestCase 
} from "../../services/testing/sentinelUnitTestRunner";

export default function SentinelTestRunnerPanel() {
  const [testResult, setTestResult] = useState<SentinelTestSuiteResult>(sentinelUnitTestRunner.getState());
  const [isRunning, setIsRunning] = useState<boolean>(false);

  useEffect(() => {
    const unsub = sentinelUnitTestRunner.subscribe(setTestResult);
    return () => unsub();
  }, []);

  const handleRunTests = async () => {
    setIsRunning(true);
    await sentinelUnitTestRunner.runAllTests();
    setIsRunning(false);
  };

  const getCategoryBadge = (category: SentinelTestCase["category"]) => {
    switch (category) {
      case "math_determinism":
        return { label: "Plan Alpha Déterministe", color: "text-cyan-400 bg-cyan-950/80 border-cyan-700/50" };
      case "resilience_quota":
        return { label: "Résilience Quota 429", color: "text-amber-400 bg-amber-950/80 border-amber-700/50" };
      case "ast_integrity":
        return { label: "Intégrité AST", color: "text-purple-400 bg-purple-950/80 border-purple-700/50" };
      case "anti_slop":
        return { label: "Filtre Anti-Slop", color: "text-emerald-400 bg-emerald-950/80 border-emerald-700/50" };
      case "twin_bus":
        return { label: "Jumeau Twin Bus", color: "text-blue-400 bg-blue-950/80 border-blue-700/50" };
      case "multi_agent":
        return { label: "Flotte 8-Pôles", color: "text-rose-400 bg-rose-950/80 border-rose-700/50" };
    }
  };

  return (
    <div className="h-full flex flex-col bg-[#07090e] border border-[#1b2030] rounded-2xl overflow-hidden font-mono text-gray-200">
      
      {/* 1. TOP HEADER & TEST STATS BAR */}
      <div className="bg-[#0c0f17] border-b border-[#1b2030] p-4 flex flex-wrap items-center justify-between gap-3 shrink-0">
        
        {/* Left: Title */}
        <div className="flex items-center gap-3">
          <div className="p-2 bg-[#141b2e] border border-purple-500/30 rounded-xl">
            <ShieldCheck className="w-5 h-5 text-purple-400 animate-pulse" />
          </div>
          <div>
            <h2 className="text-sm font-bold text-gray-100 flex items-center gap-2">
              <span>Banc de Tests Automatisés @sentinel</span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-700/50">
                Invariance & Stabilité
              </span>
            </h2>
            <p className="text-[11px] text-gray-400">
              Audit déterministe en arrière-plan avant injection de code dans l'Émulateur
            </p>
          </div>
        </div>

        {/* Center: Test Score Metrics */}
        <div className="flex items-center gap-2 text-xs">
          <div className="bg-[#060810] border border-purple-900/40 px-3 py-1.5 rounded-lg flex items-center gap-2">
            <span className="text-gray-400">Taux de Succès :</span>
            <span className={`font-bold ${testResult.passRatePercent === 100 ? "text-emerald-400" : "text-amber-400"}`}>
              {testResult.passedCount}/{testResult.totalTests} ({testResult.passRatePercent}%)
            </span>
          </div>

          <div className="bg-[#060810] border border-cyan-900/40 px-3 py-1.5 rounded-lg flex items-center gap-2">
            <span className="text-gray-400">Invariance (Ξ) :</span>
            <span className="text-cyan-400 font-bold">{(testResult.invarianceScore * 1).toFixed(4)}</span>
          </div>

          <div className="bg-[#060810] border border-[#1b2030] px-3 py-1.5 rounded-lg flex items-center gap-2">
            <Clock className="w-3.5 h-3.5 text-gray-400" />
            <span className="text-gray-400">{testResult.totalDurationMs} ms</span>
          </div>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => sentinelUnitTestRunner.setBackgroundWatch(!testResult.isBackgroundWatchActive)}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all flex items-center gap-1.5 ${
              testResult.isBackgroundWatchActive
                ? "bg-emerald-950/80 text-emerald-300 border-emerald-500/50"
                : "bg-[#101422] text-gray-400 border-gray-800 hover:text-gray-200"
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${testResult.isBackgroundWatchActive ? "bg-emerald-400 animate-ping" : "bg-gray-500"}`} />
            <span>Surveillance Continue : {testResult.isBackgroundWatchActive ? "ON" : "OFF"}</span>
          </button>

          <button
            onClick={handleRunTests}
            disabled={isRunning}
            className="px-4 py-1.5 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs rounded-xl shadow-md shadow-purple-950/40 flex items-center gap-2 transition-all active:scale-95 disabled:opacity-50"
          >
            <Play className={`w-3.5 h-3.5 fill-current ${isRunning ? "animate-spin" : ""}`} />
            <span>{isRunning ? "Audit en cours..." : "Lancer les Tests"}</span>
          </button>
        </div>
      </div>

      {/* 2. MAIN TEST LIST VIEW */}
      <div className="flex-1 p-4 overflow-y-auto space-y-3 bg-[#05070c]">
        
        {/* Banner */}
        <div className="p-3 bg-[#0a0e1a] border border-[#1b253b] rounded-xl flex items-center justify-between text-xs text-gray-300">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-purple-400 shrink-0" />
            <span>
              Tous les changements de code initiés dans le Chat sont automatiquement validés par ce banc avant commit disque.
            </span>
          </div>
          <span className="text-[10px] text-gray-500 font-mono">Dernier audit : {testResult.timestamp}</span>
        </div>

        {/* Test Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {testResult.testCases.map((tc) => {
            const badge = getCategoryBadge(tc.category);
            const isPassed = tc.status === "passed";
            const isRunningThis = tc.status === "running";

            return (
              <div
                key={tc.id}
                className={`p-4 rounded-xl border transition-all flex flex-col justify-between gap-3 ${
                  isPassed
                    ? "bg-[#0a0d17] border-[#182033] hover:border-[#283554]"
                    : tc.status === "failed"
                    ? "bg-rose-950/20 border-rose-500/50"
                    : "bg-[#0e121e] border-purple-500/40 animate-pulse"
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span className={`text-[9px] uppercase px-2 py-0.5 rounded border font-bold ${badge.color}`}>
                      {badge.label}
                    </span>
                    <span className="text-[10px] text-gray-500 font-mono">{tc.durationMs} ms</span>
                  </div>

                  <h3 className="text-xs font-bold text-white mb-1">{tc.name}</h3>
                  <p className="text-[11px] text-gray-400">{tc.description}</p>
                </div>

                <div className="pt-2 border-t border-[#141b2a] flex items-center justify-between text-xs">
                  <div className="flex items-center gap-1.5 truncate pr-2">
                    {isPassed ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    ) : tc.status === "failed" ? (
                      <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                    ) : (
                      <RefreshCw className="w-4 h-4 text-purple-400 animate-spin shrink-0" />
                    )}
                    <span className={`text-[10px] truncate font-mono ${isPassed ? "text-emerald-300" : "text-rose-300"}`}>
                      {tc.assertionMessage || (isRunningThis ? "Validation en cours..." : "En attente")}
                    </span>
                  </div>

                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded uppercase ${
                    isPassed
                      ? "bg-emerald-950/80 text-emerald-400"
                      : tc.status === "failed"
                      ? "bg-rose-950 text-rose-300"
                      : "bg-purple-950 text-purple-300"
                  }`}>
                    {tc.status}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
