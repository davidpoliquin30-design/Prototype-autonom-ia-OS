import React, { useState } from "react";
import { 
  Download, Copy, Check, Server, Terminal, ShieldCheck, 
  Cpu, FileCode, CheckCircle2, ChevronRight, X, Sparkles, 
  Layers, HardDrive, RefreshCw
} from "lucide-react";
import { 
  sovereignBundleGenerator, 
  SovereignDeploymentFile 
} from "../../services/export/sovereignBundleGenerator";
import { WorkspaceFile } from "../../types";

interface LocalDeploymentBundleModalProps {
  isOpen: boolean;
  onClose: () => void;
  files?: WorkspaceFile[];
}

export default function LocalDeploymentBundleModal({
  isOpen,
  onClose,
  files,
}: LocalDeploymentBundleModalProps) {
  const [deploymentPkg] = useState(() => sovereignBundleGenerator.generateDeploymentFiles());
  const [selectedFileName, setSelectedFileName] = useState<string>("docker-compose.yml");
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [copiedFile, setCopiedFile] = useState<string | null>(null);

  if (!isOpen) return null;

  const selectedFile = deploymentPkg.files.find((f) => f.name === selectedFileName) || deploymentPkg.files[0];

  const handleDownloadZip = async () => {
    setIsDownloading(true);
    try {
      await sovereignBundleGenerator.downloadZipBundle();
    } catch (err) {
      console.error("Failed to generate zip bundle:", err);
    } finally {
      setTimeout(() => setIsDownloading(false), 600);
    }
  };

  const handleCopyContent = (content: string, name: string) => {
    navigator.clipboard.writeText(content);
    setCopiedFile(name);
    setTimeout(() => setCopiedFile(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-in fade-in">
      <div className="w-full max-w-5xl h-[85vh] bg-[#090c14] border border-[#1f283d] rounded-2xl shadow-2xl flex flex-col overflow-hidden font-mono text-gray-200">
        
        {/* 1. MODAL HEADER */}
        <div className="bg-[#0e1320] border-b border-[#1b2338] p-5 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-[#141e33] border border-cyan-500/40 rounded-xl">
              <Server className="w-6 h-6 text-cyan-400 animate-pulse" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <span>Export & Déploiement Local en 1 Clic</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-cyan-950 text-cyan-400 border border-cyan-700/50">
                  Pack Souverain (0$ Token)
                </span>
              </h2>
              <p className="text-xs text-gray-400">
                Stack conteneurisée préconfigurée avec Docker, Ollama GPU et Moteur Déterministe
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleDownloadZip}
              disabled={isDownloading}
              className="px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-black font-bold text-xs rounded-xl shadow-lg shadow-emerald-950/40 flex items-center gap-2 transition-all active:scale-95 disabled:opacity-50"
            >
              <Download className={`w-4 h-4 ${isDownloading ? "animate-bounce" : ""}`} />
              <span>{isDownloading ? "Génération du ZIP..." : "Télécharger l'Archive ZIP (1-Clic)"}</span>
            </button>

            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-white hover:bg-[#161f33] rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* 2. SPECIFICATIONS & HARDWARE COMPLIANCE BAR */}
        <div className="bg-[#07090f] border-b border-[#1b2338] px-5 py-3 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs shrink-0">
          <div className="bg-[#0d121e] border border-[#1a243b] p-2.5 rounded-xl">
            <span className="text-[10px] text-gray-500 block">VRAM GPU Conseillée</span>
            <span className="text-cyan-300 font-bold">{deploymentPkg.summary.recommendedGpuVram}</span>
          </div>

          <div className="bg-[#0d121e] border border-[#1a243b] p-2.5 rounded-xl">
            <span className="text-[10px] text-gray-500 block">Port Web Externe</span>
            <span className="text-emerald-400 font-bold">http://localhost:{deploymentPkg.summary.defaultPort}</span>
          </div>

          <div className="bg-[#0d121e] border border-[#1a243b] p-2.5 rounded-xl">
            <span className="text-[10px] text-gray-500 block">Moteur Local IA</span>
            <span className="text-purple-300 font-bold">Ollama / vLLM (0$ Token)</span>
          </div>

          <div className="bg-[#0d121e] border border-[#1a243b] p-2.5 rounded-xl">
            <span className="text-[10px] text-gray-500 block">Indépendance Réseau</span>
            <span className="text-amber-400 font-bold">100% Air-Gapped Prêt</span>
          </div>
        </div>

        {/* 3. MAIN CONTENT: FILE SELECTOR + CODE PREVIEW */}
        <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
          
          {/* Left File List */}
          <div className="w-full md:w-72 bg-[#0b0e18] border-b md:border-b-0 md:border-r border-[#1b2338] p-3 overflow-y-auto shrink-0 space-y-1.5">
            <div className="text-[10px] uppercase font-bold text-gray-400 px-2 py-1 mb-1">
              Fichiers Inclus ({deploymentPkg.files.length})
            </div>

            {deploymentPkg.files.map((file) => {
              const isSelected = file.name === selectedFileName;
              return (
                <button
                  key={file.name}
                  onClick={() => setSelectedFileName(file.name)}
                  className={`w-full text-left p-2.5 rounded-xl text-xs transition-all flex flex-col gap-0.5 border ${
                    isSelected
                      ? "bg-[#141e33] text-cyan-300 border-cyan-500/50 shadow-md"
                      : "bg-[#0d111c] text-gray-400 border-transparent hover:bg-[#111726] hover:text-gray-200"
                  }`}
                >
                  <div className="flex items-center justify-between font-bold">
                    <span className="truncate">{file.name}</span>
                    <span className="text-[9px] uppercase px-1.5 py-0.2 rounded bg-black/40 text-gray-400 border border-gray-800">
                      {file.language}
                    </span>
                  </div>
                  <span className="text-[10px] text-gray-500 truncate">{file.description}</span>
                </button>
              );
            })}
          </div>

          {/* Right Code Inspector */}
          <div className="flex-1 flex flex-col bg-[#05070c] overflow-hidden">
            
            {/* Viewer Bar */}
            <div className="bg-[#0d111b] border-b border-[#1b2338] px-4 py-2.5 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <FileCode className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-bold text-white">{selectedFile.name}</span>
                <span className="text-[10px] text-gray-500">({selectedFile.description})</span>
              </div>

              <button
                onClick={() => handleCopyContent(selectedFile.content, selectedFile.name)}
                className="px-3 py-1 bg-[#161e30] hover:bg-[#202b44] text-gray-300 hover:text-white rounded-lg text-xs flex items-center gap-1.5 border border-[#23304d] transition-colors"
              >
                {copiedFile === selectedFile.name ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400 font-bold">Copié !</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copier le Fichier</span>
                  </>
                )}
              </button>
            </div>

            {/* Code Content Box */}
            <div className="flex-1 p-4 overflow-y-auto">
              <pre className="text-xs font-mono text-cyan-100/90 leading-relaxed bg-[#070910] p-4 rounded-xl border border-[#161f33] overflow-x-auto selection:bg-cyan-500/30">
                <code>{selectedFile.content}</code>
              </pre>
            </div>
          </div>
        </div>

        {/* 4. FOOTER QUICK ACTION */}
        <div className="bg-[#0b0e18] border-t border-[#1b2338] px-5 py-3 flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
          <div className="flex items-center gap-2 text-gray-400 text-[11px]">
            <Terminal className="w-4 h-4 text-cyan-400" />
            <span>Pour déployer immédiatement : lancez <code className="text-cyan-300 bg-black/40 px-1.5 py-0.5 rounded border border-gray-800">./deploy.sh</code> après décompression</span>
          </div>

          <button
            onClick={() => handleCopyContent(deploymentPkg.files.find(f => f.name === "deploy.sh")?.content || "", "deploy.sh")}
            className="px-3 py-1.5 bg-[#141b2c] hover:bg-[#1a243a] text-cyan-300 border border-cyan-800/40 rounded-lg transition-colors flex items-center gap-1.5"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>Copier le script deploy.sh</span>
          </button>
        </div>
      </div>
    </div>
  );
}
