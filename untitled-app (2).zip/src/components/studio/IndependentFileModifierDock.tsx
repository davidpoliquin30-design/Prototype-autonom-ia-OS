import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  FileCode, Sparkles, Zap, ArrowRight, CheckCircle2, 
  Trash2, RefreshCw, Eye, Code2, AlertTriangle, ShieldCheck, 
  Layers, Check, ChevronDown, Cpu, FastForward, Play
} from "lucide-react";
import { WorkspaceFile } from "../../types";
import { 
  quantumIntegrationBridge, 
  QuantumIntegrationState, 
  StagedFileModification 
} from "../../services/quantumIntegrationBridge";
import { aiStudioService } from "../../services/aiStudioService";

interface IndependentFileModifierDockProps {
  files: WorkspaceFile[];
  onFilesRefreshed?: () => void;
  selectedModel?: string;
  compact?: boolean;
}

// Utility to flatten workspace file tree
function flattenWorkspaceFiles(items: WorkspaceFile[]): { path: string; name: string }[] {
  let list: { path: string; name: string }[] = [];
  for (const item of items) {
    if (item.type === "file") {
      list.push({ path: item.path, name: item.name });
    }
    if (item.children) {
      list = list.concat(flattenWorkspaceFiles(item.children));
    }
  }
  return list;
}

export default function IndependentFileModifierDock({
  files = [],
  onFilesRefreshed,
  selectedModel = "gemini-2.5-flash",
  compact = false
}: IndependentFileModifierDockProps) {
  const [integrationState, setIntegrationState] = useState<QuantumIntegrationState>(
    quantumIntegrationBridge.getState()
  );
  const [targetFilePath, setTargetFilePath] = useState<string>("");
  const [currentFileContent, setCurrentFileContent] = useState<string>("");
  const [stagedEditorContent, setStagedEditorContent] = useState<string>("");
  const [modificationPrompt, setModificationPrompt] = useState<string>("");
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [viewMode, setViewMode] = useState<"staged" | "diff" | "original">("staged");
  const [statusMessage, setStatusMessage] = useState<string>("");

  const flatFiles = flattenWorkspaceFiles(files);

  // Subscribe to quantum integration state
  useEffect(() => {
    const unsub = quantumIntegrationBridge.subscribe(setIntegrationState);
    return () => unsub();
  }, []);

  // Default target file on load
  useEffect(() => {
    if (!targetFilePath && flatFiles.length > 0) {
      // Prefer App.tsx or main entry file if available
      const preferred = flatFiles.find(f => f.path.includes("App.tsx") || f.path.includes("UnifiedAgentMeshPanel")) || flatFiles[0];
      if (preferred) {
        handleSelectTargetFile(preferred.path);
      }
    }
  }, [flatFiles.length]);

  // Load target file content
  const handleSelectTargetFile = async (path: string) => {
    setTargetFilePath(path);
    setStatusMessage("");
    try {
      const res = await fetch("/api/files/read", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ filePath: path })
      });
      const data = await res.json();
      if (data.content !== undefined) {
        setCurrentFileContent(data.content);
        // Check if there is already a staged version
        const existingStaged = integrationState.stagedFiles.find(f => f.filePath === path);
        if (existingStaged) {
          setStagedEditorContent(existingStaged.stagedContent);
        } else {
          setStagedEditorContent(data.content);
        }
      }
    } catch (err: any) {
      setStatusMessage(`Erreur de lecture: ${err.message}`);
    }
  };

  // Generate independent modification using IA Studio without touching the live app
  const handleGenerateModification = async () => {
    if (!targetFilePath) return;
    setIsGenerating(true);
    setStatusMessage("IA Studio génère la modification indépendante...");

    const instruction = modificationPrompt.trim() 
      ? modificationPrompt 
      : "Optimise ce code, sécurise les types TypeScript et assure la conformité au Système Réflexif Φ_SOI.";

    const promptText = `Tu agis comme l'architecte de Google AI Studio. 
Voici le code actuel du fichier [/${targetFilePath}] :
\`\`\`typescript
${currentFileContent}
\`\`\`

CONSIGNE DE MODIFICATION INDÉPENDANTE :
${instruction}

RÈGLES IMPÉRATIVES :
1. Renvoie UNIQUEMENT le code source complet et valide du fichier modifié.
2. N'ajoute AUCUN texte explicatif en dehors du bloc de code.
3. Conserve 100% de la logique existante en appliquant l'amélioration demandée.
4. Aucun marqueur paresseux (pas de '// TODO' ou '// ...').`;

    try {
      const res = await aiStudioService.executePrompt({
        prompt: promptText,
        systemInstruction: "Tu es le compilateur de Google AI Studio pour Φ_SOI. Génère du code TypeScript complet et souverain.",
        model: selectedModel,
        temperature: 0.2,
      });

      // Extract code block if wrapped in markdown
      let cleanCode = res.text.trim();
      const codeBlockMatch = cleanCode.match(/```(?:typescript|tsx|javascript|js|json|css)?\n([\s\S]*?)```/);
      if (codeBlockMatch && codeBlockMatch[1]) {
        cleanCode = codeBlockMatch[1].trim();
      }

      setStagedEditorContent(cleanCode);
      
      // Stage the modification in the decoupled bridge
      quantumIntegrationBridge.stageFile(
        targetFilePath,
        cleanCode,
        currentFileContent,
        instruction
      );

      setStatusMessage(`✓ Modification indépendante de /${targetFilePath} enregistrée en staging.`);
    } catch (err: any) {
      setStatusMessage(`Erreur génération : ${err.message}`);
    } finally {
      setIsGenerating(false);
    }
  };

  // Stage manual modifications
  const handleStageManualChange = () => {
    if (!targetFilePath) return;
    quantumIntegrationBridge.stageFile(
      targetFilePath,
      stagedEditorContent,
      currentFileContent,
      "Ajustement manuel dans le bac à sable IA Studio"
    );
    setStatusMessage(`✓ Modification manuelle de /${targetFilePath} mise en attente.`);
  };

  // Trigger Quantum Integration (Send to IDE & execute live onto real app)
  const handleIntegrateAll = async () => {
    setStatusMessage("Transmission à l'IDE Quantique...");
    const result = await quantumIntegrationBridge.integrateAllToRealSystem();
    if (result.success) {
      setStatusMessage(`✓ Intégration quantique réussie ! L'application réelle a été mise à jour.`);
      if (onFilesRefreshed) {
        onFilesRefreshed();
      }
      // Reload current file view
      if (targetFilePath) {
        handleSelectTargetFile(targetFilePath);
      }
    } else {
      setStatusMessage(`✖ Échec d'intégration.`);
    }
  };

  const stagedCount = integrationState.stagedFiles.length;
  const isStaged = integrationState.stagedFiles.some(f => f.filePath === targetFilePath);

  return (
    <div className="flex flex-col bg-[#080a10] border border-[#1b1e2e] rounded-xl overflow-hidden shadow-xl text-xs font-mono">
      
      {/* 1. HEADER & STATUS BAR */}
      <div className="p-3 bg-[#0d0f18] border-b border-[#1f2234] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-indigo-950 border border-indigo-700/60 text-indigo-400">
            <Sparkles className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <div className="text-[11px] font-bold text-white flex items-center gap-2">
              <span>IA STUDIO : MODIFICATION DÉCOUPLÉE & STAGING</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-bold">
                Indépendant de l'App Live
              </span>
            </div>
            <div className="text-[9px] text-gray-400">
              Modifiez sans impacter l'app en direct • Cliquez sur Intégrer pour automatiser dans l'IDE
            </div>
          </div>
        </div>

        {/* Global Action: Integrated to Real System Button */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleIntegrateAll}
            disabled={stagedCount === 0 || integrationState.isIntegrating}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-black uppercase tracking-wider flex items-center gap-2 transition-all shadow-lg ${
              stagedCount > 0 && !integrationState.isIntegrating
                ? "bg-gradient-to-r from-orange-600 via-amber-600 to-emerald-600 hover:from-orange-500 hover:to-emerald-500 text-white shadow-orange-950/50 hover:scale-[1.02] animate-pulse"
                : "bg-[#141624] text-gray-400 border border-[#22263a] cursor-not-allowed opacity-60"
            }`}
          >
            {integrationState.isIntegrating ? (
              <>
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-white" />
                <span>Intégration Quantique en Cours...</span>
              </>
            ) : (
              <>
                <Zap className="w-3.5 h-3.5 text-amber-300 fill-current" />
                <span>INTÉGRER AU SYSTÈME RÉEL ({stagedCount})</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* 2. PROGRESSION OVERLAY WHEN INTEGRATING */}
      {integrationState.isIntegrating && (
        <div className="p-3 bg-[#0a0f1d] border-b border-cyan-800/60 flex flex-col gap-2 animate-pulse">
          <div className="flex items-center justify-between text-[11px]">
            <span className="text-cyan-300 font-bold flex items-center gap-2">
              <Cpu className="w-4 h-4 animate-spin text-cyan-400" />
              {integrationState.integrationStep}
            </span>
            <span className="text-emerald-400 font-bold">{integrationState.progressPercent}%</span>
          </div>
          <div className="w-full bg-[#11172a] h-1.5 rounded-full overflow-hidden">
            <div 
              className="bg-gradient-to-r from-cyan-500 via-indigo-500 to-emerald-500 h-full transition-all duration-300"
              style={{ width: `${integrationState.progressPercent}%` }}
            />
          </div>
        </div>
      )}

      {/* 3. TARGET FILE SELECTOR & DIRECTIVE DOCK */}
      <div className="p-3 bg-[#090b13] border-b border-[#181b28] flex flex-col md:flex-row items-stretch md:items-center gap-2">
        {/* File Dropdown */}
        <div className="flex items-center gap-2 flex-1 min-w-[240px]">
          <span className="text-gray-400 text-[10px] uppercase font-bold shrink-0">Fichier Cible :</span>
          <div className="relative flex-1">
            <select
              value={targetFilePath}
              onChange={(e) => handleSelectTargetFile(e.target.value)}
              className="w-full bg-[#101320] border border-[#22273e] text-cyan-300 rounded-lg px-2.5 py-1.5 text-xs font-mono focus:border-cyan-500 focus:outline-none"
            >
              {flatFiles.map(f => (
                <option key={f.path} value={f.path}>
                  {f.path} {integrationState.stagedFiles.some(s => s.filePath === f.path) ? "★ [En Staging]" : ""}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Quick prompt input for IA Studio modification */}
        <div className="flex items-center gap-2 flex-1 min-w-[280px]">
          <input
            type="text"
            value={modificationPrompt}
            onChange={(e) => setModificationPrompt(e.target.value)}
            placeholder="Consigne pour IA Studio (ex: 'optimiser le rendu et ajouter un log')..."
            className="flex-1 bg-[#101320] border border-[#22273e] text-gray-200 placeholder-gray-500 rounded-lg px-3 py-1.5 text-xs focus:border-cyan-500 focus:outline-none"
            onKeyDown={(e) => {
              if (e.key === "Enter") handleGenerateModification();
            }}
          />
          
          <button
            onClick={handleGenerateModification}
            disabled={isGenerating || !targetFilePath}
            className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 disabled:opacity-40 text-white font-bold text-xs flex items-center gap-1.5 shrink-0 transition-all shadow"
          >
            {isGenerating ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Sparkles className="w-3.5 h-3.5 text-cyan-200" />
            )}
            <span>Modifier via IA</span>
          </button>
        </div>
      </div>

      {/* 4. WORKSPACE COMPARISON & EDIT AREA */}
      <div className="p-3 flex-1 flex flex-col min-h-[220px] bg-[#05060a]">
        
        {/* Subheader: View mode tabs & Actions */}
        <div className="flex items-center justify-between pb-2 mb-2 border-b border-[#141724]">
          <div className="flex items-center gap-1 bg-[#0f111c] p-1 rounded-lg border border-[#1b1f30]">
            <button
              onClick={() => setViewMode("staged")}
              className={`px-2.5 py-1 rounded text-[11px] font-bold flex items-center gap-1 transition-all ${
                viewMode === "staged" 
                  ? "bg-cyan-950 text-cyan-300 border border-cyan-800/60" 
                  : "text-gray-400 hover:text-gray-200"
              }`}
            >
              <Code2 className="w-3 h-3" />
              <span>Version Proposée (Staging)</span>
            </button>

            <button
              onClick={() => setViewMode("original")}
              className={`px-2.5 py-1 rounded text-[11px] font-bold flex items-center gap-1 transition-all ${
                viewMode === "original" 
                  ? "bg-cyan-950 text-cyan-300 border border-cyan-800/60" 
                  : "text-gray-400 hover:text-gray-200"
              }`}
            >
              <FileCode className="w-3 h-3" />
              <span>Version Réelle en Ligne</span>
            </button>
          </div>

          <div className="flex items-center gap-2 text-[10px]">
            {isStaged ? (
              <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 font-bold flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" /> Modification en attente d'intégration
              </span>
            ) : (
              <span className="px-2 py-0.5 rounded bg-[#101320] text-gray-400 border border-[#1e2336]">
                Identique au fichier réel
              </span>
            )}

            <button
              onClick={handleStageManualChange}
              className="px-2.5 py-1 bg-[#151928] hover:bg-[#1d2238] text-gray-300 hover:text-white rounded border border-[#242b44] transition-colors"
              title="Enregistrer les modifications manuelles dans le buffer de staging"
            >
              Mettre en staging manuel
            </button>

            {isStaged && (
              <button
                onClick={() => quantumIntegrationBridge.discardFile(targetFilePath)}
                className="p-1 hover:bg-rose-950/60 text-gray-400 hover:text-rose-400 rounded transition-colors"
                title="Annuler cette modification"
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Code Editor Body */}
        <div className="flex-1 relative flex flex-col">
          {viewMode === "staged" ? (
            <textarea
              value={stagedEditorContent}
              onChange={(e) => setStagedEditorContent(e.target.value)}
              className="w-full flex-1 bg-[#07090f] border border-[#1b1f30] rounded-lg p-3 font-mono text-[11px] leading-relaxed text-gray-200 focus:outline-none focus:border-cyan-500 resize-none min-h-[160px]"
              placeholder="Le code modifié par IA Studio apparaîtra ici de manière totalement indépendante de l'app..."
            />
          ) : (
            <textarea
              value={currentFileContent}
              readOnly
              className="w-full flex-1 bg-[#05060a] border border-[#161824] rounded-lg p-3 font-mono text-[11px] leading-relaxed text-gray-400 focus:outline-none resize-none min-h-[160px]"
              placeholder="Code réel actuellement sur le disque..."
            />
          )}
        </div>

        {/* Status / Log Message */}
        {statusMessage && (
          <div className="mt-2 text-[10px] text-cyan-300 bg-[#0c111e] border border-cyan-800/40 px-2.5 py-1 rounded flex items-center justify-between">
            <span>{statusMessage}</span>
            <button onClick={() => setStatusMessage("")} className="text-gray-500 hover:text-gray-300">✕</button>
          </div>
        )}

      </div>

      {/* 5. STAGING QUEUE SUMMARY & PERPETUAL LOOP STATUS */}
      {stagedCount > 0 && (
        <div className="p-2.5 bg-[#0b0e18] border-t border-[#1a1d2d] flex flex-wrap items-center justify-between gap-2 text-[10px]">
          <div className="flex items-center gap-2">
            <span className="font-bold text-amber-400">File de Staging ({stagedCount}) :</span>
            <div className="flex flex-wrap gap-1">
              {integrationState.stagedFiles.map(f => (
                <span key={f.filePath} className="px-1.5 py-0.5 rounded bg-[#131728] text-gray-300 border border-[#202742]">
                  {f.filePath}
                </span>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => quantumIntegrationBridge.clearAll()}
              className="text-gray-500 hover:text-gray-300 underline text-[9px]"
            >
              Vider le staging
            </button>
            <span className="text-gray-600">•</span>
            <span className="text-emerald-400 font-bold">
              Boucle active : Cycle #{integrationState.loopIterationCount}
            </span>
          </div>
        </div>
      )}

      {/* 6. LAST REPORT BADGE (If integration just completed) */}
      {integrationState.lastReport && stagedCount === 0 && (
        <div className="p-2.5 bg-[#071318] border-t border-emerald-900/50 flex items-center justify-between text-[10px] text-emerald-300">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            <span>
              Dernière intégration réussie : {integrationState.lastReport.filesCount} fichier(s) • Scellé : {integrationState.lastReport.resonanceHash}
            </span>
          </div>
          <span className="text-gray-400">
            {integrationState.lastReport.timestamp} • La boucle est réarmée
          </span>
        </div>
      )}

    </div>
  );
}
