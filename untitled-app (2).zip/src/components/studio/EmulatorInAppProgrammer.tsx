import React, { useState, useEffect } from "react";
import { 
  Folder, File, FileCode, Save, Plus, Trash2, RefreshCw, 
  Check, Code2, Sparkles, AlertCircle, ChevronRight, ChevronDown,
  Terminal, Zap, Eye
} from "lucide-react";
import { WorkspaceFile } from "../../types";
import { quantumIntegrationBridge } from "../../services/quantumIntegrationBridge";

interface EmulatorInAppProgrammerProps {
  files: WorkspaceFile[];
  onRefreshFiles?: () => void;
  onClose?: () => void;
}

export default function EmulatorInAppProgrammer({
  files = [],
  onRefreshFiles,
  onClose
}: EmulatorInAppProgrammerProps) {
  const [selectedPath, setSelectedPath] = useState<string>("");
  const [fileContent, setFileContent] = useState<string>("");
  const [isDirty, setIsDirty] = useState<boolean>(false);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [statusLog, setStatusLog] = useState<string>("Prêt pour la programmation in-app.");
  const [expandedFolders, setExpandedFolders] = useState<{ [path: string]: boolean }>({ "src": true, "src/components": true });
  const [searchFilter, setSearchFilter] = useState<string>("");
  const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
  const [newFilePath, setNewFilePath] = useState<string>("src/");

  // Flatten or filter files
  const toggleFolder = (path: string) => {
    setExpandedFolders(prev => ({ ...prev, [path]: !prev[path] }));
  };

  // Load a file
  const handleOpenFile = async (path: string) => {
    setIsLoading(true);
    setStatusLog(`Chargement de /${path}...`);
    try {
      const res = await fetch("/api/files/read", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ filePath: path })
      });
      const data = await res.json();
      if (data.content !== undefined) {
        setSelectedPath(path);
        setFileContent(data.content);
        setIsDirty(false);
        setStatusLog(`✓ Fichier /${path} ouvert (${data.content.length} caractères).`);
      } else {
        setStatusLog(`Erreur: Fichier introuvable.`);
      }
    } catch (err: any) {
      setStatusLog(`Erreur de lecture: ${err.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  // Save directly to the real application filesystem
  const handleSaveReal = async () => {
    if (!selectedPath) return;
    setIsSaving(true);
    setStatusLog(`Écriture sur le disque de l'application réelle...`);

    try {
      const res = await fetch("/api/files/write", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ filePath: selectedPath, content: fileContent })
      });
      const data = await res.json();
      if (data.success) {
        setIsDirty(false);
        setStatusLog(`✓ /${selectedPath} enregistré dans l'application réelle avec succès.`);
        if (onRefreshFiles) onRefreshFiles();
        
        // Notify window for instant hot reload
        if (typeof window !== "undefined") {
          window.dispatchEvent(new CustomEvent("quantum-app-refresh", { detail: { path: selectedPath } }));
        }
      } else {
        setStatusLog(`Erreur d'écriture: ${data.error}`);
      }
    } catch (err: any) {
      setStatusLog(`Erreur sauvegarde: ${err.message}`);
    } finally {
      setIsSaving(false);
    }
  };

  // Stage into AI Studio decoupled bridge
  const handleSendToAiStaging = () => {
    if (!selectedPath) return;
    quantumIntegrationBridge.stageFile(
      selectedPath,
      fileContent,
      fileContent,
      "Modifié depuis le Programmateur In-App de l'Émulateur"
    );
    setStatusLog(`✓ /${selectedPath} envoyé vers le Staging IA Studio pour intégration quantique.`);
  };

  // Create new file
  const handleCreateNewFile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFilePath.trim()) return;

    try {
      const res = await fetch("/api/files/write", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          filePath: newFilePath.trim(),
          content: `// ${newFilePath.trim()} créé depuis l'Émulateur In-App\nexport {};\n`
        })
      });
      const data = await res.json();
      if (data.success) {
        setShowCreateModal(false);
        if (onRefreshFiles) onRefreshFiles();
        handleOpenFile(newFilePath.trim());
      }
    } catch (err: any) {
      setStatusLog(`Erreur création: ${err.message}`);
    }
  };

  // Render tree recursively
  const renderTree = (items: WorkspaceFile[], depth = 0) => {
    return (
      <div className="space-y-0.5">
        {items.map(item => {
          if (item.type === "directory") {
            const isExp = !!expandedFolders[item.path];
            return (
              <div key={item.path} style={{ paddingLeft: `${depth * 10}px` }}>
                <div 
                  onClick={() => toggleFolder(item.path)}
                  className="flex items-center gap-1.5 py-1 px-1.5 hover:bg-[#151928] rounded cursor-pointer text-gray-400 hover:text-white select-none text-[11px]"
                >
                  {isExp ? <ChevronDown className="w-3 h-3 text-gray-500" /> : <ChevronRight className="w-3 h-3 text-gray-500" />}
                  <Folder className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="truncate">{item.name}</span>
                </div>
                {isExp && item.children && renderTree(item.children, depth + 1)}
              </div>
            );
          } else {
            const isSel = selectedPath === item.path;
            if (searchFilter && !item.path.toLowerCase().includes(searchFilter.toLowerCase())) {
              return null;
            }
            return (
              <div 
                key={item.path}
                onClick={() => handleOpenFile(item.path)}
                style={{ paddingLeft: `${depth * 10 + 14}px` }}
                className={`flex items-center justify-between py-1 px-1.5 rounded cursor-pointer select-none text-[11px] transition-colors ${
                  isSel ? "bg-cyan-950 text-cyan-300 font-bold border border-cyan-800/60" : "text-gray-300 hover:bg-[#121522] hover:text-white"
                }`}
              >
                <div className="flex items-center gap-1.5 truncate">
                  <FileCode className={`w-3.5 h-3.5 ${isSel ? "text-cyan-400" : "text-gray-500"}`} />
                  <span className="truncate">{item.name}</span>
                </div>
              </div>
            );
          }
        })}
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full bg-[#07090e] border border-cyan-800/40 rounded-xl overflow-hidden font-mono text-xs shadow-2xl">
      
      {/* 1. TOP HEADER */}
      <div className="p-3 bg-[#0d101a] border-b border-[#1d2236] flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-cyan-950 border border-cyan-700/60 text-cyan-400">
            <Code2 className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <div className="text-[11px] font-bold text-white flex items-center gap-2">
              <span>PROGRAMMATEUR IN-APP DE L'ÉMULATEUR</span>
              <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold">
                Édition Directe de Chaque Fichier
              </span>
            </div>
            <div className="text-[9px] text-gray-400">
              L'application principale est modifiable fichier par fichier directement dans l'émulateur
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {selectedPath && (
            <>
              <button
                onClick={handleSendToAiStaging}
                className="px-2.5 py-1 bg-[#13192c] hover:bg-[#1c243e] text-indigo-300 rounded border border-indigo-700/50 flex items-center gap-1.5 text-[10px] font-bold transition-all"
                title="Transférer ce fichier au Staging IA Studio"
              >
                <Sparkles className="w-3 h-3 text-indigo-400" />
                <span>Envoyer au Staging IA</span>
              </button>

              <button
                onClick={handleSaveReal}
                disabled={isSaving}
                className={`px-3 py-1 rounded text-[11px] font-bold flex items-center gap-1.5 transition-all shadow ${
                  isDirty 
                    ? "bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500 text-white animate-pulse" 
                    : "bg-[#161a29] hover:bg-[#1e2338] text-gray-300 border border-[#232940]"
                }`}
              >
                {isSaving ? (
                  <RefreshCw className="w-3 h-3 animate-spin text-white" />
                ) : (
                  <Save className="w-3 h-3 text-emerald-400" />
                )}
                <span>{isDirty ? "Enregistrer dans l'App (Disque)" : "Enregistré"}</span>
              </button>
            </>
          )}

          {onClose && (
            <button
              onClick={onClose}
              className="p-1 hover:bg-[#1e2236] rounded text-gray-400 hover:text-white text-xs"
              title="Fermer le programmateur"
            >
              ✕
            </button>
          )}
        </div>
      </div>

      {/* 2. BODY: FILE TREE (LEFT) + CODE EDITOR (RIGHT) */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* LEFT: File Browser */}
        <div className="w-64 border-r border-[#1a1e30] bg-[#090b12] flex flex-col shrink-0">
          
          <div className="p-2 border-b border-[#171a29] flex items-center justify-between gap-1">
            <input
              type="text"
              placeholder="Filtrer les fichiers..."
              value={searchFilter}
              onChange={(e) => setSearchFilter(e.target.value)}
              className="w-full bg-[#101320] border border-[#1f243a] text-gray-200 placeholder-gray-500 text-[10px] rounded px-2 py-1 focus:outline-none focus:border-cyan-500"
            />
            <button
              onClick={() => setShowCreateModal(true)}
              className="p-1 hover:bg-[#181d30] rounded text-cyan-400"
              title="Créer un fichier"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-2 scrollbar-thin">
            {files.length === 0 ? (
              <div className="text-gray-500 text-[10px] p-2 italic">Aucun fichier détecté.</div>
            ) : (
              renderTree(files)
            )}
          </div>

          <div className="p-2 bg-[#0c0e18] border-t border-[#181b2a] text-[9px] text-gray-400 flex items-center justify-between">
            <span>{files.length} dossiers racines</span>
            <button 
              onClick={onRefreshFiles} 
              className="hover:text-cyan-400 flex items-center gap-1"
            >
              <RefreshCw className="w-2.5 h-2.5" /> Actualiser
            </button>
          </div>
        </div>

        {/* RIGHT: Code Editor Area */}
        <div className="flex-1 flex flex-col bg-[#05060a] overflow-hidden">
          {selectedPath ? (
            <>
              {/* File Info Bar */}
              <div className="px-3 py-1.5 bg-[#0e111a] border-b border-[#181c2c] flex items-center justify-between text-[10px] text-gray-400 shrink-0">
                <div className="flex items-center gap-2">
                  <span className="text-white font-bold">/{selectedPath}</span>
                  {isDirty && (
                    <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" title="Modifications non enregistrées" />
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <span>{fileContent.split("\n").length} lignes</span>
                  <span>•</span>
                  <span>{fileContent.length} car.</span>
                </div>
              </div>

              {/* Textarea Editor */}
              <div className="flex-1 relative flex">
                <textarea
                  value={fileContent}
                  onChange={(e) => {
                    setFileContent(e.target.value);
                    setIsDirty(true);
                  }}
                  className="w-full h-full bg-[#06070c] text-gray-200 p-4 font-mono text-[11px] leading-relaxed focus:outline-none resize-none selection:bg-cyan-600/30"
                  spellCheck={false}
                  placeholder="Code du fichier..."
                />
              </div>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center p-6 text-gray-500 space-y-2">
              <Code2 className="w-8 h-8 text-cyan-500/40" />
              <div className="text-sm font-bold text-gray-300">Sélectionnez un fichier pour commencer la programmation in-app</div>
              <p className="text-xs text-gray-400 max-w-sm">
                Vous pouvez modifier n'importe quel composant, type, style ou route de l'application directement dans l'émulateur.
              </p>
            </div>
          )}

          {/* Bottom Status / Terminal Bar */}
          <div className="p-2 bg-[#090b12] border-t border-[#181c2c] flex items-center justify-between text-[10px] text-cyan-300 shrink-0">
            <div className="flex items-center gap-2">
              <Terminal className="w-3 h-3 text-cyan-400" />
              <span className="truncate">{statusLog}</span>
            </div>
            <span className="text-emerald-400 font-bold">Hot-Reload Actif</span>
          </div>
        </div>

      </div>

      {/* CREATE FILE MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50">
          <form 
            onSubmit={handleCreateNewFile} 
            className="bg-[#0e111a] border border-[#222840] rounded-xl p-4 w-full max-w-md space-y-3 shadow-2xl"
          >
            <div className="text-sm font-bold text-white flex items-center gap-2">
              <Plus className="w-4 h-4 text-cyan-400" />
              Créer un nouveau fichier dans l'application
            </div>
            <input
              type="text"
              value={newFilePath}
              onChange={(e) => setNewFilePath(e.target.value)}
              placeholder="Ex: src/components/MonNouveauComposant.tsx"
              className="w-full bg-[#121524] border border-[#282f4c] text-white p-2 text-xs rounded focus:outline-none focus:border-cyan-500 font-mono"
            />
            <div className="flex justify-end gap-2 text-xs">
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="px-3 py-1.5 bg-[#171b2e] hover:bg-[#20253e] text-gray-300 rounded"
              >
                Annuler
              </button>
              <button
                type="submit"
                className="px-3 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white font-bold rounded"
              >
                Créer et Ouvrir
              </button>
            </div>
          </form>
        </div>
      )}

    </div>
  );
}
