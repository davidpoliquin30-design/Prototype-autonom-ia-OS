import React, { useState, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  BookOpen, Search, Sparkles, Sliders, CheckCircle2, ChevronRight, 
  Layers, Zap, Cpu, Network, ArrowUpRight, Copy, Download, 
  HelpCircle, RefreshCw, Plus, Eye, Check, X, Filter, Code2,
  Share2, Shield, Heart, Activity, Compass, FileText, Printer
} from "lucide-react";
import { 
  symbolDictionaryService, 
  SystemSymbol, 
  SystemEquation, 
  LexicographerProposal 
} from "../../services/dictionary/symbolDictionaryService";

export default function SymbolEquationDictionary() {
  const [symbols, setSymbols] = useState<SystemSymbol[]>(symbolDictionaryService.getSymbols());
  const [equations, setEquations] = useState<SystemEquation[]>(symbolDictionaryService.getEquations());
  const [proposals, setProposals] = useState<LexicographerProposal[]>(symbolDictionaryService.getProposals());
  
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [selectedComplexity, setSelectedComplexity] = useState<string>("all");
  const [activeView, setActiveView] = useState<"symbols" | "equations" | "simulator" | "lexicographer">("symbols");
  
  const [selectedSymbolId, setSelectedSymbolId] = useState<string>("sym_phi_soi");
  const [highlightedSymbolToken, setHighlightedSymbolToken] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState<boolean>(false);
  const [scanResult, setScanResult] = useState<string | null>(null);
  
  // Interactive Simulation Sandbox State
  const [simValue, setSimValue] = useState<number>(1.0);
  const [liveExampleOutput, setLiveExampleOutput] = useState<string | null>(null);
  const [isGeneratingExample, setIsGeneratingExample] = useState<boolean>(false);
  
  // Add Symbol Modal
  const [isAddModalOpen, setIsAddModalOpen] = useState<boolean>(false);
  const [newSymbolForm, setNewSymbolForm] = useState({
    symbol: "",
    name: "",
    category: "symbolique" as SystemSymbol["category"],
    complexity: "intermediaire" as SystemSymbol["complexity"],
    humanSummary: "",
    humanConcrete: "",
    humanAnalogy: "",
    humanExample: "",
    techDefinition: "",
    techMath: "",
    techUsage: "",
    usedByAgent: "@supervisor",
    plane: "unifie" as any
  });

  useEffect(() => {
    const unsub = symbolDictionaryService.subscribe(() => {
      setSymbols([...symbolDictionaryService.getSymbols()]);
      setEquations([...symbolDictionaryService.getEquations()]);
      setProposals([...symbolDictionaryService.getProposals()]);
    });
    return () => unsub();
  }, []);

  const selectedSymbol = useMemo(() => {
    return symbols.find(s => s.id === selectedSymbolId || s.symbol === selectedSymbolId) || symbols[0];
  }, [symbols, selectedSymbolId]);

  // Sync simulation value with selected symbol defaults
  useEffect(() => {
    if (selectedSymbol?.simulationConfig) {
      setSimValue(selectedSymbol.simulationConfig.defaultValue);
    } else {
      setSimValue(1.0);
    }
    setLiveExampleOutput(null);
  }, [selectedSymbolId]);

  // Filtered symbols
  const filteredSymbols = useMemo(() => {
    return symbols.filter(s => {
      const matchQuery = 
        s.symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.humanVersion.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.technicalVersion.formalDefinition.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchCategory = selectedCategory === "all" || s.category === selectedCategory;
      const matchComplexity = selectedComplexity === "all" || s.complexity === selectedComplexity;

      return matchQuery && matchCategory && matchComplexity;
    });
  }, [symbols, searchQuery, selectedCategory, selectedComplexity]);

  // Filtered equations
  const filteredEquations = useMemo(() => {
    return equations.filter(eq => {
      const matchQuery = 
        eq.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        eq.formula.toLowerCase().includes(searchQuery.toLowerCase()) ||
        eq.formulaAnnotated.toLowerCase().includes(searchQuery.toLowerCase()) ||
        eq.description.toLowerCase().includes(searchQuery.toLowerCase());
      
      return matchQuery;
    });
  }, [equations, searchQuery]);

  const handleRunScan = () => {
    setIsScanning(true);
    setScanResult(null);
    setTimeout(() => {
      const result = symbolDictionaryService.runLexicographerScan();
      setIsScanning(false);
      if (result.newSymbolsFound > 0) {
        setScanResult(`${result.newSymbolsFound} nouveau(x) symbole(s) extrait(s) et soumis à validation !`);
      } else {
        setScanResult("Toutes les équations sont 100% synchronisées avec le dictionnaire.");
      }
    }, 900);
  };

  const handleGenerateLiveExample = () => {
    if (!selectedSymbol) return;
    setIsGeneratingExample(true);
    setTimeout(() => {
      const examplesMap: Record<string, string> = {
        "Φ_SOI": `[Exécution Live Φ_SOI] : Intégration en cours...
- Intention : "Créer un dictionnaire de symboles" (∇Ψ = 1.0)
- Transducteur : TypeScript pur (T_p = 100% stable)
- Bruit résiduel : D_c = 0.00
- Télémétrie : Latence 12ms | RAM 1.4 GB
=> Résultat : Indice de Réalité unifié Ξ = 1.00 (100% Conforme).`,
        "Ψ_m": `[Sondage Fonction d'Onde Ψ_m] :
- Superposition de 24 agents actifs
- Charge cognitive moyenne : 34%
- Cohérence de phase : 99.4%
=> La mémoire quantique a absorbé l'historique sans saturation de tokens.`,
        "ρ_m": `[Évaluation Ancrage Matière ρ_m] :
- Profondeur de gel : 48 pouces (1.22 m)
- Foisonnement terre argileuse : Facteur 1.25
- Capacité camion : 10 roues (15 verges cubes)
=> Volume calculé : 45 v³ nécessaires | 3 voyages de camion requis.`,
        "D_c": `[Filtrage Disrésonance Cognitive D_c] :
- Bruit détecté dans le flux : 0.0002
- Sas SynapticConduit : Activé
=> Répression immédiate : D_c ramené à 0.00 (Zéro hallucination).`
      };

      setLiveExampleOutput(
        examplesMap[selectedSymbol.symbol] || 
        `[Simulation de ${selectedSymbol.name} (${selectedSymbol.symbol})] :
- Valeur paramétrée : ${simValue}
- Équation associée : ${selectedSymbol.connections.equations.join(", ")}
- Agents mobilisés : ${selectedSymbol.connections.usedByAgents.join(", ")}
=> Résonance stabilisée avec succès dans le Plan ${selectedSymbol.connections.plane.toUpperCase()}.`
      );
      setIsGeneratingExample(false);
    }, 600);
  };

  const handleExportJson = () => {
    const jsonStr = symbolDictionaryService.exportAsJson();
    const blob = new Blob([jsonStr], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `phi_soi_symbol_dictionary_${new Date().toISOString().split("T")[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleCreateSymbolSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSymbolForm.symbol || !newSymbolForm.name) return;

    symbolDictionaryService.addCustomSymbol({
      symbol: newSymbolForm.symbol,
      name: newSymbolForm.name,
      category: newSymbolForm.category,
      complexity: newSymbolForm.complexity,
      humanVersion: {
        summary: newSymbolForm.humanSummary || "Nouveau symbole documenté.",
        concreteMeaning: newSymbolForm.humanConcrete || "Signification concrète en cours de précision.",
        analogy: newSymbolForm.humanAnalogy || "Analogie quotidienne.",
        example: newSymbolForm.humanExample || "Exemple d'utilisation."
      },
      technicalVersion: {
        formalDefinition: newSymbolForm.techDefinition || "Définition mathématique formelle.",
        mathContext: newSymbolForm.techMath || "Contexte MRD v8.0",
        systemUsage: newSymbolForm.techUsage || "Utilisation système."
      },
      connections: {
        relatedSymbols: ["Φ_SOI"],
        equations: ["eq_phi_soi"],
        usedByAgents: [newSymbolForm.usedByAgent],
        plane: newSymbolForm.plane
      }
    });

    setIsAddModalOpen(false);
    setSelectedSymbolId(`sym_${Date.now()}_${newSymbolForm.symbol.toLowerCase()}`);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      
      {/* 1. TOP HEADER & LEXICOGRAPHER HUD */}
      <div className="bg-gradient-to-r from-[#0c0e18] via-[#101322] to-[#0c1220] border border-[#1e2338] rounded-2xl p-6 shadow-2xl relative overflow-hidden">
        
        {/* Glow backdrop */}
        <div className="absolute -top-24 -right-24 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-24 -left-24 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          
          {/* Title & Agent Avatar */}
          <div className="flex items-start gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-cyan-600 via-indigo-600 to-purple-700 flex items-center justify-center text-white shadow-xl shadow-cyan-500/20 shrink-0 border border-cyan-400/40">
              <BookOpen className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2.5 flex-wrap">
                <h1 className="text-xl font-black uppercase tracking-wider text-white flex items-center gap-2">
                  Dictionnaire des Symboles & Équations
                  <span className="text-cyan-400 font-mono text-sm px-2 py-0.5 rounded-lg bg-cyan-950/80 border border-cyan-800">
                    Φ_SOI • MRD
                  </span>
                </h1>
                <span className="text-[10px] px-2.5 py-1 rounded-full bg-purple-950/80 text-purple-300 border border-purple-700 font-bold flex items-center gap-1.5">
                  <Sparkles className="w-3 h-3 text-purple-400 animate-pulse" />
                  @symbol_lexicographer Actif
                </span>
              </div>
              <p className="text-xs text-gray-300 mt-1 max-w-3xl leading-relaxed">
                Page d'éducation interactive et de transmission de savoir. Comprenez chaque symbole et chaque équation sous deux angles inséparables : la <strong className="text-emerald-400">version humaine claire</strong> (analogies simples) et la <strong className="text-cyan-400">version technique poussée</strong> (mathématiques et contraintes machine).
              </p>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <button
              onClick={handleRunScan}
              disabled={isScanning}
              className="px-3.5 py-2 rounded-xl bg-[#161a2e] hover:bg-[#202642] text-cyan-300 border border-cyan-500/40 text-xs font-bold flex items-center gap-2 shadow-lg transition-all"
              title="Scanner le code et les équations pour découvrir de nouveaux symboles"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isScanning ? "animate-spin text-cyan-400" : ""}`} />
              <span>{isScanning ? "Scan en cours..." : "Scanner Équations"}</span>
            </button>

            <button
              onClick={() => setIsAddModalOpen(true)}
              className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-teal-600 hover:from-cyan-500 hover:to-teal-500 text-white text-xs font-bold flex items-center gap-1.5 shadow-lg shadow-cyan-500/20 transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Ajouter un Symbole</span>
            </button>

            <button
              onClick={handleExportJson}
              className="p-2 rounded-xl bg-[#121422] hover:bg-[#1a1d30] text-gray-300 border border-[#252a40] text-xs transition-colors"
              title="Exporter le dictionnaire en JSON"
            >
              <Download className="w-4 h-4" />
            </button>

            <button
              onClick={handlePrint}
              className="p-2 rounded-xl bg-[#121422] hover:bg-[#1a1d30] text-gray-300 border border-[#252a40] text-xs transition-colors"
              title="Imprimer / Sauvegarder en PDF"
            >
              <Printer className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scan feedback alert */}
        {scanResult && (
          <div className="mt-4 p-3 rounded-xl bg-cyan-950/70 border border-cyan-500/40 flex items-center justify-between text-xs text-cyan-200 animate-fadeIn">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>{scanResult}</span>
            </div>
            <button onClick={() => setScanResult(null)} className="text-gray-400 hover:text-white">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Lexicographer Pending Proposals Queue */}
        {proposals.filter(p => p.status === "pending_review").length > 0 && (
          <div className="mt-4 p-3.5 rounded-xl bg-purple-950/60 border border-purple-500/50 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-purple-200 flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                {proposals.filter(p => p.status === "pending_review").length} proposition(s) de symbole générée(s) automatiquement par @symbol_lexicographer en attente de validation humaine :
              </span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {proposals.filter(p => p.status === "pending_review").map(prop => (
                <div key={prop.id} className="p-2.5 rounded-lg bg-[#0e101f] border border-purple-800/60 flex items-center justify-between gap-3 text-xs">
                  <div>
                    <div className="font-bold text-cyan-300 font-mono text-sm">{prop.symbol}</div>
                    <div className="text-[11px] text-gray-300">{prop.name} (Source : {prop.equationOrigin})</div>
                  </div>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => symbolDictionaryService.approveProposal(prop.id)}
                      className="px-2 py-1 rounded bg-emerald-700 hover:bg-emerald-600 text-white text-[10px] font-bold flex items-center gap-1"
                    >
                      <Check className="w-3 h-3" /> Valider
                    </button>
                    <button
                      onClick={() => symbolDictionaryService.rejectProposal(prop.id)}
                      className="px-2 py-1 rounded bg-red-950 hover:bg-red-900 text-red-300 text-[10px] font-bold"
                    >
                      Refuser
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>

      {/* 2. NAVIGATION BAR (TABS & FILTERS) */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
        
        {/* View switcher */}
        <div className="flex items-center gap-1 p-1 bg-[#10121e] border border-[#1e2235] rounded-xl overflow-x-auto shrink-0">
          <button
            onClick={() => setActiveView("symbols")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all ${
              activeView === "symbols"
                ? "bg-cyan-600 text-white shadow-lg shadow-cyan-500/20"
                : "text-gray-400 hover:text-white hover:bg-[#181a2b]"
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Symboles ({symbols.length})</span>
          </button>

          <button
            onClick={() => setActiveView("equations")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all ${
              activeView === "equations"
                ? "bg-purple-600 text-white shadow-lg shadow-purple-500/20"
                : "text-gray-400 hover:text-white hover:bg-[#181a2b]"
            }`}
          >
            <Code2 className="w-3.5 h-3.5" />
            <span>Équations ({equations.length})</span>
          </button>

          <button
            onClick={() => setActiveView("simulator")}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all ${
              activeView === "simulator"
                ? "bg-emerald-600 text-white shadow-lg shadow-emerald-500/20"
                : "text-gray-400 hover:text-white hover:bg-[#181a2b]"
            }`}
          >
            <Sliders className="w-3.5 h-3.5" />
            <span>Simulateur Interactif</span>
          </button>
        </div>

        {/* Search Input & Category Filters */}
        <div className="flex-1 flex flex-wrap items-center gap-3">
          <div className="relative flex-1 min-w-[220px]">
            <Search className="w-4 h-4 text-gray-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Rechercher un symbole (Ψ, Φ, ⊗), une équation ou un mot-clé..."
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-[#0e101b] border border-[#1e2235] text-xs text-gray-200 placeholder-gray-500 focus:outline-none focus:border-cyan-500 transition-colors"
            />
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Category filter pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto text-[11px]">
            {["all", "mathematique", "symbolique", "operationnelle", "materielle"].map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 rounded-lg border capitalize transition-all ${
                  selectedCategory === cat
                    ? "bg-[#181d32] border-cyan-500 text-cyan-300 font-bold"
                    : "bg-[#0c0e18] border-[#1a1d2e] text-gray-400 hover:text-gray-200"
                }`}
              >
                {cat === "all" ? "Toutes Catégories" : cat}
              </button>
            ))}
          </div>
        </div>

      </div>

      {/* 3. MAIN WORKSPACE VIEW (SPLIT: LIST + DETAILED INSPECTOR) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* LEFT COLUMN: LIST OF SYMBOLS OR EQUATIONS (5 COLS) */}
        <div className="lg:col-span-5 space-y-4">
          
          {activeView === "symbols" && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-gray-400 px-1">
                <span>{filteredSymbols.length} symbole(s) trouvé(s)</span>
                <span className="text-[10px]">Cliquez pour ouvrir le dossier complet</span>
              </div>

              <div className="space-y-2.5 max-h-[750px] overflow-y-auto pr-1">
                {filteredSymbols.map(sym => {
                  const isSelected = sym.id === selectedSymbol.id;
                  const isTokenHighlighted = highlightedSymbolToken === sym.symbol;

                  return (
                    <motion.div
                      key={sym.id}
                      onClick={() => setSelectedSymbolId(sym.id)}
                      whileHover={{ scale: 1.01 }}
                      className={`p-4 rounded-xl border transition-all cursor-pointer relative group ${
                        isSelected
                          ? "bg-gradient-to-r from-[#12152a] to-[#151833] border-cyan-500 shadow-xl shadow-cyan-500/10 ring-1 ring-cyan-500/30"
                          : isTokenHighlighted
                          ? "bg-gradient-to-r from-purple-950/70 to-indigo-950/70 border-purple-500 animate-pulse"
                          : "bg-[#0d0f1a] border-[#1c2033] hover:border-gray-600 hover:bg-[#111322]"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-center gap-3">
                          <div className={`w-12 h-12 rounded-xl flex items-center justify-center font-mono font-bold text-xl shrink-0 border ${
                            isSelected 
                              ? "bg-cyan-950 text-cyan-300 border-cyan-500/60 shadow-inner" 
                              : "bg-[#141728] text-gray-200 border-[#232740] group-hover:border-cyan-500/40"
                          }`}>
                            {sym.symbol}
                          </div>
                          <div>
                            <div className="text-xs font-bold text-white group-hover:text-cyan-300 transition-colors">
                              {sym.name}
                            </div>
                            <div className="text-[11px] text-gray-400 line-clamp-1 mt-0.5">
                              {sym.humanVersion.summary}
                            </div>
                          </div>
                        </div>

                        <div className="flex flex-col items-end gap-1 shrink-0">
                          <span className={`text-[9px] uppercase px-2 py-0.5 rounded font-bold border ${
                            sym.category === "mathematique" ? "bg-blue-950/80 text-blue-300 border-blue-800" :
                            sym.category === "symbolique" ? "bg-purple-950/80 text-purple-300 border-purple-800" :
                            sym.category === "operationnelle" ? "bg-cyan-950/80 text-cyan-300 border-cyan-800" :
                            "bg-amber-950/80 text-amber-300 border-amber-800"
                          }`}>
                            {sym.category}
                          </span>
                          <span className="text-[9px] text-gray-500 font-mono">
                            {sym.complexity}
                          </span>
                        </div>
                      </div>

                      {/* Micro connection tags */}
                      <div className="mt-2.5 pt-2 border-t border-[#181c2f] flex items-center justify-between text-[10px] text-gray-400">
                        <div className="flex items-center gap-1 text-[9px] text-gray-500 font-mono">
                          <span>Équations :</span>
                          <span className="text-purple-400 font-bold">{sym.connections.equations.length}</span>
                        </div>
                        <div className="flex items-center gap-1 text-[9px] text-cyan-400">
                          <span>Agents :</span>
                          <span className="font-bold">{sym.connections.usedByAgents.slice(0, 2).join(", ")}</span>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </div>
          )}

          {activeView === "equations" && (
            <div className="space-y-3">
              <div className="flex items-center justify-between text-xs text-gray-400 px-1">
                <span>{filteredEquations.length} équation(s) fondamentale(s)</span>
              </div>

              <div className="space-y-3 max-h-[750px] overflow-y-auto pr-1">
                {filteredEquations.map(eq => (
                  <div
                    key={eq.id}
                    className="p-4 rounded-xl bg-[#0d0f1a] border border-[#1c2033] hover:border-purple-500/50 transition-all space-y-3"
                  >
                    <div className="flex items-center justify-between">
                      <h3 className="text-xs font-bold text-purple-300">{eq.name}</h3>
                      <span className="text-[9px] px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800 uppercase font-mono">
                        {eq.category}
                      </span>
                    </div>

                    <div className="p-3 rounded-lg bg-[#07080f] border border-[#1a1d2e] font-mono text-xs text-emerald-300 font-bold overflow-x-auto leading-relaxed">
                      {eq.formula}
                    </div>

                    <p className="text-[11px] text-gray-300 leading-relaxed">
                      {eq.humanSummary}
                    </p>

                    {/* Interactive tokens inside this equation */}
                    <div className="space-y-1 pt-2 border-t border-[#181c2f]">
                      <span className="text-[9px] text-gray-500 uppercase font-bold tracking-wider">Symboles à explorer :</span>
                      <div className="flex flex-wrap gap-1.5">
                        {eq.symbolsUsed.map(symToken => (
                          <button
                            key={symToken}
                            onClick={() => {
                              const match = symbols.find(s => s.symbol === symToken || s.id === symToken);
                              if (match) {
                                setSelectedSymbolId(match.id);
                                setActiveView("symbols");
                              }
                            }}
                            onMouseEnter={() => setHighlightedSymbolToken(symToken)}
                            onMouseLeave={() => setHighlightedSymbolToken(null)}
                            className="px-2 py-0.5 rounded bg-[#141728] hover:bg-cyan-900/40 border border-[#242844] text-[10px] font-mono font-bold text-cyan-300 transition-colors"
                          >
                            {symToken}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeView === "simulator" && (
            <div className="p-5 rounded-2xl bg-[#0d0f1a] border border-[#1c2033] space-y-4">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-emerald-400" />
                <h3 className="text-xs font-bold text-white uppercase tracking-wider">
                  Laboratoire de Simulation Mathématique
                </h3>
              </div>
              <p className="text-xs text-gray-400 leading-relaxed">
                Modifiez les valeurs des variables pour observer en temps réel la réaction de la formule maîtresse Φ_SOI et des agents associés.
              </p>

              <div className="space-y-4 pt-2">
                <div>
                  <div className="flex items-center justify-between text-xs mb-1">
                    <span className="text-gray-300 font-bold">Symbole sélectionné :</span>
                    <span className="text-cyan-400 font-mono font-bold">{selectedSymbol.symbol} ({selectedSymbol.name})</span>
                  </div>
                </div>

                {selectedSymbol.simulationConfig ? (
                  <div className="p-3.5 rounded-xl bg-[#121424] border border-[#20253d] space-y-3">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-gray-300 font-mono">{selectedSymbol.simulationConfig.variableName}</span>
                      <span className="text-emerald-400 font-mono font-bold text-sm">
                        {simValue} {selectedSymbol.simulationConfig.unit}
                      </span>
                    </div>

                    <input
                      type="range"
                      min={selectedSymbol.simulationConfig.min}
                      max={selectedSymbol.simulationConfig.max}
                      step={selectedSymbol.simulationConfig.step}
                      value={simValue}
                      onChange={e => setSimValue(parseFloat(e.target.value))}
                      className="w-full accent-emerald-500 cursor-pointer"
                    />

                    <div className="p-2 rounded-lg bg-[#0a0c16] text-[11px] text-gray-300 border border-[#171b2d]">
                      {selectedSymbol.simulationConfig.impactDescription(simValue)}
                    </div>
                  </div>
                ) : (
                  <div className="p-3 rounded-xl bg-[#121424] text-xs text-gray-400 border border-[#20253d]">
                    Ce symbole est une constante universelle ou un opérateur d'action sans curseur scalaire continu.
                  </div>
                )}

                <button
                  onClick={handleGenerateLiveExample}
                  disabled={isGeneratingExample}
                  className="w-full py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 transition-all"
                >
                  <Zap className={`w-3.5 h-3.5 ${isGeneratingExample ? "animate-spin" : ""}`} />
                  <span>{isGeneratingExample ? "Calcul de Résonance..." : "Exécuter la Simulation Live"}</span>
                </button>

                {liveExampleOutput && (
                  <div className="p-3.5 rounded-xl bg-[#090b14] border border-emerald-500/40 text-xs font-mono text-emerald-300 whitespace-pre-wrap leading-relaxed animate-fadeIn">
                    {liveExampleOutput}
                  </div>
                )}
              </div>
            </div>
          )}

        </div>

        {/* RIGHT COLUMN: DETAILED DOUBLE-LEVEL INSPECTOR (7 COLS) */}
        <div className="lg:col-span-7 bg-[#0b0d17] border border-[#1c2033] rounded-2xl p-6 space-y-6 shadow-2xl relative">
          
          {/* Header of Detailed View */}
          <div className="flex items-start justify-between gap-4 border-b border-[#1c2033] pb-4">
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-cyan-950 via-indigo-950 to-purple-950 border border-cyan-500/50 text-cyan-300 flex items-center justify-center text-2xl font-mono font-black shadow-lg">
                {selectedSymbol.symbol}
              </div>
              <div>
                <h2 className="text-lg font-black text-white">{selectedSymbol.name}</h2>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-[10px] uppercase font-mono px-2 py-0.5 rounded bg-[#161a2e] text-cyan-300 border border-cyan-800">
                    Catégorie : {selectedSymbol.category}
                  </span>
                  <span className="text-[10px] text-gray-500 font-mono">
                    Ajouté le {selectedSymbol.dateAdded}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleGenerateLiveExample}
                disabled={isGeneratingExample}
                className="px-3 py-1.5 rounded-lg bg-emerald-950/80 hover:bg-emerald-900/80 border border-emerald-700 text-emerald-300 text-xs font-bold flex items-center gap-1.5 transition-colors"
                title="Générer un exemple en direct"
              >
                <Zap className="w-3.5 h-3.5" />
                <span>Exemple en Direct</span>
              </button>
            </div>
          </div>

          {/* DOUBLE EXPLANATION SECTIONS */}
          <div className="space-y-4">
            
            {/* 1. VERSION HUMAINE (VERT ÉMERAUDE / CLAIR) */}
            <div className="p-4 rounded-xl bg-gradient-to-br from-[#0c1815] via-[#0e1d19] to-[#0c1714] border border-emerald-500/40 space-y-3 shadow-lg">
              <div className="flex items-center justify-between border-b border-emerald-900/50 pb-2">
                <div className="flex items-center gap-2">
                  <Heart className="w-4 h-4 text-emerald-400 fill-current" />
                  <span className="text-xs font-black uppercase tracking-wider text-emerald-300">
                    Version Humaine (Langage Clair & Intuitif)
                  </span>
                </div>
                <span className="text-[9px] px-2 py-0.5 rounded-full bg-emerald-950 text-emerald-400 border border-emerald-800 font-bold">
                  Compréhension Directe
                </span>
              </div>

              {/* Résumé concis */}
              <p className="text-xs text-gray-100 font-medium leading-relaxed">
                {selectedSymbol.humanVersion.summary}
              </p>

              {/* Ce que cela représente concrètement */}
              <div className="p-3 rounded-lg bg-[#071310] border border-emerald-900/40 text-xs text-gray-200 leading-relaxed space-y-1">
                <span className="text-[10px] uppercase font-bold text-emerald-400 block tracking-wider">Ce que cela fait concrètement :</span>
                <p>{selectedSymbol.humanVersion.concreteMeaning}</p>
              </div>

              {/* Analogie & Exemple */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-lg bg-[#071310] border border-emerald-900/40 space-y-1">
                  <span className="text-[10px] uppercase font-bold text-emerald-400 flex items-center gap-1">
                    <Compass className="w-3 h-3" /> Analogie / Image :
                  </span>
                  <p className="text-gray-300 text-[11px] leading-relaxed italic">
                    "{selectedSymbol.humanVersion.analogy}"
                  </p>
                </div>

                <div className="p-3 rounded-lg bg-[#071310] border border-emerald-900/40 space-y-1">
                  <span className="text-[10px] uppercase font-bold text-emerald-400 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Exemple du Quotidien :
                  </span>
                  <p className="text-gray-300 text-[11px] leading-relaxed">
                    {selectedSymbol.humanVersion.example}
                  </p>
                </div>
              </div>
            </div>

            {/* 2. VERSION TECHNIQUE (CYAN / BLEU PROFOND) */}
            <div className="p-4 rounded-xl bg-gradient-to-br from-[#0c1220] via-[#0e1628] to-[#0c1322] border border-cyan-500/40 space-y-3 shadow-lg">
              <div className="flex items-center justify-between border-b border-cyan-900/50 pb-2">
                <div className="flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-cyan-400" />
                  <span className="text-xs font-black uppercase tracking-wider text-cyan-300">
                    Version Technique (Formalisme MRD & Physique)
                  </span>
                </div>
                <span className="text-[9px] px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-400 border border-cyan-800 font-bold">
                  Niveau Expert
                </span>
              </div>

              {/* Définition formelle */}
              <div className="p-3 rounded-lg bg-[#070b14] border border-cyan-900/40 text-xs text-gray-200 leading-relaxed space-y-1 font-mono">
                <span className="text-[10px] uppercase font-bold text-cyan-400 block tracking-wider">Définition Formelle :</span>
                <p className="text-cyan-200 text-xs">{selectedSymbol.technicalVersion.formalDefinition}</p>
              </div>

              {/* Formule mathématique si disponible */}
              {selectedSymbol.technicalVersion.mathematicalFormula && (
                <div className="p-2.5 rounded-lg bg-[#05080e] border border-cyan-900/60 font-mono text-xs text-emerald-300 font-bold overflow-x-auto">
                  {selectedSymbol.technicalVersion.mathematicalFormula}
                </div>
              )}

              {/* Contexte Mathématique & Utilisation Système */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-lg bg-[#070b14] border border-cyan-900/40 space-y-1">
                  <span className="text-[10px] uppercase font-bold text-cyan-400 flex items-center gap-1">
                    <Activity className="w-3 h-3" /> Origine & Contexte :
                  </span>
                  <p className="text-gray-300 text-[11px] leading-relaxed">
                    {selectedSymbol.technicalVersion.mathContext}
                  </p>
                </div>

                <div className="p-3 rounded-lg bg-[#070b14] border border-cyan-900/40 space-y-1">
                  <span className="text-[10px] uppercase font-bold text-cyan-400 flex items-center gap-1">
                    <Zap className="w-3 h-3" /> Impact Machine & Code :
                  </span>
                  <p className="text-gray-300 text-[11px] leading-relaxed">
                    {selectedSymbol.technicalVersion.systemUsage}
                  </p>
                </div>
              </div>
            </div>

            {/* 3. CONNEXIONS & ÉQUATIONS LIÉES */}
            <div className="p-4 rounded-xl bg-[#0e101c] border border-[#1e2238] space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-purple-300 flex items-center gap-1.5">
                <Network className="w-4 h-4 text-purple-400" />
                Intrications & Connexions Système
              </span>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                {/* Symboles Liés */}
                <div className="p-2.5 rounded-lg bg-[#121524] border border-[#20253d] space-y-1.5">
                  <span className="text-[10px] text-gray-400 uppercase font-bold block">Symboles Liés :</span>
                  <div className="flex flex-wrap gap-1">
                    {selectedSymbol.connections.relatedSymbols.map(sToken => (
                      <button
                        key={sToken}
                        onClick={() => {
                          const match = symbols.find(s => s.symbol === sToken || s.id === sToken);
                          if (match) setSelectedSymbolId(match.id);
                        }}
                        className="px-2 py-0.5 rounded bg-[#171b30] hover:bg-cyan-900/50 text-cyan-300 border border-[#2a3050] text-[10px] font-mono font-bold"
                      >
                        {sToken}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Équations où il apparaît */}
                <div className="p-2.5 rounded-lg bg-[#121524] border border-[#20253d] space-y-1.5">
                  <span className="text-[10px] text-gray-400 uppercase font-bold block">Équations Actives :</span>
                  <div className="flex flex-wrap gap-1">
                    {selectedSymbol.connections.equations.map(eqId => {
                      const eq = equations.find(e => e.id === eqId);
                      return (
                        <button
                          key={eqId}
                          onClick={() => setActiveView("equations")}
                          className="px-2 py-0.5 rounded bg-[#171b30] hover:bg-purple-900/50 text-purple-300 border border-[#2a3050] text-[10px] font-mono"
                        >
                          {eq ? eq.name.split(" ")[0] : eqId}
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Agents mobilisés */}
                <div className="p-2.5 rounded-lg bg-[#121524] border border-[#20253d] space-y-1.5">
                  <span className="text-[10px] text-gray-400 uppercase font-bold block">Agents Mobilisés :</span>
                  <div className="flex flex-wrap gap-1">
                    {selectedSymbol.connections.usedByAgents.map(ag => (
                      <span
                        key={ag}
                        className="px-2 py-0.5 rounded bg-[#171b30] text-emerald-300 border border-[#2a3050] text-[10px] font-mono font-bold"
                      >
                        {ag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Live Example Output Box if generated */}
            {liveExampleOutput && (
              <div className="p-4 rounded-xl bg-[#090d18] border border-emerald-500/50 text-xs font-mono text-emerald-300 whitespace-pre-wrap leading-relaxed shadow-xl animate-fadeIn">
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-emerald-900/40 text-emerald-400 font-bold">
                  <span className="flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 fill-current" />
                    Exécution en direct transmise par @symbol_lexicographer :
                  </span>
                  <button onClick={() => setLiveExampleOutput(null)} className="text-gray-400 hover:text-white">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
                {liveExampleOutput}
              </div>
            )}

          </div>

        </div>

      </div>

      {/* 4. MODAL : AJOUT MANUEL D'UN SYMBOLE AVEC VALIDATION HUMAINE */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-[#0e101d] border border-[#252a42] rounded-2xl w-full max-w-2xl p-6 space-y-4 shadow-2xl relative my-8">
            
            <div className="flex items-center justify-between border-b border-[#20253d] pb-3">
              <div className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-cyan-400" />
                <h3 className="text-sm font-bold uppercase tracking-wider text-white">
                  Ajouter un Symbole au Dictionnaire
                </h3>
              </div>
              <button onClick={() => setIsAddModalOpen(false)} className="text-gray-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateSymbolSubmit} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="text-gray-400 font-bold block mb-1">Symbole (ex: Ψ_m, ∇Ψ, θ) :</label>
                  <input
                    type="text"
                    required
                    value={newSymbolForm.symbol}
                    onChange={e => setNewSymbolForm({ ...newSymbolForm, symbol: e.target.value })}
                    className="w-full p-2.5 rounded-lg bg-[#07080f] border border-[#1f2338] text-white font-mono"
                    placeholder="Ψ_m"
                  />
                </div>
                <div>
                  <label className="text-gray-400 font-bold block mb-1">Nom Complet :</label>
                  <input
                    type="text"
                    required
                    value={newSymbolForm.name}
                    onChange={e => setNewSymbolForm({ ...newSymbolForm, name: e.target.value })}
                    className="w-full p-2.5 rounded-lg bg-[#07080f] border border-[#1f2338] text-white"
                    placeholder="Fonction d'onde globale"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="text-gray-400 font-bold block mb-1">Catégorie :</label>
                  <select
                    value={newSymbolForm.category}
                    onChange={e => setNewSymbolForm({ ...newSymbolForm, category: e.target.value as any })}
                    className="w-full p-2.5 rounded-lg bg-[#07080f] border border-[#1f2338] text-white"
                  >
                    <option value="mathematique">Mathématique</option>
                    <option value="symbolique">Symbolique</option>
                    <option value="operationnelle">Opérationnelle</option>
                    <option value="materielle">Matérielle</option>
                  </select>
                </div>
                <div>
                  <label className="text-gray-400 font-bold block mb-1">Complexité :</label>
                  <select
                    value={newSymbolForm.complexity}
                    onChange={e => setNewSymbolForm({ ...newSymbolForm, complexity: e.target.value as any })}
                    className="w-full p-2.5 rounded-lg bg-[#07080f] border border-[#1f2338] text-white"
                  >
                    <option value="fondamental">Fondamental</option>
                    <option value="intermediaire">Intermédiaire</option>
                    <option value="avance">Avancé</option>
                    <option value="transcendant">Transcendant</option>
                  </select>
                </div>
                <div>
                  <label className="text-gray-400 font-bold block mb-1">Agent Responsable :</label>
                  <input
                    type="text"
                    value={newSymbolForm.usedByAgent}
                    onChange={e => setNewSymbolForm({ ...newSymbolForm, usedByAgent: e.target.value })}
                    className="w-full p-2.5 rounded-lg bg-[#07080f] border border-[#1f2338] text-white font-mono"
                    placeholder="@supervisor"
                  />
                </div>
              </div>

              {/* Version Humaine */}
              <div className="p-3 rounded-xl bg-[#091512] border border-emerald-500/30 space-y-2">
                <span className="text-[11px] font-bold text-emerald-400 uppercase">Version Humaine (Langage Simple) :</span>
                <div>
                  <textarea
                    rows={2}
                    placeholder="Ce qu'il représente concrètement en mots simples..."
                    value={newSymbolForm.humanConcrete}
                    onChange={e => setNewSymbolForm({ ...newSymbolForm, humanConcrete: e.target.value })}
                    className="w-full p-2 rounded bg-[#050c0a] border border-emerald-900/50 text-gray-200"
                  />
                </div>
                <div>
                  <input
                    type="text"
                    placeholder="Une analogie simple (ex: comme la météo intérieure)..."
                    value={newSymbolForm.humanAnalogy}
                    onChange={e => setNewSymbolForm({ ...newSymbolForm, humanAnalogy: e.target.value })}
                    className="w-full p-2 rounded bg-[#050c0a] border border-emerald-900/50 text-gray-200"
                  />
                </div>
              </div>

              {/* Version Technique */}
              <div className="p-3 rounded-xl bg-[#08101a] border border-cyan-500/30 space-y-2">
                <span className="text-[11px] font-bold text-cyan-400 uppercase">Version Technique (Mathématique / Code) :</span>
                <div>
                  <textarea
                    rows={2}
                    placeholder="Définition formelle, équations, contexte de Hilbert / MRD..."
                    value={newSymbolForm.techDefinition}
                    onChange={e => setNewSymbolForm({ ...newSymbolForm, techDefinition: e.target.value })}
                    className="w-full p-2 rounded bg-[#04080e] border border-cyan-900/50 text-gray-200 font-mono"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#1f2338]">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-lg bg-[#141726] hover:bg-[#1a1e32] text-gray-300"
                >
                  Annuler
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-gradient-to-r from-cyan-600 to-teal-600 text-white font-bold shadow-lg shadow-cyan-500/20"
                >
                  Valider et Enregistrer
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
}
