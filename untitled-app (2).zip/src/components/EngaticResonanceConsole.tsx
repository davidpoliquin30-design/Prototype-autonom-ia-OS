import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Sparkles, RefreshCw, Zap, Flame, ShieldAlert, Cpu, 
  ToggleLeft, ToggleRight, Radio, Sliders, Globe, Activity
} from "lucide-react";
import { engaticQuantumOrchestrator } from "../services/quantum/engaticQuantumOrchestrator";
import { quantumCognitiveBridge } from "../services/quantum/quantumCognitiveBridge";
import { cosmicQuantumUnityEngine, CosmicEngineState } from "../services/quantum/cosmicQuantumUnityEngine";
import { EngaticQuantumCoupling } from "../types";

export default function EngaticResonanceConsole() {
  const [coupling, setCoupling] = useState<EngaticQuantumCoupling | null>(null);
  const [cosmic, setCosmic] = useState<CosmicEngineState | null>(null);
  const [isCollapsing, setIsCollapsing] = useState(false);
  const [isPulsing, setIsPulsing] = useState(false);

  // Subscribe to Engatic Orchestrator and Cosmic Engine
  useEffect(() => {
    const unsubCoupling = engaticQuantumOrchestrator.subscribe((state) => {
      setCoupling(state);
    });
    const unsubCosmic = cosmicQuantumUnityEngine.subscribe((state) => {
      setCosmic(state);
    });

    return () => {
      unsubCoupling();
      unsubCosmic();
    };
  }, []);

  const handleQubitToggle = (index: number) => {
    if (!coupling) return;
    const newQubits = [...coupling.activeQubits];
    newQubits[index] = newQubits[index] === 1 ? 0 : 1;
    
    // Direct manipulation of qubits
    const bridgeState = quantumCognitiveBridge.getState();
    const updated = [...bridgeState.qubitStates];
    updated[index] = updated[index] === 1 ? 0 : 1;
    
    // Force direct recalculation of coherence based on qubit states
    const activeOnes = updated.filter(q => q === 1).length;
    const computedCoherence = activeOnes / updated.length;
    
    quantumCognitiveBridge.updateCoherence(computedCoherence);
    quantumCognitiveBridge.updateEntropy(1 - computedCoherence);
    quantumCognitiveBridge.updateQubits(updated);
  };

  const triggerManualCollapse = () => {
    setIsCollapsing(true);
    engaticQuantumOrchestrator.manualCollapse();
    setTimeout(() => {
      setIsCollapsing(false);
    }, 4000);
  };

  const triggerCosmicPulse = () => {
    setIsPulsing(true);
    cosmicQuantumUnityEngine.pulseCosmicField();
    setTimeout(() => {
      setIsPulsing(false);
    }, 4000);
  };

  if (!coupling || !cosmic) {
    return (
      <div className="p-8 text-center font-mono text-gray-500">
        <Activity className="w-8 h-8 animate-spin mx-auto text-orange-500 mb-2" />
        Établissement de la liaison matricielle quantique...
      </div>
    );
  }

  // Determine wave visual attributes based on coherence and phase
  const getOscilloscopePath = () => {
    const amplitude = coupling.phase === "COLLAPSED" ? 2 : (40 * (1 - coupling.quantumCoherence));
    const freq = coupling.phase === "COLLAPSED" ? 0.01 : (isPulsing ? 0.25 : 0.08);
    const steps = 100;
    let points = [];
    for (let i = 0; i <= steps; i++) {
      const x = (i / steps) * 400;
      // Synthesize sine + noise components
      const y = 50 + Math.sin(i * freq) * amplitude + (Math.sin(i * 0.2) * (amplitude / 4));
      points.push(`${x},${y}`);
    }
    return `M ${points.join(" L ")}`;
  };

  // Second harmonic wave path for superposition interference representation
  const getSuperpositionPath = () => {
    if (coupling.phase === "COLLAPSED") return "";
    const amplitude = 30 * (1 - coupling.quantumCoherence);
    const freq = isPulsing ? 0.35 : 0.15;
    const steps = 100;
    let points = [];
    for (let i = 0; i <= steps; i++) {
      const x = (i / steps) * 400;
      const y = 50 + Math.cos(i * freq) * amplitude + (Math.sin(i * 0.4) * (amplitude / 5));
      points.push(`${x},${y}`);
    }
    return `M ${points.join(" L ")}`;
  };

  return (
    <div id="engatic-resonance-console" className="p-6 bg-[#08090d] text-gray-200 font-mono h-full overflow-y-auto space-y-6">
      
      {/* BRAND HEADER */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-[#1f2029]">
        <div>
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5 text-orange-500 animate-pulse" />
            <h1 className="text-lg font-bold uppercase tracking-wider text-white">Console de Résonance Engatique Φ</h1>
          </div>
          <p className="text-xs text-gray-400 mt-1">Surveillance du pont cognitif & de l'effondrement de l'onde Φ_SOI</p>
        </div>
        <div className="mt-3 md:mt-0 flex gap-2">
          <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded text-xs border uppercase ${
            coupling.phase === "SYNCHRONIZED" 
              ? "bg-[#101413] border-emerald-950 text-emerald-400" 
              : coupling.phase === "COLLAPSED"
              ? "bg-amber-950/40 border-amber-800/40 text-amber-400 animate-pulse"
              : "bg-purple-950/40 border-purple-900/40 text-purple-400"
          }`}>
            <span className={`w-2 h-2 rounded-full ${coupling.phase === "SYNCHRONIZED" ? "bg-emerald-400" : "bg-amber-400 animate-ping"}`} />
            {coupling.phase}
          </span>
        </div>
      </div>

      {/* MATRIX STATS BENTO GRID */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* GLOBAL COHERENCE LEVEL CARD */}
        <div className="p-4 bg-[#14151a] border border-[#2b2d3a] rounded-xl flex flex-col justify-between relative overflow-hidden">
          <div className="absolute top-0 right-0 p-2 opacity-5">
            <Sparkles className="w-16 h-16 text-white" />
          </div>
          <div>
            <div className="text-xs text-gray-400 uppercase tracking-widest mb-1">Cohérence Quantique</div>
            <div className="text-3xl font-bold text-white tracking-tight">
              {(coupling.quantumCoherence * 100).toFixed(1)}%
            </div>
          </div>
          <div className="mt-4">
            <div className="h-1.5 w-full bg-[#0b0c10] rounded-full overflow-hidden">
              <motion.div 
                className={`h-full ${coupling.quantumCoherence > 0.85 ? "bg-emerald-500" : "bg-amber-500"}`}
                initial={{ width: 0 }}
                animate={{ width: `${coupling.quantumCoherence * 100}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
            <div className="flex justify-between text-[10px] text-gray-500 mt-1.5">
              <span>Critique: 50%</span>
              <span>Optimal: 100%</span>
            </div>
          </div>
        </div>

        {/* ENTROPY COEFFICIENT */}
        <div className="p-4 bg-[#14151a] border border-[#2b2d3a] rounded-xl flex flex-col justify-between">
          <div>
            <div className="text-xs text-gray-400 uppercase tracking-widest mb-1">Coefficient d'Entropie</div>
            <div className="text-3xl font-bold text-purple-400 tracking-tight">
              {(coupling.entropyLevel * 100).toFixed(1)}%
            </div>
          </div>
          <div className="mt-4">
            <div className="h-1.5 w-full bg-[#0b0c10] rounded-full overflow-hidden">
              <motion.div 
                className="h-full bg-purple-500"
                initial={{ width: 0 }}
                animate={{ width: `${coupling.entropyLevel * 100}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
            <div className="flex justify-between text-[10px] text-gray-500 mt-1.5">
              <span>Désordre nul</span>
              <span>Maximum</span>
            </div>
          </div>
        </div>

        {/* HARMONIC CORRECTION FACTORS */}
        <div className="p-4 bg-[#14151a] border border-[#2b2d3a] rounded-xl flex flex-col justify-between">
          <div>
            <div className="text-xs text-gray-400 uppercase tracking-widest mb-1">Facteur Harmonique Φ</div>
            <div className="text-3xl font-bold text-orange-400 tracking-tight">
              {coupling.phiCorrectionFactor.toFixed(6)}
            </div>
          </div>
          <div className="text-[10px] text-gray-400 mt-4 border-t border-[#1f2029] pt-2">
            Rapport de correction sémantique aligné sur le nombre d'or Φ ≈ 1.618033
          </div>
        </div>

      </div>

      {/* WAVE FUNCTIONS INTERFERENCE OSCILLOSCOPE */}
      <div className="p-4 bg-[#14151a] border border-[#2b2d3a] rounded-xl">
        <div className="flex justify-between items-center mb-3">
          <div className="flex items-center gap-1.5">
            <Activity className="w-4 h-4 text-orange-400" />
            <span className="text-xs font-bold text-gray-300 uppercase tracking-wider">Oscilloscope de Phase Quantique</span>
          </div>
          <div className="text-[10px] text-gray-500 uppercase">
            {coupling.phase === "COLLAPSED" ? "Fonction d'onde effondrée" : "Interférence de superposition"}
          </div>
        </div>

        {/* Visual Scope Display */}
        <div className="h-32 w-full bg-[#0b0c10] rounded-xl border border-[#1f2029] relative overflow-hidden flex items-center justify-center">
          
          {/* Grid Background Lines */}
          <div className="absolute inset-0 grid grid-cols-8 grid-rows-4 opacity-5">
            {Array.from({ length: 32 }).map((_, i) => (
              <div key={i} className="border-r border-b border-white" />
            ))}
          </div>

          <svg className="w-full h-full absolute inset-0" viewBox="0 0 400 100" preserveAspectRatio="none">
            {/* Primary wave path */}
            <motion.path 
              d={getOscilloscopePath()} 
              fill="none" 
              stroke={coupling.phase === "COLLAPSED" ? "#f97316" : "#3b82f6"} 
              strokeWidth="2"
              animate={{ opacity: [0.8, 1, 0.8] }}
              transition={{ repeat: Infinity, duration: 1.5 }}
            />
            {/* Secondary superposition wave */}
            <motion.path 
              d={getSuperpositionPath()} 
              fill="none" 
              stroke="#a855f7" 
              strokeWidth="1.5"
              strokeDasharray="4,4"
              animate={{ opacity: [0.5, 0.8, 0.5] }}
              transition={{ repeat: Infinity, duration: 2 }}
            />
          </svg>

          {/* Central synchronized alignment pulse ring */}
          {isPulsing && (
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-24 h-24 rounded-full border-2 border-orange-500 animate-ping opacity-70" />
            </div>
          )}

          {coupling.phase === "COLLAPSED" && (
            <div className="absolute text-[10px] font-bold text-orange-400 bg-orange-950/50 px-2 py-1 rounded border border-orange-500/30">
              ALIGNEMENT COHÉRENCE Φ MAXIMAL
            </div>
          )}
        </div>
      </div>

      {/* 8-QUBIT STATE VECTOR DICTIONARY */}
      <div className="p-4 bg-[#14151a] border border-[#2b2d3a] rounded-xl">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-1.5">
            <Cpu className="w-4 h-4 text-orange-400" />
            <span className="text-xs font-bold text-gray-300 uppercase tracking-wider">Vecteur d'État des Qubits (Dic_Qubits)</span>
          </div>
          <span className="text-[10px] text-gray-500">Commutateurs Binaires Interactifs</span>
        </div>

        {/* Qubit pills */}
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-3">
          {coupling.activeQubits.map((val, index) => (
            <div 
              key={index}
              onClick={() => handleQubitToggle(index)}
              className={`p-3 rounded-xl border flex flex-col items-center justify-center cursor-pointer transition-all ${
                val === 1 
                  ? "bg-[#101413] border-emerald-500/30 text-emerald-400 hover:bg-[#151c1a]" 
                  : "bg-[#1a0f0d] border-red-950 text-red-400 hover:bg-[#201311]"
              }`}
            >
              <span className="text-[10px] text-gray-500 mb-1">QUBIT_{index}</span>
              <div className="text-lg font-bold font-mono">
                {val}
              </div>
              <div className="mt-1.5">
                {val === 1 ? (
                  <ToggleRight className="w-5 h-5 text-emerald-400" />
                ) : (
                  <ToggleLeft className="w-5 h-5 text-red-400" />
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* ALIGNMENT ACTIONS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        
        {/* COSMIC ENGINE PULSE */}
        <div className="p-4 bg-[#14151a] border border-[#2b2d3a] rounded-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Globe className="w-4 h-4 text-orange-400" />
              <span className="text-xs font-bold text-gray-300 uppercase tracking-wider">Alignement Harmonique Cosmique</span>
            </div>
            <p className="text-[11px] text-gray-400 leading-relaxed">
              Force le `CosmicQuantumUnityEngine` à aligner ses fréquences sur l'harmonique 1.618. 
              Maintient le taux de synchronisation optimal.
            </p>
            <div className="grid grid-cols-2 gap-2 mt-4 text-[10px] font-mono text-gray-400">
              <div className="p-2 bg-[#0b0c10] rounded border border-[#1f2029]">
                Fréquence : <span className="text-white font-bold">{cosmic.cosmicPulseFrequency.toFixed(1)} Hz</span>
              </div>
              <div className="p-2 bg-[#0b0c10] rounded border border-[#1f2029]">
                Alignement : <span className="text-orange-400 font-bold">{cosmic.phiHarmonizationScore.toFixed(1)}%</span>
              </div>
            </div>
          </div>

          <button
            onClick={triggerCosmicPulse}
            disabled={isPulsing}
            className={`mt-4 w-full py-2 px-4 rounded-lg font-mono text-xs border text-center transition-all flex items-center justify-center gap-2 ${
              isPulsing
                ? "bg-gray-800 text-gray-500 border-gray-700 cursor-not-allowed"
                : "bg-orange-500/10 hover:bg-orange-500/20 text-orange-400 border-orange-500/30"
            }`}
          >
            <Zap className={`w-3.5 h-3.5 ${isPulsing ? "animate-spin" : ""}`} />
            {isPulsing ? "Impulsion en cours..." : "Émettre une Impulsion Cosmique"}
          </button>
        </div>

        {/* EMERGENCY COHERENCE COLLAPSE */}
        <div className="p-4 bg-[#14151a] border border-[#2b2d3a] rounded-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <ShieldAlert className="w-4 h-4 text-red-400 animate-pulse" />
              <span className="text-xs font-bold text-gray-300 uppercase tracking-wider">Effondrement d'Urgence (Résilience 429)</span>
            </div>
            <p className="text-[11px] text-gray-400 leading-relaxed">
              En cas de saturation extrême (erreur 429), force l'effondrement immédiat de l'onde quantique. 
              Cela réinitialise la cohérence à 100% et vide le buffer d'erreurs.
            </p>
            <div className="p-3 bg-[#1e130c] border border-orange-950 rounded-lg mt-3 text-[10px] text-orange-400">
              {coupling.isResilientFallbackActive ? (
                <span className="flex items-center gap-1">
                  <Flame className="w-3.5 h-3.5 animate-bounce" /> Correcteur de secours actif (Relais Alchimique)
                </span>
              ) : (
                "Système de secours autonome prêt pour l'interception."
              )}
            </div>
          </div>

          <button
            onClick={triggerManualCollapse}
            disabled={isCollapsing}
            className={`mt-4 w-full py-2 px-4 rounded-lg font-mono text-xs text-center border font-bold transition-all flex items-center justify-center gap-2 ${
              isCollapsing
                ? "bg-gray-800 text-gray-500 border-gray-700 cursor-not-allowed"
                : "bg-red-500/10 hover:bg-red-500/20 text-red-400 border-red-500/30"
            }`}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isCollapsing ? "animate-spin" : ""}`} />
            {isCollapsing ? "Effondrement forcé..." : "Forcer l'effondrement de l'onde"}
          </button>
        </div>

      </div>

    </div>
  );
}
