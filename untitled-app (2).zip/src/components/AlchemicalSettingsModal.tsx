import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Key, Cpu, Layers, Globe, ShieldAlert, PlugZap, X, Check, AlertCircle, 
  RefreshCw, Info, DollarSign
} from "lucide-react";
import { apiMatrixRoutingService, PHI_SUPER_AGENTS } from "../services/agents/apiMatrixRoutingService";

interface AlchemicalSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AlchemicalSettingsModal({ isOpen, onClose }: AlchemicalSettingsModalProps) {
  const [activeSubTab, setActiveSubTab] = useState<"keys" | "matrix">("keys");
  const [geminiKey, setGeminiKey] = useState("");
  const [openaiKey, setOpenaiKey] = useState("");
  const [anthropicKey, setAnthropicKey] = useState("");
  const [ollamaEndpoint, setOllamaEndpoint] = useState("");
  
  // Connection status states: 'untested' | 'loading' | 'success' | 'failed'
  const [connectionStatuses, setConnectionStatuses] = useState<{ [key: string]: 'untested' | 'loading' | 'success' | 'failed' }>({
    gemini: 'untested',
    openai: 'untested',
    anthropic: 'untested',
    ollama: 'untested',
    local_gguf: 'success',
    local_deterministic: 'success'
  });

  const [agentAssignments, setAgentAssignments] = useState<{ [agentId: string]: string }>({});

  // Cost projections based on simulated 100k socratic characters processed across agents
  const [projectedCost, setProjectedCost] = useState(0);

  // Sync state with apiMatrixRoutingService on open
  useEffect(() => {
    if (isOpen) {
      const gConfig = apiMatrixRoutingService.getProviderConfig("gemini");
      const oConfig = apiMatrixRoutingService.getProviderConfig("openai");
      const aConfig = apiMatrixRoutingService.getProviderConfig("anthropic");
      const ollConfig = apiMatrixRoutingService.getProviderConfig("ollama");

      setGeminiKey(gConfig.apiKey || "");
      setOpenaiKey(oConfig.apiKey || "");
      setAnthropicKey(aConfig.apiKey || "");
      setOllamaEndpoint(ollConfig.localEndpoint || "http://localhost:11434");

      // Load agent assignments
      const loadedAssignments: { [agentId: string]: string } = {};
      PHI_SUPER_AGENTS.forEach(agent => {
        loadedAssignments[agent.id] = apiMatrixRoutingService.getAgentAssignment(agent.id);
      });
      setAgentAssignments(loadedAssignments);
    }
  }, [isOpen]);

  // Recalculate projected character cost (e.g. 50k input chars + 50k output chars across all assigned agents)
  useEffect(() => {
    let sum = 0;
    Object.entries(agentAssignments).forEach(([agentId, providerKey]) => {
      // Impact budget simulated cost weights
      sum += apiMatrixRoutingService.calculateImpactCost(agentId, 100000); // 100k chars benchmark
    });
    setProjectedCost(sum);
  }, [agentAssignments]);

  const handleSaveKeys = () => {
    apiMatrixRoutingService.updateProviderConfig("gemini", { apiKey: geminiKey });
    apiMatrixRoutingService.updateProviderConfig("openai", { apiKey: openaiKey });
    apiMatrixRoutingService.updateProviderConfig("anthropic", { apiKey: anthropicKey });
    apiMatrixRoutingService.updateProviderConfig("ollama", { localEndpoint: ollamaEndpoint });
    alert("Foyers d'énergie quantiques sauvegardés avec succès !");
  };

  const handleTestConnection = async (providerKey: string) => {
    setConnectionStatuses(prev => ({ ...prev, [providerKey]: 'loading' }));
    
    // Save keys first to make sure the test uses the latest value
    if (providerKey === "gemini") apiMatrixRoutingService.updateProviderConfig("gemini", { apiKey: geminiKey });
    if (providerKey === "openai") apiMatrixRoutingService.updateProviderConfig("openai", { apiKey: openaiKey });
    if (providerKey === "anthropic") apiMatrixRoutingService.updateProviderConfig("anthropic", { apiKey: anthropicKey });
    if (providerKey === "ollama") apiMatrixRoutingService.updateProviderConfig("ollama", { localEndpoint: ollamaEndpoint });

    const isAlive = await apiMatrixRoutingService.testConnection(providerKey);
    setConnectionStatuses(prev => ({ 
      ...prev, 
      [providerKey]: isAlive ? 'success' : 'failed' 
    }));
  };

  const handleAssignAgent = (agentId: string, providerKey: string) => {
    apiMatrixRoutingService.setAgentAssignment(agentId, providerKey);
    setAgentAssignments(prev => ({ ...prev, [agentId]: providerKey }));
  };

  // Canada TPS/TVQ fiscal rate simulation (5% + 9.975%)
  const TPS_RATE = 0.05;
  const TVQ_RATE = 0.09975;
  const simulatedTaxes = projectedCost * (TPS_RATE + TVQ_RATE);
  const totalCostWithTaxes = projectedCost + simulatedTaxes;

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50 font-mono backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="bg-[#0b0c10] border border-[#2b2d3a] rounded-xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col text-gray-200"
      >
        
        {/* HEADER */}
        <div className="flex items-center justify-between px-6 py-4 bg-[#14151a] border-b border-[#1f2029]">
          <div className="flex items-center gap-2.5">
            <PlugZap className="w-5 h-5 text-orange-500 animate-pulse" />
            <span className="text-sm font-bold uppercase tracking-wider text-white">Alchimie des Énergies & Routage Cognitif</span>
          </div>
          <button 
            onClick={onClose}
            className="p-1 hover:bg-[#1e202b] rounded transition-colors text-gray-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* DOUBLE TABS */}
        <div className="flex border-b border-[#1f2029] bg-[#0c0d12]">
          <button
            onClick={() => setActiveSubTab("keys")}
            className={`flex-1 py-3 px-4 text-xs font-bold uppercase tracking-widest transition-all text-center border-b-2 ${
              activeSubTab === "keys"
                ? "border-orange-500 text-orange-400 bg-[#14151a]/40"
                : "border-transparent text-gray-400 hover:text-gray-200 hover:bg-[#14151a]/10"
            }`}
          >
            <Key className="w-3.5 h-3.5 inline mr-1.5" />
            1. Foyers d'Énergie (Clés API)
          </button>
          
          <button
            onClick={() => setActiveSubTab("matrix")}
            className={`flex-1 py-3 px-4 text-xs font-bold uppercase tracking-widest transition-all text-center border-b-2 ${
              activeSubTab === "matrix"
                ? "border-orange-500 text-orange-400 bg-[#14151a]/40"
                : "border-transparent text-gray-400 hover:text-gray-200 hover:bg-[#14151a]/10"
            }`}
          >
            <Layers className="w-3.5 h-3.5 inline mr-1.5" />
            2. Matrice d'Assignation (Multi-Agents)
          </button>
        </div>

        {/* CONTAINER CONTENT */}
        <div className="p-6 flex-1 overflow-y-auto space-y-6 min-h-[350px] max-h-[500px]">
          
          {/* TAB 1: KEYS CONFIGURATION */}
          {activeSubTab === "keys" && (
            <div className="space-y-5">
              
              <div className="text-[11px] text-gray-400 bg-orange-950/10 border border-orange-950/40 p-3 rounded-lg leading-relaxed">
                Configurez vos foyers d'énergie cloud ou locaux. Les clés API sont chiffrées localement dans votre cache. 
                Si un agent est configuré sur Ollama, assurez-vous que l'application Ollama est active en tâche de fond.
              </div>

              {/* API KEYS INPUTS */}
              <div className="space-y-4">
                
                {/* GEMINI */}
                <div className="p-3 bg-[#121319] border border-[#1f2029] rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-orange-500" />
                      <label className="text-xs font-bold text-gray-300">Clé d'API Gemini Cloud (Overrule)</label>
                    </div>
                    <input
                      type="password"
                      value={geminiKey}
                      onChange={(e) => setGeminiKey(e.target.value)}
                      placeholder="Laisser vide pour utiliser le quota partagé..."
                      className="w-full bg-[#0b0c10] border border-[#1f2029] rounded p-2 text-xs text-gray-300 focus:outline-none focus:border-orange-500/50"
                    />
                  </div>
                  <div className="flex items-center gap-2 self-end md:self-center">
                    <LEDIndicator status={connectionStatuses.gemini} />
                    <button
                      onClick={() => handleTestConnection("gemini")}
                      className="py-1.5 px-3 bg-[#1e202b] hover:bg-[#282a39] border border-[#2b2d3a] text-[10px] font-bold rounded text-gray-300 transition-colors"
                    >
                      {connectionStatuses.gemini === 'loading' ? 'Validation...' : 'Tester'}
                    </button>
                  </div>
                </div>

                {/* OPENAI */}
                <div className="p-3 bg-[#121319] border border-[#1f2029] rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />
                      <label className="text-xs font-bold text-gray-300">Clé d'API OpenAI Expert</label>
                    </div>
                    <input
                      type="password"
                      value={openaiKey}
                      onChange={(e) => setOpenaiKey(e.target.value)}
                      placeholder="sk-proj-..."
                      className="w-full bg-[#0b0c10] border border-[#1f2029] rounded p-2 text-xs text-gray-300 focus:outline-none focus:border-orange-500/50"
                    />
                  </div>
                  <div className="flex items-center gap-2 self-end md:self-center">
                    <LEDIndicator status={connectionStatuses.openai} />
                    <button
                      onClick={() => handleTestConnection("openai")}
                      className="py-1.5 px-3 bg-[#1e202b] hover:bg-[#282a39] border border-[#2b2d3a] text-[10px] font-bold rounded text-gray-300 transition-colors"
                    >
                      {connectionStatuses.openai === 'loading' ? 'Validation...' : 'Tester'}
                    </button>
                  </div>
                </div>

                {/* ANTHROPIC */}
                <div className="p-3 bg-[#121319] border border-[#1f2029] rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-purple-500" />
                      <label className="text-xs font-bold text-gray-300">Clé d'API Anthropic Expert</label>
                    </div>
                    <input
                      type="password"
                      value={anthropicKey}
                      onChange={(e) => setAnthropicKey(e.target.value)}
                      placeholder="sk-ant-..."
                      className="w-full bg-[#0b0c10] border border-[#1f2029] rounded p-2 text-xs text-gray-300 focus:outline-none focus:border-orange-500/50"
                    />
                  </div>
                  <div className="flex items-center gap-2 self-end md:self-center">
                    <LEDIndicator status={connectionStatuses.anthropic} />
                    <button
                      onClick={() => handleTestConnection("anthropic")}
                      className="py-1.5 px-3 bg-[#1e202b] hover:bg-[#282a39] border border-[#2b2d3a] text-[10px] font-bold rounded text-gray-300 transition-colors"
                    >
                      {connectionStatuses.anthropic === 'loading' ? 'Validation...' : 'Tester'}
                    </button>
                  </div>
                </div>

                {/* OLLAMA LOCAL ENDPOINT */}
                <div className="p-3 bg-[#121319] border border-[#1f2029] rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      <label className="text-xs font-bold text-gray-300">Endpoint Local Ollama (Hors-Ligne)</label>
                    </div>
                    <input
                      type="text"
                      value={ollamaEndpoint}
                      onChange={(e) => setOllamaEndpoint(e.target.value)}
                      placeholder="http://localhost:11434"
                      className="w-full bg-[#0b0c10] border border-[#1f2029] rounded p-2 text-xs text-gray-300 focus:outline-none focus:border-orange-500/50"
                    />
                  </div>
                  <div className="flex items-center gap-2 self-end md:self-center">
                    <LEDIndicator status={connectionStatuses.ollama} />
                    <button
                      onClick={() => handleTestConnection("ollama")}
                      className="py-1.5 px-3 bg-[#1e202b] hover:bg-[#282a39] border border-[#2b2d3a] text-[10px] font-bold rounded text-gray-300 transition-colors"
                    >
                      {connectionStatuses.ollama === 'loading' ? 'Ping...' : 'Tester'}
                    </button>
                  </div>
                </div>

              </div>

              <div className="flex justify-end pt-3">
                <button
                  onClick={handleSaveKeys}
                  className="px-5 py-2.5 bg-orange-500 hover:bg-orange-600 text-black font-black text-xs uppercase tracking-wider rounded-lg transition-all shadow-md shadow-orange-500/10"
                >
                  Sauvegarder les Foyers
                </button>
              </div>

            </div>
          )}

          {/* TAB 2: AGENT TO MODEL ASSIGNMENTS */}
          {activeSubTab === "matrix" && (
            <div className="space-y-6">
              
              <div className="text-[11px] text-gray-400 bg-orange-950/10 border border-orange-950/40 p-3 rounded-lg leading-relaxed">
                Assignez une <strong>"Aura d'Exécution"</strong> individuelle à chaque super-agent. 
                Le routage s'occupe de rediriger de manière sécurisée et d'activer l'intercepteur de résilience si le service local n'est pas détecté.
              </div>

              {/* LIST OF SUPER AGENTS */}
              <div className="space-y-3">
                {PHI_SUPER_AGENTS.map((agent) => {
                  const assigned = agentAssignments[agent.id] || "local_deterministic";
                  return (
                    <div 
                      key={agent.id}
                      className="p-3.5 bg-[#121319] border border-[#1f2029] rounded-xl flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all hover:border-gray-700"
                    >
                      <div>
                        <div className="text-xs font-bold text-white flex items-center gap-1.5">
                          <Cpu className="w-3.5 h-3.5 text-orange-400" />
                          {agent.name}
                        </div>
                        <div className="text-[10px] text-gray-500 mt-1">
                          ID: <span className="font-mono text-gray-400">{agent.id}</span>
                        </div>
                      </div>

                      {/* Provider Select dropdown */}
                      <div className="shrink-0">
                        <select
                          value={assigned}
                          onChange={(e) => handleAssignAgent(agent.id, e.target.value)}
                          className="bg-[#0b0c10] border border-[#1f2029] text-xs font-mono p-2 rounded-lg text-orange-400 focus:outline-none focus:border-orange-500/50"
                        >
                          <option value="gemini">Gemini Cloud (Rapide)</option>
                          <option value="openai">OpenAI Expert (Avancé)</option>
                          <option value="anthropic">Anthropic Expert (Nuancé)</option>
                          <option value="ollama">Ollama Local (Privé)</option>
                          <option value="local_gguf">WASM GGUF (Autonome)</option>
                          <option value="local_deterministic">Moteur Déterministe (Secours)</option>
                        </select>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* BUDGET PROJECTION PANEL */}
              <div className="p-4 bg-[#14151a] border border-orange-500/20 rounded-xl space-y-3">
                <div className="flex items-center gap-1.5 border-b border-[#1f2029] pb-2">
                  <DollarSign className="w-4 h-4 text-orange-400" />
                  <span className="text-xs font-bold uppercase text-gray-300">Optimisation Budgétaire en Temps Réel</span>
                </div>
                
                <p className="text-[10px] text-gray-400 leading-relaxed">
                  Projection financière simulée basée sur le traitement global d'une charge de **100k caractères** par super-agent (charges OIQ standards) :
                </p>

                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-2 text-[11px]">
                  <div className="p-2 bg-[#0b0c10] rounded border border-[#1f2029]">
                    <span className="text-gray-500 uppercase text-[9px] block">Coût Net :</span>
                    <strong className="text-white text-xs">{projectedCost.toFixed(5)}$ CAD</strong>
                  </div>
                  <div className="p-2 bg-[#0b0c10] rounded border border-[#1f2029]">
                    <span className="text-gray-500 uppercase text-[9px] block">TPS (5%) :</span>
                    <strong className="text-gray-400 text-xs">{simulatedTaxes.toFixed(5)}$ CAD</strong>
                  </div>
                  <div className="p-2 bg-[#0b0c10] rounded border border-[#1f2029]">
                    <span className="text-gray-500 uppercase text-[9px] block">TVQ (9.975%) :</span>
                    <strong className="text-gray-400 text-xs">{simulatedTaxes.toFixed(5)}$ CAD</strong>
                  </div>
                  <div className="p-2 bg-[#1e130c] rounded border border-orange-500/20">
                    <span className="text-orange-400 uppercase text-[9px] block">Coût Fiscal Total :</span>
                    <strong className="text-orange-400 text-xs">{(projectedCost * 1.14975).toFixed(5)}$ CAD</strong>
                  </div>
                </div>

                <div className="text-[9px] text-gray-500 italic mt-1">
                  💡 En orientant vos agents vers "Ollama Local" ou "Moteur Déterministe", le coût d'exécution est instantanément réduit à 0.00$ CAD.
                </div>
              </div>

            </div>
          )}

        </div>

      </motion.div>
    </div>
  );
}

// LED Indicator helper sub-component
function LEDIndicator({ status }: { status: 'untested' | 'loading' | 'success' | 'failed' }) {
  let ledClass = "bg-gray-600 shadow-gray-500/50";
  let title = "Non testé";

  if (status === 'loading') {
    ledClass = "bg-amber-400 animate-ping shadow-amber-400/50";
    title = "Validation...";
  } else if (status === 'success') {
    ledClass = "bg-emerald-500 shadow-emerald-500/50";
    title = "Actif / Connecté";
  } else if (status === 'failed') {
    ledClass = "bg-red-500 animate-pulse shadow-red-500/50";
    title = "Échec de connexion";
  }

  return (
    <div className="flex items-center gap-1.5" title={title}>
      <div className={`w-2.5 h-2.5 rounded-full shadow-md ${ledClass}`} />
      <span className="text-[9px] text-gray-500 uppercase font-mono">{title}</span>
    </div>
  );
}
