import React, { useState } from 'react';
import { codeTranslatorService, SupportedLanguage } from '../../services/CodeTranslatorService';
import { Languages, ArrowRight, Copy, Check, Terminal } from 'lucide-react';

export const PolyglotTranslatorPanel: React.FC = () => {
  const [sourceLang, setSourceLang] = useState<SupportedLanguage>('typescript');
  const [targetLang, setTargetLang] = useState<SupportedLanguage>('python');
  const [inputCode, setInputCode] = useState<string>('function calculerArea(x: number, y: number): number {\n  console.log("Calcul...");\n  return x * y;\n}');
  const [outputCode, setOutputCode] = useState<string>('');
  const [isTranslating, setIsTranslating] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  const handleTranslate = async () => {
    setIsTranslating(true);
    const result = await codeTranslatorService.translate(inputCode, sourceLang, targetLang);
    setOutputCode(result);
    setIsTranslating(false);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(outputCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const languages: { id: SupportedLanguage; label: string }[] = [
    { id: 'typescript', label: 'TypeScript' },
    { id: 'python', label: 'Python' },
    { id: 'sql', label: 'SQL' },
    { id: 'json', label: 'JSON' },
    { id: 'yaml', label: 'YAML' },
    { id: 'tuple', label: 'Tuple Géométrique (Φ_SOI)' }
  ];

  return (
    <div className="p-6 bg-slate-900 h-full text-slate-200 font-mono text-xs flex flex-col gap-6">
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <h2 className="text-sm font-black uppercase tracking-widest text-cyan-400 flex items-center gap-2">
          <Languages className="w-5 h-5" /> Traducteur Polyglote de Code & Informations
        </h2>
        <span className="text-[10px] text-slate-500 uppercase">Plan ALPHA / GAMMA</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Source */}
        <div className="flex flex-col gap-2">
          <div className="flex justify-between items-center">
            <label className="text-slate-400 uppercase font-bold text-[10px]">Langage Source</label>
            <select
              value={sourceLang}
              onChange={(e) => setSourceLang(e.target.value as SupportedLanguage)}
              className="bg-slate-950 border border-slate-700 p-1.5 rounded text-cyan-300 text-xs"
            >
              {languages.map(l => <option key={l.id} value={l.id}>{l.label}</option>)}
            </select>
          </div>
          <textarea
            value={inputCode}
            onChange={(e) => setInputCode(e.target.value)}
            rows={12}
            className="w-full bg-slate-950 border border-slate-700 p-4 rounded text-slate-100 font-mono text-xs resize-none focus:border-cyan-500 outline-none"
            placeholder="Collez votre code ou structure de données ici..."
          />
        </div>

        {/* Target */}
        <div className="flex flex-col gap-2">
          <div className="flex justify-between items-center">
            <label className="text-slate-400 uppercase font-bold text-[10px]">Langage Cible</label>
            <div className="flex items-center gap-2">
              <select
                value={targetLang}
                onChange={(e) => setTargetLang(e.target.value as SupportedLanguage)}
                className="bg-slate-950 border border-slate-700 p-1.5 rounded text-cyan-300 text-xs"
              >
                {languages.map(l => <option key={l.id} value={l.id}>{l.label}</option>)}
              </select>
              {outputCode && (
                <button
                  onClick={handleCopy}
                  className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded text-slate-200 transition-colors flex items-center gap-1"
                  title="Copier le résultat"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              )}
            </div>
          </div>
          <div className="relative">
            <textarea
              value={outputCode}
              readOnly
              rows={12}
              className="w-full bg-slate-950 border border-slate-800 p-4 rounded text-cyan-200 font-mono text-xs resize-none outline-none"
              placeholder="Le résultat converti apparaîtra ici..."
            />
          </div>
        </div>
      </div>

      <button
        onClick={handleTranslate}
        disabled={isTranslating}
        className="w-full py-3 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-800 text-white font-black uppercase tracking-wider transition-all flex items-center justify-center gap-2 rounded shadow-lg shadow-cyan-950/50"
      >
        <Terminal className="w-4 h-4" /> {isTranslating ? 'Conversion en cours...' : 'Traduire & Convertir le Code'}
      </button>
    </div>
  );
};
