import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  ShieldAlert, Settings2, Activity, Play, Zap, RotateCcw, AlertTriangle, CheckCircle, Flame, Layers
} from "lucide-react";
import { selfHealingOrchestrator, LedgerCommit, SchedulerTask } from "../../services/quantum/selfHealingOrchestrator";

export default function SelfHealingDashboard() {
  const [orchState, setOrchState] = useState(selfHealingOrchestrator.getState());

  useEffect(() => {
    const unsubscribe = selfHealingOrchestrator.subscribe((state) => {
      setOrchState(state);
    });
    return unsubscribe;
  }, []);

  const { ledgerCommits, schedulerQueue, caughtErrors, entropyLevel, tokenBucketCapacity, lastEventFired } = orchState;

  const handleSimulateError = () => {
    selfHealingOrchestrator.handleCapturedError(
      "TypeError: Cannot read properties of undefined (reading 'renderMatrix')",
      "src/components/LiveUiInspectorOverlay.tsx",
      "at renderMatrix (LiveUiInspectorOverlay.tsx:42:15)\nat Object.eval (LiveUiInspectorOverlay.tsx:109:2)"
    );
  };

  const handleSimulateComplexity = () => {
    selfHealingOrchestrator.fireReactiveSignal(
      "COMPLEXITY_EXCEEDED",
      "Fichier activeFile.tsx dépasse une complexité cyclomatique de 18 (seuil = 12)"
    );
  };

  const handleSimulateContractMutation = () => {
    selfHealingOrchestrator.fireReactiveSignal(
      "CONTRACT_MUTATED",
      "L'export du composant 'AlchemicalSettingsModal' a été altéré à chaud."
    );
  };

  const handleAddCustomTask = (priority: "P0" | "P1" | "P2", tier: "Tier 0 (Local AST)" | "Tier 1 (LLM Gemini)") => {
    selfHealingOrchestrator.pushSchedulerTask(
      `Analyse corrective ad-hoc - Niveau ${priority}`,
      priority,
      tier
    );
  };

  return (
    <div className="space-y-4 p-4 overflow-y-auto h-full text-gray-300 font-mono text-xs bg-[#040507]">
      
      {/* EXCEPTION ALERT BANNER OR METRIC HEADER */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        
        {/* Entropie Métrique */}
        <div className="bg-[#08090d] border border-[#14151d] p-3 rounded-lg flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[9px] uppercase font-bold text-gray-400">Entropie Logique</span>
            <Flame className={`w-4 h-4 ${entropyLevel > 0.4 ? "text-red-500 animate-pulse" : "text-emerald-500"}`} />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-xl font-bold font-mono text-white">{(entropyLevel * 100).toFixed(0)}%</span>
            <span className="text-[8px] text-gray-600">Seuil critique : 75%</span>
          </div>
          <div className="w-full h-1 bg-gray-900 rounded overflow-hidden mt-2">
            <div 
              className={`h-full ${entropyLevel > 0.4 ? "bg-red-500" : "bg-emerald-500"}`}
              style={{ width: `${entropyLevel * 100}%` }}
            />
          </div>
        </div>

        {/* Token Bucket Capacity */}
        <div className="bg-[#08090d] border border-[#14151d] p-3 rounded-lg flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[9px] uppercase font-bold text-gray-400">Rate-Limiter (Token Bucket)</span>
            <Activity className="w-4 h-4 text-purple-400" />
          </div>
          <div className="mt-2 flex items-baseline gap-2">
            <span className="text-xl font-bold font-mono text-white">{tokenBucketCapacity}/100</span>
            <span className="text-[8px] text-gray-600">Recharge : +8/sec</span>
          </div>
          <div className="w-full h-1 bg-gray-900 rounded overflow-hidden mt-2">
            <div className="h-full bg-purple-500" style={{ width: `${tokenBucketCapacity}%` }} />
          </div>
        </div>

        {/* Status System Banner */}
        <div className="bg-[#08090d] border border-[#14151d] p-3 rounded-lg flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[9px] uppercase font-bold text-gray-400">Dernier Événement Bus</span>
            <span className="h-2 w-2 rounded-full bg-emerald-500 animate-ping" />
          </div>
          <div className="mt-2 text-[9px] text-orange-400 truncate font-semibold" title={lastEventFired || "Aucun événement actif"}>
            {lastEventFired || "Système nominal - En attente de signaux"}
          </div>
          <div className="text-[7px] text-gray-600 mt-2">Closed-loop SRE supervision active.</div>
        </div>

      </div>

      {/* DETECTOR & SIMULATION INTERACTIVE TRIGGERS */}
      <div className="bg-[#08090d] border border-[#14151d] p-3 rounded-lg space-y-2.5">
        <span className="text-[9px] text-gray-400 uppercase font-black block tracking-widest">
          Injecteurs Synthétiques de Signaux & Exception (Closed-Loop Testing)
        </span>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          <button
            onClick={handleSimulateError}
            className="py-2 px-3 bg-[#1c0d0d] hover:bg-[#281515] border border-red-950 text-red-400 rounded text-[9px] font-bold uppercase transition-all flex items-center justify-center gap-1.5"
          >
            <ShieldAlert className="w-3.5 h-3.5" /> Injecter Erreur Runtime (TypeError)
          </button>
          <button
            onClick={handleSimulateComplexity}
            className="py-2 px-3 bg-[#1a110a] hover:bg-[#261910] border border-orange-950 text-orange-400 rounded text-[9px] font-bold uppercase transition-all flex items-center justify-center gap-1.5"
          >
            <AlertTriangle className="w-3.5 h-3.5" /> Déclencher Dette Complexité AST
          </button>
          <button
            onClick={handleSimulateContractMutation}
            className="py-2 px-3 bg-[#0d161d] hover:bg-[#13222e] border border-blue-950 text-blue-400 rounded text-[9px] font-bold uppercase transition-all flex items-center justify-center gap-1.5"
          >
            <Zap className="w-3.5 h-3.5 animate-bounce" /> Mutation d'Export Contrat
          </button>
        </div>
      </div>

      {/* REAL-TIME MAIN DATA MONITORING TABLES */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        
        {/* LEFT COLUMN: PILLAR 4 TIERED COMPUTE SCHEDULER */}
        <div className="bg-[#08090d] border border-[#14151d] p-3 rounded-lg space-y-2.5">
          <div className="flex items-center justify-between border-b border-[#14151d] pb-2">
            <span className="text-[10px] font-extrabold uppercase text-white tracking-wider flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-purple-400" /> Ordonnanceur de Calcul Tiered Compute
            </span>
            <div className="flex gap-1 text-[8px]">
              <button onClick={() => handleAddCustomTask("P0", "Tier 0 (Local AST)")} className="px-1.5 py-0.5 bg-gray-800 rounded text-gray-400 hover:text-white">+ T0</button>
              <button onClick={() => handleAddCustomTask("P1", "Tier 1 (LLM Gemini)")} className="px-1.5 py-0.5 bg-gray-800 rounded text-gray-400 hover:text-white">+ T1</button>
            </div>
          </div>

          <div className="space-y-1.5 max-h-48 overflow-y-auto">
            {schedulerQueue.length === 0 ? (
              <div className="py-8 text-center text-gray-600 text-[9px] italic">
                Aucune tâche sémantique ou structurelle en file d'attente.
              </div>
            ) : (
              schedulerQueue.map((task) => (
                <div key={task.id} className="p-2 bg-[#040507] border border-[#121319] rounded flex items-center justify-between text-[9px]">
                  <div className="flex items-center gap-2 min-w-0 flex-1">
                    <span className={`px-1 rounded text-[7px] font-black ${
                      task.priority === "P0" ? "bg-red-500/10 text-red-400" : task.priority === "P1" ? "bg-orange-500/10 text-orange-400" : "bg-gray-800 text-gray-400"
                    }`}>
                      {task.priority}
                    </span>
                    <span className="text-gray-200 truncate font-semibold">{task.name}</span>
                  </div>
                  <div className="flex items-center gap-2 shrink-0 text-right ml-2">
                    <span className="text-[7.5px] text-purple-400 font-bold">{task.tier}</span>
                    <span className={`px-1 py-0.5 rounded text-[7px] font-black uppercase ${
                      task.status === "success" ? "bg-emerald-500/10 text-emerald-400" : task.status === "processing" ? "bg-blue-500/10 text-blue-400 animate-pulse" : "bg-gray-800 text-gray-500"
                    }`}>
                      {task.status}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* RIGHT COLUMN: PILLAR 5 TWO-PHASE COMMIT TRANSACTION LEDGER */}
        <div className="bg-[#08090d] border border-[#14151d] p-3 rounded-lg space-y-2.5">
          <div className="border-b border-[#14151d] pb-2">
            <span className="text-[10px] font-extrabold uppercase text-white tracking-wider flex items-center gap-1.5">
              <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> Registre de Transaction (2-Phase Commit Ledger)
            </span>
          </div>

          <div className="space-y-1.5 max-h-48 overflow-y-auto">
            {ledgerCommits.map((commit) => (
              <div key={commit.id} className="p-2 bg-[#040507] border border-[#121319] rounded flex items-center justify-between text-[9px]">
                <div className="flex flex-col min-w-0 flex-1">
                  <div className="flex items-center gap-1.5">
                    <span className="font-extrabold text-white text-[9.5px]">{commit.id}</span>
                    <span className="text-[7px] text-gray-600">Checksum: {commit.verificationChecksum}</span>
                  </div>
                  <div className="text-[8px] text-gray-500 truncate mt-0.5">
                    Fichiers : {commit.modifiedFiles.map(f => f.split("/").pop()).join(", ")}
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-gray-600 text-[8px]">{commit.timestamp}</div>
                  <span className={`px-1 py-0.5 rounded text-[7px] font-black uppercase inline-block mt-0.5 ${
                    commit.status === "COMMITTED" ? "bg-emerald-500/10 text-emerald-400" : commit.status === "STAGED" ? "bg-blue-500/10 text-blue-400 animate-pulse" : "bg-red-500/10 text-red-400"
                  }`}>
                    {commit.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* CAPTURED ERROR LIST (PILLAR 1 CLOSED LOOP) */}
      <div className="bg-[#08090d] border border-[#14151d] p-3 rounded-lg space-y-2.5">
        <span className="text-[10px] font-extrabold uppercase text-white tracking-wider block">
          Journal des Anomalies Runtime Captées (Self-Healing Traces)
        </span>
        <div className="space-y-1.5 max-h-36 overflow-y-auto">
          {caughtErrors.length === 0 ? (
            <div className="py-6 text-center text-gray-600 text-[9px] italic">
              Aucune exception runtime interceptée par la Sentinelle Runtime.
            </div>
          ) : (
            caughtErrors.map((err, i) => (
              <div key={i} className="p-2.5 bg-[#0d0909] border border-red-950/40 rounded flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[9px]">
                <div className="min-w-0 flex-1 space-y-0.5">
                  <div className="text-red-400 font-bold truncate">{err.message}</div>
                  <div className="text-[8px] text-gray-500 font-mono truncate">Source : {err.source}</div>
                  <div className="text-[7px] text-gray-600 font-mono truncate">{err.stack}</div>
                </div>
                <div className="shrink-0 text-right">
                  <span className={`px-2 py-0.5 rounded text-[8px] font-bold uppercase ${
                    err.resolved ? "bg-emerald-500/10 text-emerald-400" : "bg-red-500/10 text-red-400 animate-pulse"
                  }`}>
                    {err.resolved ? "Corrigé (Auto-Healed)" : "Analyse en cours"}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

    </div>
  );
}
