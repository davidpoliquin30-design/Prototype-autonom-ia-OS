import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Network, Activity, Workflow, Binary, Settings2, ShieldAlert, Cpu, Sparkles, RefreshCw, ShieldCheck
} from "lucide-react";
import { agentCommunicationBus, AgentNode, SynapticSignal } from "../../services/quantum/agentCommunicationBus";
import { quantumCognitiveBridge } from "../../services/quantum/quantumCognitiveBridge";
import SelfHealingDashboard from "./SelfHealingDashboard";
import AgentSupervisorNarrator from "./AgentSupervisorNarrator";

export default function AgentConstellationGraph() {
  const [busState, setBusState] = useState(agentCommunicationBus.getState());
  const [activeTab, setActiveTab] = useState<"graph" | "signals" | "calibrate" | "resilience" | "supervisor">("graph");
  const [selectedNode, setSelectedNode] = useState<AgentNode | null>(null);
  const [draggedNodeId, setDraggedNodeId] = useState<string | null>(null);
  
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Manual signal fields
  const [manualSender, setManualSender] = useState("procoder");
  const [manualReceiver, setManualReceiver] = useState("companion");
  const [manualLabel, setManualLabel] = useState("Ajustement de liaison synaptique");

  // Subscribe to companion service
  useEffect(() => {
    const unsubscribe = agentCommunicationBus.subscribe((state) => {
      setBusState(state);
      
      // Update selectedNode state dynamically to match current live telemetry inside nodes array
      if (selectedNode) {
        const liveMatch = state.nodes.find(n => n.id === selectedNode.id);
        if (liveMatch) {
          setSelectedNode(liveMatch);
        }
      }
    });
    return unsubscribe;
  }, [selectedNode]);

  const { nodes, signals, isSimulating, intensityMultiplier, faultTolerance } = busState;

  // Render SVG connections
  const renderConnections = () => {
    const lines: React.ReactNode[] = [];
    
    nodes.forEach(node => {
      node.connections.forEach(connId => {
        const target = nodes.find(n => n.id === connId);
        if (target) {
          // Unique key for line
          const key = `${node.id}-${target.id}`;
          
          // Animate pulsing signals flowing along the line if simulating
          const signalOnLine = signals.find(s => 
            (s.sender === node.id && s.receiver === target.id) || 
            (s.sender === target.id && s.receiver === node.id)
          );

          const isGlowing = !!signalOnLine;

          lines.push(
            <g key={key}>
              {/* Backing structural wire */}
              <line
                x1={node.x}
                y1={node.y}
                x2={target.x}
                y2={target.y}
                stroke={isGlowing ? "rgba(249, 115, 22, 0.4)" : "rgba(38, 38, 38, 0.5)"}
                strokeWidth={isGlowing ? "2.5" : "1.2"}
                className="transition-all duration-300"
              />
              {/* Animating signal flow dash */}
              {isSimulating && (
                <line
                  x1={node.x}
                  y1={node.y}
                  x2={target.x}
                  y2={target.y}
                  stroke={node.status === "fallback" || target.status === "fallback" ? "#a855f7" : "#f97316"}
                  strokeWidth="2"
                  strokeDasharray="8, 15"
                  className="animate-pulse"
                  style={{
                    strokeDashoffset: isGlowing ? "0" : "15",
                    animation: "flow 1s linear infinite"
                  }}
                />
              )}
            </g>
          );
        }
      });
    });

    return lines;
  };

  // Node movement drag handling
  const handleMouseDown = (nodeId: string) => {
    setDraggedNodeId(nodeId);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!draggedNodeId || !containerRef.current) return;
    
    const rect = containerRef.current.getBoundingClientRect();
    const x = Math.max(20, Math.min(rect.width - 20, e.clientX - rect.left));
    const y = Math.max(20, Math.min(rect.height - 20, e.clientY - rect.top));
    
    agentCommunicationBus.updateNodePosition(draggedNodeId, Math.round(x), Math.round(y));
  };

  const handleMouseUp = () => {
    setDraggedNodeId(null);
  };

  const handleTriggerManualSignal = () => {
    if (manualSender === manualReceiver) return;
    agentCommunicationBus.triggerDirectSignal(
      manualSender,
      manualReceiver,
      manualLabel,
      "high"
    );
  };

  return (
    <div className="bg-[#050608] border border-[#181920] rounded-xl font-mono text-xs text-gray-300 overflow-hidden shadow-2xl flex flex-col md:flex-row h-[550px]">
      
      {/* LEFT PANEL: MAIN GRAPH / SETTINGS CONTROL ZONE */}
      <div className="flex-1 flex flex-col border-b md:border-b-0 md:border-r border-[#181920] h-full overflow-hidden">
        
        {/* Header Tab Commutator */}
        <div className="bg-[#0b0c10] border-b border-[#181920] p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded bg-emerald-500/10 border border-emerald-500/20">
              <Network className="w-4 h-4 text-emerald-400" />
            </div>
            <div>
              <div className="font-bold text-white uppercase text-[10px] tracking-widest flex items-center gap-1.5">
                <span>Maillage Multi-Agents</span>
                <span className="text-[8px] px-1 bg-[#1a1b24] text-emerald-400 rounded uppercase">Agi Mesh</span>
              </div>
              <div className="text-[8px] text-gray-500">Cartographie constellationnelle & flux synaptiques</div>
            </div>
          </div>

          {/* Mini-Tabs */}
          <div className="flex gap-1 bg-[#050608] p-1 rounded-lg border border-[#14151d]">
            <button
              onClick={() => setActiveTab("graph")}
              className={`px-3 py-1 rounded text-[9px] uppercase font-bold transition-all ${
                activeTab === "graph"
                  ? "bg-emerald-500 text-black"
                  : "text-gray-500 hover:text-gray-300"
              }`}
            >
              Constellation
            </button>
            <button
              onClick={() => setActiveTab("signals")}
              className={`px-3 py-1 rounded text-[9px] uppercase font-bold transition-all ${
                activeTab === "signals"
                  ? "bg-emerald-500 text-black"
                  : "text-gray-500 hover:text-gray-300"
              }`}
            >
              Flux
            </button>
            <button
              onClick={() => setActiveTab("calibrate")}
              className={`px-3 py-1 rounded text-[9px] uppercase font-bold transition-all ${
                activeTab === "calibrate"
                  ? "bg-emerald-500 text-black"
                  : "text-gray-500 hover:text-gray-300"
              }`}
            >
              Calibrateur
            </button>
            <button
              onClick={() => setActiveTab("resilience")}
              className={`px-3 py-1 rounded text-[9px] uppercase font-bold transition-all ${
                activeTab === "resilience"
                  ? "bg-emerald-500 text-black"
                  : "text-gray-500 hover:text-gray-300"
              }`}
            >
              Résilience & Régulation
            </button>
            <button
              onClick={() => setActiveTab("supervisor")}
              className={`px-3 py-1 rounded text-[9px] uppercase font-bold transition-all ${
                activeTab === "supervisor"
                  ? "bg-emerald-500 text-black"
                  : "text-gray-500 hover:text-gray-300"
              }`}
            >
              Superviseur IA
            </button>
          </div>
        </div>

        {/* Dynamic Display Area based on tabs */}
        <div className="flex-1 relative overflow-hidden bg-[#040507]">
          
          {/* TAB 1: GALAXY CONSTELLATION GRAPH */}
          {activeTab === "graph" && (
            <div 
              ref={containerRef}
              onMouseMove={handleMouseMove}
              onMouseUp={handleMouseUp}
              onMouseLeave={handleMouseUp}
              className="w-full h-full relative cursor-crosshair select-none overflow-hidden"
            >
              {/* SVG connection lines rendering overlay */}
              <svg className="absolute inset-0 w-full h-full pointer-events-none">
                <style>{`
                  @keyframes flow {
                    to { stroke-dashoffset: -30; }
                  }
                `}</style>
                {renderConnections()}
              </svg>

              {/* Node nodes rendering map */}
              {nodes.map((node) => {
                const isSelected = selectedNode?.id === node.id;
                const isAuraActive = node.cognitiveLoad > 40;
                
                // Color configuration
                let accentColor = "border-emerald-500 text-emerald-400";
                let glowBg = "bg-emerald-500/10";
                if (node.status === "fallback") {
                  accentColor = "border-purple-500 text-purple-400";
                  glowBg = "bg-purple-500/15";
                } else if (isAuraActive) {
                  accentColor = "border-orange-500 text-orange-400";
                  glowBg = "bg-orange-500/15";
                }

                return (
                  <div
                    key={node.id}
                    onMouseDown={() => handleMouseDown(node.id)}
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedNode(node);
                    }}
                    style={{
                      left: `${node.x}px`,
                      top: `${node.y}px`,
                      transform: "translate(-50%, -50%)"
                    }}
                    className={`absolute p-2.5 rounded-xl border bg-[#090b0f] transition-all cursor-grab active:cursor-grabbing flex flex-col items-center gap-1 min-w-[100px] text-center ${accentColor} ${glowBg} ${
                      isSelected ? "ring-2 ring-emerald-400 border-white" : ""
                    }`}
                  >
                    <div className="flex items-center gap-1 justify-center">
                      <Cpu className="w-3.5 h-3.5" />
                      <span className="font-bold text-[9px] uppercase tracking-wider">{node.name.split(" ")[0]}</span>
                    </div>
                    
                    {/* Tiny micro statistics */}
                    <div className="text-[7px] text-gray-500 flex justify-between w-full gap-2 px-1">
                      <span>Charge:</span>
                      <span className="font-black text-gray-300">{node.cognitiveLoad}%</span>
                    </div>

                    {/* Progress charging miniature bar */}
                    <div className="w-full h-1 bg-[#10131d] rounded overflow-hidden">
                      <div 
                        className={`h-full ${isAuraActive ? 'bg-orange-500' : 'bg-emerald-500'}`}
                        style={{ width: `${node.cognitiveLoad}%` }}
                      />
                    </div>
                  </div>
                );
              })}

              {/* Bottom graph instructions helper */}
              <div className="absolute bottom-2 left-2 text-[8px] text-gray-600 flex items-center gap-1">
                <Workflow className="w-3 h-3 text-gray-600" />
                Déplacez les nœuds pour modéliser le maillage synaptique de l'IDE.
              </div>
            </div>
          )}

          {/* TAB 2: SYNAPTIC FLOW TIMELINE */}
          {activeTab === "signals" && (
            <div className="w-full h-full overflow-y-auto p-4 space-y-2">
              <div className="flex items-center justify-between border-b border-[#14151d] pb-2 mb-2">
                <span className="text-[9px] text-gray-500 uppercase tracking-widest font-black">Transactions de Signaux Actives</span>
                <button
                  onClick={() => agentCommunicationBus.toggleSimulation()}
                  className={`px-2 py-0.5 rounded text-[8px] uppercase font-bold flex items-center gap-1 ${
                    isSimulating ? 'bg-orange-500/10 text-orange-400 border border-orange-500/20' : 'bg-gray-800 text-gray-400'
                  }`}
                >
                  <Activity className="w-3 h-3 animate-pulse" />
                  {isSimulating ? "Simulation Active" : "Simulation En Veille"}
                </button>
              </div>

              <div className="space-y-1.5 pr-1">
                <AnimatePresence initial={false}>
                  {signals.map((sig) => {
                    const senderNode = nodes.find(n => n.id === sig.sender);
                    const receiverNode = nodes.find(n => n.id === sig.receiver);
                    return (
                      <motion.div
                        key={sig.id}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 0.15 }}
                        className="p-2.5 bg-[#08090d] border border-[#13141c] rounded-lg flex items-center justify-between text-[9px]"
                      >
                        <div className="flex items-center gap-1.5 flex-1 min-w-0">
                          <span className="px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-bold uppercase text-[7px]">
                            {senderNode?.name.split(" ")[0]}
                          </span>
                          <span className="text-gray-600">➔</span>
                          <span className="px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-400 font-bold uppercase text-[7px]">
                            {receiverNode?.name.split(" ")[0]}
                          </span>
                          <span className="text-gray-400 font-semibold truncate ml-2">"{sig.label}"</span>
                        </div>
                        <div className="text-right shrink-0">
                          <span className="text-gray-600 mr-2">{sig.timestamp}</span>
                          <span className={`px-1 rounded text-[7px] font-black uppercase ${
                            sig.intensity === "high" ? "bg-red-500/10 text-red-400" : sig.intensity === "medium" ? "bg-orange-500/10 text-orange-400" : "bg-gray-800 text-gray-400"
                          }`}>
                            {sig.intensity}
                          </span>
                        </div>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>
              </div>
            </div>
          )}

          {/* TAB 3: POWER CALIBRATOR CONTROL CONSOLE */}
          {activeTab === "calibrate" && (
            <div className="w-full h-full p-4 space-y-4 overflow-y-auto">
              <div className="border-b border-[#14151d] pb-2">
                <span className="text-[10px] font-bold text-white uppercase tracking-wider">Ajustements de Routage & Puissance</span>
              </div>

              {/* Sliders Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2 bg-[#08090d] border border-[#12131a] p-3 rounded-lg">
                  <span className="text-gray-400 font-bold text-[9px] uppercase">Multiplicateur de Signal</span>
                  <div className="flex items-center gap-3">
                    <input 
                      type="range" 
                      min="0.5" 
                      max="2.5" 
                      step="0.1" 
                      value={intensityMultiplier}
                      onChange={(e) => agentCommunicationBus.updatePowerSettings(parseFloat(e.target.value), faultTolerance)}
                      className="w-full accent-emerald-500"
                    />
                    <span className="text-emerald-400 font-bold w-8">{intensityMultiplier.toFixed(1)}x</span>
                  </div>
                  <p className="text-[8px] text-gray-600">Ajuste l'intensité de résonance synaptique sur la constellation.</p>
                </div>

                <div className="space-y-2 bg-[#08090d] border border-[#12131a] p-3 rounded-lg">
                  <span className="text-gray-400 font-bold text-[9px] uppercase">Seuil Tolérance aux Pannes</span>
                  <div className="flex items-center gap-3">
                    <input 
                      type="range" 
                      min="50" 
                      max="100" 
                      step="1" 
                      value={faultTolerance}
                      onChange={(e) => agentCommunicationBus.updatePowerSettings(intensityMultiplier, parseInt(e.target.value))}
                      className="w-full accent-emerald-500"
                    />
                    <span className="text-emerald-400 font-bold w-10">{faultTolerance}%</span>
                  </div>
                  <p className="text-[8px] text-gray-600">Limite de résilience avant basculement vers moteur local.</p>
                </div>
              </div>

              {/* Manual Direct Injector Tool */}
              <div className="bg-[#08090d] border border-[#12131a] p-3 rounded-lg space-y-3">
                <span className="text-gray-400 font-bold text-[9px] uppercase flex items-center gap-1">
                  <Workflow className="w-3.5 h-3.5 text-emerald-400" /> Émission Manuelle de Signal Synaptique
                </span>

                <div className="grid grid-cols-3 gap-2">
                  <div className="space-y-1">
                    <label className="text-[8px] text-gray-500">ÉMETTEUR</label>
                    <select 
                      value={manualSender} 
                      onChange={(e) => setManualSender(e.target.value)}
                      className="w-full bg-[#050608] border border-[#181920] rounded p-1 text-[9px] text-gray-300"
                    >
                      {nodes.map(n => <option key={n.id} value={n.id}>{n.name.split(" ")[0]}</option>)}
                    </select>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[8px] text-gray-500">RÉCEPTEUR</label>
                    <select 
                      value={manualReceiver} 
                      onChange={(e) => setManualReceiver(e.target.value)}
                      className="w-full bg-[#050608] border border-[#181920] rounded p-1 text-[9px] text-gray-300"
                    >
                      {nodes.map(n => <option key={n.id} value={n.id}>{n.name.split(" ")[0]}</option>)}
                    </select>
                  </div>
                  <div className="space-y-1 flex flex-col justify-end">
                    <button
                      onClick={handleTriggerManualSignal}
                      disabled={manualSender === manualReceiver}
                      className="w-full py-1.5 bg-emerald-500 hover:bg-emerald-400 text-black font-black uppercase text-[9px] rounded"
                    >
                      ÉMETTRE
                    </button>
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="text-[8px] text-gray-500">LABEL DU FLUX DE SIGNAL</label>
                  <input
                    type="text"
                    value={manualLabel}
                    onChange={(e) => setManualLabel(e.target.value)}
                    className="w-full bg-[#050608] border border-[#181920] rounded p-1 text-[9px] text-gray-300"
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === "resilience" && (
            <SelfHealingDashboard />
          )}

          {activeTab === "supervisor" && (
            <AgentSupervisorNarrator />
          )}

        </div>
      </div>

      {/* RIGHT SIDEBAR: NODE DETAILED ANALYZER DRAWER */}
      <div className="w-full md:w-64 bg-[#0a0c10] p-3 shrink-0 flex flex-col justify-between overflow-y-auto">
        <div>
          <div className="text-[10px] font-extrabold uppercase text-gray-400 tracking-wider mb-2 border-b border-[#14151c] pb-1">
            Analyse de l'Agent Cliqué
          </div>

          {selectedNode ? (
            <div className="space-y-3.5">
              <div>
                <span className="text-gray-500 text-[8px] uppercase font-bold">Identifiant Unique :</span>
                <div className="text-white font-bold text-[10px] tracking-wide">@{selectedNode.id}</div>
              </div>

              {/* REAL-TIME TRANSMISSION DATA (WHO TO, WHO FROM) */}
              <div className="bg-[#07090e] border border-[#12141d] p-2 rounded space-y-1.5">
                <span className="text-emerald-400 text-[8px] uppercase font-bold tracking-widest block">📡 Télémesure de Signal</span>
                <div className="grid grid-cols-2 gap-1.5 text-[8.5px]">
                  <div>
                    <span className="text-gray-500 text-[7px] block uppercase">Émis vers :</span>
                    <span className="text-gray-200 font-semibold uppercase">{selectedNode.lastSentTo ? `@${selectedNode.lastSentTo}` : "Néant"}</span>
                  </div>
                  <div>
                    <span className="text-gray-500 text-[7px] block uppercase">Reçu de :</span>
                    <span className="text-gray-200 font-semibold uppercase">{selectedNode.lastReceivedFrom ? `@${selectedNode.lastReceivedFrom}` : "Néant"}</span>
                  </div>
                </div>
              </div>

              {/* WHY ACTION (MOTIVATION) */}
              <div>
                <span className="text-orange-400 text-[8px] uppercase font-bold tracking-widest block">💡 Motivation de l'Action :</span>
                <div className="text-gray-300 text-[9px] leading-relaxed bg-[#0a0502] border border-orange-950/30 p-2 rounded mt-0.5">
                  {selectedNode.whyAction}
                </div>
              </div>

              {/* REAL-TIME LOGICAL REASONING */}
              <div>
                <span className="text-blue-400 text-[8px] uppercase font-bold tracking-widest block">🧠 Raisonnement Interne (Temps Réel) :</span>
                <div className="text-gray-300 text-[9px] leading-relaxed bg-[#03060a] border border-blue-950/35 p-2 rounded mt-0.5 italic text-blue-200">
                  {selectedNode.lastReasoning}
                </div>
              </div>

              <div>
                <span className="text-gray-500 text-[8px] uppercase font-bold">Architecture Système :</span>
                <div className="text-gray-200 text-[9px] font-semibold leading-relaxed bg-[#06070a] border border-[#14151d] p-1.5 rounded mt-0.5">
                  {selectedNode.architecture}
                </div>
              </div>

              <div>
                <span className="text-gray-500 text-[8px] uppercase font-bold">Modélisation Mathématique :</span>
                <div className="text-orange-400 font-mono text-[8px] bg-[#0c0502] border border-orange-950/40 p-1.5 rounded mt-0.5 whitespace-pre-wrap overflow-x-auto">
                  {selectedNode.equation}
                </div>
              </div>

              <div>
                <span className="text-gray-500 text-[8px] uppercase font-bold">Topologie Cognitive :</span>
                <div className="text-gray-400 text-[8.5px] mt-0.5">
                  {selectedNode.topology}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 bg-[#06070a] border border-[#14151d] p-2 rounded">
                <div>
                  <span className="text-gray-500 text-[7px] uppercase block">Budget Token :</span>
                  <span className="text-white font-bold text-[9px]">{selectedNode.tokenAllocation}K tk</span>
                </div>
                <div>
                  <span className="text-gray-500 text-[7px] uppercase block">Budget Latence :</span>
                  <span className="text-emerald-400 font-bold text-[9px]">{selectedNode.latency.split(" @ ")[0]}</span>
                </div>
              </div>

              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-gray-500 text-[8px] uppercase">Charge Cognitive Actuelle :</span>
                  <span className="text-white font-bold">{selectedNode.cognitiveLoad}%</span>
                </div>
                <div className="w-full h-1.5 bg-[#12131c] rounded overflow-hidden">
                  <div 
                    className="h-full bg-orange-500"
                    style={{ width: `${selectedNode.cognitiveLoad}%` }}
                  />
                </div>
              </div>

              <div>
                <span className="text-gray-500 text-[8px] uppercase font-bold">Connexions Actives :</span>
                <div className="flex flex-wrap gap-1 mt-1">
                  {selectedNode.connections.map(c => (
                    <span key={c} className="px-1.5 py-0.5 rounded bg-[#13141c] text-gray-400 text-[8px] uppercase font-semibold">
                      @{c}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-gray-600 text-center space-y-2">
              <Binary className="w-8 h-8 text-gray-800" />
              <span className="text-[9px]">Sélectionnez un nœud d'agent sur le graphe interactif pour analyser ses métadonnées.</span>
            </div>
          )}
        </div>

        {selectedNode && (
          <div className="border-t border-[#14151c] pt-2.5 mt-4 flex items-center justify-between text-[8px] text-gray-500 italic">
            <span>Aura de l'agent active :</span>
            <span className="text-emerald-400 uppercase font-black flex items-center gap-0.5">
              <Activity className="w-3 h-3 animate-pulse" /> Résonance OK
            </span>
          </div>
        )}
      </div>

    </div>
  );
}
