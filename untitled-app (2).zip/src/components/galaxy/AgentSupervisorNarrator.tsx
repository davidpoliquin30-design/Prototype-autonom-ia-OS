import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Eye, Terminal, Sparkles, MessageSquare, Play, Pause, RefreshCw, Cpu, Activity
} from "lucide-react";
import { agentCommunicationBus, AgentNode, SynapticSignal } from "../../services/quantum/agentCommunicationBus";
import { selfHealingOrchestrator } from "../../services/quantum/selfHealingOrchestrator";

interface HumanNarrativeLog {
  id: string;
  timestamp: string;
  title: string;
  narrative: string;
  agentFrom: string;
  agentTo: string;
  type: "info" | "alert" | "success" | "reasoning";
}

export default function AgentSupervisorNarrator() {
  const [busState, setBusState] = useState(agentCommunicationBus.getState());
  const [orchState, setOrchState] = useState(selfHealingOrchestrator.getState());
  const [narratives, setNarratives] = useState<HumanNarrativeLog[]>([]);
  const [isNarrating, setIsNarrating] = useState<boolean>(true);
  const scrollRef = useRef<HTMLDivElement | null>(null);

  // Subscribe to system telemetries
  useEffect(() => {
    const unsubBus = agentCommunicationBus.subscribe((state) => {
      setBusState(state);
    });
    const unsubOrch = selfHealingOrchestrator.subscribe((state) => {
      setOrchState(state);
    });
    return () => {
      unsubBus();
      unsubOrch();
    };
  }, []);

  // Listen to incoming signals & errors to write human narrative logs
  useEffect(() => {
    if (!isNarrating) return;

    const latestSignal = busState.signals[0];
    if (!latestSignal) return;

    // Check if this signal was already narrated
    const isAlreadyNarrated = narratives.some(n => n.id === latestSignal.id);
    if (isAlreadyNarrated) return;

    // Resolve human-friendly agent names
    const senderName = busState.nodes.find(n => n.id === latestSignal.sender)?.name || latestSignal.sender;
    const receiverName = busState.nodes.find(n => n.id === latestSignal.receiver)?.name || latestSignal.receiver;

    // Construct highly articulate human narrative explaining the "Why", "What" and "How"
    let narrativeText = "";
    let logType: "info" | "alert" | "success" | "reasoning" = "info";
    let titleText = "";

    if (latestSignal.label.includes("AST")) {
      titleText = "Indexation de l'arbre syntaxique (AST)";
      narrativeText = `L'agent "${senderName}" a envoyé à "${receiverName}" un rapport d'indexation d'arbre syntaxique abstrait. L'objectif est de vérifier que le code saisi par l'utilisateur ne comporte aucune erreur de grammaire structurelle. "${receiverName}" va analyser ce signal pour valider les exports ou anticiper un besoin de refactorisation.`;
    } else if (latestSignal.label.includes("cache")) {
      titleText = "Synchronisation de la mémoire cache de l'IDE";
      narrativeText = `Un flux de données transite de "${senderName}" vers "${receiverName}" pour mettre en commun l'état d'édition des fichiers ouverts. Cela garantit qu'aucun agent ne travaille sur des versions obsolètes du workspace.`;
    } else if (latestSignal.label.includes("jeton") || latestSignal.label.includes("budget")) {
      titleText = "Négociation de l'enveloppe budgétaire sémantique";
      narrativeText = `L'agent "${senderName}" notifie "${receiverName}" de son allocation de tokens en cours. Afin d'éviter tout dépassement de quota (Erreur 429), ils s'accordent sur le niveau de compression de contexte requis avant de solliciter l'API Gemini.`;
      logType = "reasoning";
    } else if (latestSignal.label.includes("correction") || latestSignal.label.includes("auto-guérison")) {
      titleText = "Lancement d'une procédure d'auto-réparation";
      narrativeText = `Alerte d'anomalie ! "${senderName}" transmet à "${receiverName}" un paquet correctif. L'agent d'auto-réparation évalue la trace d'erreur pour appliquer un patch direct en mémoire. Cette action est hautement critique pour maintenir l'IDE stable.`;
      logType = "alert";
    } else if (latestSignal.label.includes("quantique") || latestSignal.label.includes("intrication")) {
      titleText = "Sondage de liaison cognito-quantique";
      narrativeText = `L'agent "${senderName}" teste la qualité de la liaison d'intrication avec "${receiverName}". En évaluant l'entropie, ils s'assurent que les intentions de discussion s'alignent parfaitement avec l'état actif des fichiers.`;
      logType = "success";
    } else {
      titleText = `Transaction sémantique : ${latestSignal.label}`;
      narrativeText = `Une communication directe est établie entre "${senderName}" et "${receiverName}" au sujet de : "${latestSignal.label}". Les deux entités synchronisent leurs modèles logiques pour garantir une cohérence optimale sur le projet.`;
    }

    const newLog: HumanNarrativeLog = {
      id: latestSignal.id,
      timestamp: latestSignal.timestamp,
      title: titleText,
      narrative: narrativeText,
      agentFrom: latestSignal.sender,
      agentTo: latestSignal.receiver,
      type: logType
    };

    setNarratives(prev => [newLog, ...prev.slice(0, 49)]);
  }, [busState.signals, isNarrating]);

  // Hook into self-healing errors to write direct supervisor notifications
  useEffect(() => {
    if (!isNarrating) return;

    const latestError = orchState.caughtErrors[0];
    if (!latestError) return;

    const isAlreadyNarrated = narratives.some(n => n.id === `err_${latestError.message}`);
    if (isAlreadyNarrated) return;

    const newLog: HumanNarrativeLog = {
      id: `err_${latestError.message}`,
      timestamp: new Date().toLocaleTimeString(),
      title: "⚠️ Interception d'un plantage d'exécution !",
      narrative: `La Sentinelle de l'IDE vient d'intercepter une erreur en direct : "${latestError.message}" provenant du fichier "${latestError.source}". Le superviseur IA réveille instantanément l'autoRepairEngine pour formuler un plan de résolution et appliquer un correctif à chaud sans perturber le développeur humain.`,
      agentFrom: "system_kernel",
      agentTo: "reparateur",
      type: "alert"
    };

    setNarratives(prev => [newLog, ...prev.slice(0, 49)]);
  }, [orchState.caughtErrors, isNarrating]);

  // Hook into reactive signals
  useEffect(() => {
    if (!isNarrating || !orchState.lastEventFired) return;

    const eventName = orchState.lastEventFired;
    const isAlreadyNarrated = narratives.some(n => n.id === `event_${eventName}`);
    if (isAlreadyNarrated) return;

    let titleText = "Signal d'événement émis";
    let narrativeText = `L'orchestrateur de résilience a émis un signal système d'entropie : "${eventName}". Le réseau s'adapte en temps réel.`;
    let logType: "info" | "alert" | "success" | "reasoning" = "info";

    if (eventName.includes("COMPLEXITY_EXCEEDED")) {
      titleText = "📈 Alerte de complexité cyclomatique excessive";
      narrativeText = "L'un des fichiers vient de franchir un seuil critique d'imbrication ou de longueur. L'observateur IA ordonne au ProCoder Agent de lancer une tâche d'auto-modularisation en tâche de fond pour scinder le code en modules plus digestes.";
      logType = "alert";
    } else if (eventName.includes("CONTRACT_MUTATED")) {
      titleText = "🔄 Rupture sémantique de contrat (API Export)";
      narrativeText = "La signature d'un export de fonction a été modifiée à chaud. Pour éviter toute erreur de compilation, le bus synaptique notifie automatiquement tous les agents consommateurs pour mettre à jour leurs clauses d'imports.";
      logType = "reasoning";
    } else if (eventName.includes("SUCCESS")) {
      titleText = "✅ Correctif d'auto-guérison validé !";
      narrativeText = "Excellente nouvelle ! Le pipeline de validation en mémoire a exécuté les tests d'intégrité sur la dernière proposition de code. Toutes les assertions sont passées au vert, la modification est définitivement enregistrée sur le disque.";
      logType = "success";
    }

    const newLog: HumanNarrativeLog = {
      id: `event_${eventName}`,
      timestamp: new Date().toLocaleTimeString(),
      title: titleText,
      narrative: narrativeText,
      agentFrom: "self_healing_orchestrator",
      agentTo: "all_agents",
      type: logType
    };

    setNarratives(prev => [newLog, ...prev.slice(0, 49)]);
  }, [orchState.lastEventFired, isNarrating]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = 0;
    }
  }, [narratives]);

  return (
    <div className="bg-[#050608] border border-[#181920] rounded-xl font-mono text-xs text-gray-300 overflow-hidden shadow-2xl flex flex-col h-[550px]">
      
      {/* HEADER CONTROL BAR */}
      <div className="bg-[#0b0c10] border-b border-[#181920] p-3.5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded bg-orange-500/10 border border-orange-500/20">
            <Eye className="w-4 h-4 text-orange-400 animate-pulse" />
          </div>
          <div>
            <div className="font-bold text-white uppercase text-[10px] tracking-widest flex items-center gap-1.5">
              <span>Superviseur Narratif IA</span>
              <span className="text-[8px] px-1 bg-[#1a1b24] text-orange-400 rounded uppercase">Observateur Sémantique</span>
            </div>
            <div className="text-[8px] text-gray-500">Traduction humaine et explication logique de l'activité multi-agents</div>
          </div>
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => setIsNarrating(!isNarrating)}
            className={`px-3 py-1 rounded text-[9px] uppercase font-bold flex items-center gap-1.5 transition-all ${
              isNarrating 
                ? "bg-orange-500 text-black font-extrabold" 
                : "bg-gray-800 text-gray-400 hover:text-gray-200"
            }`}
          >
            {isNarrating ? (
              <>
                <Activity className="w-3.5 h-3.5 animate-pulse" />
                Narrateur Actif
              </>
            ) : (
              <>
                <Pause className="w-3.5 h-3.5" />
                Mettre en pause
              </>
            )}
          </button>

          <button
            onClick={() => setNarratives([])}
            className="p-1 px-2.5 hover:bg-[#1a1b24] border border-[#1c1d27] text-gray-400 rounded text-[9px] uppercase font-bold transition-all"
            title="Effacer le journal d'analyse"
          >
            Réinitialiser
          </button>
        </div>
      </div>

      {/* MATRIX OF THE 4 ORTHOGONAL PLANES & GEOMETRICAL KERNEL STATUS */}
      <div className="bg-[#080a0e] border-b border-[#141824] p-3 space-y-2 shrink-0">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5">
          <span className="text-[9px] font-black uppercase tracking-widest text-orange-400 flex items-center gap-1">
            📐 KERNEL D'ALIGNEMENT GÉOMÉTRIQUE & TOPOLOGIQUE (Φ_SOI)
          </span>
          <span className="text-[9px] font-mono font-bold text-emerald-400 bg-emerald-950/40 px-1.5 py-0.5 rounded border border-emerald-900/30">
            Ξ_Indice Réalité = 1.000 (D_c → 0)
          </span>
        </div>

        <div className="text-[8px] font-mono text-orange-300 bg-[#0c0602] border border-orange-950/40 p-2 rounded leading-normal select-all">
          Φ_SOI = ∮_σ [ ((∇Ψ ⊗ T_p) ★ H_∞) / (ρ_m · (1 + D_c)^λ_sep) ] · ΔOTel = Ξ = 1
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[8px]">
          <div className="bg-[#030508] border border-[#141620] p-1.5 rounded">
            <span className="text-gray-500 block uppercase font-bold">PLAN ALPHA [X, Y]</span>
            <span className="text-white font-semibold">Sous-sol déterministe (TS)</span>
            <span className="text-emerald-400 block mt-0.5">● Aligné (0$ Token)</span>
          </div>
          <div className="bg-[#030508] border border-[#141620] p-1.5 rounded">
            <span className="text-gray-500 block uppercase font-bold">PLAN BÊTA [X, Z]</span>
            <span className="text-white font-semibold">Membrane Immunitaire</span>
            <span className="text-emerald-400 block mt-0.5">● Chiffré GCM / Anon</span>
          </div>
          <div className="bg-[#030508] border border-[#141620] p-1.5 rounded">
            <span className="text-gray-500 block uppercase font-bold">PLAN GAMMA [Y, Z]</span>
            <span className="text-white font-semibold">Cortex Inférence aveugle</span>
            <span className="text-emerald-400 block mt-0.5">● Gemini 2.0 SDK</span>
          </div>
          <div className="bg-[#030508] border border-[#141620] p-1.5 rounded">
            <span className="text-gray-500 block uppercase font-bold">PLAN DELTA</span>
            <span className="text-white font-semibold">Rétine Contractuelle 16:9</span>
            <span className="text-emerald-400 block mt-0.5">● Scellé SHA-256</span>
          </div>
        </div>

        {/* Synaptic Conduit Pipeline indicator */}
        <div className="flex items-center gap-1.5 text-[7.5px] text-gray-500 pt-1">
          <span className="font-bold text-gray-400">SynapticConduit :</span>
          <span className="px-1 bg-gray-900 rounded text-gray-400 font-mono">shield()</span>
          <span>→</span>
          <span className="px-1 bg-gray-900 rounded text-gray-400 font-mono">localReflex()</span>
          <span>→</span>
          <span className="px-1 bg-gray-900 rounded text-gray-400 font-mono">cognitiveBridge()</span>
          <span>→</span>
          <span className="px-1 bg-gray-900 rounded text-gray-400 font-mono">rehydrateAndCommit()</span>
          <span className="text-emerald-400 font-black ml-1">● ACTIF & SCELLÉ</span>
        </div>
      </div>

      {/* NARRATOR CHRONICLE SCROLL VIEW */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-[#030406] custom-scrollbar"
      >
        <AnimatePresence initial={false}>
          {narratives.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center py-24 text-gray-600 space-y-3">
              <Terminal className="w-10 h-10 text-gray-800 animate-bounce" />
              <div className="space-y-1">
                <span className="text-[10px] uppercase font-black tracking-widest block text-gray-500">En attente de transactions synaptiques...</span>
                <span className="text-[8px] block text-gray-600 max-w-xs">
                  Activez la simulation ou manipulez les commandes d'auto-guérison de l'onglet voisin pour voir l'explication logique se rédiger en temps réel.
                </span>
              </div>
            </div>
          ) : (
            narratives.map((log) => {
              let borderStyle = "border-[#14151e] bg-[#07090d]";
              let labelStyle = "text-blue-400 bg-blue-500/10";
              if (log.type === "alert") {
                borderStyle = "border-red-950/40 bg-[#0e0707]";
                labelStyle = "text-red-400 bg-red-500/10";
              } else if (log.type === "success") {
                borderStyle = "border-emerald-950/40 bg-[#060a08]";
                labelStyle = "text-emerald-400 bg-emerald-500/10";
              } else if (log.type === "reasoning") {
                borderStyle = "border-orange-950/40 bg-[#0a0806]";
                labelStyle = "text-orange-400 bg-orange-500/10";
              }

              return (
                <motion.div
                  key={log.id}
                  initial={{ opacity: 0, y: -20, scale: 0.98 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 20 }}
                  transition={{ duration: 0.25 }}
                  className={`p-3.5 rounded-xl border ${borderStyle} shadow-md space-y-2`}
                >
                  <div className="flex items-center justify-between">
                    <span className={`px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-wider ${labelStyle}`}>
                      {log.title}
                    </span>
                    <span className="text-[8px] text-gray-600 font-bold">{log.timestamp}</span>
                  </div>

                  <p className="text-[10px] text-gray-300 leading-relaxed font-sans font-medium">
                    {log.narrative}
                  </p>

                  <div className="flex items-center justify-between border-t border-[#13141d]/60 pt-2 text-[8px] text-gray-500 font-mono">
                    <div className="flex items-center gap-1">
                      <span className="text-gray-600">Émetteur :</span>
                      <span className="text-white font-bold uppercase">@{log.agentFrom}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="text-gray-600">Destinataire :</span>
                      <span className="text-white font-bold uppercase">@{log.agentTo}</span>
                    </div>
                  </div>
                </motion.div>
              );
            })
          )}
        </AnimatePresence>
      </div>

      {/* STATIC INFORMATIVE FOOTER */}
      <div className="bg-[#0b0c10] border-t border-[#181920] p-2 px-3 text-[8.5px] text-gray-600 flex items-center justify-between">
        <span className="flex items-center gap-1">
          <Sparkles className="w-3.5 h-3.5 text-orange-400" />
          Analyseur de flux logique rattaché au processeur central de l'Agi Mesh.
        </span>
        <span className="font-extrabold text-orange-400">SUPERVISOR nominal</span>
      </div>

    </div>
  );
}
