import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Wrench, ShieldCheck, AlertTriangle, Stethoscope, Activity, RefreshCw, Cpu
} from "lucide-react";
import { autoRepairSystemEngine, RepairIncident } from "../services/agents/autoRepairSystemEngine";
import AgenticAutonomySuite from "./AgenticAutonomySuite";

export default function AutoRepairPanel() {
  const [engineState, setEngineState] = useState(autoRepairSystemEngine.getState());
  const [selectedIncident, setSelectedIncident] = useState<RepairIncident | null>(null);
  const [subTab, setSubTab] = useState<"sre" | "l3">("l3");

  useEffect(() => {
    const unsubscribe = autoRepairSystemEngine.subscribe((state) => {
      setEngineState(state);
    });
    return unsubscribe;
  }, []);

  const { currentAnomaly, activeStep, metrics, incidentsHistory, isEmergencyStopped, isRepairing } = engineState;

  // The 12 steps of the self-healing synaptic loop
  const LOOP_STEPS = [
    { num: 1, label: "Interception", desc: "Sonde globale window.onerror / Exception capture" },
    { num: 2, label: "Triage & Impact", desc: "Analyse de gravité (Bloquant, Dégradé, Léger)" },
    { num: 3, label: "Isolation", desc: "Thread-Shielding de protection d'exécution" },
    { num: 4, label: "Diagnostic", desc: "Analyse de la trace d'erreur et de source" },
    { num: 5, label: "Mobilisation", desc: "Appel du Coordinateur de Famille ciblé" },
    { num: 6, label: "Planification", desc: "Plan de correction d'urgence par ProCoder" },
    { num: 7, label: "Simulation", desc: "Validation en Sandbox Virtuelle d'arrière-plan" },
    { num: 8, label: "Arbitrage", desc: "Validation sémantique par CodeSynchronizer" },
    { num: 9, label: "Hot-Swap Patch", desc: "Injection directe à chaud dans le DOM React" },
    { num: 10, label: "Non-Régression", desc: "Validation de stabilité en moins de 5s" },
    { num: 11, label: "Audit Log", desc: "Production de la fiche technique d'incident" },
    { num: 12, label: "Archivage Quantique", desc: "Hydratation de l'équation corrective" },
  ];

  const handleTriggerBug = () => {
    autoRepairSystemEngine.triggerIntentionalTestBug();
  };

  const handleToggleEmergency = () => {
    autoRepairSystemEngine.toggleEmergencyStop();
  };

  return (
    <div className="bg-[#050608] border border-[#181920] rounded-xl p-4 font-mono text-xs text-gray-300 space-y-4 max-w-4xl mx-auto shadow-2xl">
      
      {/* 1. HEADER LOGO & CONTROL BAR */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-[#181920] pb-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded bg-orange-500/10 border border-orange-500/20">
            <Wrench className="w-4 h-4 text-orange-400 animate-spin" style={{ animationDuration: isRepairing ? "4s" : "15s" }} />
          </div>
          <div>
            <div className="font-bold text-white uppercase text-[11px] tracking-widest flex items-center gap-1.5">
              <span>Auto-Guérison</span>
              <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#1c1d25] text-gray-400 font-normal">SRE Self-Healing</span>
            </div>
            <div className="text-[9px] text-gray-500">Moteur de résilience quantique de l'IDE en temps réel (&lt; 20s)</div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Emergency Stop Toggle */}
          <button
            onClick={handleToggleEmergency}
            className={`px-3 py-1.5 rounded border text-[10px] uppercase font-bold transition-all flex items-center gap-1.5 ${
              isEmergencyStopped
                ? "bg-red-500/10 border-red-500 text-red-400"
                : "bg-[#121318] border-[#181920] text-gray-400 hover:text-gray-200 hover:border-red-500/40"
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            {isEmergencyStopped ? "Arrêt Urgence Actif" : "Arrêt Urgence"}
          </button>

          {/* Test Trigger */}
          <button
            onClick={handleTriggerBug}
            disabled={isRepairing || isEmergencyStopped}
            className={`px-3 py-1.5 rounded border text-[10px] uppercase font-bold transition-all flex items-center gap-1.5 ${
              isRepairing || isEmergencyStopped
                ? "bg-[#0b0c10] border-[#13141b] text-gray-600 cursor-not-allowed"
                : "bg-orange-500 text-black border-orange-600 hover:bg-orange-400 font-black"
            }`}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRepairing ? 'animate-spin' : ''}`} />
            Injecter Bug Test
          </button>
        </div>
      </div>

      {/* SUB-NAVIGATION TAB SELECTOR */}
      <div className="flex border-b border-[#181920] pb-2 gap-3">
        <button
          onClick={() => setSubTab("l3")}
          className={`px-3 py-1.5 rounded-lg text-xs font-extrabold uppercase tracking-wider flex items-center gap-1.5 transition-all ${
            subTab === "l3"
              ? "bg-[#1e130c] text-orange-400 border border-orange-500/30"
              : "bg-transparent border border-transparent text-gray-500 hover:text-gray-300"
          }`}
        >
          <Cpu className="w-3.5 h-3.5" />
          Autonomie Niveau 3 (Φ_SOI)
        </button>
        <button
          onClick={() => setSubTab("sre")}
          className={`px-3 py-1.5 rounded-lg text-xs font-extrabold uppercase tracking-wider flex items-center gap-1.5 transition-all ${
            subTab === "sre"
              ? "bg-[#1e130c] text-orange-400 border border-orange-500/30"
              : "bg-transparent border border-transparent text-gray-500 hover:text-gray-300"
          }`}
        >
          <Wrench className="w-3.5 h-3.5" />
          SRE Self-Healing Loop (12 Étapes)
        </button>
      </div>

      {subTab === "l3" ? (
        <AgenticAutonomySuite />
      ) : (
        <>
          {/* 2. METRICS INFOGRAPHICS GRID */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2.5">
            <div className="p-3 bg-[#0a0c10] border border-[#14151c] rounded-lg">
              <div className="text-[9px] text-gray-500 uppercase tracking-wider font-extrabold">Total Intercepté</div>
              <div className="text-xl font-bold text-orange-400 mt-1">{metrics.totalIntercepted}</div>
              <div className="text-[8px] text-gray-600 mt-0.5">Sondes window.onerror</div>
            </div>
            <div className="p-3 bg-[#0a0c10] border border-[#14151c] rounded-lg">
              <div className="text-[9px] text-gray-500 uppercase tracking-wider font-extrabold">Anomalies Résolues</div>
              <div className="text-xl font-bold text-emerald-400 mt-1">{metrics.resolvedCount}</div>
              <div className="text-[8px] text-gray-600 mt-0.5">Taux de succès : 100%</div>
            </div>
            <div className="p-3 bg-[#0a0c10] border border-[#14151c] rounded-lg">
              <div className="text-[9px] text-gray-500 uppercase tracking-wider font-extrabold">Vitesse Correction</div>
              <div className="text-xl font-bold text-sky-400 mt-1">{(metrics.avgResolutionTimeMs / 1000).toFixed(1)}s</div>
              <div className="text-[8px] text-gray-600 mt-0.5">Budget max SRE : 20.0s</div>
            </div>
            <div className="p-3 bg-[#0a0c10] border border-[#14151c] rounded-lg">
              <div className="text-[9px] text-gray-500 uppercase tracking-wider font-extrabold">Index Stabilité</div>
              <div className="text-xl font-bold text-white mt-1">{metrics.stabilityScore}%</div>
              <div className="text-[8px] text-gray-600 mt-0.5">Moyenne pondérée active</div>
            </div>
          </div>

          {/* 3. 12-STEP SELF-HEALING LOOP VISUALIZER */}
          <div className="bg-[#07080b] border border-[#121319] p-3 rounded-lg space-y-3">
            <div className="flex items-center justify-between text-[10px]">
              <div className="text-gray-400 font-extrabold uppercase tracking-wider flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 text-orange-400" />
                Résonance Synaptique en Direct
              </div>
              {isRepairing && (
                <span className="text-[9px] text-orange-400 uppercase font-black animate-pulse flex items-center gap-1">
                  <RefreshCw className="w-3 h-3 animate-spin" /> Cycle d'auto-réparation en cours...
                </span>
              )}
            </div>

            {/* The 12-Step horizontal/vertical fluid visualizer grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2">
              {LOOP_STEPS.map((st) => {
                const isCompleted = isRepairing && activeStep > st.num;
                const isCurrent = isRepairing && activeStep === st.num;
                return (
                  <div
                    key={st.num}
                    className={`p-2 rounded border transition-all ${
                      isCurrent 
                        ? "bg-orange-500/10 border-orange-500 text-orange-400"
                        : isCompleted
                        ? "bg-emerald-500/5 border-emerald-900/40 text-emerald-500"
                        : "bg-[#0b0c11]/40 border-[#14151a] text-gray-600"
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[9px] font-black uppercase">Étape [{st.num.toString().padStart(2, "0")}]</span>
                      {isCompleted ? (
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                      ) : isCurrent ? (
                        <Stethoscope className="w-3.5 h-3.5 text-orange-400 animate-pulse" />
                      ) : null}
                    </div>
                    <div className={`font-bold text-[10px] ${isCurrent ? 'text-orange-300' : isCompleted ? 'text-emerald-400' : 'text-gray-400'}`}>
                      {st.label}
                    </div>
                    <p className="text-[8px] text-gray-500 line-clamp-2 mt-0.5 leading-normal">
                      {st.desc}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 4. ACTIVE INCIDENT TELEMETRY / DETAILED ARCHIVE logs */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            
            {/* Left: Interactive Chronological Archive */}
            <div className="border border-[#14151c] bg-[#07080b] rounded-lg p-3 space-y-2">
              <div className="text-[10px] font-extrabold uppercase text-gray-400 tracking-wider">
                Fiches d'Incident Archivées
              </div>
              <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                {incidentsHistory.map((inc) => (
                  <button
                    key={inc.id}
                    onClick={() => setSelectedIncident(inc)}
                    className={`w-full text-left p-2 rounded border transition-all flex items-center justify-between ${
                      selectedIncident?.id === inc.id
                        ? "bg-[#12141c] border-orange-500/30 text-gray-200"
                        : "bg-[#0a0b0e] border-[#121319] hover:border-[#1c1d27] text-gray-400"
                    }`}
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-1.5">
                        <span className={`w-1.5 h-1.5 rounded-full ${inc.severity === "high" ? "bg-red-500" : "bg-orange-500"}`} />
                        <span className="font-bold text-white text-[10px]">{inc.id}</span>
                      </div>
                      <div className="text-[9px] text-gray-500 truncate max-w-[200px]">{inc.errorTrace}</div>
                    </div>
                    <div className="text-right space-y-0.5">
                      <div className="text-[8px] text-gray-500">{inc.timestamp}</div>
                      <span className="text-[8px] px-1 py-0.5 rounded bg-[#151720] text-emerald-400 uppercase font-black tracking-widest">
                        Stabilité: {inc.stabilityScore}%
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Right: Selected Technical Card Report */}
            <div className="border border-[#14151c] bg-[#07080b] rounded-lg p-3 space-y-2 flex flex-col justify-between min-h-[200px]">
              <div>
                <div className="text-[10px] font-extrabold uppercase text-gray-400 tracking-wider mb-2 border-b border-[#14151c] pb-1">
                  Fiche Technique de l'Incident
                </div>
                
                {selectedIncident ? (
                  <div className="space-y-2 text-[10px]">
                    <div className="flex justify-between">
                      <span className="text-gray-500">ID d'Archive :</span>
                      <span className="text-white font-bold">{selectedIncident.id}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Coordinateur Mobilisé :</span>
                      <span className="text-orange-400 font-bold">{selectedIncident.coordinator}</span>
                    </div>
                    <div className="space-y-1">
                      <span className="text-gray-500">Trace Exception :</span>
                      <div className="p-1.5 bg-[#040507] border border-[#13141a] rounded text-red-400 font-mono text-[9px] leading-normal break-all">
                        {selectedIncident.errorTrace}
                      </div>
                    </div>
                    <div className="space-y-1">
                      <span className="text-gray-500">Correction Hot-Swap :</span>
                      <div className="p-1.5 bg-[#040507] border border-[#13141a] rounded text-emerald-400 font-mono text-[9px] leading-normal italic">
                        {selectedIncident.proposedFix}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-8 text-gray-500 space-y-2">
                    <ShieldCheck className="w-8 h-8 text-gray-700" />
                    <span className="text-[9px]">Sélectionnez un incident archivé pour auditer sa fiche d'auto-réparation.</span>
                  </div>
                )}
              </div>

              {selectedIncident && (
                <div className="text-[9px] text-gray-500 italic border-t border-[#14151c] pt-2 flex items-center justify-between">
                  <span>SRE Resolution Status :</span>
                  <span className="text-emerald-400 uppercase font-bold flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" /> Automatisé & Corrigé &lt; 20s
                  </span>
                </div>
              )}
            </div>

          </div>
        </>
      )}

    </div>
  );
}
