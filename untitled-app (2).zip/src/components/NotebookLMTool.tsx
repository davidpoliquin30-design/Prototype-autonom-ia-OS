import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  FileText, MessageSquare, Columns, Cpu, Send, RefreshCw, 
  ChevronRight, Circle, FileCode, CheckCircle, Database, Sparkles
} from "lucide-react";
import { notebookConversationsService } from "../services/notebookConversationsService";
import { NotebookConversation, ChatMessage, FileAgentInfo, EngaticQuantumCoupling } from "../types";
import { engaticQuantumOrchestrator } from "../services/quantum/engaticQuantumOrchestrator";
import { apiMatrixRoutingService } from "../services/agents/apiMatrixRoutingService";

interface NotebookLMToolProps {
  files: any[];
  onSelectFile?: (path: string) => void;
}

export default function NotebookLMTool({ files, onSelectFile }: NotebookLMToolProps) {
  const [conversations, setConversations] = useState<NotebookConversation[]>([]);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"split" | "reader" | "chat">("split");
  const [inputText, setInputText] = useState("");
  const [selectedFileContent, setSelectedFileContent] = useState<string>("");
  const [selectedFilePath, setSelectedFilePath] = useState<string>("");
  const [selectedAgentName, setSelectedAgentName] = useState<string>("");
  
  // File Agents state
  const [fileAgents, setFileAgents] = useState<FileAgentInfo[]>([]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [synapticPulse, setSynapticPulse] = useState(false);

  // Reactive Engatic Quantum coupling state
  const [coupling, setCoupling] = useState<EngaticQuantumCoupling | null>(null);
  const [lastCalculatedEnergy, setLastCalculatedEnergy] = useState<number>(0);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Subscribe to engatic orchestrator changes
  useEffect(() => {
    const unsubCoupling = engaticQuantumOrchestrator.subscribe((state) => {
      setCoupling(state);
    });
    return unsubCoupling;
  }, []);

  // Subscribe to reactive conversation service
  useEffect(() => {
    const unsubscribe = notebookConversationsService.subscribe((convs, actId) => {
      setConversations(convs);
      setActiveId(actId);
    });
    return unsubscribe;
  }, []);

  // Sync scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [conversations, activeId, isStreaming]);

  // Generate file agents list dynamically from actual files list
  useEffect(() => {
    if (files && files.length > 0) {
      const agents: FileAgentInfo[] = [];
      const extractAgents = (items: any[]) => {
        items.forEach(item => {
          if (item.type === "file" && agents.length < 8) {
            let cleanName = item.name.replace(/\.[^/.]+$/, "").replace(/[^a-zA-Z0-9]/g, "_");
            if (!cleanName || cleanName.trim() === "") {
              cleanName = item.name.replace(/[^a-zA-Z0-9]/g, "_") || "unnamed";
            }
            const agentName = `@agent_${cleanName}`;
            agents.push({
              name: agentName,
              filePath: item.path,
              status: "idle",
              latency: Math.floor(Math.random() * 45) + 10,
              pulseRate: Math.floor(Math.random() * 20) + 60,
              lastActive: new Date().toLocaleTimeString(),
            });
          }
          if (item.children) {
            extractAgents(item.children);
          }
        });
      };
      extractAgents(files);
      setFileAgents(agents);

      // Select first file as default for reader
      if (agents.length > 0 && !selectedFilePath) {
        handleSelectFile(agents[0].filePath, agents[0].name);
      }
    }
  }, [files]);

  const handleSelectFile = async (path: string, agentName: string) => {
    setSelectedFilePath(path);
    setSelectedAgentName(agentName);
    try {
      const response = await fetch("/api/files/read", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ filePath: path }),
      });
      const data = await response.json();
      if (data.content !== undefined) {
        setSelectedFileContent(data.content);
        if (onSelectFile) onSelectFile(path);
      }
    } catch (err) {
      console.error("Error reading file:", err);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isStreaming) return;

    const userQuery = inputText.trim();
    setInputText("");

    // Calculate dynamic cognitive energy of the query using Phi ratios
    const energy = engaticQuantumOrchestrator.calculateEngaticEnergy(userQuery.length);
    setLastCalculatedEnergy(energy);

    // Add user message to active conversation
    notebookConversationsService.addMessageToActive("user", userQuery, "👤 Utilisateur");
    
    // Create placeholder message for Assistant streaming
    const assistantMsg = notebookConversationsService.addMessageToActive(
      "assistant",
      "Établissement du pont de transmission synaptique...",
      "🧬 @orchestrateur_central"
    );

    setIsStreaming(true);
    setSynapticPulse(true);

    // Animate file agents to "analyzing" status
    setFileAgents(prev => prev.map(agent => ({
      ...agent,
      status: Math.random() > 0.4 ? "analyzing" : "idle",
      latency: Math.floor(Math.random() * 80) + 50
    })));

    try {
      // Send to alchemical matrix routing system
      const data = await apiMatrixRoutingService.executeAgentQuery("NotebookLM", userQuery, {
        history: notebookConversationsService.getActiveConversation()?.messages.slice(0, -1) || [],
        activeFiles: fileAgents.filter(f => f.status === "analyzing").map(f => f.filePath),
      });
      
      // If server falls back due to rate/quota limits, feed it to the orchestrator anomaly monitor
      if (data.fallback) {
        engaticQuantumOrchestrator.handleQuantumSystemAnomalies("resource_exhausted_429");
      }

      // Simulate real-time streaming effect from the result
      let currentLength = 0;
      const fullText = data.text || "Erreur de transmission.";
      const interval = setInterval(() => {
        currentLength += Math.min(12, fullText.length - currentLength);
        const sliced = fullText.slice(0, currentLength);
        
        notebookConversationsService.updateLastMessageInActive(
          sliced + (currentLength < fullText.length ? " █" : ""),
          data.fallback ? "🔮 Moteur de Secours" : "🧬 @orchestrateur_central"
        );

        if (currentLength >= fullText.length) {
          clearInterval(interval);
          setIsStreaming(false);
          setSynapticPulse(false);
          // Return agents to idle or synthesized state
          setFileAgents(prev => prev.map(agent => ({
            ...agent,
            status: agent.status === "analyzing" ? "synthesizing" : "idle",
            lastActive: new Date().toLocaleTimeString()
          })));
        }
      }, 25);

    } catch (err: any) {
      console.error(err);
      engaticQuantumOrchestrator.handleQuantumSystemAnomalies(err.message || "connection_failure");
      
      notebookConversationsService.updateLastMessageInActive(
        "Échec de synchronisation synaptique. Impossible de joindre le pont quantique.",
        "⚠️ Système"
      );
      setIsStreaming(false);
      setSynapticPulse(false);
      setFileAgents(prev => prev.map(agent => ({ ...agent, status: "idle" })));
    }
  };

  const activeConv = conversations.find(c => c.id === activeId);

  return (
    <div id="notebook-lm-widget" className="h-full flex flex-col bg-[#0b0c10] border border-[#1f2029] rounded-xl overflow-hidden shadow-xl text-gray-200">
      
      {/* HEADER SECTION WITH INTEGRATED TABS */}
      <div className="flex flex-wrap items-center justify-between px-4 py-2 border-b border-[#1f2029] bg-[#14151a]">
        <div className="flex items-center gap-2">
          <Database className="w-4 h-4 text-orange-500 animate-pulse" />
          <span className="text-sm font-mono uppercase tracking-wider text-gray-300">NotebookLM Systémique</span>
        </div>
        
        {/* Navigation Tabs */}
        <div className="flex gap-1 bg-[#0b0c10] p-1 rounded-lg border border-[#1f2029]">
          <button
            onClick={() => setActiveTab("split")}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded-md transition-all ${
              activeTab === "split" 
                ? "bg-[#1e202b] text-orange-400 border border-[#2b2d3a]" 
                : "text-gray-400 hover:text-gray-200"
            }`}
          >
            <Columns className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Vue Scindée</span>
          </button>
          <button
            onClick={() => setActiveTab("reader")}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded-md transition-all ${
              activeTab === "reader" 
                ? "bg-[#1e202b] text-orange-400 border border-[#2b2d3a]" 
                : "text-gray-400 hover:text-gray-200"
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Lecteur</span>
          </button>
          <button
            onClick={() => setActiveTab("chat")}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-mono rounded-md transition-all ${
              activeTab === "chat" 
                ? "bg-[#1e202b] text-orange-400 border border-[#2b2d3a]" 
                : "text-gray-400 hover:text-gray-200"
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            <span>Dialogue</span>
          </button>
        </div>
      </div>

      {/* SYNAPTIC BUS ACTIVE MONITOR */}
      <div className="bg-[#121319] border-b border-[#1f2029] px-4 py-2 text-xs font-mono">
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-2">
            <Cpu className={`w-3.5 h-3.5 ${synapticPulse ? 'text-orange-500 animate-spin' : 'text-gray-400'}`} />
            <span className="text-gray-400 font-bold">SynapticConduit™ Multi-Agents :</span>
          </div>
          <div className="text-[10px] text-gray-500 uppercase tracking-widest">
            {isStreaming ? "Diffusion synaptique active" : "Canal synaptique en veille"}
          </div>
        </div>
        
        {/* Animated File Node Bubbles */}
        <div className="flex flex-wrap gap-2 py-1 items-center">
          {fileAgents.map((agent) => (
            <div 
              key={agent.filePath}
              onClick={() => handleSelectFile(agent.filePath, agent.name)}
              className={`flex items-center gap-1.5 px-2 py-1 rounded border text-[10px] transition-all cursor-pointer ${
                agent.filePath === selectedFilePath 
                  ? "bg-[#1e202b] border-orange-500/50 text-orange-400" 
                  : "bg-[#0b0c10] border-[#1f2029] text-gray-400 hover:border-gray-600"
              }`}
            >
              <Circle className={`w-1.5 h-1.5 ${
                agent.status === "analyzing" 
                  ? "fill-orange-500 text-orange-500 animate-ping" 
                  : agent.status === "synthesizing"
                  ? "fill-emerald-500 text-emerald-500"
                  : "fill-gray-600 text-gray-600"
              }`} />
              <span className="font-semibold">{agent.name}</span>
              <span className="text-[9px] text-gray-600">({agent.latency}ms)</span>
            </div>
          ))}
        </div>

        {/* Real-time Quantum Coherence display */}
        {coupling && (
          <div className="flex flex-wrap items-center justify-between text-[10px] text-gray-500 mt-2 pt-1.5 border-t border-[#1f2029]/60">
            <div className="flex items-center gap-1.5">
              <Sparkles className="w-3 h-3 text-orange-400 animate-pulse" />
              <span>Cohérence Quantique: <strong className={coupling.quantumCoherence > 0.90 ? "text-emerald-400" : "text-amber-400"}>{(coupling.quantumCoherence * 100).toFixed(1)}%</strong></span>
              <span className="text-gray-600">|</span>
              <span>Entropie: <strong className="text-purple-400">{(coupling.entropyLevel * 100).toFixed(1)}%</strong></span>
              <span className="text-gray-600">|</span>
              <span>Phase: <strong className="text-blue-400 uppercase">{coupling.phase}</strong></span>
            </div>
            {lastCalculatedEnergy > 0 && (
              <div className="text-[9px] text-orange-400/80 bg-orange-950/20 px-1.5 py-0.5 rounded border border-orange-950/40">
                Énergie d'interaction : {lastCalculatedEnergy} J
              </div>
            )}
          </div>
        )}
      </div>

      {/* MAIN CONTAINER CONTENT */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* SPLIT VIEW OR READER TAB */}
        {(activeTab === "split" || activeTab === "reader") && (
          <div className={`flex-1 flex flex-col border-r border-[#1f2029] bg-[#0b0c10] ${activeTab === "reader" ? "w-full" : "w-1/2 hidden md:flex"}`}>
            
            {/* File Info Bar */}
            <div className="flex items-center justify-between px-4 py-2 bg-[#14151a] border-b border-[#1f2029] text-xs font-mono">
              <div className="flex items-center gap-2 text-gray-300">
                <FileCode className="w-4 h-4 text-orange-400" />
                <span className="truncate">{selectedFilePath || "Sélectionnez un fichier..."}</span>
              </div>
              {selectedAgentName && (
                <div className="text-[10px] bg-[#1e202b] px-2 py-0.5 rounded border border-[#2b2d3a] text-orange-400">
                  Géré par {selectedAgentName}
                </div>
              )}
            </div>

            {/* Content area */}
            <div className="flex-1 p-4 overflow-auto font-mono text-xs text-gray-300 leading-relaxed bg-[#08090d]">
              {selectedFileContent ? (
                <pre className="whitespace-pre-wrap select-text">{selectedFileContent}</pre>
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-gray-500 gap-2">
                  <FileText className="w-8 h-8 opacity-40 text-orange-400" />
                  <span>Aucun fichier chargé dans le NotebookLM.</span>
                  <span className="text-[10px] text-gray-600 text-center max-w-xs">Double-cliquez sur un fichier de l'explorateur ou sélectionnez-en un ci-dessus.</span>
                </div>
              )}
            </div>
          </div>
        )}

        {/* SPLIT VIEW CHAT OR CHAT TAB */}
        {(activeTab === "split" || activeTab === "chat") && (
          <div className={`flex flex-col bg-[#0b0c10] ${activeTab === "chat" ? "w-full" : "w-full md:w-1/2"}`}>
            
            {/* Conversation Selector & Creator Bar */}
            <div className="flex items-center justify-between px-3 py-2 bg-[#14151a] border-b border-[#1f2029]">
              <select
                value={activeId || ""}
                onChange={(e) => notebookConversationsService.selectConversation(e.target.value)}
                className="bg-[#0b0c10] border border-[#1f2029] text-xs font-mono p-1 rounded text-gray-300 focus:outline-none focus:border-orange-500/50"
              >
                {conversations.map(c => (
                  <option key={c.id} value={c.id}>{c.title}</option>
                ))}
              </select>
              
              <button
                onClick={() => {
                  const title = prompt("Nom du fil d'auto-évolution :");
                  if (title !== null) {
                    notebookConversationsService.createConversation(title);
                  }
                }}
                className="px-2 py-1 bg-[#1e202b] hover:bg-[#282a39] text-[10px] font-mono rounded border border-[#2b2d3a] text-gray-300 transition-colors"
              >
                + Nouveau Fil
              </button>
            </div>

            {/* Chat Messages Log */}
            <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-[#08090d]">
              {activeConv ? (
                activeConv.messages.map((msg) => (
                  <div 
                    key={msg.id} 
                    className={`flex flex-col p-3 rounded-lg border text-xs font-mono transition-all ${
                      msg.role === "user"
                        ? "bg-[#1e130c] border-orange-950 ml-6 text-gray-200"
                        : msg.role === "system"
                        ? "bg-[#101413] border-emerald-950 text-emerald-400/90 text-center max-w-md mx-auto"
                        : "bg-[#14151a] border-[#1f2029] mr-6 text-gray-300"
                    }`}
                  >
                    <div className="flex items-center justify-between text-[10px] text-gray-500 mb-1.5 pb-1 border-b border-[#1f2029]/40">
                      <span className="font-bold text-gray-400 uppercase tracking-widest">{msg.agentName || (msg.role === "user" ? "USER" : "ASSISTANT")}</span>
                      <span>{msg.timestamp}</span>
                    </div>
                    <div className="whitespace-pre-wrap select-text leading-relaxed">
                      {msg.content}
                    </div>
                  </div>
                ))
              ) : (
                <div className="h-full flex items-center justify-center text-gray-500 font-mono text-xs">
                  Aucun fil de conversation actif.
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input form */}
            <form onSubmit={handleSendMessage} className="p-3 bg-[#14151a] border-t border-[#1f2029] flex gap-2">
              <input
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                disabled={isStreaming}
                placeholder={isStreaming ? "Diffusion d'informations..." : "Interroger les agents du NotebookLM..."}
                className="flex-1 bg-[#0b0c10] border border-[#1f2029] rounded-lg px-3 py-2 text-xs font-mono text-gray-200 focus:outline-none focus:border-orange-500/50"
              />
              <button
                type="submit"
                disabled={isStreaming || !inputText.trim()}
                className={`p-2 rounded-lg text-white font-mono text-xs flex items-center gap-1.5 transition-colors ${
                  isStreaming || !inputText.trim()
                    ? "bg-gray-800 text-gray-500 cursor-not-allowed"
                    : "bg-orange-500 hover:bg-orange-600"
                }`}
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>

          </div>
        )}

      </div>
    </div>
  );
}
