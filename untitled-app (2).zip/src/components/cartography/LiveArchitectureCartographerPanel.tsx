import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Compass, Search, Cpu, Layers, Wrench, Shield, 
  Activity, Sparkles, CheckCircle2, ArrowRight, 
  RefreshCw, Globe, Database, Network, Eye, Terminal,
  Sliders, Heart, Zap, FolderTree
} from "lucide-react";
import { 
  omniLiveArchitectureCartographer, 
  LiveCartographySnapshot,
  LiveAgentEntry,
  AppInternalView,
  AppIntegratedTool,
  AppStructuralPlane
} from "../../services/agent/omniLiveArchitectureCartographer";

interface LiveArchitectureCartographerPanelProps {
  embedded?: boolean;
}

export default function LiveArchitectureCartographerPanel({ embedded = false }: LiveArchitectureCartographerPanelProps) {
  const [snapshot, setSnapshot] = useState<LiveCartographySnapshot>(omniLiveArchitectureCartographer.getSnapshot());
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [activeTab, setActiveTab] = useState<"overview" | "agents" | "structure" | "tools" | "metrics">("overview");
  const [selectedPole, setSelectedPole] = useState<string>("all");

  useEffect(() => {
    const unsub = omniLiveArchitectureCartographer.subscribe(setSnapshot);
    return () => unsub();
  }, []);

  const searchResults = omniLiveArchitectureCartographer.query(searchQuery);

  const filteredAgents = searchResults.matchedAgents.filter(ag => {
    if (selectedPole === "all") return true;
    return ag.pole === selectedPole;
  });

  return (
    <div className={`flex flex-col h-full bg-[#05060a] text-gray-200 font-mono rounded-xl border border-[#1b1e2e] overflow-hidden ${embedded ? "" : "shadow-2xl"}`}>
      
      {/* HEADER: Cartographer Agent Identity */}
      <div className="p-4 bg-gradient-to-r from-[#0e1220] via-[#090b14] to-[#120e22] border-b border-[#1c2238] flex flex-wrap items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 via-indigo-600 to-purple-600 p-0.5 flex items-center justify-center shadow-lg shadow-cyan-950/50">
              <div className="w-full h-full bg-[#070912] rounded-[10px] flex items-center justify-center">
                <Compass className="w-5 h-5 text-cyan-400 animate-spin" style={{ animationDuration: "30s" }} />
              </div>
            </div>
            <span className="absolute -top-1 -right-1 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-cyan-500"></span>
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xs sm:text-sm font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                Agent Cartographe Intégral (@omni_live_architecture_cartographer)
              </h2>
              <span className="text-[9px] px-2 py-0.5 rounded-full bg-cyan-950 text-cyan-300 border border-cyan-800 font-bold">
                Temps Réel
              </span>
            </div>
            <p className="text-[11px] text-gray-400">
              Cartographie dynamique complète • {snapshot.totalAgentsCount} Agents IA • {snapshot.totalViewsCount} Vues Internes • {snapshot.totalToolsCount} Outils Intégrés
            </p>
          </div>
        </div>

        {/* Global Key Counters */}
        <div className="flex items-center gap-2 text-[10px]">
          <div className="px-2.5 py-1 rounded-lg bg-[#0e1222] border border-[#1d2644] text-cyan-300 font-bold flex items-center gap-1.5">
            <Cpu className="w-3.5 h-3.5 text-cyan-400" />
            <span>{snapshot.activeAgentsCount} Agents</span>
          </div>
          <div className="px-2.5 py-1 rounded-lg bg-[#0e1222] border border-[#1d2644] text-purple-300 font-bold flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-purple-400" />
            <span>{snapshot.totalViewsCount} Vues</span>
          </div>
          <div className="px-2.5 py-1 rounded-lg bg-[#0e1222] border border-[#1d2644] text-emerald-300 font-bold flex items-center gap-1.5">
            <Wrench className="w-3.5 h-3.5 text-emerald-400" />
            <span>{snapshot.totalToolsCount} Outils</span>
          </div>
        </div>
      </div>

      {/* SEARCH BAR & NAVIGATION TABS */}
      <div className="p-3 bg-[#0a0c14] border-b border-[#181c2c] flex flex-wrap items-center justify-between gap-3 shrink-0">
        
        {/* Search Input */}
        <div className="relative flex-1 min-w-[220px] max-w-md">
          <Search className="w-3.5 h-3.5 text-gray-500 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            placeholder="Rechercher un agent, un outil, une vue ou un fichier..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full bg-[#101320] border border-[#202740] rounded-lg pl-9 pr-3 py-1.5 text-xs text-gray-200 placeholder-gray-500 focus:outline-none focus:border-cyan-500 transition-all font-mono"
          />
        </div>

        {/* View Tabs */}
        <div className="flex items-center gap-1 text-[11px] overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveTab("overview")}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all whitespace-nowrap ${
              activeTab === "overview" ? "bg-cyan-950 text-cyan-300 border border-cyan-700/50" : "text-gray-400 hover:text-gray-200"
            }`}
          >
            Vue d'Ensemble
          </button>

          <button
            onClick={() => setActiveTab("agents")}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all whitespace-nowrap ${
              activeTab === "agents" ? "bg-cyan-950 text-cyan-300 border border-cyan-700/50" : "text-gray-400 hover:text-gray-200"
            }`}
          >
            Agents IA ({filteredAgents.length})
          </button>

          <button
            onClick={() => setActiveTab("structure")}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all whitespace-nowrap ${
              activeTab === "structure" ? "bg-purple-950 text-purple-300 border border-purple-700/50" : "text-gray-400 hover:text-gray-200"
            }`}
          >
            Structure Interne (14)
          </button>

          <button
            onClick={() => setActiveTab("tools")}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all whitespace-nowrap ${
              activeTab === "tools" ? "bg-emerald-950 text-emerald-300 border border-emerald-700/50" : "text-gray-400 hover:text-gray-200"
            }`}
          >
            Outils Intégrés (16)
          </button>

          <button
            onClick={() => setActiveTab("metrics")}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all whitespace-nowrap ${
              activeTab === "metrics" ? "bg-amber-950 text-amber-300 border border-amber-700/50" : "text-gray-400 hover:text-gray-200"
            }`}
          >
            Invariants & Métriques
          </button>
        </div>

      </div>

      {/* CONTENT AREA */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4">
        
        {/* 1. OVERVIEW VIEW */}
        {activeTab === "overview" && (
          <div className="space-y-4">
            
            {/* Real-time System Summary Card */}
            <div className="p-4 rounded-xl bg-gradient-to-r from-[#0d101e] to-[#0a0c16] border border-[#1e2540] grid grid-cols-1 md:grid-cols-4 gap-3 text-xs">
              <div className="p-3 rounded-lg bg-[#111626] border border-[#222c4d]">
                <div className="text-[10px] text-gray-400 uppercase">Flotte Multi-Agents</div>
                <div className="text-cyan-400 font-bold text-sm mt-1">20 Agents Actifs</div>
                <div className="text-[9px] text-gray-500 mt-0.5">Orchestrés sur 6 Pôles</div>
              </div>

              <div className="p-3 rounded-lg bg-[#111626] border border-[#222c4d]">
                <div className="text-[10px] text-gray-400 uppercase">Architecture en 4 Plans</div>
                <div className="text-purple-400 font-bold text-sm mt-1">Alpha • Bêta • Gamma • Delta</div>
                <div className="text-[9px] text-gray-500 mt-0.5">Topologie étanche AROA</div>
              </div>

              <div className="p-3 rounded-lg bg-[#111626] border border-[#222c4d]">
                <div className="text-[10px] text-gray-400 uppercase">Outils du Système</div>
                <div className="text-emerald-400 font-bold text-sm mt-1">16 Outils Concrets</div>
                <div className="text-[9px] text-gray-500 mt-0.5">Exécuteurs, Linters & Transducteurs</div>
              </div>

              <div className="p-3 rounded-lg bg-[#111626] border border-[#222c4d]">
                <div className="text-[10px] text-gray-400 uppercase">Indice de Réalité</div>
                <div className="text-rose-400 font-bold text-sm mt-1">Ξ ≡ 1.0000</div>
                <div className="text-[9px] text-gray-500 mt-0.5">Amour Source : Amr ≡ 1</div>
              </div>
            </div>

            {/* The 4 Structural Planes */}
            <div className="space-y-2">
              <h3 className="text-xs font-black text-gray-300 uppercase tracking-wider flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-cyan-400" />
                Les 4 Plans de l'Architecture Interne (MRD / AROA)
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {snapshot.planes.map(plane => (
                  <div key={plane.id} className="p-3.5 rounded-xl bg-[#0b0e18] border border-[#1c233a] space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-white text-xs">{plane.name}</span>
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-[#151c30] text-cyan-300 border border-[#253256]">
                        {plane.dimension}
                      </span>
                    </div>

                    <p className="text-gray-400 text-[11px] leading-relaxed">
                      {plane.description}
                    </p>

                    <div className="pt-2 border-t border-[#161c2e] flex flex-wrap gap-1.5">
                      {plane.features.map((feat, i) => (
                        <span key={i} className="text-[9px] px-2 py-0.5 rounded bg-[#101424] text-gray-300 border border-[#1f2640]">
                          {feat}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Preview: 6 Top Agents */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-black text-gray-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Cpu className="w-3.5 h-3.5 text-indigo-400" />
                  Agents Clés de la Flotte
                </h3>
                <button
                  onClick={() => setActiveTab("agents")}
                  className="text-[11px] text-cyan-400 hover:underline flex items-center gap-1"
                >
                  Voir les 20 agents <ArrowRight className="w-3 h-3" />
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                {snapshot.agents.slice(0, 6).map(ag => (
                  <div key={ag.id} className="p-3 rounded-xl bg-[#090c16] border border-[#1c2236] space-y-1.5 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-cyan-300 text-[11px]">{ag.id}</span>
                      <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
                        {ag.latencyMs}ms
                      </span>
                    </div>
                    <div className="text-white font-medium text-[11px]">{ag.name}</div>
                    <p className="text-gray-400 text-[10px] line-clamp-2">{ag.role}</p>
                    <div className="text-[9px] text-indigo-400 font-mono pt-1 border-t border-[#151928]">
                      {ag.equation}
                    </div>
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* 2. AGENTS VIEW */}
        {activeTab === "agents" && (
          <div className="space-y-3">
            
            {/* Pole Filters */}
            <div className="flex flex-wrap gap-1.5 text-[10px]">
              {["all", "direction", "gouvernance", "structure", "intuition", "code", "optimisation"].map(pole => (
                <button
                  key={pole}
                  onClick={() => setSelectedPole(pole)}
                  className={`px-2.5 py-1 rounded-lg uppercase font-bold transition-all ${
                    selectedPole === pole 
                      ? "bg-cyan-600 text-white shadow-sm" 
                      : "bg-[#0d101c] text-gray-400 hover:text-white border border-[#1b223a]"
                  }`}
                >
                  {pole === "all" ? "Tous les Pôles (20)" : `Pôle ${pole}`}
                </button>
              ))}
            </div>

            {/* Agents List Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {filteredAgents.map(ag => (
                <div key={ag.id} className="p-3.5 rounded-xl bg-[#090b14] border border-[#1b2138] space-y-2 text-xs hover:border-cyan-500/40 transition-all">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      <span className="font-bold text-cyan-300">{ag.id}</span>
                    </div>
                    <span className="text-[9px] px-2 py-0.5 rounded bg-[#121626] text-purple-300 border border-[#232c4d] font-bold uppercase">
                      Pôle {ag.pole}
                    </span>
                  </div>

                  <div className="text-white font-bold text-xs">{ag.name}</div>
                  <p className="text-gray-300 text-[11px] leading-relaxed">{ag.role}</p>

                  <div className="p-2 rounded bg-[#06070d] border border-[#141828] text-[10px] space-y-1">
                    <div className="text-indigo-400 font-mono">
                      Formule : <span className="text-gray-300">{ag.equation}</span>
                    </div>
                    <div className="text-gray-400 text-[9px] flex items-center justify-between pt-1 border-t border-[#121624]">
                      <span>Dernière action : {ag.lastAction}</span>
                      <span className="text-emerald-400 font-bold">{ag.latencyMs} ms</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 text-[9px] text-gray-400">
                    <span className="text-gray-500">Connexions :</span>
                    <div className="flex flex-wrap gap-1">
                      {ag.connections.map((c, i) => (
                        <span key={i} className="px-1.5 py-0.2 rounded bg-[#101424] text-cyan-400 border border-[#1e2640]">
                          {c}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>

          </div>
        )}

        {/* 3. STRUCTURE VIEW (14 VUES & ARCHITECTURE) */}
        {activeTab === "structure" && (
          <div className="space-y-3">
            <div className="text-xs text-gray-400">
              Cartographie des 14 vues et modules composant l'application :
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {searchResults.matchedViews.map(view => (
                <div key={view.id} className="p-3.5 rounded-xl bg-[#090b14] border border-[#1b2138] space-y-2 text-xs">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-cyan-400" />
                      <span className="font-bold text-white text-xs">{view.name}</span>
                    </div>
                    <span className="text-[9px] px-2 py-0.5 rounded bg-[#131728] text-cyan-300 border border-[#212944] font-mono">
                      {view.route}
                    </span>
                  </div>

                  <p className="text-gray-400 text-[11px] leading-relaxed">
                    {view.description}
                  </p>

                  <div className="pt-2 border-t border-[#161a2c] flex items-center justify-between text-[10px] text-gray-500">
                    <span>Composant : <span className="text-purple-300 font-mono">{view.component}</span></span>
                    <span className="text-emerald-400 font-bold">Actif • 60 FPS</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 4. TOOLS VIEW (16 OUTILS CONCRETS) */}
        {activeTab === "tools" && (
          <div className="space-y-3">
            <div className="text-xs text-gray-400">
              Recensement complet des 16 outils intégrés dans le système :
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {searchResults.matchedTools.map(tool => (
                <div key={tool.id} className="p-3.5 rounded-xl bg-[#090b14] border border-[#1b2138] space-y-2 text-xs hover:border-emerald-500/40 transition-all">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Wrench className="w-3.5 h-3.5 text-emerald-400" />
                      <span className="font-bold text-white text-xs">{tool.name}</span>
                    </div>
                    <span className="text-[9px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold uppercase">
                      {tool.activeStatus}
                    </span>
                  </div>

                  <p className="text-gray-300 text-[11px] leading-relaxed">
                    {tool.description}
                  </p>

                  <div className="text-[10px] text-gray-400 font-mono">
                    Emplacement : <span className="text-cyan-300">{tool.location}</span>
                  </div>

                  <div className="pt-2 border-t border-[#161a2c] flex flex-wrap gap-1">
                    {tool.capabilities.map((cap, i) => (
                      <span key={i} className="text-[9px] px-1.5 py-0.5 rounded bg-[#0e1220] text-gray-300 border border-[#1c2440]">
                        {cap}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 5. METRICS & INVARIANTS */}
        {activeTab === "metrics" && (
          <div className="space-y-4 text-xs">
            <div className="p-4 rounded-xl bg-[#090b14] border border-[#1b2138] space-y-3">
              <h3 className="text-xs font-black text-white uppercase tracking-wider flex items-center gap-1.5">
                <Activity className="w-4 h-4 text-rose-400" />
                Invariants Fondamentaux Φ_SOI & MRD
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div className="p-3 rounded-lg bg-[#0e111e] border border-[#1d2440] space-y-1">
                  <span className="text-[10px] text-gray-400 uppercase">Indice de Réalité (Ξ = 1)</span>
                  <div className="text-white font-bold">1.0000 (Consistance absolue)</div>
                  <p className="text-[10px] text-gray-400">La matière est le seul tribunal qui ne ment jamais (E_100 = 1).</p>
                </div>

                <div className="p-3 rounded-lg bg-[#0e111e] border border-[#1d2440] space-y-1">
                  <span className="text-[10px] text-gray-400 uppercase">Disrésonance Cognitive (D_c → 0)</span>
                  <div className="text-cyan-400 font-bold">{snapshot.systemMetrics.cognitiveDissonanceDc.toFixed(4)}</div>
                  <p className="text-[10px] text-gray-400">Élimination stricte de toute hallucination probabiliste.</p>
                </div>

                <div className="p-3 rounded-lg bg-[#0e111e] border border-[#1d2440] space-y-1">
                  <span className="text-[10px] text-gray-400 uppercase">Protocole Amour Source (Amr ≡ 1)</span>
                  <div className="text-rose-400 font-bold flex items-center gap-1">
                    <Heart className="w-3.5 h-3.5 text-rose-400 fill-current" />
                    1.0000 (Source Première)
                  </div>
                  <p className="text-[10px] text-gray-400">Harmonique Universelle H_∞ et vibration 528 Hz.</p>
                </div>

                <div className="p-3 rounded-lg bg-[#0e111e] border border-[#1d2440] space-y-1">
                  <span className="text-[10px] text-gray-400 uppercase">Empreinte Mémoire Vive</span>
                  <div className="text-emerald-400 font-bold">{snapshot.systemMetrics.memoryFootprintMb} MB</div>
                  <p className="text-[10px] text-gray-400">Application stricte de l'Intégrale du Silence (∮_σ).</p>
                </div>
              </div>

              <div className="pt-2 border-t border-[#171c2e] text-[10px] text-gray-400">
                <span>Endpoints API Actifs : </span>
                {snapshot.systemMetrics.activeEndpoints.map((ep, i) => (
                  <span key={i} className="mx-1 px-1.5 py-0.5 rounded bg-[#121626] text-cyan-300 font-mono">
                    {ep}
                  </span>
                ))}
              </div>
            </div>
          </div>
        )}

      </div>

    </div>
  );
}
