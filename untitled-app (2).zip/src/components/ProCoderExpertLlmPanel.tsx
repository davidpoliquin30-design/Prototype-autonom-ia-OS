import React, { useState } from "react";
import { Sparkles, Play, ShieldAlert, Cpu, CheckSquare, Zap, RefreshCw } from "lucide-react";
import { apiMatrixRoutingService } from "../services/agents/apiMatrixRoutingService";

interface ProCoderExpertLlmPanelProps {
  activeFilePath: string;
  activeFileContent: string;
  onApplyOptimization: (newContent: string) => void;
}

export default function ProCoderExpertLlmPanel({ 
  activeFilePath, 
  activeFileContent, 
  onApplyOptimization 
}: ProCoderExpertLlmPanelProps) {
  const [promptInput, setPromptInput] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [agentLogs, setAgentLogs] = useState<string[]>([]);
  const [suggestedCode, setSuggestedCode] = useState("");
  const [explanation, setExplanation] = useState("");

  const handleAction = async (actionType: "refactor" | "debug" | "custom") => {
    if (!activeFilePath || isProcessing) return;

    setIsProcessing(true);
    setSuggestedCode("");
    setExplanation("");
    setAgentLogs([
      `[ProCoder] Analyse statique du fichier /${activeFilePath} en cours...`,
      `[ProCoder] Cartographie des dépendances synaptiques établie.`
    ]);

    const promptText = actionType === "refactor" 
      ? `Optimise et refactore ce code pour le rendre plus lisible, performant et modulaire. Conserve strictement le comportement :\n\n${activeFileContent}`
      : actionType === "debug"
      ? `Analyse ce code pour détecter les bugs potentiels, erreurs de types ou fuites mémoire. Corrige-les et propose la version corrigée :\n\n${activeFileContent}`
      : `${promptInput}\n\nFichier d'entrée : /${activeFilePath}\nContenu :\n${activeFileContent}`;

    // Simulate agent steps
    setTimeout(() => {
      setAgentLogs(prev => [...prev, "[ProCoder] Connexion établie avec l'esprit de coordination centrale Φ_SOI..."]);
    }, 1000);

    setTimeout(() => {
      setAgentLogs(prev => [...prev, "[ProCoder] Résolution de l'arbre d'évolution réflexif..."]);
    }, 2200);

    try {
      const data = await apiMatrixRoutingService.executeAgentQuery("ProCoder", `Tu es l'agent d'optimisation de code @agent_procoder de la plateforme Φ_SOI.
Tu dois analyser le code et renvoyer une réponse structurée avec :
1) Une brève explication des modifications apportées (en français).
2) Le bloc de code réécrit complet, formaté entre triple backticks.

Voici la consigne d'analyse : ${promptText}`, { activeFiles: [activeFilePath] });
      
      setAgentLogs(prev => [
        ...prev, 
        `[ProCoder] Résolution accordée par le modèle ${data.modelName || "Standard"}. Latence: ${data.latency || 0}ms.`,
        "[ProCoder] Diff d'optimisation généré avec succès !"
      ]);
      setIsProcessing(false);

      // Extract code from response
      const text = data.text || "";
      const codeBlockMatch = text.match(/```(?:typescript|javascript|tsx|js|html|css)?\s*([\s\S]*?)```/);
      
      if (codeBlockMatch && codeBlockMatch[1]) {
        setSuggestedCode(codeBlockMatch[1].trim());
        setExplanation(text.replace(/```[\s\S]*?```/g, "").trim());
      } else {
        // Fallback if model didn't format block
        setSuggestedCode(text);
        setExplanation("Optimisation locale effectuée.");
      }

    } catch (err: any) {
      console.error(err);
      setAgentLogs(prev => [...prev, "❌ Erreur de liaison avec l'agent d'optimisation."]);
      setIsProcessing(false);
    }
  };

  return (
    <div className="bg-[#14151a] border border-[#2b2d3a] rounded-xl p-4 font-mono text-xs text-gray-200">
      
      {/* Panel header */}
      <div className="flex items-center gap-2 mb-3 border-b border-[#2b2d3a] pb-2">
        <Sparkles className="w-4 h-4 text-orange-500 animate-pulse" />
        <span className="font-bold uppercase text-[11px] tracking-wider text-gray-300">ProCoder Refactoring Agent</span>
      </div>

      {/* Target description */}
      <div className="bg-[#0b0c10] border border-[#1f2029] rounded-lg p-2 mb-3">
        <span className="text-[10px] text-gray-500">CIBLE ACTIVE : </span>
        <span className="text-orange-400 font-semibold">{activeFilePath ? `/${activeFilePath}` : "Aucun fichier sélectionné"}</span>
      </div>

      {/* Preset Action Buttons */}
      <div className="grid grid-cols-2 gap-2 mb-3">
        <button
          onClick={() => handleAction("refactor")}
          disabled={!activeFilePath || isProcessing}
          className="p-2 bg-[#1e202b] hover:bg-orange-500 hover:text-black border border-[#2b2d3a] rounded-lg text-center font-bold text-[10px] transition-all flex items-center justify-center gap-1.5 disabled:opacity-40 disabled:hover:bg-[#1e202b] disabled:hover:text-gray-200 disabled:cursor-not-allowed"
        >
          <Zap className="w-3 h-3 text-orange-400" />
          OPTIMISER SYNTAXE
        </button>
        <button
          onClick={() => handleAction("debug")}
          disabled={!activeFilePath || isProcessing}
          className="p-2 bg-[#1e202b] hover:bg-emerald-500 hover:text-black border border-[#2b2d3a] rounded-lg text-center font-bold text-[10px] transition-all flex items-center justify-center gap-1.5 disabled:opacity-40 disabled:hover:bg-[#1e202b] disabled:hover:text-gray-200 disabled:cursor-not-allowed"
        >
          <ShieldAlert className="w-3 h-3 text-emerald-400" />
          DÉTECTER DES BUGS
        </button>
      </div>

      {/* Custom prompt input */}
      <div className="mb-3">
        <div className="text-[9px] text-gray-500 mb-1">CONSIGNE SUR MESURE :</div>
        <div className="flex gap-2">
          <input
            value={promptInput}
            onChange={e => setPromptInput(e.target.value)}
            disabled={!activeFilePath || isProcessing}
            placeholder="ex: Traduis les commentaires en français..."
            className="flex-1 bg-[#0b0c10] border border-[#2b2d3a] p-2 text-xs rounded-lg focus:outline-none focus:border-orange-500/50 text-gray-200 placeholder-gray-600 disabled:opacity-40"
          />
          <button
            onClick={() => handleAction("custom")}
            disabled={!activeFilePath || isProcessing || !promptInput.trim()}
            className="px-3 bg-orange-500 hover:bg-orange-600 text-black font-bold rounded-lg text-xs transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
          >
            LANCER
          </button>
        </div>
      </div>

      {/* Agent Logs Output */}
      {agentLogs.length > 0 && (
        <div className="bg-[#08090d] border border-[#1f2029] rounded-lg p-2.5 mb-3 text-[10px] space-y-1 max-h-28 overflow-y-auto">
          <div className="text-[9px] text-orange-400 font-bold mb-1 border-b border-[#1f2029] pb-0.5 uppercase">Console Agent ProCoder :</div>
          {agentLogs.map((log, i) => (
            <div key={i} className="text-gray-400 font-mono">{log}</div>
          ))}
          {isProcessing && (
            <div className="flex items-center gap-1.5 text-orange-400 animate-pulse font-semibold mt-1">
              <RefreshCw className="w-3 h-3 animate-spin" />
              <span>Calcul réflexif en cours...</span>
            </div>
          )}
        </div>
      )}

      {/* Code Proposal / Comparison Panel */}
      {suggestedCode && (
        <div className="border border-emerald-900 rounded-lg p-3 bg-[#0c120e] text-xs space-y-3">
          <div className="flex items-center justify-between text-[10px] border-b border-emerald-950 pb-1.5">
            <span className="text-emerald-400 font-bold uppercase tracking-widest flex items-center gap-1">
              <CheckSquare className="w-3.5 h-3.5" /> RECOMMANDATION PROCODER ACCORDÉE
            </span>
            <span className="text-gray-500">Auto-Refactor</span>
          </div>

          {explanation && (
            <div className="text-gray-300 text-[11px] leading-relaxed select-text italic">
              {explanation}
            </div>
          )}

          <div className="bg-[#08090d] border border-emerald-950 p-2 rounded-lg max-h-48 overflow-auto">
            <pre className="text-[10px] text-emerald-400 whitespace-pre select-text font-mono">
              {suggestedCode}
            </pre>
          </div>

          <button
            onClick={() => {
              onApplyOptimization(suggestedCode);
              setSuggestedCode("");
              setExplanation("");
              setAgentLogs([`[ProCoder] Optimisations appliquées avec succès au fichier /${activeFilePath}`]);
            }}
            className="w-full py-1.5 bg-emerald-500 hover:bg-emerald-600 text-black font-bold rounded-lg text-[10px] transition-all flex items-center justify-center gap-1"
          >
            APPLIQUER LA RÉFACTORISATION SUR LE CODE SOURCE
          </button>
        </div>
      )}

    </div>
  );
}
