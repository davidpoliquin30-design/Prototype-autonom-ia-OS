import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Sparkles, Command, Workflow, BrainCircuit, KeyRound, RotateCcw,
  Send, Trash2, Cpu, CheckCircle2, AlertCircle, FileCode, Radio
} from "lucide-react";
import { quantumIdeCompanionService, ChatMessage } from "../../services/agents/quantumIdeCompanionService";
import { quantumCognitiveBridge, QuantumBridgeState } from "../../services/quantum/quantumCognitiveBridge";

interface QuantumIdeChatProps {
  activeFile: string | null;
  onRefreshFiles: () => void;
  onSelectFile: (path: string, content: string) => void;
  addConsoleLog?: (msg: string) => void;
}

export default function QuantumIdeChat({
  activeFile,
  onRefreshFiles,
  onSelectFile,
  addConsoleLog
}: QuantumIdeChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [intricacyTarget, setIntricacyTarget] = useState<string | null>(null);
  
  // Quantum bridge state tracking
  const [bridgeState, setBridgeState] = useState<QuantumBridgeState>({
    coherenceScore: 0.92,
    entropyLevel: 0.08,
    qubitStates: [1, 0, 1, 1, 1, 0, 1, 1],
    phase: "SYNCHRONIZED",
    isResilientFallbackActive: false
  });

  const scrollRef = useRef<HTMLDivElement | null>(null);

  // Subscribe to companion service
  useEffect(() => {
    const unsubCompanion = quantumIdeCompanionService.subscribe((state) => {
      setMessages(state.messages);
      setIsGenerating(state.isGenerating);
      setIntricacyTarget(state.intricacyTarget);
    });

    const unsubBridge = quantumCognitiveBridge.subscribe((state) => {
      setBridgeState(state);
    });

    return () => {
      unsubCompanion();
      unsubBridge();
    };
  }, []);

  // Update companion intricacy targets based on active file changes
  useEffect(() => {
    quantumIdeCompanionService.setIntricacyTarget(activeFile);
  }, [activeFile]);

  // Keep chat scrolled
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputValue.trim() || isGenerating) return;

    const textToSend = inputValue;
    setInputValue("");
    
    await quantumIdeCompanionService.sendUserMessage(textToSend, intricacyTarget);
  };

  const handleClearHistory = () => {
    quantumIdeCompanionService.clearHistory();
    if (addConsoleLog) {
      addConsoleLog("Quantum companion conversation history cleared.");
    }
  };

  const applyHotSwapPatch = async (msgId: string, filePath: string, code: string) => {
    if (addConsoleLog) {
      addConsoleLog(`Initiating Hot-Swap patch to /${filePath}...`);
    }
    
    const success = await quantumIdeCompanionService.applyPatchToWorkspace(filePath, code);
    
    if (success) {
      if (addConsoleLog) {
        addConsoleLog(`✓ Hot-Swap successful! File /${filePath} mutated and synced to editor.`);
      }
      onRefreshFiles();
      onSelectFile(filePath, code);

      // Mutate chat state to show applied success state
      const updatedMessages = messages.map(m => {
        if (m.id === msgId) {
          return { ...m, appliedPatch: true };
        }
        return m;
      });
      // We force local update of messages
      setMessages(updatedMessages);
    } else {
      if (addConsoleLog) {
        addConsoleLog(`❌ Hot-Swap failed for /${filePath}. SRE engine isolated the thread.`);
      }
    }
  };

  return (
    <div className="bg-[#050608] border border-[#181920] rounded-xl font-mono text-xs text-gray-300 flex flex-col h-[520px] shadow-xl overflow-hidden">
      
      {/* HEADER SECTION */}
      <div className="bg-[#0b0c10] border-b border-[#181920] p-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <BrainCircuit className="w-4 h-4 text-orange-400 animate-pulse" />
          <div>
            <div className="font-bold text-white uppercase text-[10px] tracking-wider flex items-center gap-1.5">
              <span>Quantum Copilot</span>
              <span className="text-[8px] px-1 bg-[#1a1b24] text-orange-400 rounded">v1.2</span>
            </div>
            <div className="text-[8px] text-gray-500">Intrication Cognitive Active</div>
          </div>
        </div>

        {/* Clear History Button */}
        <button
          onClick={handleClearHistory}
          title="Vider la mémoire"
          className="p-1.5 rounded hover:bg-[#151720] text-gray-500 hover:text-red-400 transition-colors"
        >
          <Trash2 className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* METRICS & INTRICACY STATS BAR */}
      <div className="bg-[#08090d] border-b border-[#121319] p-2.5 flex items-center justify-between text-[9px] text-gray-500">
        <div className="flex items-center gap-1.5">
          <Radio className="w-3 h-3 text-emerald-500 animate-ping" />
          <span className="uppercase text-[8px] font-bold text-gray-400">Intrication :</span>
          {intricacyTarget ? (
            <span className="text-emerald-400 truncate max-w-[120px]" title={intricacyTarget}>
              @{intricacyTarget.split("/").pop()}
            </span>
          ) : (
            <span className="text-gray-600 italic">Aucun fichier</span>
          )}
        </div>

        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1">
            <span className="text-gray-600">Cohérence :</span>
            <span className="font-bold text-orange-400">{(bridgeState.coherenceScore * 100).toFixed(0)}%</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-gray-600">Phi-Mod :</span>
            <span className="font-bold text-purple-400">1.618</span>
          </div>
        </div>
      </div>

      {/* CHAT MESSAGES DISPLAY ZONE */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-3 space-y-3 bg-[#050608]"
      >
        <AnimatePresence initial={false}>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.2 }}
              className={`flex flex-col space-y-1 ${
                msg.role === "user" ? "items-end" : "items-start"
              }`}
            >
              {/* Sender eyebrow */}
              <div className="text-[8px] text-gray-500 px-1">
                {msg.role === "user" ? "INGÉNIEUR" : "COPILOTE QUANTIQUE"} — {msg.timestamp}
              </div>

              {/* Message body */}
              <div
                className={`p-2.5 rounded-lg max-w-[90%] leading-relaxed border ${
                  msg.role === "user"
                    ? "bg-[#18120c] border-orange-500/20 text-orange-300"
                    : msg.isFallback
                    ? "bg-[#130d10] border-purple-500/15 text-purple-200"
                    : "bg-[#0b0c10] border-[#181920] text-gray-300"
                }`}
              >
                {/* Main text message */}
                <div className="whitespace-pre-wrap select-text text-[10px]">
                  {msg.content}
                </div>

                {/* Display proposed patch apply buttons */}
                {msg.proposedPatch && (
                  <div className="mt-3 pt-2.5 border-t border-[#1d1f2a] space-y-2">
                    <div className="text-[8px] text-gray-500 uppercase tracking-widest font-bold flex items-center gap-1">
                      <FileCode className="w-3 h-3 text-orange-400" /> Mutation proposée : /{msg.proposedFilePath}
                    </div>
                    
                    <div className="p-1.5 bg-[#030406] rounded border border-[#161720] text-[9px] text-orange-300 font-mono overflow-x-auto whitespace-pre max-h-36">
                      {msg.proposedPatch}
                    </div>

                    {!msg.appliedPatch ? (
                      <button
                        onClick={() => applyHotSwapPatch(msg.id, msg.proposedFilePath!, msg.proposedPatch!)}
                        className="w-full py-1.5 bg-orange-500 hover:bg-orange-400 text-black font-black uppercase rounded text-[9px] transition-all flex items-center justify-center gap-1"
                      >
                        <Workflow className="w-3 h-3" /> Appliquer le Patch Hot-Swap
                      </button>
                    ) : (
                      <div className="w-full py-1 bg-[#0b1510] border border-emerald-950 text-emerald-400 text-[9px] rounded font-bold uppercase flex items-center justify-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> Patch Appliqué avec succès
                      </div>
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {/* QUICK COMMAND DIRECT SHORTCUTS */}
      <div className="bg-[#07080b] border-t border-[#121319] p-2 flex gap-1.5 overflow-x-auto">
        <button
          onClick={() => setInputValue("Crée la page de contact")}
          disabled={isGenerating}
          className="px-2.5 py-1.5 bg-[#0e0f14] hover:bg-[#171924] border border-[#1f2029] rounded-md text-[9px] text-gray-400 hover:text-gray-200 transition-colors shrink-0 flex items-center gap-1"
        >
          <Command className="w-3 h-3 text-orange-400" />
          Crée Contact
        </button>
        <button
          onClick={() => setInputValue("Corrige l'erreur de rendu")}
          disabled={isGenerating}
          className="px-2.5 py-1.5 bg-[#0e0f14] hover:bg-[#171924] border border-[#1f2029] rounded-md text-[9px] text-gray-400 hover:text-gray-200 transition-colors shrink-0 flex items-center gap-1"
        >
          <RotateCcw className="w-3 h-3 text-purple-400 animate-spin-slow" />
          Corrige l'erreur
        </button>
        <button
          onClick={() => setInputValue("Comment fonctionne la mémoire quantique ?")}
          disabled={isGenerating}
          className="px-2.5 py-1.5 bg-[#0e0f14] hover:bg-[#171924] border border-[#1f2029] rounded-md text-[9px] text-gray-400 hover:text-gray-200 transition-colors shrink-0 flex items-center gap-1"
        >
          <Sparkles className="w-3 h-3 text-yellow-400" />
          Explique Système
        </button>
      </div>

      {/* CHAT INPUT AREA */}
      <form 
        onSubmit={handleSendMessage}
        className="bg-[#0b0c10] border-t border-[#181920] p-2 flex gap-2 items-center"
      >
        <input
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder={isGenerating ? "Le Copilote synthétise la réponse..." : "Saisir une directive en langage naturel..."}
          disabled={isGenerating}
          className="flex-1 bg-[#050608] border border-[#181920] rounded-lg px-2.5 py-2 text-[10px] text-gray-200 focus:outline-none focus:border-orange-500/50"
        />
        
        <button
          type="submit"
          disabled={!inputValue.trim() || isGenerating}
          className={`p-2 rounded-lg transition-colors flex items-center justify-center ${
            !inputValue.trim() || isGenerating
              ? "bg-[#111217] text-gray-600 cursor-not-allowed"
              : "bg-orange-500 hover:bg-orange-400 text-black"
          }`}
        >
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>

    </div>
  );
}
