export interface WorkspaceFile {
  name: string;
  path: string;
  content: string;
  type: 'file' | 'directory';
  children?: WorkspaceFile[];
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  agentName?: string; // e.g. @agent_main, @agent_config
}

export interface NotebookConversation {
  id: string;
  title: string;
  messages: ChatMessage[];
  createdAt: string;
  updatedAt: string;
}

export interface FileAgentInfo {
  name: string;
  filePath: string;
  status: 'idle' | 'analyzing' | 'synthesizing' | 'active';
  latency: number; // ms
  pulseRate: number; // Heartbeats per minute
  lastActive: string;
}

export interface InspectorLog {
  id: string;
  agent: 'Compilateur' | 'ProCoder' | 'Expert d\'Installation';
  status: 'info' | 'success' | 'warning' | 'error';
  message: string;
  timestamp: string;
}

export interface BudgetConfig {
  inputTokenPrice: number; // price per million tokens
  outputTokenPrice: number; // price per million tokens
  inputMultiplier: number; // coefficient multiplier
  outputMultiplier: number;
  tpsTax: boolean; // 5%
  tvqTax: boolean; // 9.975%
  emergencyBudget: boolean; // 7.5% contingency
}

export interface BudgetCalculation {
  inputTokens: number;
  outputTokens: number;
  rawCost: number;
  multiplierCost: number;
  taxes: number;
  contingency: number;
  totalCost: number;
  complianceRating: 'excellent' | 'warning' | 'critical';
  complianceDetails: string[];
}

export interface AgentNode {
  id: string;
  name: string;
  role: string;
  status: 'online' | 'degraded' | 'offline';
  latency: number;
  connections: string[]; // target agent IDs
}

export interface AgentNetworkState {
  nodes: AgentNode[];
  interconnectionEnabled: boolean;
  systemLoad: number;
}

export interface EngaticQuantumCoupling {
  quantumCoherence: number;          // Récupéré de quantumCognitiveBridge.getState().coherenceScore
  entropyLevel: number;              // Récupéré de quantumCognitiveBridge.getState().entropyLevel
  phase: "SYNCHRONIZED" | "SUPERPOSITION" | "COLLAPSED" | "RESONANT";
  phiCorrectionFactor: number;       // Calculé via computePhiHarmonic(tokens)
  activeQubits: number[];            // Vecteur d'état qubitStates
  isResilientFallbackActive: boolean; // True si l'erreur 429 a effondré la fonction d'onde
}

export interface CodeStudioContract {
  activeFile: string | null;           // Fichier en cours d'édition dans l'IDE
  fileTreeSnapshot: WorkspaceFile[];   // Arbre de fichiers actuel
  activeMutation: {
    description: string;
    timestamp: string;
    patchLength: number;
  } | null;                            // Mutation en cours de génération
  linterStatus: "CLEAN" | "WARNING" | "ERROR";
  hotSwapActive: boolean;              // Si l'injection temps réel est opérationnelle
  attachedAgents: [
    "pro_coder", 
    "source_code_analyzer", 
    "live_ide_executor", 
    "code_synchronizer", 
    "tool_reconfigurator", 
    "inspector_mode_controller", 
    "inspector_ide_translator",
    "user_intent_analyst",
    "deployer_agent",
    "visual_structural_orchestrator"
  ];
}
